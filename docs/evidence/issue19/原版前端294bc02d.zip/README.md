# MES 對話前端

## 自動圖表與查詢重點（2026-10-13）

查詢完成後直接顯示摘要與自動推薦圖表。推薦層依欄位語意、資料條件及問題意圖，選擇長條、折線、點圖、散佈、熱圖或堆疊圖；可切換符合條件的圖型，不另查資料或呼叫模型。完整量與已知部分分開，缺值維持未知，圖表數值、明細與 Excel 沿用原保存結果。

本次以前端隔離 fixture 驗證，未以測試資料宣稱真實模型對答品質。正式資源封裝版本為 `mes-assistant-ui-20261013-r46`；本機建置與部署包不代表已部署到客戶主機。

React／TypeScript／assistant-ui 與 shadcn 元件呈現 MES 問答、活動摘要、歷史、圖表、依據及既有管理功能。使用原 ChatController，不新增模型、草稿或 API 呼叫流程。

## 開發

```sh
npm ci
npm run check
npm run build
npm run dev
```

Node 版本依 package.json engines，鎖版以 package-lock.json 為準。dev 為本機預覽入口；正式宿主使用 widget IIFE。預覽登入僅供隔離開發，不代表正式 MES Token 核驗已完成，不封裝入 Widget。

## 現行聊天行為

等待時只顯示一行真實動態活動；實際查詢才加入可展開紀錄，預設收合。沒有工具事件就不補五階段空列，沒有計時器編造進度。已通過後端驗證的答案立即呈現，不等待開合；手動展開不被完成事件強制收走，歷史與重連不重播。

後端 response_kind 區分澄清、資料不足、業務解釋與保存結果整理。澄清不誤顯示 MES 資料不足；實際工具缺項、失敗、保存失敗仍呈現。純整理回覆依 server 的 source_request_id 顯示「沒有重新查詢 MES」，不從正文推測來源。

資料、圖表與 Excel 使用已保存結構，不解析 Markdown 抓數字。追問按鈕只填入原草稿，使用者送出後才產生新請求。原生中文輸入、訊息編輯、權限、取消與幂等行為維持原樣。

## 文件與部署

`/docs` 是獨立唯讀預覽頁，不掛載聊天或執行模型。`npm run documentation` 只發布白名單 Markdown；核對路徑、大小與 SHA，不發布 archive、診斷、帳本或本機秘密。Mermaid 區塊保留程式碼，沒有額外安裝圖形引擎。

build 同步六項正式資產與三份文件到 `outputs/wwwroot-mes-ai-copilot-folder-v2/wwwroot/mes-ai-copilot`。每次部署先使用同版來源重新 build，不混用歷史 r42 編譯檔。修改後端對話契約需同步載入最新後端並建立新聊天；完成 CI 不代表客戶主機已部署。

[設計規範](DESIGN_SYSTEM.md) · [對話契約](../../docs/Emerald_多輪對話.md) · [部署手冊](../../docs/Emerald_正式資料模式與部署.md) · [歷史入口](../../docs/archive/README.md)
