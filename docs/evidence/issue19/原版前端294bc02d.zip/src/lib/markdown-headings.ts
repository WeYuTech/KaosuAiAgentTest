/** 文件標題沿用 GitHub 常見 slug，保留中文字。 */
export function headingSlug(text: string): string {
    return text.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\p{L}\p{N}\p{M}_-]/gu, '') || 'section';
}
