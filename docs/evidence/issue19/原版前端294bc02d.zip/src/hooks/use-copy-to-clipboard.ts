"use client";

import { useEffect, useRef, useState } from "react";

export type UseCopyToClipboardOptions = {
  copiedDuration?: number;
  fallback?: (value: string) => void | Promise<void>;
};

/** 相容請求交回既有控制器；其結果未知時不顯示假的「已複製」 */
export async function copyTextWithFallback(value: string, clipboard?: Pick<Clipboard, 'writeText'>, fallback?: UseCopyToClipboardOptions['fallback']): Promise<boolean> {
  if (!value) return false;
  if (clipboard) {
    try {await clipboard.writeText(value); return true;} catch { /* 權限拒絕時沿用宿主的相容回報 */ }
  }
  try {await fallback?.(value);} catch { /* 複製失敗不產生未處理的 Promise */ }
  return false;
}

export const useCopyToClipboard = ({
  copiedDuration = 3000,
  fallback,
}: UseCopyToClipboardOptions = {}) => {
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const copiedTimerRef = useRef<ReturnType<typeof setTimeout> | undefined>(
    undefined,
  );
  const scopeGenerationRef = useRef(0);

  useEffect(
    () => () => {
      scopeGenerationRef.current += 1;
      if (copiedTimerRef.current === undefined) return;

      clearTimeout(copiedTimerRef.current);
      copiedTimerRef.current = undefined;
      setIsCopied(false);
    },
    [fallback],
  );

  const copyToClipboard = (value: string) => {
    if (!value) return;

    const scopeGeneration = scopeGenerationRef.current;
    void copyTextWithFallback(value, typeof navigator === 'undefined' ? undefined : navigator.clipboard,
      fallback ? text => {if (scopeGeneration === scopeGenerationRef.current) return fallback(text);} : undefined).then(
      nativeCopied => {
        if (!nativeCopied || scopeGeneration !== scopeGenerationRef.current) return;

        if (copiedTimerRef.current !== undefined) {
          clearTimeout(copiedTimerRef.current);
        }
        setIsCopied(true);
        copiedTimerRef.current = setTimeout(() => {
          copiedTimerRef.current = undefined;
          setIsCopied(false);
        }, copiedDuration);
      },
      () => {},
    );
  };

  return { isCopied, copyToClipboard };
};
