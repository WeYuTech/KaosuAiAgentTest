import {useSyncExternalStore} from 'react';

const query = '(prefers-reduced-motion: reduce)';
function subscribe(changed: () => void) {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return () => {};
    const preference = window.matchMedia(query);
    preference.addEventListener('change', changed);
    return () => preference.removeEventListener('change', changed);
}
function read() {return typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia(query).matches;}

/** 沿用系統動畫偏好，支援執行中變更且不保存第二份設定 */
export function useReducedMotion() {return useSyncExternalStore(subscribe, read, () => false);}
