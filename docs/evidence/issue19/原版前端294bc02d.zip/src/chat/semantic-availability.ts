import type {SemanticReportColumn} from './types';

const finiteCount = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && Number.isInteger(value) && value > 0;

/** 摘要與圖表只依同卡保存的欄位關係判斷；不猜業務欄名或借用其他來源。 */
export function savedSemanticMetricAvailable(column: SemanticReportColumn, values: Record<string, unknown>, columns: readonly SemanticReportColumn[]): boolean {
    if (column.value_guards?.some(guard => guard.operator === 'eq' ? values[guard.field] !== guard.value :
        typeof values[guard.field] !== 'number' || !Number.isFinite(values[guard.field]) || typeof guard.value !== 'number' || (values[guard.field] as number) < guard.value)) return false;
    const value = values[column.name];
    if (column.data_type === 'number' && (typeof value !== 'number' || !Number.isFinite(value)) || column.data_type === 'boolean' && typeof value !== 'boolean' ||
        ['string', 'date', 'datetime'].includes(column.data_type) && typeof value !== 'string') return false;
    const needsEvidence = column.completeness_required === true || column.interpretation === 'known_partial' || column.availability_count_field !== undefined;
    if (!needsEvidence) return true;
    const missing = column.required_missing_fields;
    if (typeof column.completeness_required !== 'boolean' || !Array.isArray(missing) ||
        (column.completeness_required ? missing.length === 0 : missing.length !== 0) || new Set(missing).size !== missing.length) return false;
    const sameSource = (target: SemanticReportColumn) => column.source_group === undefined || target.source_group === column.source_group;
    const count = columns.find(target => target.name === column.availability_count_field && target.name !== column.name &&
        target.availability_count_field === undefined && target.data_type === 'number' && sameSource(target) &&
        (target.role === 'quality' || target.role === 'metric' && target.interpretation === 'count'));
    if (!count || !finiteCount(values[count.name])) return false;
    return missing.every(field => typeof field === 'string' && columns.some(target => target.name === field && target.name !== column.name &&
        target.role === 'quality' && target.data_type === 'number' && sameSource(target)) && values[field] === 0);
}
