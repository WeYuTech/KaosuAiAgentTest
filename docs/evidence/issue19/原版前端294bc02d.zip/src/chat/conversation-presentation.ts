import type {Turn} from './types';

export function hasAnswerFailure(turn?: Turn | null): boolean {
    return !!turn?.result_reasons?.some(reason => reason === 'verification_failed' || reason === 'task_incomplete');
}

/** 新契約區分澄清與資料缺項；未知／舊紀錄保留原本的警告。 */
export function hasDataLimitation(turn?: Turn | null): boolean {
    if (turn?.status !== 'insufficient_data') return false;
    const observed = turn.evidence?.some(item => item.status === 'no_data' || item.status === 'insufficient_data');
    if (turn.result_reasons != null) return !!observed || turn.result_reasons.includes('data_unavailable');
    return turn.response_kind !== 'clarification' || !!observed;
}

export function completedConversationLabel(turn?: Turn | null): string {
    if (hasAnswerFailure(turn)) return '回答未完成';
    if (turn?.result_reasons?.includes('unsupported_capability')) return '部分要求未支援';
    if (hasDataLimitation(turn)) return '已回答 · 資料不足';
    return turn?.response_kind === 'clarification' ? '等待補充條件' : '已完成';
}
