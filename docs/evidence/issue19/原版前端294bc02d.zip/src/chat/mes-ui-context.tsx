import { createContext, useContext, useRef, type ReactNode } from 'react';
import type { ChatControllerResult } from './types';

export interface ReadingPosition {top: number; sticky: boolean}
const MesUiContext = createContext<(ChatControllerResult & {readingPositions: Map<string, ReadingPosition>}) | null>(null);

/** 將 MES 保存結果與動作交給官方聊天元件的擴充區，不建立第二套 API 流程。 */
export function MesUiProvider({state, actions, children}: ChatControllerResult & {children: ReactNode}) {
    const positions = useRef(new Map<string, ReadingPosition>());
    return <MesUiContext.Provider value={{state, actions, readingPositions: positions.current}}>{children}</MesUiContext.Provider>;
}

export function useMesUi() {
    const value = useContext(MesUiContext);
    if (!value) throw new Error('MES 畫面需要 MesUiProvider');
    return value;
}
