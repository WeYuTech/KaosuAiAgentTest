/** 舊圖表與摘要規則只在報告解碼時轉換，保留保存當時口徑，不讀目前 MDL。 */
import {reportText} from './report';
import type {ChartPlan} from './chart-planner';
import type {RawReportCard, ReportCard, ReportColumn, ReportDisplayMetric, ReportMetric, SemanticReportColumn} from './types';
interface ReportChartPoint { label: string; value: number }
interface ReportChartData { title: string; measure: string; unit: string; points: ReportChartPoint[]; notices: string[] }
interface ReportChartSeries { key: string; label: string }
interface ReportChartPanelPoint { label: string; values: Record<string, number | null> }
interface ReportChartPanel {
    id: string;
    title: string;
    kind: 'bar' | 'line';
    measure: string;
    unit: string;
    series: ReportChartSeries[];
    points: ReportChartPanelPoint[];
    notices: string[];
}
const MAX_POINTS = 8;
const finite = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value);
const identity = (value: unknown): string => typeof value === 'string' || typeof value === 'number' ? String(value) : '';
const metric = (card: ReportCard, key: string) => card.metrics?.find(item => item.key === key);

function semanticValue(row: Record<string, unknown>, column: SemanticReportColumn): number | null {
    const value = row[column.name];
    return finite(value) && legacyMetricAvailable(column, row) ? value : null;
}

/** 僅為呈現核對保存時間的間距，不轉換標籤或補造缺少的日期 */
function savedTime(value: unknown, type: 'date' | 'datetime' | 'month'): number | null {
    if (typeof value !== 'string') return null;
    if (type === 'month') return /^\d{4}-(0[1-9]|1[0-2])$/.test(value) ? Number(value.slice(0, 4)) * 12 + Number(value.slice(5, 7)) : null;
    const date = value.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
    const day = Date.parse(`${date}T00:00:00Z`);
    if (!Number.isFinite(day) || new Date(day).toISOString().slice(0, 10) !== date) return null;
    if (type === 'date') return value === date ? day : null;
    if (!/^\d{4}-\d{2}-\d{2}[T ]([01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-]([01]\d|2[0-3]):[0-5]\d)$/.test(value)) return null;
    const time = Date.parse(value.replace(' ', 'T'));
    return Number.isFinite(time) ? time : null;
}

function continuousSavedTimes(rows: Record<string, unknown>[], key: string, type: 'date' | 'datetime' | 'month'): boolean {
    if (rows.length < 2) return false;
    let previous: number | null = null;
    let interval: number | null = type === 'date' ? 86_400_000 : type === 'month' ? 1 : null;
    for (const row of rows) {
        const value = savedTime(row[key], type);
        if (value === null) return false;
        if (previous !== null) {
            const difference = value - previous;
            if (difference <= 0 || (interval !== null && difference !== interval)) return false;
            interval = difference;
        }
        previous = value;
    }
    return true;
}

/** 只有封閉數量欄位家族與相同保存單位可共軸，未知指標保持各自呈現 */
function semanticMetricGroups(columns: SemanticReportColumn[]): SemanticReportColumn[][] {
    const groups = new Map<string, SemanticReportColumn[]>();
    for (const column of columns) {
        if (column.role !== 'metric' || column.data_type !== 'number') continue;
        let family = column.name;
        if (['produced_quantity', 'good_quantity', 'scrap_quantity'].includes(column.name)) family = 'quantity:complete';
        if (['known_produced_quantity', 'known_good_quantity', 'known_scrap_quantity'].includes(column.name)) family = 'quantity:known';
        const key = JSON.stringify([family, column.unit || '', column.interpretation || '']);
        groups.set(key, [...(groups.get(key) || []), column]);
    }
    return [...groups.values()];
}

/** 每個已核准指標直接投影保存值；折線保留 null，呈現端不得跨缺值連線 */
function reportChartPanels(card: ReportCard): ReportChartPanel[] {
    if (!legacyAnswerVisible(card) || card.status === 'no_data' || card.status === 'failed') return [];
    const rows = (card.detail?.rows || []).filter(row => row && typeof row === 'object');
    if (card.kind === 'semantic_query') {
        const columns = card.chart_contract === 'unavailable' ? [] : card.semantic_columns || [];
        const dimensions = columns.filter(column => column.role === 'dimension');
        if (!dimensions.length) return [];
        const dimension = dimensions.length === 1 ? dimensions[0] : undefined;
        const timeType = dimension?.name === 'production_month' && ['date', 'string'].includes(dimension.data_type) ? 'month'
            : dimension?.data_type === 'date' || dimension?.data_type === 'datetime' ? dimension.data_type : undefined;
        const kind = dimension && timeType && continuousSavedTimes(rows, dimension.name, timeType) ? 'line' : 'bar';
        return semanticMetricGroups(columns).flatMap(group => {
            const notices: string[] = [], points: ReportChartPanelPoint[] = [];
            const missing = new Map(group.map(column => [column.name, 0]));
            const partial = group[0].interpretation === 'known_partial';
            for (const row of rows) {
                const completeIdentity = dimensions.every(dimension => dimension.name in row);
                const values = Object.fromEntries(group.map(column => {
                    const value = completeIdentity ? semanticValue(row, column) : null;
                    if (value === null) missing.set(column.name, missing.get(column.name)! + 1);
                    return [column.name, value];
                }));
                if (!completeIdentity) continue;
                const label = dimensions.map(dimension => identity(row[dimension.name]) || '未知').join(' · ') + (partial ? '（已知部分）' : '');
                // 共用原列位置，各指標自行保留缺值，避免錯把另一列的數值對在同一對象。
                points.push({label, values});
            }
            const visiblePoints = points.slice(0, MAX_POINTS);
            if (!visiblePoints.some(point => Object.values(point.values).some(value => value !== null))) return [];
            for (const column of group) if (missing.get(column.name)) notices.push(`${column.label}有 ${missing.get(column.name)} 筆數量或維度未完整取得，未補零`);
            if (partial) notices.push('標記為已知部分的數量不能當成完整產量');
            if (dimensions.some(dimension => dimension.name === 'personnel_group')) notices.push('依人員組合顯示，不拆分為各人的獨立績效');
            const pagination = card.pagination as {offset?: number; truncated?: boolean; has_more?: boolean} | undefined;
            if (pagination?.truncated || pagination?.has_more || (pagination?.offset || 0) > 0) notices.push('查詢結果有分頁或截斷，不代表所有資料');
            notices.push('各列保留完整查詢維度與保存順序，未跨列加總或重新排名');
            if (points.some(point => Object.values(point.values).some(value => value !== null && value < 0))) notices.push('包含負數紀錄，保留原值，未自行修正');
            const unit = group[0].unit || '';
            if (!unit) notices.push('數量單位尚未驗證');
            if (points.length > MAX_POINTS) notices.push(`顯示已保存順序的前 ${MAX_POINTS} 項／共 ${points.length} 項，完整資料請查看明細`);
            const measure = group.map(column => column.label).join('／');
            return [{id: `${card.id}:${group.map(column => column.name).join(':')}`, title: card.title || measure, kind, measure, unit,
                series: group.map(column => ({key: column.name, label: column.label})), points: visiblePoints, notices}];
        });
    }
    const data = reportChartData(card);
    if (!data) return [];
    const monthlyTrend = card.kind === 'reporting_coverage' && continuousSavedTimes(rows, 'production_month', 'month');
    const points = monthlyTrend
        ? rows.slice(0, MAX_POINTS).map(row => ({label: identity(row.production_month) + (row.quantity_complete === false ? '（已知部分）' : ''), values: {value: finite(row.produced_quantity) ? row.produced_quantity : null}}))
        : data.points.map(point => ({label: point.label, values: {value: point.value}}));
    if (!points.some(point => Object.values(point.values).some(value => value !== null))) return [];
    const notices = [...data.notices];
    if (monthlyTrend && rows.length > MAX_POINTS) {
        const range = `顯示已保存順序的前 ${MAX_POINTS} 項／共 ${rows.length} 項，完整資料請查看明細`;
        const previous = notices.findIndex(notice => notice.startsWith('顯示已保存順序的前 '));
        if (previous >= 0) notices[previous] = range;
        else notices.push(range);
    }
    return [{id: card.id, title: data.title, kind: monthlyTrend ? 'line' : 'bar', measure: data.measure, unit: data.unit,
        series: [{key: 'value', label: data.measure}], points, notices}];
}

/** 僅投影已保存的工具欄位，不解析回答、補缺值、重算產量或產生排名 */
function reportChartData(card: ReportCard): ReportChartData | null {
    if (!legacyAnswerVisible(card)) return null;
    if (card.status === 'no_data' || card.status === 'failed') return null;
    let points: ReportChartPoint[] = [], unit = '', measure = '報工產量';
    const notices: string[] = [];
    const rows = (card.detail?.rows || []).filter(row => row && typeof row === 'object');
    const selectedMetrics = (items: (ReportMetric | undefined)[]) => {
        const valid = items.filter((item): item is ReportMetric & {value: number} => !!item && finite(item.value));
        // 不同單位不能混在同一數值軸，沒有驗證的單位保持空白
        const units = new Set(valid.map(item => item.unit || ''));
        if (units.size > 1) return;
        unit = valid[0]?.unit || '';
        points = valid.map(item => ({label: item.label || item.key, value: item.value}));
        if (valid.length !== items.length) notices.push('部分數值未取得，未補零');
    };
    if (card.kind === 'work_order') {
        selectedMetrics([metric(card, 'produced_quantity'), metric(card, 'planned_quantity')]);
        measure = '已報工與目標產量';
        if (card.quantity_complete === false || rows.some(row => row.quantity_complete === false)) {
            points = points.map((point, index) => ({...point, label: index === 0 && finite(metric(card, 'produced_quantity')?.value) ? '已知報工量（部分）' : point.label}));
            notices.push('僅包含已知報工量，不能據此計算完整完成率');
        }
    } else if (card.kind === 'work_order_cycle' || card.kind === 'machine_cycle') {
        const samples = metric(card, 'interval_sample_count')?.value;
        if (card.status === 'insufficient_data' || !finite(samples) || samples < 2) return null;
        const machine = card.kind === 'machine_cycle';
        selectedMetrics((machine ? ['minimum_cycle_seconds', 'average_cycle_seconds', 'maximum_cycle_seconds'] : ['minimum_seconds', 'average_seconds', 'maximum_seconds']).map(key => metric(card, key)));
        if (points.some(point => point.value < 0)) return null;
        measure = 'Cycle 統計';
        notices.push('統計摘要，不代表時間趨勢或正常／故障判定');
    } else if (['shift_production', 'machine_production', 'personnel_production', 'reporting_coverage', 'reporting_records'].includes(card.kind)) {
        const key = card.kind === 'shift_production' ? 'total_quantity' : 'produced_quantity';
        unit = metric(card, key)?.unit || '';
        let missing = 0, partial = false;
        for (const [index, row] of rows.entries()) {
            const value = row[key];
            if (!finite(value)) {missing++; continue;}
            let label = '';
            if (card.kind === 'machine_production') label = identity(row.machine_id);
            else if (card.kind === 'personnel_production') label = identity(row.personnel_group);
            else if (card.kind === 'reporting_coverage') label = identity(row.production_month);
            else if (card.kind === 'reporting_records') label = [identity(row.task_id), identity(row.reported_at)].filter(Boolean).join(' · ');
            else label = [identity(row.work_order_no), identity(row.machine_id), identity(row.shift_no)].filter(Boolean).join(' · ');
            if (!label) label = `紀錄 ${index + 1}`;
            if (row.quantity_complete === false) {partial = true; label += '（已知部分）';}
            points.push({label, value});
        }
        if (missing) notices.push(`${missing} 筆數量未取得，未補零`);
        if (partial) notices.push('標記為已知部分的數量不能當成完整產量');
        if (card.kind === 'personnel_production') notices.push('依人員組合顯示，不拆分為各人的獨立績效');
        if (card.kind === 'shift_production') notices.push('每列為班別工單紀錄，未自行合併或排名');
        if (card.kind === 'reporting_records') notices.push('僅顯示本頁已保存作業，不代表工單完整合計');
        const pagination = card.pagination as {has_more?: boolean; truncated?: boolean} | undefined;
        if (pagination?.has_more || pagination?.truncated || card.months_truncated === true) notices.push('查詢結果有分頁或截斷，不代表所有資料');
    } else return null;
    if (!points.length) return null;
    if (points.some(point => point.value < 0)) notices.push('包含負數紀錄，保留原值，未自行修正');
    if (!unit) notices.push('數量單位尚未驗證');
    if (points.length > MAX_POINTS) notices.push(`顯示已保存順序的前 ${MAX_POINTS} 項／共 ${points.length} 項，完整資料請查看明細`);
    return {title: card.title || measure, measure, unit, points: points.slice(0, MAX_POINTS), notices};
}


/** r44 的保存數量規則保持凍結，只供舊報告轉換，不讀現行語意定義。 */
function legacyMetricAvailable(column: SemanticReportColumn, values: Record<string, unknown>): boolean {
    const quantity = ['produced_quantity', 'good_quantity', 'scrap_quantity', 'known_produced_quantity', 'known_good_quantity', 'known_scrap_quantity'];
    if (!quantity.includes(column.name) && !column.completeness_required && column.interpretation !== 'known_partial') return true;
    const missing = column.required_missing_fields;
    if (!Array.isArray(missing) || typeof column.completeness_required !== 'boolean' ||
        (column.completeness_required ? missing.length === 0 : missing.length !== 0) || new Set(missing).size !== missing.length) return false;
    const count = values.operation_count;
    return typeof count === 'number' && Number.isInteger(count) && count > 0 &&
        missing.every(field => ['missing_good_count', 'missing_scrap_count'].includes(field) && values[field] === 0);
}

const quantityKeys = ['produced_quantity', 'good_quantity', 'scrap_quantity', 'known_produced_quantity', 'known_good_quantity', 'known_scrap_quantity'];
const businessKeys: Record<string, readonly string[]> = {
    work_order: ['completion_percent', 'produced_quantity', 'planned_quantity', 'good_quantity', 'scrap_quantity', 'efficiency_percent'],
    running_orders: ['work_order_count', 'machine_count'],
    shift_production: ['total_quantity', 'good_quantity', 'scrap_quantity', 'comparison_count'],
    machine_production: quantityKeys,
    personnel_production: quantityKeys,
    reporting_records: quantityKeys,
    reporting_coverage: quantityKeys,
    machine_cycle: ['average_cycle_seconds', 'minimum_cycle_seconds', 'maximum_cycle_seconds'],
    work_order_cycle: ['average_seconds', 'minimum_seconds', 'maximum_seconds'],
    work_order_oee: ['operation_count'],
    machine_oee: ['operation_count'],
    oee_readiness: ['operation_count'],
};


export function legacyAnswerVisible(card: RawReportCard): boolean {
    return card.presentation !== 'evidence' && (card.kind !== 'reporting_coverage' || card.presentation === 'answer');
}

function legacyMetricPresentation(card: ReportCard) {
    const metrics = card.metrics || [];
    const metricValue = (key: string) => metrics.find(metric => metric.key === key)?.value;
    const produced = metricValue('produced_quantity'), planned = metricValue('planned_quantity'), completion = metricValue('completion_percent');
    const validCompletion = card.status === 'ok' && finite(planned) && planned > 0 && finite(produced) && produced >= 0 && finite(completion) && completion >= 0 && Number.isFinite(produced / planned * 100);
    const selected = card.kind === 'work_order' ? ['completion_percent', 'produced_quantity', 'planned_quantity'].flatMap(key => metrics.filter(metric => metric.key === key).slice(0, 1)) : metrics.slice(0, 3);
    const labels: Record<string, string> = {completion_percent: '完成率', produced_quantity: '已報工', planned_quantity: '目標'};
    return selected.map(metric => {
        const known = finite(metric.value) && !(card.kind === 'work_order' && metric.key === 'completion_percent' && !validCompletion);
        return {...metric, label: card.kind === 'work_order' ? labels[metric.key] || metric.label || metric.key : metric.label || metric.key, displayValue: known ? reportText(metric.value) : '—', unit: known ? metric.unit || '' : ''};
    });
}

export function legacyDetailMetrics(card: ReportCard, highlights: ReportDisplayMetric[]): ReportDisplayMetric[] {
    const safe = new Map(highlights.map(item => [item.key, item]));
    const presentation = legacyMetricPresentation(card);
    return (card.metrics || []).map(metric => {
        const approved = safe.get(metric.key);
        const completion = card.kind === 'work_order' && metric.key === 'completion_percent' ? presentation.find(item => item.key === metric.key) : undefined;
        return {key: metric.key, label: completion ? '報工完成率' : approved?.label || metric.label || metric.key,
            value: approved ? approved.value : completion ? completion.displayValue : reportText(metric.value),
            unit: approved ? approved.unit : completion ? completion.unit : finite(metric.value) ? metric.unit || '' : '',
            detail: approved?.detail || metric.detail};
    });
}

export function legacyDetailColumns(card: ReportCard): ReportColumn[] {
    return (card.detail?.columns || []).map(column => ({...column, label: card.kind === 'work_order' && column.key === 'completion_percent' ? '報工完成率' : column.label || column.key}));
}

/** 直接呈現已保存的業務摘要，不加總明細、不排名、不解析模型答案 */
export function legacyHighlights(card: ReportCard): ReportDisplayMetric[] {
    if (card.chart_contract === 'unavailable' || !legacyAnswerVisible(card) || card.status === 'no_data' || card.status === 'failed') return [];
    const metrics = Array.isArray(card.metrics) ? card.metrics.filter((metric): metric is ReportMetric => !!metric && typeof metric === 'object' && typeof metric.key === 'string') : [];
    const keys = businessKeys[card.kind];
    if (!keys) return [];
    const rows = Array.isArray(card.detail?.rows) ? card.detail.rows : [];
    const incomplete = card.quantity_complete === false || rows.some(row => row?.quantity_complete === false);
    // 舊快照可能保留相容的零完成率，缺量時仍經原 presentation 規則隱藏
    const presentation = legacyMetricPresentation(card.kind === 'work_order' && incomplete ? {...card, status: 'insufficient_data'} : card);
    const cycle = card.kind === 'machine_cycle' || card.kind === 'work_order_cycle';
    const samples = metrics.find(metric => metric.key === 'interval_sample_count')?.value;
    const cycleAvailable = !cycle || (card.status !== 'insufficient_data' && finite(samples) && samples >= 2);
    const seen = new Set<string>();
    return metrics.filter(metric => {
        if (!keys.includes(metric.key) || seen.has(metric.key)) return false;
        seen.add(metric.key);
        return true;
    }).map(metric => {
        const displayed = presentation.find(item => item.key === metric.key);
        const known = finite(metric.value) && cycleAvailable && !(cycle && metric.value < 0) &&
            !(card.kind === 'work_order' && metric.key === 'completion_percent' && displayed?.displayValue === '—');
        const partial = metric.key.startsWith('known_') ||
            (incomplete && ['work_order', 'shift_production'].includes(card.kind) && ['produced_quantity', 'total_quantity', 'good_quantity', 'scrap_quantity'].includes(metric.key));
        return {
            key: metric.key,
            label: (metric.label || displayed?.label || metric.key) + (partial ? '（已知部分）' : ''),
            value: known ? displayed?.displayValue || reportText(metric.value) : '未知',
            unit: known ? metric.unit || '' : '',
            ...(!known ? {detail: cycle ? '有效樣本不足或數值未取得' : '資料未完整取得'} : partial ? {detail: '不能當成完整產量'} : metric.detail ? {detail: metric.detail} : {}),
        };
    });
}

const IDENTITY = '__saved_identity';

/** 固定工具的偏好只引用原明細；部分量沿凍結欄位契約及原計數判斷。 */
export function fixedPreferenceInput(card: ReportCard, selected: string[]): NonNullable<ReportCard['chart_input']> {
    const detailKeys = card.detail?.columns?.map(column => column.key) || [];
    const known = new Set(['known_good_quantity', 'known_scrap_quantity', 'known_produced_quantity']);
    const complete = new Set(['good_quantity', 'scrap_quantity', 'produced_quantity', 'total_quantity']);
    const columns: SemanticReportColumn[] = [{name: IDENTITY, label: '保存完整明細列', role: 'dimension', data_type: 'string'},
        ...selected.map(key => ({name: key, label: (card.detail?.columns?.find(column => column.key === key)?.label || card.metrics?.find(metric => metric.key === key)?.label || key) + (known.has(key) ? '（已知部分）' : ''),
            role: 'metric' as const, data_type: 'number' as const, unit: card.metrics?.find(metric => metric.key === key)?.unit || null,
            ...(known.has(key) ? {interpretation: 'known_partial', completeness_required: false, required_missing_fields: [], availability_count_field: 'operation_count'} : {})}))];
    if (selected.some(key => known.has(key))) {
        if (!columns.some(column => column.name === 'operation_count')) columns.push({name: 'operation_count', label: '保存作業數', role: 'quality', data_type: 'number', interpretation: 'count'});
        else columns.find(column => column.name === 'operation_count')!.interpretation = 'count';
    }
    const rows = (card.detail?.rows || []).map(row => ({
        ...Object.fromEntries(selected.map(key => [key, finite(row[key]) && !((row.quantity_complete === false || card.quantity_complete === false) && complete.has(key)) ? row[key] : null])),
        ...(selected.some(key => known.has(key)) ? {operation_count: row.operation_count} : {}),
        [IDENTITY]: JSON.stringify(detailKeys.map(key => [key, row[key]])),
    }));
    return {columns, rows};
}
export function legacyChartPlan(card: ReportCard): ChartPlan {
    return {recommended: reportChartPanels(card).map(panel => ({version: 1, id: `${panel.id}:legacy`, groupId: `${panel.id}:legacy`, sourceRef: card.id,
        mark: panel.kind, title: panel.title, reason: '舊快照沿用已核准的保存圖表口徑', encoding: {x: IDENTITY, y: panel.series[0].key, series: panel.series.map(series => series.key)},
        columns: [{name: IDENTITY, label: '保存對象', role: 'dimension', data_type: 'string'}, ...panel.series.map(series => ({name: series.key, label: series.label, role: 'metric' as const, data_type: 'number' as const, unit: panel.unit}))],
        points: panel.points.map((point, rowIndex) => ({rowIndex, label: point.label, dimensions: {[IDENTITY]: point.label}, values: {...point.values}})), unit: panel.unit, measure: panel.measure, notices: [...panel.notices],
        scope: {kind: 'saved_rows', totalRows: card.detail?.rows?.length || panel.points.length, shownRows: panel.points.length, paginated: !!((card.pagination as {truncated?: boolean; has_more?: boolean; offset?: number} | undefined)?.truncated || (card.pagination as {has_more?: boolean} | undefined)?.has_more || ((card.pagination as {offset?: number} | undefined)?.offset || 0) > 0)},
        missing: 'gap', order: 'source'})), alternatives: []};
}

