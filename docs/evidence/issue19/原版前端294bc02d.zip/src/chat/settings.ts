import type {Mode} from './types';

export interface ProviderValues {
    mode: Mode;
    api: {provider?: 'cloud' | 'local'; model: string; reasoning_effort: string};
    local?: {base_url: string; model: string; context_tokens: number};
    agent: {id: string; project_id: string; model: string; reasoning_effort: string};
}
export type ProviderDraft = ProviderValues & {api: ProviderValues['api'] & {provider: 'cloud' | 'local'}; local: NonNullable<ProviderValues['local']>};
export type SettingsField = 'mode' | 'api_key' | 'api.provider' | 'api.model' | 'api.reasoning_effort' | 'local.base_url' | 'local.model' | 'local.context_tokens' | 'agent.id' | 'agent.project_id' | 'agent.model' | 'agent.reasoning_effort';
export interface ProviderSettings {
    revision: string;
    effective: ProviderValues;
    saved: ProviderValues;
    api_key: {configured: boolean; saved_configured: boolean; source: string; editable: boolean};
    sources: Record<SettingsField, string>;
    locked_fields: SettingsField[];
    restart_required: boolean;
    apply: 'restart' | 'immediate';
    updated?: boolean;
    management: {authorization: 'loopback' | 'management_token'};
    blocked_reason: 'active_turns' | 'submission_unknown' | null;
    message?: string;
}
export interface SettingsUpdate {
    revision: string;
    mode?: Mode;
    api_key?: string;
    api?: Partial<ProviderValues['api']>;
    local?: Partial<NonNullable<ProviderValues['local']>>;
    agent?: Partial<ProviderValues['agent']>;
}

/** 環境變數控制的欄位呈現有效值；其餘呈現已保存的值 */
export function settingsDraft(settings: ProviderSettings): ProviderDraft {
    const draft: ProviderDraft = {...structuredClone(settings.saved), api: {...settings.saved.api, provider: settings.saved.api.provider ?? 'cloud'}, local: {...(settings.saved.local ?? {base_url: 'http://127.0.0.1:8081/v1', model: '', context_tokens: 32768})}};
    for (const field of settings.locked_fields) {
        if (field === 'mode') draft.mode = settings.effective.mode;
        else if (field === 'api.provider') draft.api.provider = settings.effective.api.provider ?? 'cloud';
        else if (field.startsWith('api.')) {
            const name = field.slice(4) as 'model' | 'reasoning_effort';
            draft.api[name] = settings.effective.api[name];
        } else if (field.startsWith('local.') && settings.effective.local) {
            if (field === 'local.context_tokens') draft.local.context_tokens = settings.effective.local.context_tokens;
            else {const name = field.slice(6) as 'base_url' | 'model'; draft.local[name] = settings.effective.local[name];}
        } else if (field.startsWith('agent.')) {
            const name = field.slice(6) as keyof ProviderValues['agent'];
            draft.agent[name] = settings.effective.agent[name];
        }
    }
    return draft;
}

/** 只提交有變更的模型設定；金鑰由後端維護，不產生金鑰更新。 */
export function buildSettingsUpdate(settings: ProviderSettings, draft: ProviderValues): SettingsUpdate {
    const update: SettingsUpdate = {revision: settings.revision};
    const unlocked = (field: SettingsField) => !settings.locked_fields.includes(field);
    if (unlocked('api.provider') && draft.api.provider && draft.api.provider !== (settings.saved.api.provider ?? 'cloud')) update.api = {provider: draft.api.provider};
    if (unlocked('mode') && draft.mode !== settings.saved.mode) update.mode = draft.mode;
    for (const name of ['model', 'reasoning_effort'] as const) {
        if (unlocked(`api.${name}`) && draft.api[name].trim() !== settings.saved.api[name]) {
            update.api ??= {}; update.api[name] = draft.api[name].trim();
        }
    }
    for (const name of ['id', 'project_id', 'model', 'reasoning_effort'] as const) {
        if (unlocked(`agent.${name}`) && draft.agent[name].trim() !== settings.saved.agent[name]) {
            update.agent ??= {}; update.agent[name] = draft.agent[name].trim();
        }
    }
    if (draft.local) {
        const saved = settingsDraft(settings).local;
        for (const name of ['base_url', 'model'] as const) {
            if (unlocked(`local.${name}`) && draft.local[name].trim() !== saved[name]) {update.local ??= {}; update.local[name] = draft.local[name].trim();}
        }
        if (unlocked('local.context_tokens') && draft.local.context_tokens !== saved.context_tokens) {
            if (!Number.isSafeInteger(draft.local.context_tokens) || draft.local.context_tokens < 4096 || draft.local.context_tokens > 1000000) throw new Error('本地上下文上限請輸入 4,096 至 1,000,000 的整數');
            update.local ??= {}; update.local.context_tokens = draft.local.context_tokens;
        }
    }
    return update;
}
