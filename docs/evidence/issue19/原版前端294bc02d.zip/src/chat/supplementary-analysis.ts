import type {SupplementaryAnalysis, SupplementaryAnalysisState, SupplementaryFinding} from './types';

const labels: Record<SupplementaryAnalysisState, string> = {
    pending: '準備補充分析', running: '正在補充分析', completed: '分析完成', no_signal: '未發現明顯訊號',
    insufficient_data: '資料不足，暫無法補充分析', failed: '補充分析未完成', cancelled: '補充分析已取消',
};
export function supplementaryAnalysisPending(analysis: SupplementaryAnalysis): boolean {return analysis.state === 'pending' || analysis.state === 'running';}
export function supplementaryAnalysisLabel(analysis: SupplementaryAnalysis): string {return supplementaryAnalysisPending(analysis) && analysis.progress ? analysis.progress : labels[analysis.state];}
function record(value: unknown): value is Record<string, unknown> {return !!value && typeof value === 'object' && !Array.isArray(value);}
function text(value: unknown): value is string {return typeof value === 'string' && !!value.trim();}

/** 分析只採用公開投影；損壞資料不可影響原答案或帶出私有計畫。 */
export function decodeSupplementaryAnalysis(value: unknown, requestId?: string): SupplementaryAnalysis | null {
    if (value == null) return null;
    if (!record(value) || !text(value.request_id) || requestId && value.request_id !== requestId || !text(value.state) || !Object.hasOwn(labels, value.state) || !Array.isArray(value.findings) || value.findings.length > 3) throw new Error('補充分析資料格式無法讀取');
    const findings: SupplementaryFinding[] = value.findings.map(item => {
        if (!record(item) || !text(item.id) || !text(item.title) || !text(item.observation) || !text(item.scope) || !text(item.comparison) || !record(item.follow_up) || !text(item.follow_up.label) || !text(item.follow_up.question)) throw new Error('補充分析資料格式無法讀取');
        return {id: item.id, title: item.title, observation: item.observation, scope: item.scope, comparison: item.comparison, follow_up: {label: item.follow_up.label, question: item.follow_up.question}};
    });
    if (new Set(findings.map(item => item.id)).size !== findings.length || value.state !== 'completed' && findings.length || value.state === 'completed' && !findings.length) throw new Error('補充分析資料格式無法讀取');
    return {request_id: value.request_id, state: value.state as SupplementaryAnalysisState, findings, ...(text(value.progress) ? {progress: value.progress} : {}), ...(text(value.reason) ? {reason: value.reason} : {})};
}
