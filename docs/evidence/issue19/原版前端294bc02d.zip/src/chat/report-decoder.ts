import {fixedPreferenceInput, legacyChartPlan, legacyAnswerVisible, legacyHighlights, legacyDetailMetrics, legacyDetailColumns} from './report-legacy';
import {reportText} from './report';
import {savedSemanticMetricAvailable} from './semantic-availability';
import type {AnswerPresentation, BindingSelection, ChartContract, ChartIntent, ChartPreference, RawReportCard, Report, ReportCard, ReportDisplay, ReportDisplayMetric, ReportMetric, ReportViewPreferences, SemanticReportColumn} from './types';

const intents: readonly ChartIntent[] = ['auto', 'comparison', 'trend', 'relationship', 'composition', 'distribution'];
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const name = (value: unknown): value is string => typeof value === 'string' && /^[a-z][a-z0-9_]*$/.test(value);
const group = (value: unknown): value is string => typeof value === 'string' && /^[a-z][a-z0-9_]{0,127}$/.test(value);
const strings = (value: unknown) => Array.isArray(value) && value.every(item => typeof item === 'string');
const finite = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value);

export class ReportDecodeError extends Error { constructor(message: string) {super(message); this.name = 'ReportDecodeError';} }

function unavailable(value: unknown, index: number, reason: string): ReportCard {
    const input = record(value) ? value : {};
    return {id: typeof input.id === 'string' && input.id ? input.id : `unavailable-${index}`, kind: typeof input.kind === 'string' ? input.kind : 'unavailable',
        title: typeof input.title === 'string' ? input.title : '保存報告', chart_contract: 'unavailable', chart_model: 'legacy', chart_reason: reason,
        display: {answer: true, highlights: [], metrics: [], columns: []}, detail: {columns: [], rows: []}, warnings: [reason]};
}

function validateColumns(value: unknown, keys: Set<string>, version: 1 | 2): SemanticReportColumn[] {
    if (!Array.isArray(value)) throw new ReportDecodeError('保存欄位描述無法讀取');
    const names = new Set<string>();
    for (const column of value) {
        if (!record(column) || !name(column.name) || names.has(column.name) || !keys.has(column.name) || typeof column.label !== 'string' ||
            (typeof column.role !== 'string' || !['dimension', 'metric', 'quality'].includes(column.role)) || (typeof column.data_type !== 'string' || !['string', 'number', 'date', 'datetime', 'boolean'].includes(column.data_type)) ||
            (column.unit != null && typeof column.unit !== 'string') ||
            (column.comparison_group !== undefined && (!group(column.comparison_group) || column.role !== 'metric' || column.data_type !== 'number')) ||
            (column.temporal_grain !== undefined && ((typeof column.temporal_grain !== 'string' || !['day', 'month', 'instant'].includes(column.temporal_grain)) || column.role !== 'dimension' || !['string', 'date', 'datetime'].includes(String(column.data_type)))) ||
            (column.composition !== undefined && (!record(column.composition) || !group(column.composition.group) || (typeof column.composition.role !== 'string' || !['component', 'total'].includes(column.composition.role)) || column.role !== 'metric' || column.data_type !== 'number')) ||
            (column.availability_count_field !== undefined && !name(column.availability_count_field))) throw new ReportDecodeError('保存欄位描述不符合圖表契約');
        if (version === 2 && (typeof column.source_group !== 'string' || !column.source_group)) throw new ReportDecodeError('保存欄位缺少來源關係');
        if (version === 2 && column.role !== 'dimension' && (typeof column.completeness_required !== 'boolean' || !strings(column.required_missing_fields) || (column.required_missing_fields as string[]).some(field => !name(field)) || Boolean((column.required_missing_fields as string[]).length) !== column.completeness_required || new Set(column.required_missing_fields as string[]).size !== (column.required_missing_fields as string[]).length)) throw new ReportDecodeError('保存指標缺少完整性關係');
        names.add(column.name);
    }
    const columns = structuredClone(value) as SemanticReportColumn[];
    if (version === 2) {
        const counterparts = new Set<string>();
        for (const column of columns) if (column.complete_counterpart !== undefined) {
            const target = columns.find(item => item.name === column.complete_counterpart);
            if (!target || target.name === column.name || counterparts.has(target.name) || column.role !== 'metric' || column.data_type !== 'number' || column.interpretation !== 'known_partial' || column.completeness_required !== false ||
                target.role !== 'metric' || target.data_type !== 'number' || target.interpretation !== 'complete' || target.completeness_required !== true || column.unit !== target.unit || !column.source_group || target.source_group !== column.source_group)
                throw new ReportDecodeError('保存的完整量對應關係無法核對');
            counterparts.add(target.name);
        }
    }
    if (version === 2) for (const column of columns) {
        const needs = column.completeness_required === true || column.interpretation === 'known_partial' || column.availability_count_field !== undefined;
        if (!needs) continue;
        const missing = column.required_missing_fields;
        if (typeof column.completeness_required !== 'boolean' || !Array.isArray(missing) || !strings(missing) ||
            (column.completeness_required ? missing.length === 0 : missing.length !== 0) || new Set(missing).size !== missing.length) throw new ReportDecodeError('保存指標缺少完整性關係');
        const count = columns.find(target => target.name === column.availability_count_field);
        if (!count || column.role !== 'metric' || column.data_type !== 'number' || typeof column.source_group !== 'string' || !column.source_group || count.name === column.name || count.data_type !== 'number' || !['metric', 'quality'].includes(count.role) || count.interpretation !== 'count' ||
            count.availability_count_field !== undefined || count.completeness_required !== false || count.required_missing_fields?.length !== 0 || count.source_group !== column.source_group) throw new ReportDecodeError('保存指標的可用性計數來源不一致');
        if (missing.some(field => {const target = columns.find(item => item.name === field); return !target || target.name === column.name || target.role !== 'quality' || target.data_type !== 'number' || target.interpretation !== 'quality' || target.availability_count_field !== undefined || target.completeness_required !== false || target.required_missing_fields?.length !== 0 || target.source_group !== column.source_group;})) throw new ReportDecodeError('保存指標的缺值來源不一致');
    }
    return columns;
}

function legacyColumns(columns: SemanticReportColumn[]): SemanticReportColumn[] {
    const quantity = ['produced_quantity', 'good_quantity', 'scrap_quantity', 'known_produced_quantity', 'known_good_quantity', 'known_scrap_quantity'];
    const normalized = columns.map(column => ({...column, ...(column.name === 'operation_count' ? {interpretation: 'count'} : {}),
        ...((quantity.includes(column.name) || column.completeness_required === true || column.interpretation === 'known_partial') && column.availability_count_field === undefined ? {availability_count_field: 'operation_count'} : {})}));
    for (const field of ['operation_count', 'missing_good_count', 'missing_scrap_count']) if (!normalized.some(column => column.name === field))
        normalized.push({name: field, label: field, role: 'quality', data_type: 'number', interpretation: field === 'operation_count' ? 'count' : 'quality'});
    return normalized;
}

function preference(value: unknown, source: string, metricNames: Set<string>): ChartPreference | undefined {
    if (value == null) return undefined;
    if (!record(value) || value.call_id !== source || !intents.includes(value.intent as ChartIntent) || !strings(value.metrics) ||
        Object.keys(value).some(key => !['call_id', 'intent', 'metrics'].includes(key))) throw new ReportDecodeError('保存的圖表偏好來源無法核對');
    const metrics = value.metrics as string[];
    if (metrics.length > 5 || new Set(metrics).size !== metrics.length || metrics.some(metric => !name(metric) || !metricNames.has(metric)) ||
        (value.intent === 'relationship' && metrics.length !== 2)) throw new ReportDecodeError('保存的圖表指標無法核對');
    return {call_id: source, intent: value.intent as ChartIntent, metrics: [...metrics]};
}

function answerPresentation(value: unknown): AnswerPresentation | undefined {
    if (value == null) return undefined;
    if (!record(value) || value.version !== 'answer-presentation-v1' || !['auto', 'table', 'chart'].includes(String(value.mode)) ||
        ![null, 'bar'].includes(value.preferred_chart_kind as null | 'bar') || Object.keys(value).some(key => !['version', 'mode', 'preferred_chart_kind'].includes(key)))
        throw new ReportDecodeError('保存的回答呈現方式無法讀取');
    return structuredClone(value) as unknown as AnswerPresentation;
}

function savedChartMetadata(card: ReportCard, value: unknown): void {
    if (!record(value) || value.version !== 'mes-chart-metadata-v1' || typeof value.fingerprint !== 'string' || !value.fingerprint || !Array.isArray(value.columns) ||
        Object.keys(value).some(key => !['version', 'fingerprint', 'columns'].includes(key))) throw new ReportDecodeError('保存的自動呈現版本無法讀取');
    const keys = new Set(value.columns.filter(record).map(column => String(column.name)));
    const columns = validateColumns(value.columns, keys, 1);
    for (const column of columns) {
        if (column.value_guards !== undefined && (!Array.isArray(column.value_guards) || column.value_guards.some(guard => !record(guard) || !name(guard.field) ||
            !['eq', 'gte'].includes(String(guard.operator)) || !(typeof guard.value === 'boolean' || finite(guard.value)) ||
            guard.operator === 'gte' && !finite(guard.value) || Object.keys(guard).some(key => !['field', 'operator', 'value'].includes(key))))) throw new ReportDecodeError('保存的數值可用條件無法核對');
        if (column.target_field !== undefined) {
            const target = columns.find(item => item.name === column.target_field);
            if (!target || target.name === column.name || column.role !== 'metric' || !['metric', 'quality'].includes(target.role) || column.data_type !== 'number' || target.data_type !== 'number' ||
                (column.unit || '') !== (target.unit || '') || column.source_group !== target.source_group) throw new ReportDecodeError('保存的目標關係無法核對');
        }
    }
    card.chart_metadata = {version: 'mes-chart-metadata-v1', fingerprint: value.fingerprint, columns};
    card.chart_contract = 'v2';
    card.chart_model = 'semantic';
    card.chart_input = {columns, rows: structuredClone(card.detail?.rows || [])};
}

function bindingMetadata(card: ReportCard, value: Record<string, unknown>): void {
    if (value.binding_reason !== undefined && typeof value.binding_reason !== 'string') throw new ReportDecodeError('保存引用說明無法讀取');
    if (value.binding_table !== undefined) {
        const table = value.binding_table;
        const columns = [{key: 'subject', label: '對象'}, {key: 'metric', label: '指標'}, {key: 'value', label: '保存值'}];
        if (!record(table) || !Array.isArray(table.columns) || table.columns.length !== columns.length || table.columns.some((column, index) => !record(column) || column.key !== columns[index].key || column.label !== columns[index].label || Object.keys(column).some(key => !['key', 'label'].includes(key))) || !Array.isArray(table.rows) ||
            table.rows.some(row => !record(row) || ['subject', 'metric', 'value'].some(key => typeof row[key] !== 'string') || Object.keys(row).some(key => !['subject', 'metric', 'value'].includes(key))))
            throw new ReportDecodeError('原回答的保存表格無法核對');
    }
    const selection = value.binding_selection;
    if (selection === undefined) return;
    const indices = card.detail?.rows || [];
    const metricNames = new Set(card.semantic_columns?.filter(column => column.role === 'metric' && column.data_type === 'number').map(column => column.name) ||
        card.detail?.columns?.filter(column => indices.some(row => finite(row[column.key]))).map(column => column.key));
    if (!record(selection) || !strings(selection.metrics) || !Array.isArray(selection.row_indices) ||
        Object.keys(selection).some(key => !['metrics', 'row_indices', 'cells', 'row_subjects'].includes(key))) throw new ReportDecodeError('原回答的保存引用無法核對');
    const metrics = selection.metrics as string[], rows = selection.row_indices as unknown[];
    if (new Set(metrics).size !== metrics.length || metrics.some(metric => !name(metric) || !metricNames.has(metric)) || new Set(rows).size !== rows.length ||
        rows.some(index => !Number.isInteger(index) || Number(index) < 0 || Number(index) >= indices.length)) throw new ReportDecodeError('原回答的保存欄列無法核對');
    if (selection.cells !== undefined) {
        if (!Array.isArray(selection.cells) || selection.cells.some(cell => !record(cell) || !rows.includes(cell.row_index) || typeof cell.metric !== 'string' || !metrics.includes(cell.metric) || Object.keys(cell).some(key => !['row_index', 'metric'].includes(key))) ||
            new Set(selection.cells.map(cell => JSON.stringify([cell.row_index, cell.metric]))).size !== selection.cells.length) throw new ReportDecodeError('原回答的保存儲存格無法核對');
    }
    if (selection.row_subjects !== undefined) {
        if (!Array.isArray(selection.row_subjects) || selection.row_subjects.length !== rows.length || selection.row_subjects.some(subject => !record(subject) || !rows.includes(subject.row_index) || typeof subject.label !== 'string' || !subject.label || Object.keys(subject).some(key => !['row_index', 'label'].includes(key))) ||
            new Set(selection.row_subjects.map(subject => subject.row_index)).size !== rows.length) throw new ReportDecodeError('原回答的保存對象無法核對');
    }
    const saved = selection as unknown as BindingSelection;
    const input = card.chart_input || fixedPreferenceInput(card, metrics);
    if (input) {
        card.binding_chart_input = structuredClone(input);
        if (!card.semantic_columns && !card.chart_metadata) {
            const subjects = new Map(saved.row_subjects?.map(subject => [subject.row_index, subject.label]));
            card.binding_chart_input.rows.forEach((row, index) => {row.__saved_identity = subjects.get(index) || null;});
        }
    }
}

function decodeCard(value: unknown, version: 1 | 2): ReportCard {
    if (!record(value) || typeof value.id !== 'string' || !value.id || typeof value.kind !== 'string') throw new ReportDecodeError('保存卡片格式無法讀取');
    if (typeof value.unavailable_reason === 'string' && value.unavailable_reason) throw new ReportDecodeError(value.unavailable_reason);
    for (const key of ['title', 'status', 'source_label', 'data_time', 'presentation']) if (value[key] != null && typeof value[key] !== 'string') throw new ReportDecodeError('保存卡片文字格式無法讀取');
    if (value.formula != null && (!record(value.formula) || Object.values(value.formula).some(item => item != null && typeof item !== 'string'))) throw new ReportDecodeError('保存公式格式無法讀取');
    if (value.evidence !== undefined && (!Array.isArray(value.evidence) || value.evidence.some(item => !validEvidence(item)))) throw new ReportDecodeError('保存依據格式無法讀取');
    for (const key of ['warnings', 'notes']) if (value[key] !== undefined && !strings(value[key])) throw new ReportDecodeError('保存卡片說明格式無法讀取');
    if (value.metrics !== undefined && (!Array.isArray(value.metrics) || value.metrics.some(metric => !record(metric) || typeof metric.key !== 'string' || (metric.label != null && typeof metric.label !== 'string') || (metric.unit != null && typeof metric.unit !== 'string') || (metric.detail != null && typeof metric.detail !== 'string')))) throw new ReportDecodeError('保存指標格式無法讀取');
    if (value.detail !== undefined && (!record(value.detail) || (value.detail.columns !== undefined && (!Array.isArray(value.detail.columns) || value.detail.columns.some(column => !record(column) || typeof column.key !== 'string' || (column.label !== undefined && typeof column.label !== 'string')))) || (value.detail.rows !== undefined && (!Array.isArray(value.detail.rows) || value.detail.rows.some(row => !record(row)))))) throw new ReportDecodeError('保存明細格式無法讀取');
    const normalized = structuredClone(value);
    for (const key of ['title', 'status', 'source_label', 'data_time', 'presentation', 'formula']) if (normalized[key] === null) delete normalized[key];
    const raw = normalized as unknown as RawReportCard;
    const card: ReportCard = {...raw, chart_contract: 'legacy_r44', chart_model: 'legacy', display: {answer: legacyAnswerVisible(raw), highlights: [], metrics: [], columns: []}};
    delete card.chart_input; delete card.binding_chart_input; delete card.legacy_charts; delete card.chart_preference; delete card.chart_reason; delete card.chart_metadata; delete card.primary_metrics;
    const detailKeys = new Set(card.detail?.columns?.map(column => column.key));
    const columns = card.semantic_columns === undefined ? undefined : validateColumns(card.semantic_columns, detailKeys, card.semantic_metadata_version === 2 ? 2 : 1);
    if (card.chart_intent !== undefined && !intents.includes(card.chart_intent)) throw new ReportDecodeError('保存的圖表意圖無法讀取');
    if (columns) {
        if (typeof card.semantic_fingerprint !== 'string' || !card.semantic_fingerprint) throw new ReportDecodeError('保存的欄位依據不完整');
        if (card.semantic_metadata_version !== undefined && card.semantic_metadata_version !== 1 && card.semantic_metadata_version !== 2) throw new ReportDecodeError('保存語意版本尚未支援');
        const hasMetadata = columns.some(column => ['comparison_group', 'composition', 'temporal_grain', 'availability_count_field'].some(key => Object.hasOwn(column, key)));
        const oldAvailability = columns.some(column => (column.completeness_required || column.interpretation === 'known_partial') && column.availability_count_field === undefined);
        const contract: ChartContract = card.semantic_metadata_version === 2 ? 'v2' : hasMetadata || card.chart_intent !== undefined && !oldAvailability ? 'metadata_v1' : 'legacy_r44';
        card.chart_contract = contract;
        card.semantic_columns = columns;
        card.chart_input = {columns: contract === 'legacy_r44' ? legacyColumns(columns) : columns, rows: structuredClone(card.detail?.rows || [])};
        if (contract !== 'legacy_r44') card.chart_model = 'semantic';
        if (contract === 'legacy_r44' && columns.some(column => column.name.endsWith('_percent') || column.name.includes('oee'))) throw new ReportDecodeError('舊快照包含未核准圖表欄位');
    }
    if (version === 2) {
        if (typeof card.source_call_id !== 'string' || !card.source_call_id) throw new ReportDecodeError('保存卡片缺少工具來源');
        if (value.chart_metadata !== undefined) savedChartMetadata(card, value.chart_metadata);
        const metrics = new Set((card.chart_input?.columns || columns)?.filter(column => column.data_type === 'number' && (column.role === 'metric' || !!card.chart_metadata && column.role === 'quality')).map(column => column.name) ||
            [...detailKeys, ...(card.metrics?.map(metric => metric.key) || [])].filter(key => card.detail?.rows?.some(row => finite(row[key])) || card.metrics?.some(metric => metric.key === key && finite(metric.value))));
        card.chart_preference = preference(value.chart_preference, card.source_call_id, metrics);
        if (value.primary_metrics !== undefined) {
            if (!strings(value.primary_metrics) || new Set(value.primary_metrics as string[]).size !== (value.primary_metrics as string[]).length ||
                (value.primary_metrics as string[]).some(metric => !metrics.has(metric))) throw new ReportDecodeError('主圖指標不屬於保存來源');
            card.primary_metrics = [...value.primary_metrics as string[]];
        }
        if (card.chart_metadata && card.chart_input && (card.chart_preference?.metrics.length || card.primary_metrics?.length)) {
            const requested = new Set(card.chart_preference?.metrics.length ? card.chart_preference.metrics : card.primary_metrics);
            card.chart_input.columns = card.chart_input.columns.map(column => column.role === 'quality' && column.interpretation === 'count' && requested.has(column.name) ? {...column, role: 'metric' as const} : column);
        }
        if (!columns) card.chart_contract = 'v2';
        if (!columns && !card.chart_metadata && card.chart_preference?.metrics.length) {
            card.chart_model = 'semantic';
            card.chart_input = fixedPreferenceInput(card, card.chart_preference.metrics);
        }
    }
    if (card.chart_model === 'legacy') card.legacy_charts = legacyChartPlan({...card, semantic_columns: columns}).recommended;
    bindingMetadata(card, value);
    card.display = displayProjection(card);
    return card;
}

/** 所有歷史版本判斷集中於此；單一卡片損壞不影響其他保存答案或卡片。 */
export function decodeReportCard(value: unknown, version: 1 | 2 = 1, index = 0): ReportCard {
    try {return decodeCard(value, version);} catch (error) {return unavailable(value, index, error instanceof ReportDecodeError ? error.message : '保存卡片格式無法讀取');}
}

export function decodeReport(value: unknown, expectedRequestId?: string): Report {
    if (!record(value) || (typeof value.report_version !== 'string' || !['mes-report-v1', 'mes-report-v2'].includes(value.report_version)) || typeof value.request_id !== 'string' ||
        expectedRequestId !== undefined && value.request_id !== expectedRequestId || !Array.isArray(value.cards)) throw new ReportDecodeError('保存報告版本或來源無法讀取');
    if (value.warnings !== undefined && !strings(value.warnings) || value.evidence !== undefined && (!Array.isArray(value.evidence) || value.evidence.some(item => !validEvidence(item)))) throw new ReportDecodeError('保存報告說明格式無法讀取');
    const presentation = answerPresentation(value.answer_presentation);
    if (value.source_answer !== undefined && typeof value.source_answer !== 'string') throw new ReportDecodeError('原保存回答無法讀取');
    const version = value.report_version === 'mes-report-v2' ? 2 : 1;
    const seen = new Set<string>();
    const cards = value.cards.map((raw, index) => {
        const card = decodeReportCard(raw, version, index);
        if (seen.has(card.id)) return {...unavailable(raw, index, '保存卡片識別重複'), id: `unavailable-${index}`};
        seen.add(card.id); return card;
    });
    const view = decodeViewPreferences(value, version, cards);
    return {...structuredClone(value), ...view, answer_presentation: presentation, report_version: value.report_version as Report['report_version'], request_id: value.request_id, cards} as Report;
}

/** 偏好損壞時保留答案及卡片；呈現候選仍交由 planner 核對。 */
function decodeViewPreferences(value: Record<string, unknown>, version: 1 | 2, cards: ReportCard[]): Pick<Report, 'view_preferences' | 'view_preferences_editable' | 'view_preferences_reason'> {
    const result: ReportViewPreferences = {version: 'report-view-preferences-v1', revision: 0, selections: []};
    if (version === 1 || value.view_preferences === undefined) return {view_preferences: result, view_preferences_editable: false};
    const preferences = value.view_preferences;
    const marks = ['bar', 'line', 'point', 'scatter', 'heatmap', 'stacked', 'value', 'bullet', 'table'];
    const invalid = !record(preferences) || preferences.version !== result.version || !Number.isSafeInteger(preferences.revision) || Number(preferences.revision) < 0 ||
        !Array.isArray(preferences.selections) || preferences.selections.length > 50 || preferences.selections.some(item => !record(item) || typeof item.card_id !== 'string' || !cards.some(card => card.id === item.card_id) ||
            !marks.includes(String(item.mark)) || !strings(item.metrics) || (item.metrics as string[]).length > 8 || new Set(item.metrics as string[]).size !== (item.metrics as string[]).length ||
            (item.metrics as string[]).some(metric => !name(metric)) || (item.mark !== 'table' && !(item.metrics as string[]).length) || Object.keys(item).some(key => !['card_id', 'mark', 'metrics'].includes(key))) ||
        new Set((preferences.selections as Record<string, unknown>[]).map(item => item.card_id)).size !== (preferences.selections as unknown[]).length ||
        Object.keys(preferences).some(key => !['version', 'revision', 'selections'].includes(key)) || typeof value.view_preferences_editable !== 'boolean';
    if (invalid) return {view_preferences: result, view_preferences_editable: false, view_preferences_reason: '保存的呈現偏好無法讀取，已使用自動呈現'};
    return {view_preferences: structuredClone(preferences) as unknown as ReportViewPreferences, view_preferences_editable: value.view_preferences_editable as boolean};
}

function validEvidence(value: unknown): boolean {
    if (!record(value)) return false;
    return ['tool_name', 'tool_label', 'query_start', 'query_end', 'data_source', 'calculation', 'status'].every(key => value[key] == null || typeof value[key] === 'string') &&
        (value.arguments === undefined || record(value.arguments)) && (value.warnings === undefined || strings(value.warnings));
}

function semanticHighlights(card: ReportCard, metrics: ReportMetric[]): ReportDisplayMetric[] {
    const summary = record(card.summary) ? card.summary : {};
    const columns = card.semantic_columns || [];
    return columns.filter(column => column.role === 'metric' && column.data_type === 'number').map(column => {
        // 同份保存摘要的兩個投影矛盾時保留未知，不默選其中一方
        const savedMetric = metrics.find(metric => metric.key === column.name);
        const hasSummary = Object.hasOwn(summary, column.name);
        const conflict = hasSummary && !!savedMetric && summary[column.name] !== savedMetric.value;
        const value = hasSummary ? summary[column.name] : savedMetric?.value;
        const availability = card.chart_input?.columns.find(saved => saved.name === column.name) || column;
        const known = !conflict && finite(value) && savedSemanticMetricAvailable(availability, summary, card.chart_input?.columns || columns);
        const partial = column.interpretation === 'known_partial';
        return {
            key: column.name,
            label: column.label + (partial ? '（已知部分）' : ''),
            value: known ? reportText(value) : '未知',
            unit: known ? column.unit || '' : '',
            ...(conflict ? {detail: '保存摘要數值不一致'} : !known ? {detail: '資料未完整取得'} : partial ? {detail: '不能當成完整產量'} : {}),
        };
    });
}

/** 摘要、明細標籤及數字顯示共用一次解碼，元件不猜版本或業務欄名。 */
function displayProjection(card: ReportCard): ReportDisplay {
    const semantic = !!card.semantic_columns || card.kind === 'semantic_query';
    const metrics = card.metrics || [];
    const highlights = !card.display.answer || ['no_data', 'failed'].includes(card.status || '') ? [] : semantic ? semanticHighlights(card, metrics) : legacyHighlights(card);
    if (!semantic) return {answer: card.display.answer, highlights, metrics: legacyDetailMetrics(card, highlights), columns: legacyDetailColumns(card)};
    const approved = new Map(highlights.map(item => [item.key, item]));
    return {answer: card.display.answer, highlights, columns: (card.detail?.columns || []).map(column => ({...column, label: column.label || column.key})),
        metrics: metrics.map(metric => {
            const saved = approved.get(metric.key);
            return saved ? {...saved, detail: saved.detail || metric.detail} : {key: metric.key, label: metric.label || metric.key, value: reportText(metric.value), unit: finite(metric.value) ? metric.unit || '' : '', detail: metric.detail};
        })};
}
