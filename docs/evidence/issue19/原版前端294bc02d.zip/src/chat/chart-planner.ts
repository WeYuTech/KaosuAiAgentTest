import {savedSemanticMetricAvailable} from './semantic-availability';
import type { AnswerPresentation, ChartIntent, ReportCard, ReportViewSelection, SemanticReportColumn } from './types';

export type ChartMark = 'bar' | 'line' | 'point' | 'scatter' | 'heatmap' | 'stacked' | 'value' | 'bullet';
export type ChartDimensionValue = string | number | boolean | null;
export interface ChartSpecPoint {
    rowIndex: number;
    label: string;
    dimensions: Record<string, ChartDimensionValue>;
    values: Record<string, number | null>;
}
export interface ChartSpec {
    version: 1;
    id: string;
    groupId: string;
    sourceRef: string;
    mark: ChartMark;
    title: string;
    reason: string;
    encoding: {x: string; y: string; series: string[]};
    columns: SemanticReportColumn[];
    points: ChartSpecPoint[];
    unit: string;
    measure: string;
    notices: string[];
    scope: {kind: 'saved_rows'; totalRows: number; shownRows: number; paginated: boolean};
    missing: 'gap';
    order: 'source';
}
export interface ChartPlan { recommended: ChartSpec[]; alternatives: ChartSpec[]; reason?: string; fallback?: 'table' }
interface Profile {
    card: ReportCard;
    columns: SemanticReportColumn[];
    dimensions: SemanticReportColumn[];
    metrics: SemanticReportColumn[];
    points: ChartSpecPoint[];
    totalRows: number;
    paginated: boolean;
    completeIdentity: boolean;
    uniqueIdentity: boolean;
    continuousTime: boolean;
    timeDimension: boolean;
    timeColumn: SemanticReportColumn | undefined;
}
interface CandidateRule {
    mark: ChartMark;
    reason: string;
    allowed(profile: Profile, metrics: SemanticReportColumn[]): boolean;
    score: Record<ChartIntent, number>;
}
const IDENTITY = '__saved_identity';
const intents: readonly ChartIntent[] = ['auto', 'comparison', 'trend', 'relationship', 'composition', 'distribution'];
const finite = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value);
const own = (value: object, key: string) => Object.hasOwn(value, key);
const dimensionValue = (value: unknown): value is ChartDimensionValue => value === null || typeof value === 'string' || typeof value === 'boolean' || finite(value);
const dimensionTypeMatches = (value: unknown, column: SemanticReportColumn): boolean => value === null || (column.data_type === 'number' ? finite(value) : column.data_type === 'boolean' ? typeof value === 'boolean' : typeof value === 'string');
const empty = (): ChartPlan => ({recommended: [], alternatives: []});

/** 只核對保存時間間距，不切日期、不補列、不對資料重新排序 */
function savedTime(value: ChartDimensionValue, grain: SemanticReportColumn['temporal_grain']): number | null {
    if (typeof value !== 'string') return null;
    if (grain === 'month') return /^\d{4}-(0[1-9]|1[0-2])$/.test(value) ? Number(value.slice(0, 4)) * 12 + Number(value.slice(5, 7)) : null;
    const date = value.slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
    const day = Date.parse(`${date}T00:00:00Z`);
    if (!Number.isFinite(day) || new Date(day).toISOString().slice(0, 10) !== date) return null;
    if (grain === 'day') return value === date ? day : null;
    if (grain !== 'instant' || !/^\d{4}-\d{2}-\d{2}[T ]([01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-]([01]\d|2[0-3]):[0-5]\d)$/.test(value)) return null;
    const time = Date.parse(value.replace(' ', 'T'));
    return Number.isFinite(time) ? time : null;
}

/** 時間軸只轉換已保存座標，不新增日期列、資料值或跨列運算。 */
export function chartTimeAxis(spec: ChartSpec): {grain: NonNullable<SemanticReportColumn['temporal_grain']>; positions: number[]; domain: [number, number]} | null {
    if (spec.mark !== 'point' && spec.mark !== 'line') return null;
    const column = spec.columns.find(item => item.name === spec.encoding.x && item.role === 'dimension' && item.temporal_grain);
    if (!column?.temporal_grain) return null;
    const positions = spec.points.map(point => savedTime(point.dimensions[column.name], column.temporal_grain));
    if (!positions.length || !positions.every((position): position is number => position !== null)) return null;
    const minimum = Math.min(...positions), maximum = Math.max(...positions);
    const padding = minimum === maximum ? column.temporal_grain === 'month' ? .5 : column.temporal_grain === 'day' ? 43_200_000 : 500 : 0;
    return {grain: column.temporal_grain, positions, domain: [minimum - padding, maximum + padding]};
}

export function formatChartTimeTick(value: unknown, grain: NonNullable<SemanticReportColumn['temporal_grain']>): string {
    if (!finite(value)) return '';
    if (grain === 'month') return Number.isInteger(value) ? `${Math.floor((value - 1) / 12)}-${String((value - 1) % 12 + 1).padStart(2, '0')}` : '';
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return '';
    const iso = date.toISOString();
    return grain === 'instant' ? `${iso.slice(5, 10).replace('-', '/')} ${iso.slice(11, 19)}` : iso.slice(5, 10).replace('-', '/');
}

function continuous(points: ChartSpecPoint[], column: SemanticReportColumn): boolean {
    if (points.length < 2) return false;
    let previous: number | null = null;
    let interval = column.temporal_grain === 'month' ? 1 : column.temporal_grain === 'day' ? 86_400_000 : null;
    for (const point of points) {
        const current = savedTime(point.dimensions[column.name], column.temporal_grain);
        if (current === null) return false;
        if (previous !== null) {
            const difference = current - previous;
            if (difference <= 0 || (interval !== null && difference !== interval)) return false;
            interval = difference;
        }
        previous = current;
    }
    return true;
}

function profile(card: ReportCard, columns: SemanticReportColumn[]): Profile | null {
    const rows = card.chart_input?.rows;
    if (!Array.isArray(rows) || !rows.length || rows.some(row => !row || typeof row !== 'object' || Array.isArray(row))) return null;
    const dimensions = columns.filter(column => column.role === 'dimension');
    const metrics = columns.filter(column => column.role === 'metric' && column.data_type === 'number');
    if ((!dimensions.length && (!card.chart_metadata || rows.length !== 1)) || !metrics.length) return null;
    const points: ChartSpecPoint[] = [];
    let completeIdentity = true;
    for (const [rowIndex, row] of rows.entries()) {
        const rowIdentityComplete = dimensions.every(column => own(row, column.name) && dimensionValue(row[column.name]) && dimensionTypeMatches(row[column.name], column));
        if (!rowIdentityComplete) completeIdentity = false;
        const dimensionEntries = dimensions.map(column => [column.name, dimensionValue(row[column.name]) ? row[column.name] : null] as const);
        const savedDimensions = Object.fromEntries(dimensionEntries) as Record<string, ChartDimensionValue>;
        const label = dimensions.map(column => savedDimensions[column.name] === null || savedDimensions[column.name] === '' ? '未知' : String(savedDimensions[column.name])).join(' · ') || '本次結果';
        const values = Object.fromEntries(columns.filter(column => column.data_type === 'number' && (column.role === 'metric' || metrics.some(metric => metric.target_field === column.name))).map(column => [column.name, rowIdentityComplete && finite(row[column.name]) && savedSemanticMetricAvailable(column, row, columns) ? row[column.name] as number : null]));
        points.push({rowIndex, label, dimensions: {...savedDimensions, [IDENTITY]: label}, values});
    }
    const pagination = card.pagination as {offset?: number; truncated?: boolean; has_more?: boolean} | undefined;
    const paginated = !!(pagination?.truncated || pagination?.has_more || (pagination?.offset || 0) > 0 || card.months_truncated);
    const identityKeys = points.map(point => JSON.stringify(dimensions.map(column => [typeof point.dimensions[column.name], point.dimensions[column.name]])));
    const uniqueIdentity = new Set(identityKeys).size === points.length;
    const timeColumns = dimensions.filter(column => !!column.temporal_grain);
    // 固定分類仍保留在完整身分；只有一個時間維度且其餘維度皆完整固定，才是單一時間系列。
    const timeColumn = timeColumns.length === 1 && dimensions.filter(column => column !== timeColumns[0]).every(column =>
        points.every(point => point.dimensions[column.name] !== null && point.dimensions[column.name] !== '') &&
        new Set(points.map(point => JSON.stringify([typeof point.dimensions[column.name], point.dimensions[column.name]]))).size === 1) ? timeColumns[0] : undefined;
    return {card, columns, dimensions, metrics, points, totalRows: rows.length, paginated, completeIdentity, uniqueIdentity,
        continuousTime: !!timeColumn && continuous(points, timeColumn), timeDimension: !!timeColumn, timeColumn};
}

function metricGroups(columns: SemanticReportColumn[]): SemanticReportColumn[][] {
    const groups = new Map<string, SemanticReportColumn[]>();
    for (const column of columns) {
        // 兩個未知單位不代表同量綱，只有核准 comparison_group 才提供額外比較依據。
        const key = JSON.stringify([column.comparison_group || column.name, column.comparison_group ? 'group' : 'single', column.unit || null, column.interpretation || '']);
        groups.set(key, [...(groups.get(key) || []), column]);
    }
    return [...groups.values()];
}

function hasValues(data: Profile, metrics: SemanticReportColumn[]): boolean {
    return data.points.some(point => metrics.some(column => point.values[column.name] !== null));
}

function heatmapAllowed(data: Profile, metrics: SemanticReportColumn[]): boolean {
    return metrics.length === 1 && data.dimensions.length === 2 && data.completeIdentity && data.uniqueIdentity &&
        data.dimensions.every(column => data.points.every(point => point.dimensions[column.name] !== null && point.dimensions[column.name] !== '') &&
            new Set(data.points.map(point => JSON.stringify(point.dimensions[column.name]))).size > 1);
}

function compositionMetrics(data: Profile, metrics: SemanticReportColumn[]): SemanticReportColumn[] | null {
    if (data.paginated || !data.completeIdentity || !data.uniqueIdentity || metrics.length < 3) return null;
    const group = metrics[0].composition?.group;
    if (!group || metrics.some(column => column.composition?.group !== group || column.interpretation === 'known_partial' || column.completeness_required !== true)) return null;
    const totals = metrics.filter(column => column.composition?.role === 'total');
    const components = metrics.filter(column => column.composition?.role === 'component');
    if (totals.length !== 1 || components.length < 2) return null;
    if (!data.points.every(point => {
        const values = metrics.map(column => point.values[column.name]);
        if (!values.every((value): value is number => value !== null && value >= 0)) return false;
        const total = point.values[totals[0].name]!;
        const componentSum = components.reduce((sum, column) => sum + point.values[column.name]!, 0);
        // 核對保存總量與組成；核對值不回傳、不作為任何新業務數字。
        return Number.isFinite(componentSum) && Math.abs(total - componentSum) <= Math.max(1, Math.abs(total)) * Number.EPSILON * 8;
    })) return null;
    return components;
}

/** 硬條件先決定合法性，問題意圖只在通過資格的候選中排序 */
export const CHART_CANDIDATE_RULES: readonly CandidateRule[] = [
    {mark: 'value', reason: '只有一個保存對象，直接呈現數值與單位', allowed: data => !!data.card.chart_metadata && data.points.length === 1 && data.completeIdentity,
        score: {auto: 110, comparison: 100, trend: 110, relationship: 50, composition: 50, distribution: 90}},
    {mark: 'bullet', reason: '以已保存的實際值和目標比較達成情形，超過目標仍保留原值', allowed: (data, metrics) => !!data.card.chart_metadata && data.points.length === 1 && data.completeIdentity && metrics.filter(column => column.target_field).length === 1 && metrics.some(column => {
        const target = column.target_field && data.columns.find(item => item.name === column.target_field);
        return target && (target.unit || '') === (column.unit || '') && data.points.every(point => point.values[column.name] !== null && point.values[column.name]! >= 0 && point.values[target.name] !== null && point.values[target.name]! > 0);
    }), score: {auto: 120, comparison: 120, trend: 115, relationship: 55, composition: 55, distribution: 85}},
    {mark: 'bar', reason: '用長條比較各對象的數值', allowed: () => true, score: {auto: 50, comparison: 90, trend: 30, relationship: 20, composition: 30, distribution: 30}},
    {mark: 'point', reason: '用獨立的點比較保存值，缺值保持未知', allowed: () => true, score: {auto: 35, comparison: 65, trend: 60, relationship: 25, composition: 20, distribution: 95}},
    {mark: 'line', reason: '用折線查看連續時間的變化', allowed: data => data.completeIdentity && data.uniqueIdentity && data.continuousTime, score: {auto: 100, comparison: 70, trend: 100, relationship: 30, composition: 40, distribution: 60}},
    {mark: 'heatmap', reason: '用色彩比較兩個分類的交叉結果', allowed: heatmapAllowed, score: {auto: 95, comparison: 85, trend: 80, relationship: 45, composition: 35, distribution: 100}},
    {mark: 'stacked', reason: '用堆疊查看各部分如何組成總量', allowed: (data, metrics) => compositionMetrics(data, metrics) !== null, score: {auto: 45, comparison: 60, trend: 45, relationship: 25, composition: 100, distribution: 45}},
    {mark: 'scatter', reason: '用兩個座標軸查看數值之間的關係', allowed: (data, metrics) => metrics.length === 2 && data.completeIdentity && metrics[0].interpretation === metrics[1].interpretation &&
        data.points.every(point => data.dimensions.every(column => point.dimensions[column.name] !== null && point.dimensions[column.name] !== '')) &&
        data.points.filter(point => metrics.every(column => point.values[column.name] !== null)).length >= 2,
        score: {auto: 20, comparison: 40, trend: 20, relationship: 100, composition: 15, distribution: 70}},
];

function notices(data: Profile, metrics: SemanticReportColumn[]): string[] {
    const result: string[] = [];
    for (const column of metrics) {
        const missing = data.totalRows - data.points.filter(point => point.values[column.name] !== null).length;
        if (missing) result.push(`${column.label}有 ${missing} 筆數量或維度未完整取得，未補零`);
    }
    if (metrics.some(column => column.interpretation === 'known_partial')) result.push('標記為已知部分的數量不能當成完整產量');
    if (data.paginated) result.push('查詢結果有分頁或截斷，不代表所有資料');
    if (data.timeDimension && !data.continuousTime) result.push('保存時間含缺口、重複、無效值或順序未確認，不以等距折線連接');
    if (data.points.some(point => metrics.some(column => point.values[column.name] !== null && point.values[column.name]! < 0))) result.push('包含負數紀錄，保留原值，未自行修正');
    if (metrics.some(column => !column.unit)) result.push('數量單位尚未驗證');
    result.push('各列保留完整查詢維度與保存順序，未跨列加總或重新排名');
    return result;
}

function makeSpec(data: Profile, metrics: SemanticReportColumn[], rule: CandidateRule, groupId: string): ChartSpec {
    const displayed = rule.mark === 'stacked' ? compositionMetrics(data, metrics)! : rule.mark === 'bullet' ? metrics.filter(column => column.target_field && data.points.every(point => point.values[column.name] !== null && point.values[column.name]! >= 0 && point.values[column.target_field!] !== null && point.values[column.target_field!]! > 0)) : metrics;
    const x = rule.mark === 'scatter' ? metrics[0].name : (rule.mark === 'line' || rule.mark === 'point') && data.timeColumn ? data.timeColumn.name : data.dimensions.length === 1 ? data.dimensions[0].name : IDENTITY;
    const encoding = rule.mark === 'heatmap' ? {x: data.dimensions[0].name, y: data.dimensions[1].name, series: [metrics[0].name]}
        : rule.mark === 'scatter' ? {x, y: metrics[1].name, series: []} : {x, y: displayed[0].name, series: displayed.map(column => column.name)};
    const measure = displayed.map(column => column.label + (column.interpretation === 'known_partial' ? '（已知部分）' : '')).join('／');
    return {version: 1, id: `${data.card.id}:${groupId}:${rule.mark}:${displayed.map(column => column.name).join(':')}`, groupId, sourceRef: data.card.id, mark: rule.mark,
        title: data.card.title || measure, reason: rule.mark === 'point' && data.timeColumn && data.points.every(point => savedTime(point.dimensions[data.timeColumn!.name], data.timeColumn!.temporal_grain) !== null) ? '依保存時間位置呈現各點，缺日不補值或連線' : rule.reason, encoding, columns: data.columns.map(column => ({...column, ...(column.required_missing_fields ? {required_missing_fields: [...column.required_missing_fields]} : {}), ...(column.composition ? {composition: {...column.composition}} : {})})),
        points: data.points.map(point => ({...point, dimensions: {...point.dimensions}, values: {...point.values}})),
        unit: rule.mark === 'scatter' ? '' : displayed[0].unit || '', measure, notices: notices(data, displayed),
        scope: {kind: 'saved_rows', totalRows: data.totalRows, shownRows: data.points.length, paginated: data.paginated}, missing: 'gap', order: 'source'};
}


export function planSavedCharts(card: ReportCard, preference?: ChartIntent): ChartPlan {
    if (!card.display.answer || ['no_data', 'failed'].includes(card.status || '')) return empty();
    if (card.chart_contract === 'unavailable') return empty();
    if (card.chart_model === 'legacy') return {recommended: card.legacy_charts || [], alternatives: []};
    const fallback = (): ChartPlan => card.chart_metadata ? {...empty(), fallback: 'table', reason: '目前保存資料不適合可靠地繪圖，改以原值表格呈現；缺值維持未知。'} : empty();
    if (preference !== undefined && !intents.includes(preference)) return empty();
    const columns = card.chart_input?.columns;
    if (!columns) return fallback();
    const data = profile(card, columns);
    if (!data) return card.chart_preference?.intent === 'relationship' ? {...fallback(), reason: '指定指標沒有足夠的共同完整資料，仍可查看保存明細'} : fallback();
    const intent = preference || card.chart_preference?.intent || card.chart_intent || 'auto';
    // 未指定目的時，以核准的單一時間系列選型；時間不連續仍由原 guard 排除折線。
    const rankedIntent = intent === 'auto' && data.timeDimension ? 'trend' : intent;
    const requested = card.chart_preference?.metrics || [];
    if (requested.some(name => !data.metrics.some(column => column.name === name))) return {...fallback(), reason: '指定欄位尚未具備核准的繪圖尺度，仍以保存原值表格呈現。'};
    const focus = requested.length ? requested : card.primary_metrics || [];
    const focusMetrics = focus.map(name => data.metrics.find(column => column.name === name)).filter((column): column is SemanticReportColumn => !!column);
    if (focusMetrics.length !== focus.length) return {...fallback(), reason: '主要指標尚未具備核准的繪圖尺度，仍以保存原值表格呈現。'};
    const focusGroups = metricGroups(focusMetrics);
    const focusedGroupIds = new Set(focusGroups.map(metrics => metrics.map(column => column.name).join(':')));
    // 主指標只限制推薦；其餘核准量測仍可由同一保存來源切換。
    const groups = new Map(metricGroups(data.metrics).map(metrics => [metrics.map(column => column.name).join(':'), metrics]));
    for (const metrics of focusGroups) groups.set(metrics.map(column => column.name).join(':'), metrics);
    const requestedPair = requested.length === 2 ? requested.map(name => data.metrics.find(column => column.name === name)!) : null;
    const candidates: {spec: ChartSpec; score: number}[] = [];
    for (const [groupId, metrics] of groups) {
        if (!hasValues(data, metrics)) continue;
        for (const rule of CHART_CANDIDATE_RULES.filter(rule => rule.mark !== 'scatter')) {
            const variations = rule.mark === 'heatmap' ? metrics.map(metric => [metric]) : [metrics];
            for (const variation of variations) if (hasValues(data, variation) && rule.allowed(data, variation))
                candidates.push({spec: makeSpec(data, variation, rule, groupId), score: rule.score[rankedIntent]});
        }
    }
    const scatter = CHART_CANDIDATE_RULES.find(rule => rule.mark === 'scatter')!;
    const pairs = new Map<string, SemanticReportColumn[]>();
    if (requestedPair) pairs.set([...requestedPair.map(column => column.name)].sort().join(':'), requestedPair);
    for (let left = 0; left < data.metrics.length; left++) for (let right = left + 1; right < data.metrics.length; right++) {
        const pair = [data.metrics[left], data.metrics[right]], key = pair.map(column => column.name).sort().join(':');
        if (!pairs.has(key)) pairs.set(key, pair);
    }
    for (const pair of pairs.values()) {
        // 座標方向是呈現選擇的一部分；兩個方向都須通過相同 guard，不能依欄位順序換軸。
        for (const ordered of [pair, [...pair].reverse()]) if (scatter.allowed(data, ordered))
            candidates.push({spec: makeSpec(data, ordered, scatter, `relation:${ordered.map(column => column.name).join(':')}`), score: scatter.score[rankedIntent]});
    }
    const requestedRelation = requestedPair ? candidates.find(candidate => candidate.spec.mark === 'scatter' && candidate.spec.encoding.x === requestedPair[0].name && candidate.spec.encoding.y === requestedPair[1].name) : undefined;
    if (intent === 'relationship' && requestedPair && !requestedRelation) return {...fallback(), alternatives: candidates.map(candidate => candidate.spec), reason: '指定指標沒有足夠的共同完整資料，仍可查看保存明細'};
    candidates.sort((left, right) => right.score - left.score);
    if (!candidates.length) return fallback();
    const focusGroup = (spec: ChartSpec): string | undefined => {
        if (focusedGroupIds.has(spec.groupId)) return spec.groupId;
        // 堆疊仍以完整來源（含總量）核對；主圖只需顯示恰好被要求的組成。
        if (spec.mark === 'stacked') return focusGroups.find(metrics => metrics.length === spec.encoding.series.length && metrics.every(metric => spec.encoding.series.includes(metric.name)))?.map(metric => metric.name).join(':');
        return undefined;
    };
    const focusedCandidates = focusMetrics.length ? candidates.filter(candidate => focusGroup(candidate.spec) !== undefined) : candidates;
    if (focus.length && !focusedCandidates.length) return {...fallback(), alternatives: candidates.map(candidate => candidate.spec), reason: '主要指標沒有可繪製的完整值，仍可查看保存明細或切換其他指標。'};
    const main = focusedCandidates[0];
    const recommended = intent === 'relationship' && requestedRelation ? [requestedRelation.spec] :
        intent === 'relationship' && !focus.length && main.spec.mark === 'scatter' ? [main.spec] :
        !focus.length && card.primary_metrics !== undefined ? [main.spec] :
        [...new Set(focusedCandidates.filter(candidate => candidate.spec.mark !== 'scatter').map(candidate => focusMetrics.length ? focusGroup(candidate.spec) : candidate.spec.groupId))].flatMap(group => {
            const inGroup = (spec: ChartSpec) => (focusMetrics.length ? focusGroup(spec) : spec.groupId) === group;
            const best = focusedCandidates.find(candidate => inGroup(candidate.spec))!.spec;
            return best.mark === 'heatmap' ? focusedCandidates.filter(candidate => inGroup(candidate.spec) && candidate.spec.mark === 'heatmap').map(candidate => candidate.spec) : [best];
        });
    const selected = new Set(recommended.map(spec => spec.id));
    return {recommended, alternatives: candidates.map(candidate => candidate.spec).filter(spec => !selected.has(spec.id))};
}

/** 保存選擇只保留合法候選的標記及有序欄位，不保存圖表數字或欄位索引。 */
export function chartSelection(spec: ChartSpec): ReportViewSelection {
    return {mark: spec.mark, metrics: spec.mark === 'scatter' ? [spec.encoding.x, spec.encoding.y] : [...spec.encoding.series]};
}

export function findChartSelection(candidates: ChartSpec[], selection: ReportViewSelection): ChartSpec | undefined {
    return candidates.find(spec => {
        const candidate = chartSelection(spec);
        return candidate.mark === selection.mark && candidate.metrics.length === selection.metrics.length && candidate.metrics.every((metric, index) => metric === selection.metrics[index]);
    });
}

/** 直接呈現只縮小原保存欄列，逐格遮蔽未顯示值；合法性仍由同一規劃器核對。 */
export function planBoundCharts(card: ReportCard, presentation: AnswerPresentation): ChartPlan {
    if (presentation.mode === 'auto') return planSavedCharts(card);
    const unavailable = (): ChartPlan => ({...empty(), reason: '原回答的保存引用無法直接轉換為圖表。' + (card.binding_reason || '請查看保存值表格或原始報表。')});
    const selection = card.binding_selection, input = card.binding_chart_input;
    if (!card.binding_table?.rows.length || !selection?.cells?.length || !selection.row_subjects || !selection.row_indices.length || !selection.metrics.length || !input || card.chart_contract === 'unavailable') return unavailable();
    const chosenRows = new Set(selection.row_indices), chosenMetrics = new Set(selection.metrics);
    const cells = new Set(selection.cells.map(cell => JSON.stringify([cell.row_index, cell.metric])));
    const labels = new Map(selection.row_subjects.map(subject => [subject.row_index, subject.label]));
    const indices = input.rows.map((_, index) => index).filter(index => chosenRows.has(index));
    if (indices.some(index => !labels.has(index) || !selection.cells!.some(cell => cell.row_index === index))) return unavailable();
    // 可用性計數仍供原 guard 使用，但不成為未核准的圖表系列或數值。
    const columns = input.columns.map(column => ({...column, ...(column.role === 'metric' && !chosenMetrics.has(column.name) ? {role: 'quality' as const} : {}),
        ...(column.target_field && !chosenMetrics.has(column.target_field) ? {target_field: undefined} : {})}));
    const rows = indices.map(index => ({...input.rows[index], ...Object.fromEntries(selection.metrics.map(metric => [metric, cells.has(JSON.stringify([index, metric])) ? input.rows[index][metric] : null]))}));
    const narrowed: ReportCard = {...card, chart_model: 'semantic', chart_input: {columns, rows}, chart_intent: 'comparison',
        chart_preference: {call_id: String(card.source_call_id || card.id), intent: 'comparison', metrics: [...selection.metrics]}};
    const original = planSavedCharts(narrowed);
    const candidates = [...original.recommended, ...original.alternatives].filter(spec => spec.mark !== 'stacked' || indices.length === input.rows.length);
    if (!candidates.length) return unavailable();
    const safe = candidates.map(spec => ({...spec, columns: spec.columns.filter(column => column.role === 'dimension' || chosenMetrics.has(column.name)),
        points: spec.points.map(point => ({...point, rowIndex: indices[point.rowIndex], label: labels.get(indices[point.rowIndex])!,
            values: Object.fromEntries(selection.metrics.map(metric => [metric, point.values[metric] ?? null]))})),
        notices: [...spec.notices.filter(notice => !notice.endsWith('筆數量或維度未完整取得，未補零')), '只呈現原回答已顯示的保存值；未引用或缺值的儲存格維持未知，未補零']}));
    const preferred = presentation.preferred_chart_kind ? safe.filter(spec => spec.mark === presentation.preferred_chart_kind) : [];
    const groups = new Set<string>();
    const recommended = (preferred.length ? preferred : safe).filter(spec => {if (groups.has(spec.groupId)) return false; groups.add(spec.groupId); return true;});
    const selected = new Set(recommended.map(spec => spec.id));
    return {recommended, alternatives: safe.filter(spec => !selected.has(spec.id))};
}
