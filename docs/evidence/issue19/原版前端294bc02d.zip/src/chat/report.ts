import {completedConversationLabel} from './conversation-presentation';
import { reportedTokenTotal } from './core';
import type { MetricDay, ReportCard, Turn } from './types';
export function formatNumber(value: unknown): string { return Number.isFinite(Number(value)) && value !== null && value !== '' ? Number(value).toLocaleString('zh-TW') : '—'; }
export function formatDate(value?: string | null): string { if (!value) return ''; const date = new Date(value); return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('zh-TW', {month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'}); }
export function statusText(turn?: Turn | null): string {
    const labels: Record<string, string> = {queued: '等待分析', submitting: '準備分析', running: '正在查詢 MES', completed: completedConversationLabel(turn), failed: '分析失敗', cancelled: '已停止分析', submission_unknown: '正在確認送出狀態'};
    const statuses: Record<string, string> = {succeeded: '已完成', insufficient_data: completedConversationLabel(turn), failed: '分析失敗', cancelled: '已停止分析', started: '正在分析', rate_limited: '暫時限制使用'};
    return labels[turn?.execution_state || ''] || statuses[turn?.status || ''] || '正在連線';
}
export function reportText(value: unknown): string {
    if (value === null || value === undefined) return '—';
    if (typeof value === 'number') return Number.isFinite(value) ? value.toLocaleString('zh-TW', {maximumFractionDigits: 2}) : '—';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
}
const sourceLabels: Record<string, string> = {backup: '備份資料', simulation: '模擬資料', mixed: '混合資料', unknown: '來源未確認', mes_database: 'MES 資料庫'};
export const sourceNoticeLabels: Record<string, string> = {backup: '備份資料，非現場即時資料', simulation: '模擬資料，供測試使用', mixed: '包含備份與模擬資料，非現場即時資料', unknown: '資料來源尚未確認', mes_database: '依資料庫實際紀錄時間，資料更新頻率尚未驗證'};
export function sourceText(card: ReportCard): string { return sourceLabels[card.provenance || 'unknown'] || '來源未確認'; }
export function warningKey(warning: unknown): string { return typeof warning === 'string' ? warning.trim().replace(/\s+/g, ' ') : reportText(warning); }
export function metricsSummary(items: MetricDay[]): {label: string; value: number | null; displayValue: string}[] {
    const values: [string, number | null][] = [['問題數', items.reduce((sum, item) => sum + Number(item.question_count || 0), 0)], ['已取得 Token 合計', reportedTokenTotal(items)], ['負評數', items.reduce((sum, item) => sum + Number(item.negative_feedback_count || 0), 0)]];
    return values.map(([label, value]) => ({label, value, displayValue: value === null ? '尚未取得' : formatNumber(value)}));
}

/** 這兩項圖表提示依產品決定僅留在查詢依據，不改數據與截斷方式 */
export function isChartEvidenceNotice(notice: string): boolean {
    return notice === '數量單位尚未驗證' || /^顯示已保存順序的前 \d+ 項／共 \d+ 項，完整資料請查看明細$/.test(notice);
}
