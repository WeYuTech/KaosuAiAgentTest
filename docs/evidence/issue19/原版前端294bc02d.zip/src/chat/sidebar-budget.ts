import {isTerminal} from './core';
import {tokenText, type BudgetSnapshot, type BudgetUsage} from './operations';
import type {ChatState, Turn} from './types';

export interface SidebarBudgetSummary {
    scope: 'account' | 'system'; scopeLabel: string; period: string;
    confirmedText: string; reservedText: string; limitText: string;
    percentage: number | null; percentageText: string; note: string;
    warning: boolean; reached: boolean; accessibleText: string;
}
function validCount(value: unknown): value is number {return typeof value === 'number' && Number.isFinite(value) && value >= 0;}

/** 明確選一個額度範圍，從不合併帳號與系統數字，也不把待確認用量補零 */
export function sidebarBudgetSummary(snapshot: BudgetSnapshot): SidebarBudgetSummary {
    const usage: BudgetUsage = snapshot.account.limit === null && snapshot.system.limit !== null ? snapshot.system : snapshot.account;
    const scopeLabel = usage.scope === 'account' ? '目前帳號' : '整個系統';
    const knownCounts = validCount(usage.confirmed_tokens) && validCount(usage.reserved_tokens);
    const counts = knownCounts ? usage.confirmed_tokens + usage.reserved_tokens : null;
    const limit = usage.limit;
    const ratio = validCount(limit) && limit > 0 && counts !== null ? counts / limit * 100 : null;
    const percentage = ratio === null ? null : Math.min(100, Math.max(0, ratio));
    // 文字保留超過上限的比例，視覺進度僅限制在 0 至 100
    const percentageText = ratio === null ? '' : `${ratio.toLocaleString('zh-TW', {maximumFractionDigits: 1})}%`;
    const limitText = limit === null ? '尚未設定月上限' : limit === 0 ? '本月額度為 0' : validCount(limit) ? `月上限 ${tokenText(limit)}` : '月上限尚未取得';
    const unknown = usage.usage_status !== 'known' || !knownCounts || !validCount(usage.unknown_request_count) || usage.unknown_request_count > 0;
    const unknownText = validCount(usage.unknown_request_count) && usage.unknown_request_count > 0 ? `含 ${tokenText(usage.unknown_request_count)} 筆待確認用量` : '含尚未確認用量';
    const systemWarning = usage.scope === 'account' && snapshot.system.limit !== null && (snapshot.system.reached || snapshot.system.near_limit);
    const capped = validCount(limit);
    const notes = [
        ...(unknown ? [unknownText] : []),
        ...(capped && usage.reached ? ['額度已達上限'] : capped && usage.near_limit ? [`已達 ${usage.config.warning_percent}% 提醒門檻`] : []),
        ...(systemWarning ? [snapshot.system.reached ? '系統額度已達上限' : '系統額度接近上限'] : []),
    ];
    const note = notes.length ? notes.join(' · ') : '已確認與預留用量';
    const confirmedText = tokenText(usage.confirmed_tokens), reservedText = tokenText(usage.reserved_tokens);
    return {scope: usage.scope, scopeLabel, period: snapshot.period, confirmedText, reservedText, limitText, percentage, percentageText,
        note, warning: capped && (usage.reached || usage.near_limit) || systemWarning, reached: capped && usage.reached,
        accessibleText: `${scopeLabel}，${snapshot.period}，已確認 ${confirmedText} Token，預留 ${reservedText} Token，${limitText}${percentageText ? `，已確認加預留占 ${percentageText}` : ''}，${note}，用量紀錄不是精確帳單`};
}

type RefreshState = Pick<ChatState, 'opened' | 'expired' | 'submitting' | 'activeTurn'> & {visible: boolean; editingBudget: boolean};
// 待確認回合只刷新用量，不將它當成可續問的業務終態
function budgetNeedsReview(turn: Turn | null): boolean {return isTerminal(turn) || turn?.execution_state === 'submission_unknown';}

/** 只決定何時重新讀取既有用量 API；切換版型、串流片段及歷史回看不重複刷新 */
export class SidebarBudgetRefresh {
    private opened = false;
    private dirty = true;
    private submitting = false;
    private pendingRequest: string | null = null;
    private wasSubmitting = false;
    private previousRequest: string | null = null;
    private submissionBaseline: string | null = null;
    invalidate() {this.dirty = true;}
    observe(state: RefreshState): boolean {
        const turn = state.activeTurn;
        if (state.submitting && !this.wasSubmitting) {this.submissionBaseline = this.previousRequest; this.pendingRequest = null;}
        // 快速完成可能略過 queued/running，但送出中出現的新 Request ID 仍屬此次需求
        if (turn?.request_id && (!budgetNeedsReview(turn) || state.submitting && turn.request_id !== this.submissionBaseline)) this.pendingRequest = turn.request_id;
        if (state.submitting) this.submitting = true;
        this.wasSubmitting = state.submitting; this.previousRequest = turn?.request_id || null;
        if (!state.submitting && (this.submitting && this.pendingRequest === null && !turn?.request_id || !!turn?.request_id && turn.request_id === this.pendingRequest && budgetNeedsReview(turn))) {
            this.dirty = true; this.submitting = false;
            if (budgetNeedsReview(turn)) this.pendingRequest = null;
        }
        if (!state.opened) {this.opened = false; this.dirty = true; return false;}
        if (!this.opened) {this.opened = true; this.dirty = true;}
        if (state.expired) {this.dirty = true; return false;}
        if (!state.visible || state.editingBudget || !this.dirty) return false;
        this.dirty = false;
        return true;
    }
}
