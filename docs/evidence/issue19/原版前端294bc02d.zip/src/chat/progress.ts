import type {ChatState} from './types';
import {isTerminal} from './core';
import {readExecutionTrace} from './execution-trace';

type ExecutionView = Pick<ChatState, 'submitting' | 'cancelling' | 'expired' | 'unknownSubmission' | 'watchUnavailable' | 'activeTurn' | 'connectionStatus' | 'hint'>;

/** 只推導顯示狀態，不提交、恢復或取消回合 */
export function chatExecutionStatus(state: ExecutionView): {spinning: boolean; text: string} {
    const phase = state.activeTurn?.execution_state;
    const spinning = !state.expired && !state.cancelling && !state.unknownSubmission && !state.watchUnavailable && !isTerminal(state.activeTurn)
        && (state.submitting || phase === 'queued' || phase === 'submitting' || phase === 'running');
    const currentText = state.connectionStatus || (state.hint.startsWith('可接續追問') ? '' : state.hint);
    const liveText = state.activeTurn?.answer && ['正在查詢 MES', '正在分析', '正在分析問題'].includes(currentText)
        ? '正在產生回答' : currentText;
    const observed = state.activeTurn && readExecutionTrace(state.activeTurn).length > 0;
    const text = state.cancelling ? '正在停止分析' : spinning
        ? observed ? liveText || '正在分析' : phase === 'queued' ? '等待分析' : phase === 'submitting' ? '正在準備分析'
            : phase === 'running' ? liveText || '正在分析' : state.submitting ? '正在送出問題' : liveText || '正在分析'
        : currentText;
    return {spinning, text};
}
