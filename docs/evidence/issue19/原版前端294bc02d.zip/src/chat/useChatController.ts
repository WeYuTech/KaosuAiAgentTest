import { useEffect, useMemo, useSyncExternalStore } from 'react';
import { ChatController } from './controller';
import type { ChatConfig, ChatControllerResult } from './types';

export function useChatController(config: ChatConfig, prefix: string): ChatControllerResult {
    const controller = useMemo(() => new ChatController(config, prefix), [config, prefix]);
    const state = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
    useEffect(() => { controller.start(); return () => controller.dispose(); }, [controller]);
    return {state, actions: controller.actions};
}
