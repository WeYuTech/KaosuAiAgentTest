import { useEffect, useMemo, useRef } from 'react';
import type { ReactNode } from 'react';
import { AssistantRuntimeProvider, useExternalStoreRuntime } from '@assistant-ui/react';
import type { AppendMessage, ExternalStoreAdapter, MessageStatus, ThreadMessageLike } from '@assistant-ui/react';
import { groupConversations } from './core';
import { getMesFollowupSource } from './follow-ups';
import type { ChatControllerResult, ChatState, Message } from './types';

/** 原始 MES 訊息留在 metadata，報告與依據仍讀取控制器已保存的結果。 */
export function convertMesMessage(message: Message, index: number, conversationId: string | null = null): ThreadMessageLike {
    const identity = message.role === 'user'
        ? message.client_message_id || message.request_id || message.sequence || index
        : message.request_id || message.client_message_id || message.sequence || index;
    const timestamp = message.created_at || message.started_at || message.completed_at;
    const parsed = timestamp ? new Date(timestamp) : undefined;
    let status: MessageStatus | undefined;
    if (message.role === 'assistant') {
        if (message.watch_unavailable === true) status = {type: 'incomplete', reason: 'other'};
        else if (message.execution_state === 'cancelled' || message.status === 'cancelled') status = {type: 'incomplete', reason: 'cancelled'};
        else if (message.execution_state === 'failed' || message.status === 'failed' || message.status === 'rate_limited') status = {type: 'incomplete', reason: 'error', ...(message.error_message ? {error: message.error_message} : {})};
        else if (message.execution_state === 'submission_unknown') status = {type: 'incomplete', reason: 'other'};
        else if (message.execution_state && ['queued', 'submitting', 'running'].includes(message.execution_state) || message.status === 'started') status = {type: 'running'};
        else status = {type: 'complete', reason: 'stop'};
    }
    return {
        id: `${conversationId || 'new'}:${message.role}:${identity}`,
        role: message.role,
        content: status?.type === 'incomplete' && status.reason === 'error' && message.error_message
            && message.content.trim() === message.error_message.trim()
            ? [] : [{type: 'text', text: message.content}],
        ...(parsed && !Number.isNaN(parsed.getTime()) ? {createdAt: parsed} : {}),
        ...(status ? {status} : {}),
        metadata: {
            custom: {mesMessage: message, requestId: message.request_id, conversationId},
            ...(message.feedback ? {submittedFeedback: {type: message.feedback.rating === 'up' ? 'positive' : 'negative', ...(message.feedback.note ? {comment: message.feedback.note} : {})}} : {}),
        },
    };
}

/** 僅接受使用者文字；附件與其他內容不觸發 MES 請求。 */
function submittedText(message: AppendMessage): string | null {
    if (message.role !== 'user' || message.attachments?.length || message.content.some(part => part.type !== 'text')) return null;
    const text = message.content.map(part => part.type === 'text' ? part.text : '').join('');
    return text.trim() ? text : null;
}

/** 所有動作交回既有 controller；此適配器不擁有 API、觀看或 MES 計算。 */
export function createMesExternalStoreAdapter(
    {state, actions}: ChatControllerResult,
    currentState: () => ChatState = () => state,
): ExternalStoreAdapter<Message> {
    return {
        messages: state.displayMessages,
        suggestions: getMesFollowupSource(state)?.suggestions || [],
        convertMessage: (message, index) => convertMesMessage(message, index, state.conversationId),
        isRunning: (state.showStop || state.submitting) && !state.watchUnavailable,
        isDisabled: state.inputDisabled,
        isSendDisabled: state.sendDisabled,
        unstable_persistsHistory: true,
        unstable_capabilities: {copy: true},
        onNew: async message => {
            const latest = currentState();
            const text = submittedText(message);
            if (text === null || latest.sendDisabled || latest.inputDisabled || latest.expired || latest.readOnly || latest.submitting || latest.showStop || latest.unknownSubmission) return;
            actions.setDraft(text);
            await actions.submitQuestion();
        },
        ...(!state.inputDisabled && !state.expired && !state.readOnly && !state.submitting && !state.showStop && !state.unknownSubmission && state.runtime?.supports_message_edit === true ? {
            onEdit: async (message: AppendMessage) => {
                const latest = currentState();
                const text = submittedText(message);
                if (text === null || latest.inputDisabled || latest.expired || latest.readOnly || latest.submitting || latest.showStop || latest.unknownSubmission || latest.runtime?.supports_message_edit !== true) return;
                const source = latest.displayMessages.find((item, index) => item.role === 'user' && convertMesMessage(item, index, latest.conversationId).id === message.sourceId);
                if (source?.request_id) await actions.resubmitQuestion(source.request_id, text);
            },
        } : {}),
        onCancel: async () => {
            const latest = currentState();
            if (latest.showStop && !latest.cancelling && !latest.expired) await actions.cancelTurn();
        },
        onRefetchThread: () => actions.reconnect(),
        adapters: {
            threadList: {
                ...(state.conversationId ? {threadId: state.conversationId} : {}),
                isLoading: state.historyLoading,
                threads: groupConversations(state.conversations).flatMap(group => group.items).map(conversation => ({
                    id: conversation.conversation_id,
                    remoteId: conversation.conversation_id,
                    title: conversation.title || '新聊天',
                    status: 'regular',
                    custom: {mesConversation: conversation},
                })),
                onSwitchToNewThread: () => actions.newChat(),
                onSwitchToThread: id => actions.selectConversation(id, true),
            },
            feedback: {
                submit: async ({message, type, comment}) => {
                    const mesMessage = message.metadata.custom.mesMessage as Message | undefined;
                    const latest = currentState();
                    const requestId = mesMessage?.request_id;
                    if (!requestId || mesMessage.role !== 'assistant' || mesMessage.audit_status === 'unavailable' || !['succeeded', 'insufficient_data', undefined].includes(mesMessage.status) || latest.feedbackSaving.includes(requestId) || latest.expired) return;
                    await actions.saveFeedback(requestId, {rating: type === 'positive' ? 'up' : 'down', reason: null, note: comment || ''});
                },
            },
        },
    };
}

export function useMesAssistantRuntime(controller: ChatControllerResult) {
    const stateRef = useRef(controller.state);
    stateRef.current = controller.state;
    const adapter = useMemo(() => createMesExternalStoreAdapter(controller, () => stateRef.current), [controller.state, controller.actions]);
    const runtime = useExternalStoreRuntime(adapter);
    // Input 的 value 與 onChange 都沿用控制器草稿，避免兩個更新時序回寫舊值並移動游標。
    // 不訂閱 runtime 送出時自動清空文字，避免清掉 controller 保存的另一份草稿。
    // 同步放在 runtime 自己的 adapter effect 之後，確保讀到切換後的新 composer。
    useEffect(() => {
        const composer = runtime.thread.composer;
        if (composer.getState().text !== controller.state.draft) composer.setText(controller.state.draft);
    }, [runtime, controller.state.conversationId, controller.state.draft, controller.state.opened, controller.state.view]);
    return runtime;
}

export function MesAssistantProvider({state, actions, children}: ChatControllerResult & {children: ReactNode}) {
    const runtime = useMesAssistantRuntime({state, actions});
    return <AssistantRuntimeProvider runtime={runtime}>{children}</AssistantRuntimeProvider>;
}
