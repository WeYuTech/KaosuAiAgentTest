import type {Turn} from './types';
import {latestTraceStep, readExecutionTrace} from './execution-trace';
import type {TraceStep} from './execution-trace';

const toolLabels: Readonly<Record<string, string>> = {
    get_work_order_summary: '工單報工摘要',
    get_running_work_orders: '未結束作業工單',
    get_work_order_cycle_statistics: '工單循環資料',
    get_shift_production_summary: '班別報工',
    get_machine_performance: '機台循環資料',
    get_reporting_data_coverage: '報工資料範圍',
    get_work_order_reporting_records: '工單報工明細',
    get_machine_production_summary: '機台報工',
    get_personnel_production_summary: '人員組合報工',
    get_work_order_oee_records: '工單已存 OEE',
    get_machine_oee_records: '機台已存 OEE',
    get_oee_data_readiness: 'OEE 資料完整性',
    query_mes_metrics: 'MES 報工資料',
};
const publicConditions = new Set(['工單', '機台', '排除機台', '生產日', '起始生產日', '結束生產日（不含）', '班別', '往前小時']);

export interface QueryActivity {
    id: string;
    label: string;
    detail: string;
    status: string;
    running: boolean;
    failed: boolean;
}
export interface ActivityPresentation {
    label: string;
    running: boolean;
    queries: QueryActivity[];
}

function queryStatus(step: TraceStep, running: boolean, paused: boolean): string {
    if (step.status === 'running') return running ? paused ? '等待更新' : '查詢中' : '結果待確認';
    if (step.status === 'cancelled') return '已停止';
    if (step.status === 'failed' || step.result_status === 'failed') return '查詢未完成';
    if (step.status === 'interrupted' || step.status === 'observed') return '結果待確認';
    if (step.result_status === 'no_data') return '查無符合資料';
    if (step.result_status === 'insufficient_data') return '資料不完整';
    return '已查詢';
}

/** 只投影已保存事件；不推測未發生的工作、不解析答案，也不改寫診斷紀錄 */
export function activityPresentation(turn: Turn, paused = false): ActivityPresentation | null {
    const steps = readExecutionTrace(turn);
    if (!steps.length) return null;
    const running = ['queued', 'submitting', 'running'].includes(turn.execution_state || '');
    const queries = steps.filter(step => step.stage === 'querying')
        .sort((left, right) => Date.parse(left.started_at || left.observed_at) - Date.parse(right.started_at || right.observed_at))
        .map((step): QueryActivity => ({
            id: step.id,
            label: toolLabels[step.tool_name || ''] || 'MES 資料',
            detail: (step.conditions || []).filter(item => publicConditions.has(item.label))
                .map(item => `${item.label}：${item.value}`).join(' · '),
            status: queryStatus(step, running, paused),
            running: running && !paused && step.status === 'running',
            failed: step.status === 'failed' || step.result_status === 'failed',
        }));
    // 功能說明、澄清及無查詢回答完成後，不留下空的分析報告
    if (!running && !queries.length) return null;
    if (running) {
        const latest = latestTraceStep(steps)!;
        let label = '正在處理問題…';
        if (paused) label = '等待狀態更新…';
        else if (latest.stage === 'understanding') label = '正在分析問題…';
        else if (latest.stage === 'querying' && latest.status === 'running') label = `正在查詢${toolLabels[latest.tool_name || ''] || 'MES 資料'}…`;
        else if (latest.stage === 'answering' && latest.status === 'running') label = queries.length ? '正在整理查詢結果…' : '正在整理回答…';
        else if (latest.stage === 'verifying' && latest.status === 'running') label = queries.length ? '正在確認查詢結果…' : '正在確認回答…';
        return {label, running: !paused, queries};
    }
    const incomplete = turn.execution_state === 'failed' || turn.execution_state === 'submission_unknown'
        || queries.some(query => query.status === '結果待確認' || query.failed);
    const label = turn.execution_state === 'cancelled' ? '查詢已停止'
        : incomplete ? '查詢未完成'
            : queries.length === 1 ? `已查詢${queries[0]!.label}` : `已查詢 ${queries.length} 項資料`;
    return {label, running: false, queries};
}

/** 僅顯示實際等待時間；不推估完成百分比或模型輸出內容。 */
export function waitingDuration(turn: Turn, now: number): number | null {
    const start = Date.parse(turn.started_at || turn.created_at || '');
    return Number.isFinite(start) && Number.isFinite(now) ? Math.max(0, Math.floor((now - start) / 1000)) : null;
}
