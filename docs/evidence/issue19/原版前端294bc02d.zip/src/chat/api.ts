import { readSession } from './core';
import type { ChatConfig, Session } from './types';

declare const originalFetch: typeof fetch | undefined;
export class ChatApiError extends Error { status?: number; code?: string; userMessage?: string; requestId?: string | null }
export function errorText(error: unknown): string {
    const value = error as ChatApiError | undefined;
    if (value?.status === 401 || value?.status === 403) return '登入已逾時或沒有權限，請重新登入 MES';
    if (value?.code === 'quota_exceeded') return value.userMessage || '本月 Token 額度不足，請調整額度或等待下個月';
    return value?.userMessage || '目前無法連線到生產情報服務，請稍後重新確認';
}
export function conversationPath(id: string): string { return '/api/chat/conversations/' + encodeURIComponent(id); }
export function turnPath(id: string, requestId: string): string { return conversationPath(id) + '/turns/' + encodeURIComponent(requestId); }
export function reportPath(requestId: string): string { return '/api/chat/history/' + encodeURIComponent(requestId) + '/report?version=2'; }
export interface ApiEvents { notifySession(message?: string): void; rateLimited(until: number): void }
export interface RequestContext { notifySessionErrors?: boolean }
interface ErrorBody { detail?: string | {message?: string}; message?: string; code?: string; request_id?: string }
export class ChatApi {
    private readonly fetchImpl: typeof fetch;
    private readonly config: ChatConfig;
    private readonly prefix: string;
    private readonly accountNo: string;
    private readonly storage: Storage;
    private readonly events: ApiEvents;
    private rejectedSessionToken: string | null = null;
    constructor(config: ChatConfig, prefix: string, accountNo: string, storage: Storage, events: ApiEvents) {
        this.config = config; this.prefix = prefix; this.accountNo = accountNo; this.storage = storage; this.events = events;
        // 宿主包裝 fetch 會預先解析 JSON；串流仍使用未包裝的原始 fetch。
        this.fetchImpl = config.fetchImpl || (typeof originalFetch === 'function' ? originalFetch : window.fetch).bind(window);
    }
    session(): Session | null { const value = readSession(this.storage, this.prefix); return value && value.accountNo === this.accountNo && value.tokenKey !== this.rejectedSessionToken ? value : null; }
    async request(path: string, options: RequestInit = {}, context: RequestContext = {}): Promise<Response> {
        const activeSession = this.session();
        if (!activeSession) { this.events.notifySession(); const error = new ChatApiError('登入已逾時'); error.status = 401; error.userMessage = '登入已逾時，請重新登入 MES'; throw error; }
        const opts: RequestInit = Object.assign({method: 'GET', cache: 'no-store'}, options);
        const headers = new Headers({'X-MES-Account-No': activeSession.accountNo, TokenKey: activeSession.tokenKey, Accept: 'application/json'});
        new Headers(options.headers).forEach((value, key) => headers.set(key, value));
        if (opts.body) headers.set('Content-Type', 'application/json'); opts.headers = headers;
        let timeout: ReturnType<typeof setTimeout> | null = null;
        if (!opts.signal) { const controller = new AbortController(); opts.signal = controller.signal; timeout = setTimeout(() => controller.abort(), Math.max(1000, Number(this.config.apiRequestTimeoutMs) || 30000)); }
        let response: Response;
        try { response = await this.fetchImpl(String(this.config.apiBaseUrl || '').replace(/\/$/, '') + path, opts); }
        finally { if (timeout) clearTimeout(timeout); }
        if (!response.ok) {
            let body: ErrorBody | null = null;
            try { body = await response.json() as ErrorBody; } catch { /* 網路設備未必回傳 JSON。 */ }
            const error = new ChatApiError('HTTP ' + response.status); error.status = response.status;
            error.code = body?.code;
            const detail = body?.detail;
            error.userMessage = typeof detail === 'string' ? detail : detail?.message || body?.message || '服務回應失敗（' + response.status + '），請稍後再試';
            error.requestId = response.headers.get('X-Request-ID') || body?.request_id;
            // 管理憑證拒絕的 403 不影響聊天；401 仍沿用 MES 登入逾時流程。
            if (response.status === 401) {
                // 只拒絕此次使用的憑證；遲來的 401 不得使已更新的宿主憑證失效。
                if (this.session()?.tokenKey === activeSession.tokenKey) this.rejectedSessionToken = activeSession.tokenKey;
                if (!this.session()) this.events.notifySession(errorText(error));
            } else if (response.status === 403 && context.notifySessionErrors !== false) this.events.notifySession(errorText(error));
            if (response.status === 429 && body?.code !== 'quota_exceeded') {
                const value = response.headers.get('Retry-After'); const seconds = Number(value);
                this.events.rateLimited(Number.isFinite(seconds) && seconds > 0 ? Date.now() + seconds * 1000 : Date.parse(value || '') || Date.now() + 60000);
            }
            throw error;
        }
        return response;
    }
    async json<T>(path: string, options?: RequestInit, context?: RequestContext): Promise<T> { return (await this.request(path, options, context)).json() as Promise<T>; }
}
