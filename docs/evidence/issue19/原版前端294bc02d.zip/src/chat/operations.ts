export type BudgetScope = 'system' | 'account';
export interface BudgetConfig {monthly_token_limit: number | null; warning_percent: number; per_turn_reservation_tokens: number; revision: number}
export interface BudgetUsage {scope: BudgetScope; account_no?: string; config: BudgetConfig; confirmed_tokens: number; reserved_tokens: number; unknown_request_count: number; active_request_count: number; limit: number | null; reached: boolean; near_limit: boolean; remaining_tokens: number | null; usage_status: 'known' | 'unknown' | 'mixed'; committed_tokens: number; used_percent: number | null}
export interface BudgetSnapshot {period: string; timezone: 'Asia/Taipei'; billing_note: string; system: BudgetUsage; account: BudgetUsage; management: {write_allowed: boolean}}
export interface BudgetUpdate {scope: BudgetScope; account_no?: string; revision: number; monthly_token_limit?: number | null; warning_percent?: number; per_turn_reservation_tokens?: number}
export interface BudgetDraft {monthlyTokenLimit: string; warningPercent: string; reservationTokens: string}

export interface ParsedSchedule {source_text?: string; report_request: string; report_scope: 'plant_machine_personnel_output'; scope_label: string; frequency: 'daily' | 'weekdays'; hour: number; minute: number; timezone: 'Asia/Taipei'; data_window: 'previous_complete_production_day'; next_run_at: string; schedule_label?: string}
export interface ReportSchedule extends ParsedSchedule {schedule_id: string; account_no: string; client_schedule_id: string; source_text: string; status: 'active' | 'paused' | 'deleted'; revision: number}
export interface ScheduleCreate {client_schedule_id: string; text: string}
export interface ScheduleUpdate {revision: number; status: 'active' | 'paused'}
export interface ScheduledReportRow {good_qty: number | null; scrap_qty: number | null; total_qty: number | null; task_count: number | null}
export interface ScheduledReport {title: string; status: 'ok' | 'no_data'; period_start: string; period_end: string; timezone: string; data_source: string; generated_at: string; summary: ScheduledReportRow & {machine_count: number | null; personnel_count: number | null; reporting_group_count?: number | null}; machines: (ScheduledReportRow & {machine_id: string})[]; personnel: (ScheduledReportRow & {personnel_id: string})[]; warnings: string[]}
export interface ScheduledReportFailure {status: 'failed' | 'submission_unknown'; title?: string}
export interface ScheduleRun {run_id: string; schedule_id: string; account_no: string; due_at: string; status: 'claimed' | 'running' | 'completed' | 'failed' | 'missed' | 'interrupted' | 'submission_unknown'; report: ScheduledReport | ScheduledReportFailure | null; started_at?: string | null; completed_at?: string | null; finished_at?: string | null; error_message?: string | null}
export interface ScheduleList {items: ReportSchedule[]}
export interface ScheduleRunList {items: ScheduleRun[]}

export function budgetDraft(config: BudgetConfig): BudgetDraft {
    return {monthlyTokenLimit: config.monthly_token_limit === null ? '' : String(config.monthly_token_limit), warningPercent: String(config.warning_percent), reservationTokens: String(config.per_turn_reservation_tokens)};
}
function wholeNumber(text: string, label: string): number {
    if (!/^\d+$/.test(text.trim())) throw new Error(`${label}請輸入非負整數`);
    const value = Number(text.trim());
    if (!Number.isSafeInteger(value)) throw new Error(`${label}超出可輸入範圍`);
    return value;
}
/** 只傳變更欄位，不把讀取額度或切換區段變成設定寫入 */
export function buildBudgetUpdate(usage: BudgetUsage, draft: BudgetDraft): BudgetUpdate {
    const update: BudgetUpdate = {scope: usage.scope, revision: usage.config.revision, ...(usage.scope === 'account' ? {account_no: usage.account_no} : {})};
    const limit = draft.monthlyTokenLimit.trim() ? wholeNumber(draft.monthlyTokenLimit, '每月 Token 上限') : null;
    const warning = wholeNumber(draft.warningPercent, '提醒比例'), reservation = wholeNumber(draft.reservationTokens, '每題預留 Token');
    if (limit !== null && limit > 9000000000000000) throw new Error('每月 Token 上限超出可輸入範圍');
    if (warning < 1 || warning > 100) throw new Error('提醒比例請輸入 1 至 100');
    if (reservation < 1 || reservation > 1000000000) throw new Error('每題預留 Token 請輸入 1 至 1000000000');
    if (limit !== usage.config.monthly_token_limit) update.monthly_token_limit = limit;
    if (warning !== usage.config.warning_percent) update.warning_percent = warning;
    if (reservation !== usage.config.per_turn_reservation_tokens) update.per_turn_reservation_tokens = reservation;
    return update;
}
export function tokenText(value: unknown): string {return typeof value === 'number' && Number.isFinite(value) ? value.toLocaleString('zh-TW') : '尚未取得';}
export function scheduleTimeText(schedule: ParsedSchedule): string {
    return `${schedule.frequency === 'weekdays' ? '週一至週五' : '每天'} ${String(schedule.hour).padStart(2, '0')}:${String(schedule.minute).padStart(2, '0')}（台北時間）`;
}
export function operationErrorText(error: unknown): string {return error instanceof Error ? (error as Error & {userMessage?: string}).userMessage || error.message : '目前無法完成操作，請稍後再試';}

function record(value: unknown): value is Record<string, unknown> {return !!value && typeof value === 'object' && !Array.isArray(value);}
function reportNumber(value: unknown): boolean {return value === null || typeof value === 'number' && Number.isFinite(value);}
function productionRow(value: unknown): boolean {return record(value) && ['good_qty', 'scrap_qty', 'total_qty', 'task_count'].every(key => reportNumber(value[key]));}
/** 完整成功報表才可以讀取數字；失敗／部分資料不補零、不暴露診斷訊息 */
export function isScheduledReport(value: unknown): value is ScheduledReport {
    if (!record(value) || !['ok', 'no_data'].includes(String(value.status))) return false;
    if (!['title', 'period_start', 'period_end', 'timezone', 'data_source', 'generated_at'].every(key => typeof value[key] === 'string')) return false;
    const summary = value.summary;
    if (!record(summary) || !productionRow(summary) || !['machine_count', 'personnel_count'].every(key => reportNumber(summary[key]))) return false;
    if (summary.reporting_group_count !== undefined && !reportNumber(summary.reporting_group_count)) return false;
    if (!Array.isArray(value.machines) || !value.machines.every(row => record(row) && typeof row.machine_id === 'string' && productionRow(row))) return false;
    if (!Array.isArray(value.personnel) || !value.personnel.every(row => record(row) && typeof row.personnel_id === 'string' && productionRow(row))) return false;
    return Array.isArray(value.warnings) && value.warnings.every(warning => typeof warning === 'string');
}
export type ScheduledReportDisplay = {kind: 'ready'; report: ScheduledReport} | {kind: 'unavailable'; title: string; message: string};
export function scheduledReportDisplay(run: Pick<ScheduleRun, 'status' | 'report'>): ScheduledReportDisplay {
    if (run.status === 'submission_unknown' || run.report?.status === 'submission_unknown') return {kind: 'unavailable', title: '報告結果待確認', message: '此次報告結果尚未確認，不會自動重新執行，也不能當成零產出'};
    if (run.status === 'failed' || run.report?.status === 'failed') return {kind: 'unavailable', title: '報告查詢未完成', message: '此次報告未能完成，沒有可確認的產出數字，請查看下一次排程結果'};
    if (run.status === 'completed' && isScheduledReport(run.report)) return {kind: 'ready', report: run.report};
    if (run.status === 'claimed' || run.status === 'running') return {kind: 'unavailable', title: '報告尚未完成', message: '請稍後重新讀取已保存的報告'};
    return {kind: 'unavailable', title: '報告資料尚未完整', message: '目前沒有完整的報告資料，尚未取得的數字不能當成零'};
}

/** 一次建立需求保留識別碼；回應不明時只允許人工以相同識別碼重試 */
export class ScheduleCreationIdentity {
    private pending: {text: string; id: string} | null = null;
    private generate: () => string;
    constructor(generate = scheduleClientId) {this.generate = generate;}
    forText(text: string): string {
        if (this.pending?.text !== text) this.pending = {text, id: this.generate()};
        return this.pending.id;
    }
    confirmed() {this.pending = null;}
}
function scheduleClientId(): string {
    if (globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID();
    // MES 的 HTTP 宿主沒有 randomUUID，getRandomValues 仍可產生本次防重送識別碼
    const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6]! & 15) | 64; bytes[8] = (bytes[8]! & 63) | 128;
    const hex = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
