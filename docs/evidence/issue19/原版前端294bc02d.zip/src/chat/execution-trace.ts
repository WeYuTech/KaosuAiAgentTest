import type {Turn} from './types';

export const TRACE_VERSION = 'mes-execution-trace-v1';
export const TRACE_STAGES = [
    {id: 'understanding', label: '理解問題'}, {id: 'selecting', label: '選擇工具'},
    {id: 'querying', label: '查詢 MES'}, {id: 'verifying', label: '驗證結果'}, {id: 'answering', label: '產生回答'},
] as const;
export type TraceStage = typeof TRACE_STAGES[number]['id'];
export type TraceStatus = 'running' | 'completed' | 'failed' | 'cancelled' | 'interrupted' | 'observed';
export interface TraceStep {
    id: string; stage: TraceStage; status: TraceStatus; source: string; observed_at: string;
    started_at?: string | null; completed_at?: string | null; duration_ms?: number | null;
    tool_name?: string | null; conditions?: {label: string; value: string | number}[];
    result_status?: 'succeeded' | 'no_data' | 'insufficient_data' | 'failed' | null;
    verification?: 'passed' | 'rejected' | null;
}
const statuses: readonly string[] = ['running', 'completed', 'failed', 'cancelled', 'interrupted', 'observed'];
const sources = ['progress', 'graph_trace', 'tool_start', 'tool_result', 'answer_verification', 'answer_snapshot'];
const conditionLabels = ['工單', '機台', '排除機台', '生產日', '起始生產日', '結束生產日（不含）', '班別', '往前小時', '筆數上限', '略過筆數'];
const tools = new Set(['get_work_order_summary', 'get_running_work_orders', 'get_work_order_cycle_statistics', 'get_shift_production_summary', 'get_machine_performance', 'get_reporting_data_coverage', 'get_work_order_reporting_records', 'get_machine_production_summary', 'get_personnel_production_summary', 'get_work_order_oee_records', 'get_machine_oee_records', 'get_oee_data_readiness', 'query_mes_metrics']);
function record(value: unknown): Record<string, unknown> | null {return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;}
function timestamp(value: unknown): string | null {return typeof value === 'string' && Number.isFinite(Date.parse(value)) ? value : null;}
function readStep(value: unknown): TraceStep | null {
    const step = record(value);
    if (!step || typeof step.id !== 'string' || step.id.length > 128 || !TRACE_STAGES.some(stage => stage.id === step.stage) || !statuses.includes(String(step.status)) || !sources.includes(String(step.source)) || !timestamp(step.observed_at)) return null;
    const conditions: NonNullable<TraceStep['conditions']> = [];
    for (const raw of Array.isArray(step.conditions) ? step.conditions.slice(0, 52) : []) {
        const item = record(raw);
        if (!item || !conditionLabels.includes(String(item.label))) continue;
        const value = item.value;
        if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && value <= 10000 || typeof value === 'string' && /^[A-Za-z0-9_\-./:]{1,64}$/.test(value) && !/sk-|token|password|secret|bearer|api.?key/i.test(value)) conditions.push({label: String(item.label), value: value as string | number});
    }
    return {id: step.id, stage: step.stage as TraceStage, status: step.status as TraceStatus, source: String(step.source), observed_at: String(step.observed_at),
        started_at: timestamp(step.started_at), completed_at: timestamp(step.completed_at),
        duration_ms: typeof step.duration_ms === 'number' && Number.isSafeInteger(step.duration_ms) && step.duration_ms >= 0 ? step.duration_ms : null,
        tool_name: typeof step.tool_name === 'string' && tools.has(step.tool_name) ? step.tool_name : null, conditions,
        result_status: ['succeeded', 'no_data', 'insufficient_data', 'failed'].includes(String(step.result_status)) ? step.result_status as TraceStep['result_status'] : null,
        verification: ['passed', 'rejected'].includes(String(step.verification)) ? step.verification as TraceStep['verification'] : null};
}
/** 只接受版本化的公開投影，不從回答、工具結果或目前模式推測步驟 */
export function readExecutionTrace(turn: Turn): TraceStep[] {
    if (turn.execution_trace_version !== TRACE_VERSION || !Array.isArray(turn.execution_trace)) return [];
    const steps = new Map<string, TraceStep>();
    for (const raw of turn.execution_trace.slice(0, 256)) {const step = readStep(raw); if (step) steps.set(step.id, step);}
    return [...steps.values()];
}
export function applyTraceEvent(turn: Turn, data: {version?: unknown; step?: unknown}): Turn {
    const step = data.version === TRACE_VERSION ? readStep(data.step) : null;
    if (!step) return turn;
    const steps = readExecutionTrace(turn);
    const index = steps.findIndex(item => item.id === step.id);
    if (index >= 0) {
        if (Date.parse(steps[index]!.observed_at) > Date.parse(step.observed_at)) return turn;
        steps[index] = step;
    } else steps.push(step);
    return {...turn, execution_trace_version: TRACE_VERSION, execution_trace: steps};
}
export const traceStatusLabels: Record<TraceStatus, string> = {running: '執行中', completed: '已完成', failed: '失敗', cancelled: '已取消', interrupted: '結果待確認', observed: '已觀測，未取得結束紀錄'};
export function traceStepStatusLabel(step: TraceStep): string {
    if (step.verification === 'rejected') return '本次核對未通過';
    if (step.verification === 'passed') return '核對通過';
    return traceStatusLabels[step.status];
}
export const traceResultLabels = {succeeded: '工具已回傳，答案另行核對', no_data: '查無資料', insufficient_data: '資料不足', failed: '工具失敗'};
export function latestTraceStep(steps: TraceStep[]): TraceStep | undefined {
    return steps.reduce<TraceStep | undefined>((latest, step) => !latest || Date.parse(step.observed_at) >= Date.parse(latest.observed_at) ? step : latest, undefined);
}
export function traceProgressText(turn: Turn): string | null {
    const latest = latestTraceStep(readExecutionTrace(turn));
    if (!latest) return null;
    const label = TRACE_STAGES.find(stage => stage.id === latest.stage)!.label;
    return latest.status === 'running' ? `正在${label}` : `${label} · ${traceStatusLabels[latest.status]}`;
}
export function traceDuration(step: TraceStep): string {
    return step.duration_ms == null ? '耗時未提供' : step.duration_ms < 1000 ? `${step.duration_ms} 毫秒` : `${(step.duration_ms / 1000).toFixed(2)} 秒`;
}
export function traceElapsed(step: TraceStep, now: number): string {
    if (step.status !== 'running' || !step.started_at) return traceDuration(step);
    return `已經過 ${Math.max(0, (now - Date.parse(step.started_at)) / 1000).toFixed(1)} 秒`;
}
