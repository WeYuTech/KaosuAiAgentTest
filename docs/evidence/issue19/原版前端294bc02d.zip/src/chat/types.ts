import type {ChartMark, ChartSpec} from './chart-planner';
import type {ProviderSettings, SettingsUpdate} from './settings';
import type {TraceStep} from './execution-trace';
import type {BudgetSnapshot, BudgetUpdate, ParsedSchedule, ReportSchedule, ScheduleCreate, ScheduleUpdate, ScheduleList, ScheduleRun, ScheduleRunList} from './operations';
export type Mode = 'API' | 'AGENT';
export type ExecutionState = 'queued' | 'submitting' | 'running' | 'completed' | 'failed' | 'cancelled' | 'submission_unknown';
export type ResponseKind = 'answer' | 'clarification' | 'insufficient_data' | 'explanation' | 'rewrite' | 'capabilities' | 'schedules' | 'acknowledgement' | 'conversation';
export type ResultReason = 'missing_condition' | 'data_unavailable' | 'unsupported_capability' | 'verification_failed' | 'task_incomplete';
export interface AnswerPresentation {version: 'answer-presentation-v1'; mode: 'auto' | 'table' | 'chart'; preferred_chart_kind: 'bar' | null}
export interface BindingTable {columns: {key: 'subject' | 'metric' | 'value'; label: string}[]; rows: {subject: string; metric: string; value: string}[]}
export interface BindingSelection {metrics: string[]; row_indices: number[]; cells?: {row_index: number; metric: string}[]; row_subjects?: {row_index: number; label: string}[]}
export interface DefinitionSource { id: string; label: string; version: string }
export type AnswerStatus = 'started' | 'succeeded' | 'insufficient_data' | 'failed' | 'cancelled' | 'rate_limited';
export interface Session { accountNo: string; tokenKey: string; userName: string }
export interface Runtime { mode: Mode; api_provider?: 'cloud' | 'local'; continuous_context: boolean; supports_message_edit?: boolean; model_name?: string; [key: string]: unknown }
export interface Evidence { tool_name?: string; tool_label?: string; arguments?: Record<string, unknown>; query_start?: string; query_end?: string; data_source?: string; calculation?: string; status?: string; warnings?: string[] }
export interface Feedback { rating: 'up' | 'down'; reason: string | null; note: string }
export interface Usage { total_tokens?: number | null; input_tokens?: number | null; output_tokens?: number | null; [key: string]: unknown }
export interface FollowUpSuggestion { title: string; prompt: string }
export type SupplementaryAnalysisState = 'pending' | 'running' | 'completed' | 'no_signal' | 'insufficient_data' | 'failed' | 'cancelled';
export interface SupplementaryFinding {id: string; title: string; observation: string; scope: string; comparison: string; follow_up: {label: string; question: string}}
export interface SupplementaryAnalysis {request_id: string; state: SupplementaryAnalysisState; progress?: string; findings: SupplementaryFinding[]; reason?: string}
export interface SupplementaryAnalysisReadError {message: string; retryable: boolean}
export interface Turn { supplementary_analysis?: SupplementaryAnalysis | null; answer_presentation?: AnswerPresentation | null; result_reasons?: ResultReason[] | null; report?: unknown; report_available?: boolean; response_kind?: ResponseKind | null; source_request_id?: string | null; definition_sources?: DefinitionSource[]; event_sequence?: number; execution_trace_version?: string; execution_trace?: TraceStep[]; conversation_id?: string; request_id?: string; client_message_id?: string; question?: string; execution_state?: ExecutionState; status?: AnswerStatus; answer?: string; error_message?: string | null; created_at?: string; started_at?: string; completed_at?: string | null; updated_at?: string; audit_status?: string; usage_known?: boolean; usage?: Usage | null; model_name?: string; evidence?: Evidence[]; warnings?: string[]; feedback?: Feedback | null; query_scope?: Record<string, unknown>; query_scope_summary?: string; scope_inherited?: boolean; follow_up_suggestions?: FollowUpSuggestion[]; [key: string]: unknown }
export interface Message extends Turn { role: 'user' | 'assistant'; content: string; sequence?: number }
export interface Conversation { conversation_id: string; title: string; mode?: Mode; updated_at?: string; created_at?: string; read_only?: boolean; read_only_reason?: string | null; active_request_id?: string | null; last_message_preview?: string; legacy?: boolean; title_customized?: boolean; is_pinned?: boolean; is_archived?: boolean; metadata_version?: number; messages?: Message[]; next_after_seq?: number | null; [key: string]: unknown }
export interface ConversationUpdate { title?: string; is_pinned?: boolean; is_archived?: boolean }
export interface PendingTurn { clientMessageId?: string; question?: string; requestId?: string | null; createdAt?: number }
export type PendingTurns = Record<string, PendingTurn>;
export type Drafts = Record<string, string>;
export interface ReportMetric { key: string; label?: string; value: unknown; unit?: string; detail?: string }
export interface ReportColumn { key: string; label?: string }
export type ChartIntent = 'auto' | 'comparison' | 'trend' | 'relationship' | 'composition' | 'distribution';
export interface ValueGuard {field: string; operator: 'eq' | 'gte'; value: number | boolean}
export interface ChartMetadata {version: 'mes-chart-metadata-v1'; fingerprint: string; columns: SemanticReportColumn[]}
export interface SemanticReportColumn { name: string; label: string; role: 'dimension' | 'metric' | 'quality'; data_type: 'string' | 'number' | 'date' | 'datetime' | 'boolean'; unit?: string | null; definition?: string; completeness_required?: boolean; required_missing_fields?: string[]; interpretation?: string; temporal_grain?: 'day' | 'month' | 'instant'; comparison_group?: string; composition?: {group: string; role: 'component' | 'total'}; availability_count_field?: string; source_group?: string; complete_counterpart?: string; target_field?: string; value_guards?: ValueGuard[] }
export type Provenance = 'backup' | 'simulation' | 'mixed' | 'unknown' | 'mes_database';
export interface RawReportCard { binding_table?: BindingTable; binding_selection?: BindingSelection; binding_reason?: string; id: string; kind: string; title?: string; status?: string; provenance?: Provenance; source_label?: string; data_time?: string; metrics?: ReportMetric[]; semantic_columns?: SemanticReportColumn[]; chart_intent?: ChartIntent; formula?: { label?: string; expression?: string; substitution?: string }; detail?: { columns?: ReportColumn[]; rows?: Record<string, unknown>[] }; evidence?: Evidence[]; warnings?: string[]; notes?: string[]; [key: string]: unknown }
export type ChartContract = 'legacy_r44' | 'metadata_v1' | 'v2' | 'unavailable';
export interface ChartPreference {call_id: string; intent: ChartIntent; metrics: string[]}
export interface ReportViewSelection {mark: ChartMark | 'table'; metrics: string[]}
export interface ReportViewPreferences {version: 'report-view-preferences-v1'; revision: number; selections: (ReportViewSelection & {card_id: string})[]}
export interface ReportDisplayMetric {key: string; label: string; value: string; unit: string; detail?: string}
export interface ReportDisplay {answer: boolean; highlights: ReportDisplayMetric[]; metrics: ReportDisplayMetric[]; columns: ReportColumn[]}
export interface ReportCard extends RawReportCard {display: ReportDisplay; primary_metrics?: string[]; chart_contract: ChartContract; chart_model: 'legacy' | 'semantic'; chart_reason?: string; chart_preference?: ChartPreference; binding_chart_input?: {columns: SemanticReportColumn[]; rows: Record<string, unknown>[]}; chart_input?: {columns: SemanticReportColumn[]; rows: Record<string, unknown>[]}; legacy_charts?: ChartSpec[]; chart_metadata?: ChartMetadata}
export interface Report { view_preferences?: ReportViewPreferences; view_preferences_editable?: boolean; view_preferences_reason?: string; answer_presentation?: AnswerPresentation | null; source_answer?: string; report_version: 'mes-report-v1' | 'mes-report-v2'; request_id: string; cards: ReportCard[]; warnings?: string[]; evidence?: Evidence[]; [key: string]: unknown }
export interface ReportEntry { state: 'loading' | 'ready' | 'retryable-error' | 'missing' | 'unavailable'; report: Report | null; message: string }
export interface ReportDialog { requestId: string; cardId: string | null; view: 'detail' | 'evidence'; report: Report }
export interface MetricDay { date: string; question_count?: number; total_tokens?: number | string | null; negative_feedback_count?: number; technical_error_rate_percent?: number; negative_feedback_rate_percent?: number; average_success_duration_ms?: number; average_duration_ms?: number; [key: string]: unknown }
export interface ChatConfig { apiBaseUrl?: string; historyPageSize?: number; metricsDays?: number; pollIntervalMs?: number; watchTimeoutMs?: number; apiRequestTimeoutMs?: number; exportRequestTimeoutMs?: number; inputPlaceholder?: string; productionLabel?: string; fetchImpl?: typeof fetch; storage?: Storage }
export type CopilotConfig = ChatConfig;
export interface ChatState {
    enabled: boolean; opened: boolean; expanded: boolean; historyOpen: boolean; view: 'chat' | 'metrics';
    runtime: Runtime | null; conversationId: string | null; conversationTitle: string; conversation: Conversation | null; conversations: Conversation[];
    historyCursor: string | null; historyLoading: boolean; historyLoaded: boolean; historyStatus: string; historyArchived: boolean; conversationSaving: string[];
    messages: Message[]; activeTurn: Turn | null; displayMessages: Message[]; draft: string;
    submitting: boolean; cancelling: boolean; connectionStatus: string; sessionNotice: string; expired: boolean;
    readOnly: boolean; readOnlyNotice: string; hint: string; sendDisabled: boolean; inputDisabled: boolean; showStop: boolean;
    unknownSubmission: boolean; reconnectNeeded: boolean; watchUnavailable?: boolean; reports: Record<string, ReportEntry>; exporting: string[]; feedbackSaving: string[];
    supplementaryAnalysisErrors?: Record<string, SupplementaryAnalysisReadError>; presentationSaving?: string[]; presentationErrors?: Record<string, string>;
    reportDialog: ReportDialog | null; metrics: MetricDay[]; metricsStatus: string; toast: string | null;
}
export interface ChatActions {
    openChat(): Promise<void>; closeChat(): void; toggleExpanded(): void; toggleHistory(): void; closeHistory(): void;
    newChat(): void; selectConversation(id: string, closeHistory?: boolean): Promise<void>; loadHistory(reset?: boolean): Promise<void>;
    showArchivedConversations(archived: boolean): Promise<void>;
    loadConversationMetadata(id: string): Promise<Conversation>;
    updateConversation(id: string, patch: ConversationUpdate, metadataVersion?: number): Promise<Conversation>;
    deleteConversation(id: string, metadataVersion?: number): Promise<void>;
    setDraft(text: string): void; submitQuestion(): Promise<void>; resubmitQuestion(sourceRequestId: string, text: string): Promise<void>; cancelTurn(): Promise<void>; reconnect(): Promise<void>;
    loadReport(requestId: string): Promise<ReportEntry>; retryReport(requestId: string): Promise<ReportEntry>; openReport(requestId: string, cardId: string | null, view: 'detail' | 'evidence', fallback?: Report): Promise<void>; closeReport(): void;
    downloadReport(requestId: string): Promise<void>; saveFeedback(requestId: string, value: Feedback): Promise<boolean>;
    savePresentation(requestId: string, cardId: string, selection: ReportViewSelection | null): Promise<boolean>;
    observeSupplementaryAnalysis(requestId: string): () => void; retrySupplementaryAnalysis(requestId: string): void;
    copyAnswer(text: string): Promise<void>;
    loadMetrics(): Promise<void>; showChat(): Promise<void>; clearToast(): void;
    loadProviderSettings(managementToken?: string): Promise<ProviderSettings>;
    saveProviderSettings(update: SettingsUpdate, managementToken?: string): Promise<ProviderSettings>;
    loadBudget(managementToken?: string): Promise<BudgetSnapshot>;
    saveBudget(update: BudgetUpdate, managementToken?: string): Promise<BudgetSnapshot>;
    loadSchedules(): Promise<ScheduleList>;
    parseSchedule(text: string): Promise<ParsedSchedule>;
    createSchedule(update: ScheduleCreate): Promise<ReportSchedule>;
    updateSchedule(id: string, update: ScheduleUpdate): Promise<ReportSchedule>;
    deleteSchedule(id: string, revision: number): Promise<void>;
    loadScheduleRuns(id: string): Promise<ScheduleRunList>;
    loadSavedScheduleReports(): Promise<ScheduleRunList>;
    loadScheduleRun(id: string, runId: string): Promise<ScheduleRun>;
}
export interface ChatControllerResult { state: ChatState; actions: ChatActions }
export type InlineToken = { type: 'text' | 'strong' | 'code'; text: string } | { type: 'link'; text: string; url: string };
export type MarkdownBlock = { type: 'table'; headers: InlineToken[][]; rows: InlineToken[][][] } | { type: 'list'; ordered: boolean; items: InlineToken[][] } | { type: 'pre'; text: string } | { type: 'heading'; level: number; content: InlineToken[] } | { type: 'quote' | 'paragraph'; content: InlineToken[] };
export interface StreamEvent { name: string; id?: number; data: Turn & { delta?: string; text?: string; message?: string; version?: unknown; step?: unknown } }
