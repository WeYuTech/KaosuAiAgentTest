import core from './core';
import {applyTraceEvent, traceProgressText} from './execution-trace';
import { ChatApi, ChatApiError, conversationPath, errorText, turnPath } from './api';
import { statusText } from './report';
import {decodeReport, ReportDecodeError} from './report-decoder';
import {supplementaryAnalysisPending} from './supplementary-analysis';
import {SavedResultState} from './saved-result-state';
import type {ProviderSettings, SettingsUpdate} from './settings';
import type {BudgetSnapshot, BudgetUpdate, ParsedSchedule, ReportSchedule, ScheduleCreate, ScheduleList, ScheduleRun, ScheduleRunList} from './operations';
import type { ChatActions, ChatConfig, ChatState, Conversation, ConversationUpdate, Drafts, Feedback, Message, MetricDay, PendingTurns, Report, ReportEntry, Turn } from './types';

const defaultConfig = {apiBaseUrl: '', historyPageSize: 20, metricsDays: 30, pollIntervalMs: 2000, watchTimeoutMs: 120000};
const explanations: Record<string, string> = {archived: '這份聊天已封存，取消封存後才能繼續提問', legacy_history: '舊版單題紀錄僅供查看開啟「新聊天」即可繼續使用', mode_changed: '系統對話模式已更新，這份聊天僅供查看請開啟新聊天', configuration_changed: '模型或查詢工具已更新，這份聊天僅供查看請開啟新聊天', submission_unknown: '上一題的送出結果尚未確認，這份聊天暫時只能查看請勿重送同一問題，待確認後再開始新主題'};
function uuid(): string { return crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : r & 3 | 8).toString(16); }); }
function readStore<T>(storage: Storage, key: string, fallback: T): T { try { const value = storage.getItem(key); return value ? JSON.parse(value) as T : fallback; } catch { return fallback; } }

/** 控制器只管理狀態、保存與請求；呈現及焦點行為交由 React 元件。 */
export class ChatController {
    private readonly config: ChatConfig & typeof defaultConfig;
    private readonly storage: Storage;
    private readonly storeKey: string;
    private readonly pendingKey: string;
    private readonly draftKey: string;
    private readonly api: ChatApi;
    private readonly savedResults: SavedResultState;
    private pending: PendingTurns;
    private drafts: Drafts;
    private watchController: AbortController | null = null;
    private watchTimer: ReturnType<typeof setTimeout> | null = null;
    private watchEpoch = 0;
    private selectingEpoch = 0;
    private selectingConversationId: string | null = null;
    private historyEpoch = 0;
    private rateLimitUntil = 0;
    private toastTimer: ReturnType<typeof setTimeout> | null = null;
    private interval: ReturnType<typeof setInterval> | null = null;
    private reportDialogEpoch = 0;
    private disposed = false;
    private listeners = new Set<() => void>();
    private scheduleCreates = new Map<string, Promise<ReportSchedule>>();
    private budgetReads = new Map<string, Promise<BudgetSnapshot>>();
    private cancellingTurns = new Set<string>();
    private watchFailures = new Map<string, string>();
    private snapshot: ChatState;
    private data: Omit<ChatState, keyof ReturnType<SavedResultState['snapshot']>>;
    private readonly prefix: string;
    readonly actions: ChatActions;

    constructor(config: ChatConfig, prefix: string) {
        this.prefix = prefix;
        this.config = Object.assign({}, defaultConfig, config);
        this.storage = config.storage || localStorage;
        const initialSession = core.readSession(this.storage, prefix);
        this.storeKey = prefix + '_MES_AI_CHAT_' + (initialSession?.accountNo || ''); this.pendingKey = this.storeKey + '_TURNS'; this.draftKey = this.storeKey + '_DRAFTS';
        const savedId = readStore<unknown>(this.storage, this.storeKey, null); const conversationId = typeof savedId === 'string' ? savedId : null;
        const savedPending = readStore<unknown>(this.storage, this.pendingKey, {}); const savedDrafts = readStore<unknown>(this.storage, this.draftKey, {});
        this.pending = savedPending && typeof savedPending === 'object' && !Array.isArray(savedPending) ? savedPending as PendingTurns : {};
        this.drafts = savedDrafts && typeof savedDrafts === 'object' && !Array.isArray(savedDrafts) ? savedDrafts as Drafts : {};
        this.data = {enabled: !!initialSession, opened: false, expanded: false, historyOpen: false, view: 'chat', runtime: null, conversationId, conversationTitle: '新聊天', conversation: null, conversations: [], historyCursor: null, historyLoading: false, historyLoaded: false, historyStatus: '', historyArchived: false, conversationSaving: [], messages: [], activeTurn: null, displayMessages: [], draft: core.draftText(this.drafts, conversationId), submitting: false, cancelling: false, connectionStatus: '', sessionNotice: '', expired: !initialSession, readOnly: false, readOnlyNotice: '', hint: '', sendDisabled: true, inputDisabled: !initialSession, showStop: false, unknownSubmission: false, reconnectNeeded: false, feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null};
        this.api = new ChatApi(this.config, prefix, initialSession?.accountNo || '', this.storage, {notifySession: message => this.notifySession(message), rateLimited: until => { this.rateLimitUntil = until; this.publish(); }});
        this.savedResults = new SavedResultState(this.api, this.config, {
            scope: () => ({opened: this.data.opened, conversationId: this.data.conversationId, selecting: this.selectingConversationId !== null, disposed: this.disposed}),
            message: id => this.analysisMessage(id),
            replaceAnalysis: (id, analysis) => {
                // 分析只替換自己的投影，不更改主回答或前景送出狀態。
                this.data.messages = this.data.messages.map(message => message.request_id === id && message.role === 'assistant' ? {...message, supplementary_analysis: analysis} : message);
                if (this.data.activeTurn?.request_id === id) this.data.activeTurn = {...this.data.activeTurn, supplementary_analysis: analysis};
            },
            reportChanged: (id, report) => {
                if (id === null || this.data.reportDialog?.requestId === id) {
                    if (report && this.data.reportDialog) this.data.reportDialog = {...this.data.reportDialog, report};
                    else {this.reportDialogEpoch++; this.data.reportDialog = null;}
                }
                if (id === null) this.snapshot = {...this.snapshot, ...this.savedResults.snapshot(), reportDialog: null};
            },
            isArchived: id => !!this.conversationMetadata(id)?.is_archived,
            publish: () => this.publish(), notify: message => this.toast(message),
        });
        this.snapshot = {...this.data, ...this.savedResults.snapshot()};
        this.actions = {...this.operationsActions(), loadConversationMetadata: id => this.loadConversationMetadata(id), showArchivedConversations: archived => this.showArchivedConversations(archived), updateConversation: (id, patch, version) => this.updateConversation(id, patch, version), deleteConversation: (id, version) => this.deleteConversation(id, version), openChat: () => this.openChat(), closeChat: () => this.closeChat(), toggleExpanded: () => { this.data.expanded = !this.data.expanded; this.data.historyOpen = false; if (this.data.expanded && !this.data.historyLoaded) void this.loadHistory(true); this.publish(); }, toggleHistory: () => { this.data.historyOpen = !this.data.historyOpen; if (this.data.historyOpen && !this.data.historyLoaded) void this.loadHistory(true); this.publish(); }, closeHistory: () => { this.data.historyOpen = false; this.publish(); }, newChat: () => this.newChat(), selectConversation: (id, closeHistory) => this.selectConversation(id, closeHistory), loadHistory: reset => this.loadHistory(reset ?? true), setDraft: text => { this.data.draft = text; this.saveDraft(); this.publish(); }, submitQuestion: () => this.submitQuestion(), resubmitQuestion: (sourceRequestId, text) => this.resubmitQuestion(sourceRequestId, text), cancelTurn: () => this.cancelTurn(), reconnect: () => this.reconnect(), loadReport: requestId => this.savedResults.load(requestId), retryReport: requestId => this.savedResults.load(requestId, true), openReport: (requestId, cardId, view, fallback) => this.openReport(requestId, cardId, view, fallback), closeReport: () => { this.reportDialogEpoch++; this.data.reportDialog = null; this.publish(); }, downloadReport: requestId => this.savedResults.download(requestId), saveFeedback: (requestId, value) => this.saveFeedback(requestId, value), savePresentation: (requestId, cardId, selection) => this.savedResults.savePresentation(requestId, cardId, selection), observeSupplementaryAnalysis: id => this.savedResults.observeAnalysis(id), retrySupplementaryAnalysis: id => this.savedResults.retryAnalysis(id), copyAnswer: text => this.copyAnswer(text), loadMetrics: () => this.loadMetrics(), showChat: () => this.showChat(), clearToast: () => { this.data.toast = null; this.publish(); }, loadProviderSettings: token => this.providerSettings(undefined, token), saveProviderSettings: (update, token) => this.providerSettings(update, token)};
        this.publish();
    }
    subscribe = (listener: () => void): (() => void) => { this.listeners.add(listener); return () => this.listeners.delete(listener); };
    getSnapshot = (): ChatState => this.snapshot;
    start(): void { this.disposed = false; if (!this.interval) { this.interval = setInterval(() => { if (this.data.opened && !this.api.session()) { this.stopWatching(); this.savedResults.reset(); this.notifySession(); } else if (this.rateLimitUntil) this.publish(); }, 1000); window.addEventListener('storage', this.storageChanged); } }
    dispose(): void { this.disposed = true; this.selectingEpoch++; this.historyEpoch++; this.savedResults.reset(); this.stopWatching(); if (this.interval) clearInterval(this.interval); this.interval = null; if (this.toastTimer) clearTimeout(this.toastTimer); window.removeEventListener('storage', this.storageChanged); }
    private storageChanged = (event: StorageEvent): void => { if (event.key && event.key.startsWith(this.prefix + '_BI_') && !this.api.session()) { this.stopWatching(); this.savedResults.reset(); this.notifySession(); } };
    private persist(): void { try { this.storage.setItem(this.storeKey, JSON.stringify(this.data.conversationId)); this.storage.setItem(this.pendingKey, JSON.stringify(this.pending)); } catch { /* 限制儲存的瀏覽器仍可進行本次對話。 */ } }
    private saveDraft(conversationId = this.data.conversationId, text = this.data.draft): void { this.drafts = core.saveDraftText(this.drafts, conversationId, text); try { this.storage.setItem(this.draftKey, JSON.stringify(this.drafts)); } catch { /* 儲存受限時仍保留本次畫面的草稿。 */ } }
    private restoreDraft(): void { this.data.draft = core.draftText(this.drafts, this.data.conversationId); }
    private notifySession(message?: string): void { this.data.sessionNotice = message || '登入已逾時，請重新登入 MES 後再使用'; this.publish(); }
    private toast(text: string): void { if (this.toastTimer) clearTimeout(this.toastTimer); this.data.toast = text; this.publish(); this.toastTimer = setTimeout(() => { this.data.toast = null; this.publish(); }, 4500); }
    private publish(): void {
        if (this.disposed) return;
        const unresolved = !!(this.data.conversationId && this.pending[this.data.conversationId]); const readonly = !!this.data.conversation?.read_only;
        const expired = !this.api.session();
        const selecting = this.selectingConversationId !== null;
        const locked = selecting || this.data.submitting || unresolved || !this.data.runtime || readonly || expired || this.rateLimitUntil > Date.now();
        const hint = expired ? '登入已逾時，請重新登入 MES' : selecting ? '正在讀取聊天…' : readonly ? '這份紀錄只能查看，請開啟新聊天提問' : this.rateLimitUntil > Date.now() ? '暫時限制使用，' + Math.ceil((this.rateLimitUntil - Date.now()) / 1000) + ' 秒後可再提問' : this.data.submitting ? '正在送出問題…' : unresolved ? '這題仍在分析或確認中，請等完成後再提問' : this.data.runtime?.continuous_context ? '可接續追問 · Enter 送出 · Shift + Enter 換行' : '';
        const active = this.data.activeTurn; const requestId = this.data.conversationId && this.pending[this.data.conversationId]?.requestId;
        const watchRequestId = active?.request_id || requestId;
        const watchFailure = watchRequestId && this.data.conversationId ? this.watchFailures.get(turnPath(this.data.conversationId, watchRequestId)) : undefined;
        let displayMessages = this.data.messages.filter(message => !(message.role === 'assistant' && message.request_id && message.request_id === requestId));
        if (active && (!core.isTerminal(active) || !this.data.messages.some(message => message.role === 'assistant' && message.request_id === active.request_id))) displayMessages = displayMessages.concat([{...active, role: 'assistant', content: active.answer || watchFailure || active.error_message || '', ...(watchFailure ? {watch_unavailable: true} : {})}]);
        this.snapshot = {...this.data, messages: [...this.data.messages], conversations: [...this.data.conversations], ...this.savedResults.snapshot(), displayMessages, expired, readOnly: readonly, readOnlyNotice: readonly ? explanations[this.data.conversation?.read_only_reason || ''] || '這份聊天僅供查看請開啟新聊天提問' : '', hint, sendDisabled: !!(locked || !this.data.draft.trim()), inputDisabled: selecting || readonly || expired, showStop: !!(!selecting && active && !core.isTerminal(active) && active.request_id), cancelling: !!(active?.request_id && this.data.conversationId && this.cancellingTurns.has(turnPath(this.data.conversationId, active.request_id))), unknownSubmission: active?.execution_state === 'submission_unknown', watchUnavailable: !!watchFailure};
        this.listeners.forEach(listener => listener());
    }
    private stopWatching(): void { this.watchEpoch++; this.watchController?.abort(); this.watchController = null; if (this.watchTimer) clearTimeout(this.watchTimer); this.watchTimer = null; }
    private async providerSettings(update?: SettingsUpdate, managementToken?: string): Promise<ProviderSettings> {
        const result = await this.managementJson<ProviderSettings>('/api/chat/settings', update, managementToken);
        if (update && result.apply === 'immediate' && result.updated !== false) {
            await this.loadRuntime();
            const id = this.data.conversationId;
            if (id) {
                try {await this.loadConversationMetadata(id);}
                catch (error) {
                    if (this.data.conversationId === id && this.data.conversation) {
                        this.data.conversation = {...this.data.conversation, read_only: true, read_only_reason: 'configuration_changed'};
                        this.publish();
                    }
                    this.toast(errorText(error));
                }
            }
        }
        return result;
    }
    private managementJson<T>(path: string, update?: unknown, managementToken?: string): Promise<T> {
        const headers: Record<string, string> = {};
        if (managementToken?.trim()) headers['X-MES-Settings-Token'] = managementToken.trim();
        // 管理憑證失敗留在設定表單，不將現有 MES 聊天誤判為登入過期。
        return this.api.json<T>(path, {
            method: update ? 'PATCH' : 'GET', headers,
            ...(update ? {body: JSON.stringify(update)} : {}),
        }, {notifySessionErrors: false});
    }
    private operationsActions(): Pick<ChatActions, 'loadBudget' | 'saveBudget' | 'loadSchedules' | 'parseSchedule' | 'createSchedule' | 'updateSchedule' | 'deleteSchedule' | 'loadScheduleRuns' | 'loadSavedScheduleReports' | 'loadScheduleRun'> {
        const path = (id: string) => '/api/chat/schedules/' + encodeURIComponent(id);
        return {
            loadBudget: token => this.loadBudget(token),
            saveBudget: (update: BudgetUpdate, token) => {this.budgetReads.clear(); return this.managementJson<BudgetSnapshot>('/api/chat/budget', update, token);},
            loadSchedules: () => this.api.json<ScheduleList>('/api/chat/schedules'),
            parseSchedule: text => this.api.json<ParsedSchedule>('/api/chat/schedules/parse', {method: 'POST', body: JSON.stringify({text})}),
            createSchedule: update => this.createSchedule(update),
            updateSchedule: (id, update) => this.api.json<ReportSchedule>(path(id), {method: 'PATCH', body: JSON.stringify(update)}),
            deleteSchedule: async (id, revision) => {await this.api.request(path(id) + '?revision=' + encodeURIComponent(revision), {method: 'DELETE'});},
            loadScheduleRuns: id => this.api.json<ScheduleRunList>(path(id) + '/runs'),
            loadSavedScheduleReports: () => this.api.json<ScheduleRunList>('/api/chat/schedule-reports'),
            loadScheduleRun: (id, runId) => this.api.json<ScheduleRun>(path(id) + '/runs/' + encodeURIComponent(runId)),
        };
    }
    private loadBudget(token?: string): Promise<BudgetSnapshot> {
        const session = this.api.session();
        // 先走既有登入檢查，不讓失效帳號取到仍在進行中的舊請求
        if (!session) return this.managementJson<BudgetSnapshot>('/api/chat/budget', undefined, token);
        const key = JSON.stringify([session.accountNo, session.tokenKey, token?.trim() || '']);
        const existing = this.budgetReads.get(key);
        if (existing) return existing;
        const request = this.managementJson<BudgetSnapshot>('/api/chat/budget', undefined, token).then(value => {
            if (this.api.session()?.tokenKey !== session.tokenKey) {
                const error = new ChatApiError('額度回應所屬登入已變更'); error.status = 401; error.userMessage = '登入已更新，請重新讀取用量額度'; throw error;
            }
            return value;
        });
        this.budgetReads.set(key, request);
        void request.finally(() => {if (this.budgetReads.get(key) === request) this.budgetReads.delete(key);}).catch(() => {});
        return request;
    }
    private createSchedule(update: ScheduleCreate): Promise<ReportSchedule> {
        const text = update.text.trim(), existing = this.scheduleCreates.get(text);
        if (existing) return existing;
        const request = this.submitSchedule({...update, text});
        this.scheduleCreates.set(text, request);
        void request.finally(() => {if (this.scheduleCreates.get(text) === request) this.scheduleCreates.delete(text);}).catch(() => {});
        return request;
    }
    private scheduleIdentities(): {source_text: string; client_schedule_id: string}[] {
        const encoded = this.storage.getItem(this.storeKey + '_SCHEDULE_PENDING');
        if (!encoded) return [];
        const value: unknown = JSON.parse(encoded);
        if (!Array.isArray(value) || value.some(item => !item || typeof item.source_text !== 'string' || !item.source_text.trim() || item.source_text.length > 1000 || item.source_text !== item.source_text.trim() || typeof item.client_schedule_id !== 'string' || !/^[A-Za-z0-9_.:-]{1,128}$/.test(item.client_schedule_id))) throw new Error('排程識別碼格式無效');
        if (new Set(value.map(item => item.source_text)).size !== value.length || new Set(value.map(item => item.client_schedule_id)).size !== value.length) throw new Error('排程識別碼重複');
        return value;
    }
    private async submitSchedule(update: ScheduleCreate): Promise<ReportSchedule> {
        // 過期或跨帳號時沿用原登入門檻，不更新其他帳號的送出紀錄
        if (!this.api.session()) return this.api.json('/api/chat/schedules', {method: 'POST', body: JSON.stringify(update)});
        let identity: {source_text: string; client_schedule_id: string};
        try {
            const pending = this.scheduleIdentities();
            identity = pending.find(item => item.source_text === update.text) || {source_text: update.text, client_schedule_id: update.client_schedule_id};
            if (!pending.some(item => item.source_text === update.text)) this.storage.setItem(this.storeKey + '_SCHEDULE_PENDING', JSON.stringify([...pending, identity]));
        } catch {
            const error = new ChatApiError('無法保存排程送出識別碼');
            error.userMessage = '無法確認已保存的排程識別碼，建立結果待確認，請先重新讀取排程，不要重複建立'; throw error;
        }
        const clear = () => this.storage.setItem(this.storeKey + '_SCHEDULE_PENDING', JSON.stringify(this.scheduleIdentities().filter(item => item.client_schedule_id !== identity.client_schedule_id)));
        let result: ReportSchedule;
        try {
            result = await this.api.json<ReportSchedule>('/api/chat/schedules', {method: 'POST', body: JSON.stringify({text: update.text, client_schedule_id: identity.client_schedule_id})});
            if (!result || typeof result.schedule_id !== 'string' || !result.schedule_id || result.client_schedule_id !== identity.client_schedule_id) throw new Error('排程建立回應未能確認');
        } catch (failure) {
            const error = failure as ChatApiError;
            if (error.status && error.status >= 400 && error.status < 500 && error.status !== 408) {try {clear();} catch {/* 識別碼仍保留，避免下次誤建另一份排程 */} throw failure;}
            const unknown = new ChatApiError('排程建立結果待確認');
            unknown.userMessage = '排程建立結果待確認，請重新讀取排程，再以相同需求人工重試，請勿另建相同排程'; throw unknown;
        }
        try {clear();} catch {
            const error = new ChatApiError('排程識別碼保存未完成');
            error.userMessage = '排程已建立，但識別碼保存未完成，請重新讀取排程，不要重複建立'; throw error;
        }
        return result;
    }
    private async loadRuntime(): Promise<void> {
        try { const runtime = await this.api.json<ChatState['runtime']>('/api/chat/runtime'); if (!runtime || !['API', 'AGENT'].includes(runtime.mode)) { const error = new ChatApiError('runtime'); error.userMessage = '服務狀態格式不相容，請確認生產情報 API 網址及版本'; throw error; } this.data.runtime = runtime; this.data.connectionStatus = ''; }
        catch (error) { this.data.runtime = null; this.data.connectionStatus = error instanceof SyntaxError ? '服務狀態回應格式不正確，請確認生產情報 API 網址及版本' : error instanceof Error && error.name === 'AbortError' ? '讀取服務狀態逾時，可重新連線；不會重送問題' : errorText(error); }
        this.publish();
    }
    private async openChat(): Promise<void> { if (!this.data.enabled) return; this.data.opened = true; this.data.expanded = false; this.data.historyOpen = false; this.publish(); await this.loadRuntime(); if (this.data.conversationId) await this.selectConversation(this.data.conversationId, false); }
    private closeChat(): void { this.reportDialogEpoch++; this.data.reportDialog = null; this.savedResults.leaveView(); this.saveDraft(); this.stopWatching(); this.data.opened = false; this.data.expanded = false; this.data.historyOpen = false; this.publish(); }
    private newChat(): void { this.reportDialogEpoch++; this.data.reportDialog = null; this.savedResults.leaveView(); this.saveDraft(); this.stopWatching(); this.selectingEpoch++; this.selectingConversationId = null; this.data.conversationId = null; this.data.conversationTitle = '新聊天'; this.data.conversation = null; this.data.messages = []; this.data.activeTurn = null; this.data.reconnectNeeded = false; this.data.view = 'chat'; this.data.historyOpen = false; this.persist(); this.restoreDraft(); this.publish(); void this.loadRuntime(); }
    private async loadHistory(reset: boolean): Promise<void> {
        if (!reset && this.data.historyLoading) return;
        const epoch = ++this.historyEpoch;
        const archived = this.data.historyArchived;
        this.data.historyLoading = true; this.data.historyStatus = '正在載入聊天紀錄…'; this.publish();
        try {
            const path = '/api/chat/conversations?limit=' + Math.max(1, Math.min(100, this.config.historyPageSize)) + '&archived=' + archived + (!reset && this.data.historyCursor ? '&before_id=' + encodeURIComponent(this.data.historyCursor) : '');
            const result = await this.api.json<{items?: Conversation[]; next_before_id?: string | null}>(path); const list = Array.isArray(result.items) ? result.items : [];
            if (epoch !== this.historyEpoch) return;
            this.data.conversations = reset ? list : this.data.conversations.concat(list.filter(item => !this.data.conversations.some(existing => existing.conversation_id === item.conversation_id))); this.data.historyCursor = result.next_before_id || null; this.data.historyLoaded = true; this.data.historyStatus = this.data.conversations.length ? '' : archived ? '沒有已封存的聊天' : '';
        } catch (error) { if (epoch === this.historyEpoch) this.data.historyStatus = errorText(error); }
        finally { if (epoch === this.historyEpoch) { this.data.historyLoading = false; this.publish(); } }
    }
    private async showArchivedConversations(archived: boolean): Promise<void> {
        this.data.historyArchived = archived;
        this.data.conversations = []; this.data.historyCursor = null; this.data.historyLoaded = false;
        // 只切換歷史來源，不切換目前聊天或中止觀看。
        await this.loadHistory(true);
    }
    private conversationMetadata(id: string): Conversation | null {
        const selected = this.data.conversation?.conversation_id === id ? this.data.conversation : null;
        const row = this.data.conversations.find(item => item.conversation_id === id) || null;
        return (row?.metadata_version ?? 0) > (selected?.metadata_version ?? 0) ? row : selected || row;
    }
    private async loadConversationMetadata(id: string): Promise<Conversation> {
        let metadata = await this.api.json<Conversation>(conversationPath(id));
        const latest = this.conversationMetadata(id);
        if ((latest?.metadata_version ?? 0) > (metadata.metadata_version ?? 0)) metadata = {...metadata, ...latest};
        if (this.data.conversationId === id) {
            this.data.conversation = {...this.data.conversation, ...metadata}; this.data.conversationTitle = metadata.title;
        }
        this.data.conversations = this.data.conversations.map(row => row.conversation_id === id ? {...row, ...metadata} : row).filter(row => !!row.is_archived === this.data.historyArchived);
        this.publish(); return metadata;
    }
    private beginConversationUpdate(id: string): void {
        if (this.data.conversationSaving.includes(id)) {
            const error = new ChatApiError('聊天正在儲存'); error.status = 409; error.userMessage = '這份聊天正在儲存，請稍候'; throw error;
        }
        this.data.conversationSaving = [...this.data.conversationSaving, id]; this.publish();
    }
    private endConversationUpdate(id: string): void {
        this.data.conversationSaving = this.data.conversationSaving.filter(value => value !== id); this.publish();
    }
    private async updateConversation(id: string, patch: ConversationUpdate, metadataVersion?: number): Promise<Conversation> {
        this.beginConversationUpdate(id);
        try {
            const version = metadataVersion ?? this.conversationMetadata(id)?.metadata_version ?? 0;
            const updated = await this.api.json<Conversation>(conversationPath(id), {method: 'PATCH', body: JSON.stringify({...patch, metadata_version: version})});
            if (this.data.conversationId === id) {
                this.data.conversation = {...this.data.conversation, ...updated}; this.data.conversationTitle = updated.title;
            }
            this.data.conversations = this.data.conversations.map(item => item.conversation_id === id ? {...item, ...updated} : item).filter(item => !!item.is_archived === this.data.historyArchived);
            if (patch.is_archived !== undefined) this.savedResults.expireConversation(id);
            if (patch.is_archived === true && (this.data.conversationId === id || this.selectingConversationId === id)) this.newChat();
            this.publish();
            await this.loadHistory(true);
            return updated;
        } catch (error) {
            // 發生衝突只重新讀取 metadata，不取消、重新提交或換掉目前訊息。
            if ((error as ChatApiError).status === 409) await this.loadHistory(true);
            throw error;
        } finally { this.endConversationUpdate(id); }
    }
    private async deleteConversation(id: string, metadataVersion?: number): Promise<void> {
        this.beginConversationUpdate(id);
        try {
            const version = metadataVersion ?? this.conversationMetadata(id)?.metadata_version ?? 0;
            await this.api.json(conversationPath(id) + '?metadata_version=' + encodeURIComponent(version), {method: 'DELETE'});
            this.savedResults.retireConversation(id);
            if (this.data.conversationId === id || this.selectingConversationId === id) this.newChat();
            delete this.pending[id]; delete this.drafts[id]; this.persist(); this.saveDraft();
            this.data.conversations = this.data.conversations.filter(item => item.conversation_id !== id); this.publish();
            await this.loadHistory(true);
        } catch (error) {
            if ((error as ChatApiError).status === 409) await this.loadHistory(true);
            throw error;
        } finally { this.endConversationUpdate(id); }
    }
    private async allMessages(id: string, detail: Conversation): Promise<Message[]> {
        let result = detail.messages || []; let next = detail.next_after_seq;
        while (next !== null && next !== undefined) { const page = await this.api.json<{items?: Message[]; messages?: Message[]; next_after_seq?: number | null}>(conversationPath(id) + '/messages?after_seq=' + encodeURIComponent(next) + '&limit=100'); result = result.concat(page.items || page.messages || []); if (page.next_after_seq === next) break; next = page.next_after_seq; }
        return result;
    }
    private async selectConversation(id: string, closeHistory = false): Promise<void> {
        this.selectingConversationId = id;
        this.reportDialogEpoch++; this.data.reportDialog = null; this.savedResults.leaveView(id !== this.data.conversationId); this.saveDraft(); const epoch = ++this.selectingEpoch; this.stopWatching(); this.data.view = 'chat'; this.data.connectionStatus = '正在讀取聊天…'; this.publish();
        try {
            let detail = await this.api.json<Conversation>(conversationPath(id)); const list = await this.allMessages(id, detail);
            if (epoch !== this.selectingEpoch || !this.data.opened) return;
            const latest = this.conversationMetadata(id);
            if ((latest?.metadata_version ?? 0) > (detail.metadata_version ?? 0)) detail = {...detail, ...latest};
            // 詳情載入完成即解除切換鎖定，後續觀看不阻擋草稿與停止操作。
            this.selectingConversationId = null;
            this.data.conversationId = id; this.data.conversationTitle = detail.title || '新聊天'; this.data.conversation = detail; this.data.messages = list; this.savedResults.remember(id, list); this.data.activeTurn = null; this.data.reconnectNeeded = false; this.persist(); this.restoreDraft();
            if (!this.pending[id] && detail.active_request_id && !list.some(message => message.role === 'assistant' && message.supplementary_analysis?.request_id === detail.active_request_id)) this.pending[id] = {requestId: detail.active_request_id}; const unresolved = this.pending[id];
            if (unresolved && !unresolved.requestId) { const candidate = list.find(message => message.role === 'user' && message.client_message_id === unresolved.clientMessageId && message.request_id); if (candidate) unresolved.requestId = candidate.request_id; }
            this.data.connectionStatus = detail.read_only ? '唯讀紀錄' : ''; if (closeHistory) this.data.historyOpen = false; this.publish();
            if (unresolved?.requestId) await this.watchTurn(id, unresolved.requestId); else if (unresolved) this.showSubmissionUnknown(id); this.publish();
        } catch (error) {
            if (epoch !== this.selectingEpoch) return;
            const status = (error as ChatApiError).status; this.data.connectionStatus = errorText(error);
            if (status === 404) {
                this.data.conversationId = null; this.data.conversationTitle = '新聊天'; this.data.conversation = null; this.data.messages = []; this.data.activeTurn = null; this.data.reconnectNeeded = false; this.persist(); this.restoreDraft();
            } else {
                // 切換已停止原觀看，讀取失敗仍留在原活動聊天時需提供既有 GET 重連入口。
                this.data.reconnectNeeded = !!(this.data.conversationId && this.pending[this.data.conversationId]?.requestId && !core.isTerminal(this.data.activeTurn) && status !== 401 && status !== 403);
            }
            this.publish();
        }
        finally { if (epoch === this.selectingEpoch && this.selectingConversationId !== null) {this.selectingConversationId = null; this.publish();} }
    }
    private showSubmissionUnknown(id: string): void { if (this.data.conversationId !== id) return; this.acceptTurn({conversation_id: id, execution_state: 'submission_unknown', answer: ''}); }
    private async resubmitQuestion(sourceRequestId: string, text: string): Promise<void> {
        // 從來源位置重新生成，保存後不顯示舊問答；底部草稿維持原值。
        if (!this.data.opened || this.selectingConversationId || !this.data.conversationId || this.data.runtime?.supports_message_edit !== true || !this.data.messages.some(message => message.role === 'user' && message.request_id === sourceRequestId)) return;
        await this.submitQuestion(text, sourceRequestId);
    }
    private async submitQuestion(editedText?: string, editSourceRequestId?: string): Promise<void> {
        const question = (editedText ?? this.data.draft).trim(); const submittedDraft = this.data.draft;
        if (!question || !this.data.runtime || this.selectingConversationId || this.data.submitting || this.data.conversation?.read_only || this.data.conversationId && this.pending[this.data.conversationId] || this.rateLimitUntil > Date.now()) return;
        if (!this.api.session()) { this.notifySession(); return; } this.data.submitting = true; this.publish(); const selection = this.selectingEpoch; let id = this.data.conversationId; let clientMessageId: string | null = null;
        try {
            if (!id) { const created = await this.api.json<Conversation>('/api/chat/conversations', {method: 'POST', body: JSON.stringify({})}); id = created.conversation_id; if (!id) throw new Error('conversation'); if (selection === this.selectingEpoch) { this.drafts = core.saveDraftText(this.drafts, 'new', ''); this.data.conversationId = id; this.data.conversation = created; this.data.messages = []; this.saveDraft(); this.persist(); } }
            clientMessageId = uuid(); this.pending[id] = {clientMessageId, question, requestId: null, createdAt: Date.now()}; this.persist();
            if (this.data.conversationId === id && selection === this.selectingEpoch) {
                if (editSourceRequestId) {
                    const index = this.data.messages.findIndex(message => message.role === 'user' && message.request_id === editSourceRequestId);
                    this.savedResults.invalidate(this.data.messages.slice(index).flatMap(message => message.request_id ? [message.request_id] : []));
                    this.data.messages = this.data.messages.slice(0, index);
                    if (index === 0 && !this.data.conversation?.title_customized) this.data.conversationTitle = core.firstQuestionTitle(question);
                }
                this.data.view = 'chat';
                if (!editSourceRequestId) this.data.conversationTitle = this.data.conversation && this.data.conversation.title !== '新聊天' ? this.data.conversation.title : core.firstQuestionTitle(question);
                this.data.messages.push({role: 'user', content: question, client_message_id: clientMessageId, created_at: new Date().toISOString()});
                if (editedText === undefined && this.data.draft === submittedDraft) this.data.draft = '';
                this.saveDraft(); this.data.activeTurn = {conversation_id: id, execution_state: 'submitting', answer: ''}; this.publish();
            }
            // 每題只提交一次；SSE 重連、收合與刷新只讀取已存在的回合。
            const accepted = await this.api.json<Turn>(conversationPath(id) + '/messages', {method: 'POST', body: JSON.stringify({question, client_message_id: clientMessageId, ...(editSourceRequestId ? {edit_source_request_id: editSourceRequestId} : {})})}); if (!accepted || typeof accepted.request_id !== 'string' || !accepted.request_id) throw new Error('submission');
            this.pending = core.acceptPendingTurn(this.pending, id, clientMessageId, accepted.request_id); this.persist();
            if (this.pending[id]?.clientMessageId === clientMessageId && this.data.conversationId === id && selection === this.selectingEpoch && this.data.opened) { const userMessage = this.data.messages.find(message => message.role === 'user' && message.client_message_id === clientMessageId); if (userMessage) userMessage.request_id = accepted.request_id; this.acceptTurn(Object.assign({question, answer: ''}, accepted)); await this.watchTurn(id, accepted.request_id); }
            void this.loadHistory(true);
        } catch (error) {
            const status = (error as ChatApiError).status;
            if (id && this.pending[id]) {
                if (status && status >= 400 && status < 500 && status !== 408) {
                    delete this.pending[id]; this.persist();
                    // 明確拒絕未保存的問題回到草稿，不覆蓋等待期間的新輸入，也不自動重送。
                    if (editedText === undefined && !core.draftText(this.drafts, id)) {
                        this.saveDraft(id, submittedDraft);
                        if (this.data.conversationId === id && !this.data.draft) this.data.draft = submittedDraft;
                    }
                    if (this.data.conversationId === id) {
                        this.data.messages = this.data.messages.filter(message => message.role !== 'user' || message.client_message_id !== clientMessageId);
                        if (!this.data.messages.some(message => message.role === 'user')) this.data.conversationTitle = this.data.conversation?.title || '新聊天';
                        this.data.activeTurn = null; this.data.connectionStatus = errorText(error);
                        if (status === 409 || editSourceRequestId) { await this.selectConversation(id, false); this.toast(errorText(error)); }
                    }
                } else if (this.data.conversationId === id && this.data.opened) this.showSubmissionUnknown(id);
            } else this.toast(errorText(error));
        }
        finally { this.data.submitting = false; this.publish(); }
    }
    private acceptTurn(turn: Turn): void {
        if (!turn || !this.data.conversationId || turn.conversation_id && turn.conversation_id !== this.data.conversationId) return;
        const previous = this.data.activeTurn;
        if (previous && previous.request_id === turn.request_id && (core.isTerminal(previous) && !core.isTerminal(turn) || typeof previous.event_sequence === 'number' && typeof turn.event_sequence === 'number' && turn.event_sequence < previous.event_sequence)) return;
        if (turn.request_id) {
            this.savedResults.recordTurn(turn, this.data.conversationId);
        }
        const savedTurn = {...turn}; delete savedTurn.report;
        const savedAnalysis = turn.request_id ? this.analysisMessage(turn.request_id)?.supplementary_analysis : null;
        if (savedAnalysis && savedAnalysis.request_id === savedTurn.supplementary_analysis?.request_id && !supplementaryAnalysisPending(savedAnalysis)) savedTurn.supplementary_analysis = savedAnalysis;
        turn = savedTurn;
        this.data.activeTurn = turn; this.data.reconnectNeeded = false;
        if (core.isTerminal(turn)) { if (turn.request_id) this.watchFailures.delete(turnPath(this.data.conversationId, turn.request_id)); this.data.messages = core.saveAssistantMessage(this.data.messages, turn, statusText(turn)); delete this.pending[this.data.conversationId]; this.persist(); this.data.connectionStatus = statusText(turn); }
        else { this.data.connectionStatus = turn.request_id ? this.watchFailures.get(turnPath(this.data.conversationId, turn.request_id)) || traceProgressText(turn) || statusText(turn) : statusText(turn); if (this.pending[this.data.conversationId]) this.pending[this.data.conversationId].requestId = turn.request_id; this.persist(); }
        this.publish();
    }
    private stopUnconfirmedWatch(id: string, requestId: string, message: string): void {
        // 觀看故障不是保存終態；保留原識別碼與提交阻擋，不新增問題。
        this.watchFailures.set(turnPath(id, requestId), message);
        if (!this.data.draft.trim() && this.pending[id]?.question) { this.data.draft = this.pending[id].question; this.saveDraft(); }
        this.stopWatching(); this.data.connectionStatus = message; this.data.reconnectNeeded = true; this.publish();
    }
    private stopStoreErrorWatch(error: unknown, id: string, requestId: string): boolean {
        const failure = error as ChatApiError;
        if (failure.status !== 503 || failure.code !== 'runtime_store_unavailable') return false;
        this.stopUnconfirmedWatch(id, requestId, '聊天狀態保存或讀取尚未確認，已停止觀看，本次不會自動重送；請明確停止原回合，或提供 Request ID 追查');
        return true;
    }
    private async watchTurn(id: string, requestId: string): Promise<void> {
        this.stopWatching(); const epoch = this.watchEpoch; if (!this.data.opened || this.data.conversationId !== id) return;
        try {
            const snapshot = await this.api.json<Turn>(turnPath(id, requestId)); if (epoch !== this.watchEpoch || !this.data.opened || this.data.conversationId !== id) return; this.acceptTurn(snapshot); if (core.isTerminal(snapshot)) { void this.loadHistory(true); return; }
            this.watchController = new AbortController(); const controller = this.watchController; const timeout = setTimeout(() => controller.abort(), this.config.watchTimeoutMs);
            try {
                const response = await this.api.request(turnPath(id, requestId) + '/stream', {headers: {Accept: 'text/event-stream'}, signal: controller.signal}); if (!response.body?.getReader || !String(response.headers.get('Content-Type')).includes('text/event-stream')) throw new Error('stream');
                let covered = snapshot.event_sequence ?? -1;
                const reader = response.body.getReader(); const decoder = new TextDecoder('utf-8'); const events = core.createEventDecoder(event => {
                    if (epoch !== this.watchEpoch || !this.data.opened || this.data.conversationId !== id || event.data.request_id && event.data.request_id !== requestId || event.data.conversation_id && event.data.conversation_id !== id) return;
                    if (event.name === 'heartbeat') return;
                    if (event.id !== undefined) {
                        if (event.id <= covered) return;
                        covered = event.id;
                    }
                    if (core.isTerminal(this.data.activeTurn) && !['done', 'snapshot'].includes(event.name)) return;
                    if (this.data.activeTurn && event.id !== undefined && !['done', 'snapshot'].includes(event.name)) this.data.activeTurn = {...this.data.activeTurn, event_sequence: covered};
                    if (['snapshot', 'done'].includes(event.name)) this.acceptTurn({...event.data, event_sequence: event.data.event_sequence ?? event.id});
                    else if (event.name === 'answer_delta') this.acceptTurn({...this.data.activeTurn, answer: (this.data.activeTurn?.answer || '') + (event.data.delta || '')});
                    else if (event.name === 'answer_snapshot') this.acceptTurn({...this.data.activeTurn, answer: event.data.text || ''});
                    else if (event.name === 'execution_trace' && this.data.activeTurn) {this.data.activeTurn = applyTraceEvent(this.data.activeTurn, event.data); this.data.connectionStatus = traceProgressText(this.data.activeTurn) || this.data.connectionStatus; this.publish();}
                    else if (['progress', 'tool_start', 'tool_result'].includes(event.name)) { this.data.connectionStatus = event.data.message || '正在查詢 MES'; this.publish(); }
                    else if (event.name === 'error') {
                        if (event.data.code === 'runtime_store_unavailable' && event.data.requires_confirmation === true) this.stopUnconfirmedWatch(id, requestId, event.data.message || '聊天狀態保存尚未確認，請明確停止原回合或提供 Request ID 追查');
                        else { this.data.connectionStatus = event.data.message || '分析失敗'; this.publish(); }
                    }
                });
                while (true) { const chunk = await reader.read(); events.push(decoder.decode(chunk.value || new Uint8Array(), {stream: !chunk.done}), chunk.done); if (chunk.done) break; }
            } finally { clearTimeout(timeout); }
            if (epoch === this.watchEpoch && !core.isTerminal(this.data.activeTurn)) this.schedulePoll(id, requestId, epoch);
        } catch (error) { if (epoch !== this.watchEpoch || !this.data.opened || this.data.conversationId !== id) return; const status = (error as ChatApiError).status; if (status === 401 || status === 403 || this.stopStoreErrorWatch(error, id, requestId)) return; this.data.connectionStatus = '觀看連線中斷，正在確認進度'; this.publish(); this.schedulePoll(id, requestId, epoch); }
    }
    private schedulePoll(id: string, requestId: string, epoch: number): void {
        if (this.watchTimer) clearTimeout(this.watchTimer);
        this.watchTimer = setTimeout(async () => { if (epoch !== this.watchEpoch || !this.data.opened || this.data.conversationId !== id) return;
            try { const turn = await this.api.json<Turn>(turnPath(id, requestId)); if (epoch !== this.watchEpoch) return; this.acceptTurn(turn); if (!core.isTerminal(turn)) this.schedulePoll(id, requestId, epoch); else void this.loadHistory(true); }
            catch (error) { if (epoch !== this.watchEpoch || this.stopStoreErrorWatch(error, id, requestId)) return; this.data.connectionStatus = errorText(error); const status = (error as ChatApiError).status; if (status !== 401 && status !== 403) this.data.reconnectNeeded = true; this.publish(); }
        }, Math.max(1000, Number(this.config.pollIntervalMs) || 2000));
    }
    private async reconnect(): Promise<void> { if (!this.data.runtime) { await this.loadRuntime(); if (!this.data.runtime) return; } const id = this.data.conversationId; if (!id) return; if (this.pending[id]?.requestId) await this.watchTurn(id, this.pending[id].requestId!); else await this.selectConversation(id, false); }
    private async cancelTurn(): Promise<void> {
        const active = this.data.activeTurn; if (!active?.request_id || core.isTerminal(active) || this.selectingConversationId || !this.data.conversationId) return;
        const id = this.data.conversationId; const requestId = active.request_id; const key = turnPath(id, requestId);
        if (this.cancellingTurns.has(key)) return;
        this.cancellingTurns.add(key); this.publish();
        try { const snapshot = await this.api.json<Turn>(key + '/cancel', {method: 'POST', body: JSON.stringify({})});
            // 停止回應可能晚於完成事件或下一題，只能更新仍活動的原回合。
            if (this.data.conversationId === id && this.data.activeTurn?.request_id === requestId && !core.isTerminal(this.data.activeTurn)) { this.acceptTurn(snapshot); if (core.isTerminal(snapshot)) this.stopWatching(); }
            this.toast('已送出停止分析要求，已使用的 API Token 仍會計費');
        }
        catch (error) { this.toast(errorText(error)); } finally { this.cancellingTurns.delete(key); this.publish(); }
    }
    private analysisMessage(requestId: string): Message | undefined {
        return this.data.messages.find(message => message.role === 'assistant' && message.request_id === requestId);
    }
    private async openReport(requestId: string, cardId: string | null, view: 'detail' | 'evidence', fallback?: Report): Promise<void> {
        const epoch = ++this.reportDialogEpoch, selection = this.selectingEpoch, token = this.api.session()?.tokenKey;
        if (!this.savedResults.allows(requestId)) return;
        let entry: Pick<ReportEntry, 'report'>;
        try {entry = fallback ? {report: decodeReport(fallback, requestId)} : await this.savedResults.load(requestId);}
        catch (error) {if (epoch === this.reportDialogEpoch && selection === this.selectingEpoch && this.savedResults.allows(requestId)) this.toast(error instanceof ReportDecodeError ? error.message : '保存依據目前無法讀取'); return;}
        if (entry.report && epoch === this.reportDialogEpoch && selection === this.selectingEpoch && token === this.api.session()?.tokenKey && this.savedResults.allows(requestId)) {this.data.reportDialog = {requestId, cardId, view, report: entry.report}; this.publish();}
    }
    private async saveFeedback(requestId: string, value: Feedback): Promise<boolean> {
        if (this.data.feedbackSaving.includes(requestId)) return false; this.data.feedbackSaving = [...this.data.feedbackSaving, requestId]; this.publish();
        try { await this.api.json('/api/chat/history/' + encodeURIComponent(requestId) + '/feedback', {method: 'PUT', body: JSON.stringify(value)}); this.data.messages = this.data.messages.map(message => message.request_id === requestId && message.role === 'assistant' ? {...message, feedback: value} : message); if (this.data.activeTurn?.request_id === requestId) this.data.activeTurn = {...this.data.activeTurn, feedback: value}; this.toast('回饋已儲存，謝謝你的協助'); return true; }
        catch (error) { this.toast(errorText(error)); return false; } finally { this.data.feedbackSaving = this.data.feedbackSaving.filter(id => id !== requestId); this.publish(); }
    }
    private async copyAnswer(text: string): Promise<void> {
        try {
            if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
            else { const temp = document.createElement('textarea'); temp.className = 'mes-ai-copy-target'; temp.value = text; (document.getElementById('mes-ai-chat-root') || document.body).appendChild(temp); temp.select(); const ok = document.execCommand('copy'); temp.remove(); if (!ok) throw new Error('copy'); }
            this.toast('回答已複製');
        } catch { this.toast('無法自動複製，請選取回答文字複製'); }
    }
    private async loadMetrics(): Promise<void> { this.reportDialogEpoch++; this.data.reportDialog = null; this.savedResults.leaveView(); this.stopWatching(); this.data.view = 'metrics'; this.data.metrics = []; this.data.metricsStatus = '正在載入最近 ' + this.config.metricsDays + ' 天資料…'; this.publish();
        try { const result = await this.api.json<{items?: MetricDay[]}>('/api/chat/metrics/daily?days=' + Math.min(180, Math.max(1, this.config.metricsDays))); const items = (result.items || []).slice().sort((a, b) => String(b.date).localeCompare(String(a.date))); this.data.metrics = items; this.data.metricsStatus = items.length ? '最近 ' + this.config.metricsDays + ' 天' : '還沒有使用統計'; } catch (error) { this.data.metricsStatus = errorText(error); } this.publish(); }
    private async showChat(): Promise<void> { this.data.view = 'chat'; this.publish(); if (this.data.conversationId) await this.selectConversation(this.data.conversationId, false); }
}
