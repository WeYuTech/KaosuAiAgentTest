import type { Drafts, InlineToken, MarkdownBlock, Message, PendingTurns, Session, StreamEvent, Turn } from './types';

const terminal = new Set(['completed', 'failed', 'cancelled']);
export function readSession(storage: Pick<Storage, 'getItem'>, prefix: string, now?: number): Session | null {
    try {
        const accountNo = String(storage.getItem(prefix + '_BI_accountNo') || '').trim().toUpperCase();
        const tokenKey = storage.getItem(prefix + '_BI_TokenKey');
        const expiry = Date.parse(storage.getItem(prefix + '_BI_TokenExpiry') || '');
        if (accountNo !== 'ADMINV2' || !tokenKey || !Number.isFinite(expiry) || expiry <= (now || Date.now())) return null;
        return {accountNo, tokenKey, userName: storage.getItem(prefix + '_BI_userName') || accountNo};
    } catch { return null; }
}
export function isTerminal(turn?: Turn | null): boolean {
    return !!turn && (terminal.has(turn.execution_state || '') || ['succeeded', 'insufficient_data', 'failed', 'cancelled', 'rate_limited'].includes(turn.status || ''));
}
export function parseEvent(block: string): StreamEvent | null {
    let name = 'message';
    let id: number | undefined;
    const data: string[] = [];
    String(block).split(/\r?\n/).forEach(function (line) {
        if (line.startsWith('event:')) name = line.slice(6).trim();
        if (/^id:\s*\d+\s*$/.test(line)) id = Number(line.slice(3).trim());
        if (line.startsWith('data:')) data.push(line.slice(5).replace(/^ /, ''));
    });
    if (!data.length) return null;
    return {name, ...(id === undefined ? {} : {id}), data: JSON.parse(data.join('\n')) as StreamEvent['data']};
}
export function createEventDecoder(callback: (event: StreamEvent) => void) {
    let buffer = '';
    return {
        push(chunk: string, done = false) {
            buffer += chunk;
            const blocks = buffer.split(/\r?\n\r?\n/);
            buffer = blocks.pop() || '';
            blocks.forEach(function (block) { const event = parseEvent(block); if (event) callback(event); });
            if (done && buffer.trim()) { const event = parseEvent(buffer); if (event) callback(event); buffer = ''; }
        }
    };
}
export function safeUrl(value: string): string | null {
    try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) ? url.href : null; }
    catch { return null; }
}
export function inline(source: string): InlineToken[] {
    const text = String(source || ''); const tokens: InlineToken[] = [];
    const pattern = /(\*\*([^*]+)\*\*|`([^`]+)`|\[([^\]]+)\]\(([^\s)]+)\))/g;
    let last = 0; let match: RegExpExecArray | null;
    while ((match = pattern.exec(text))) {
        if (match.index > last) tokens.push({type: 'text', text: text.slice(last, match.index)});
        if (match[2] !== undefined) tokens.push({type: 'strong', text: match[2]});
        else if (match[3] !== undefined) tokens.push({type: 'code', text: match[3]});
        else { const url = safeUrl(match[5]); tokens.push(url ? {type: 'link', text: match[4], url} : {type: 'text', text: match[0]}); }
        last = pattern.lastIndex;
    }
    if (last < text.length) tokens.push({type: 'text', text: text.slice(last)});
    return tokens;
}
function cells(line: string): InlineToken[][] { return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(cell => inline(cell.trim())); }
export function parseMarkdown(source: string): MarkdownBlock[] {
    const lines = String(source || '').replace(/\r\n?/g, '\n').split('\n');
    const result: MarkdownBlock[] = []; let index = 0;
    while (index < lines.length) {
        const line = lines[index];
        if (!line.trim()) { index++; continue; }
        if (/^\s*```/.test(line)) {
            const code: string[] = []; index++;
            while (index < lines.length && !/^\s*```/.test(lines[index])) code.push(lines[index++]);
            index++; result.push({type: 'pre', text: code.join('\n')}); continue;
        }
        if (/^\s*\|.+\|\s*$/.test(line) && /^\s*\|?\s*:?-{3,}:?\s*\|/.test(lines[index + 1] || '')) {
            const headers = cells(line); const rows: InlineToken[][][] = []; index += 2;
            while (index < lines.length && /^\s*\|.+\|\s*$/.test(lines[index])) rows.push(cells(lines[index++]));
            result.push({type: 'table', headers, rows}); continue;
        }
        const heading = line.match(/^(#{1,4})\s+(.+)$/);
        if (heading) { result.push({type: 'heading', level: Math.min(6, heading[1].length + 2), content: inline(heading[2])}); index++; continue; }
        const bullet = line.match(/^\s*(?:([-*])|(\d+)\.)\s+(.+)$/);
        if (bullet) {
            const ordered = !!bullet[2]; const items: InlineToken[][] = [];
            while (index < lines.length) {
                const item = lines[index].match(/^\s*(?:([-*])|(\d+)\.)\s+(.+)$/);
                if (!item || !!item[2] !== ordered) break;
                items.push(inline(item[3])); index++;
            }
            result.push({type: 'list', ordered, items}); continue;
        }
        if (/^\s*>{1}\s?/.test(line)) { result.push({type: 'quote', content: inline(line.replace(/^\s*>\s?/, ''))}); index++; continue; }
        result.push({type: 'paragraph', content: inline(line)}); index++;
    }
    return result;
}
export function firstQuestionTitle(question: string): string { return String(question || '').trim().replace(/\s+/g, ' ').slice(0, 60) || '新聊天'; }
export function chatLayout(expanded: boolean, viewportWidth: number, sidebarCollapsed = false) {
    const fullscreen = !!expanded || viewportWidth <= 640;
    const sidebarAvailable = !!expanded && viewportWidth >= 900;
    const sidebar = sidebarAvailable && !sidebarCollapsed;
    return {expanded: !!expanded, fullscreen, sidebarAvailable, sidebar, drawer: !sidebarAvailable};
}
export function draftText(drafts: Drafts, conversationId: string | null): string {
    const key = conversationId || 'new';
    return Object.prototype.hasOwnProperty.call(drafts, key) && typeof drafts[key] === 'string' ? drafts[key] : '';
}
export function saveDraftText(drafts: Drafts, conversationId: string | null, text: string): Drafts {
    const updated = Object.assign({}, drafts); const key = conversationId || 'new';
    if (text) updated[key] = String(text); else delete updated[key];
    return updated;
}
export function groupConversations<T extends {updated_at?: string; created_at?: string; is_pinned?: boolean}>(items: T[], now?: number | string) {
    const today = new Date(now === undefined ? Date.now() : now); const yesterday = new Date(today.getTime()); yesterday.setDate(yesterday.getDate() - 1);
    function localDay(date: Date) { return date.getFullYear() + '-' + date.getMonth() + '-' + date.getDate(); }
    const todayKey = localDay(today); const yesterdayKey = localDay(yesterday);
    const groups: {label: string; items: T[]}[] = [{label: '已釘選', items: []}, {label: '今天', items: []}, {label: '昨天', items: []}, {label: '更早', items: []}];
    items.forEach(function (item) {
        if (item.is_pinned) { groups[0].items.push(item); return; }
        // 帶 offset 的時間先轉為宿主當地日期，不能截取 ISO 字串的日期部分。
        const updated = new Date(item.updated_at || item.created_at || ''); const key = Number.isFinite(updated.getTime()) ? localDay(updated) : null;
        groups[key === todayKey ? 1 : key === yesterdayKey ? 2 : 3].items.push(item);
    });
    return groups.filter(group => group.items.length > 0);
}
type OverflowStyle = Pick<CSSStyleDeclaration, 'getPropertyValue' | 'getPropertyPriority' | 'setProperty' | 'removeProperty'>;
export function createOverflowLock(styles: OverflowStyle[]) {
    const properties = ['overflow', 'overflow-x', 'overflow-y'];
    let saved: {property: string; value: string; priority: string}[][] | null = null;
    return {setLocked(locked: boolean) {
        if (locked && !saved) {
            saved = styles.map(style => properties.map(property => ({property, value: style.getPropertyValue(property), priority: style.getPropertyPriority(property)})));
            styles.forEach(style => style.setProperty('overflow', 'hidden', 'important'));
        } else if (!locked && saved) {
            const restore = saved;
            styles.forEach(function (style, index) { properties.forEach(property => style.removeProperty(property)); restore[index].forEach(entry => { if (entry.value) style.setProperty(entry.property, entry.value, entry.priority); }); });
            saved = null;
        }
    }};
}
export function saveAssistantMessage(messages: Message[], turn: Turn, emptyText?: string): Message[] {
    const saved: Message = Object.assign({}, turn, {role: 'assistant' as const, content: turn.answer || turn.error_message || emptyText || '', created_at: turn.completed_at || turn.started_at});
    const index = messages.findIndex(message => message.role === 'assistant' && message.request_id === turn.request_id);
    if (index < 0) return messages.concat([saved]);
    return messages.map((message, i) => i === index ? saved : message);
}
export function reportedTokenTotal(items: {total_tokens?: number | string | null}[]): number | null {
    const known = items.filter(item => item.total_tokens !== null && item.total_tokens !== undefined && item.total_tokens !== '' && Number.isFinite(Number(item.total_tokens)));
    return known.length ? known.reduce((sum, item) => sum + Number(item.total_tokens), 0) : null;
}
export function acceptPendingTurn(pending: PendingTurns, conversationId: string, clientMessageId: string, requestId: string): PendingTurns {
    const entry = pending[conversationId];
    // GET 可能已恢復完成並移除等待狀態；遲來的 202 不可重新建立或覆蓋另一題。
    if (!entry || entry.clientMessageId !== clientMessageId) return pending;
    const updated = Object.assign({}, pending); updated[conversationId] = Object.assign({}, entry, {requestId}); return updated;
}
const core = {readSession, isTerminal, parseEvent, createEventDecoder, parseMarkdown, inline, safeUrl, firstQuestionTitle, chatLayout, draftText, saveDraftText, groupConversations, createOverflowLock, saveAssistantMessage, reportedTokenTotal, acceptPendingTurn};
export default core;
