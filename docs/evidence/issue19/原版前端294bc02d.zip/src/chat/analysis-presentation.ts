/** 僅保存使用者的開合選擇；回答可見性不依賴執行終態或動畫 */
export interface AnalysisPresentation {
    identity: string;
    open: boolean;
}

export function observeAnalysis(previous: AnalysisPresentation | null, identity: string): AnalysisPresentation {
    return previous?.identity === identity ? previous : {identity, open: false};
}

export function toggleAnalysis(value: AnalysisPresentation, open: boolean): AnalysisPresentation {
    return value.open === open ? value : {...value, open};
}
