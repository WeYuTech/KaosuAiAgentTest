import type {ChatActions, ChatState, FollowUpSuggestion, Message} from './types';

export interface MesFollowupSource {
    conversationId: string;
    requestId: string;
    suggestions: FollowUpSuggestion[];
}

/** 只讀取目前聊天最後一則已完成回答的保存建議，不從正文推測追問。 */
export function getMesFollowupSource(state: ChatState): MesFollowupSource | null {
    if (!state.enabled || !state.opened || state.view !== 'chat' || !state.conversationId || !state.runtime || state.inputDisabled || state.expired || state.readOnly || state.submitting || state.showStop || state.cancelling || state.unknownSubmission) return null;
    const message = state.displayMessages.at(-1);
    if (!message || message.role !== 'assistant' || !message.request_id || message.conversation_id && message.conversation_id !== state.conversationId || message.audit_status === 'unavailable') return null;
    if (message.execution_state ? message.execution_state !== 'completed' : !['succeeded', 'insufficient_data'].includes(message.status || '')) return null;
    if (message.status && !['succeeded', 'insufficient_data'].includes(message.status)) return null;
    if (!Array.isArray(message.follow_up_suggestions)) return null;
    const seen = new Set<string>();
    const suggestions = message.follow_up_suggestions.filter(suggestion => {
        if (!suggestion || typeof suggestion.title !== 'string' || !suggestion.title.trim() || typeof suggestion.prompt !== 'string' || !suggestion.prompt.trim() || seen.has(suggestion.prompt)) return false;
        seen.add(suggestion.prompt);
        return true;
    }).slice(0, 3).map(({title, prompt}) => ({title, prompt}));
    return suggestions.length ? {conversationId: state.conversationId, requestId: message.request_id, suggestions} : null;
}

/** 點選只更新原控制器草稿；再次核對來源，避免遲來事件污染切換後的聊天。 */
export function setMesFollowupDraft(state: ChatState, actions: Pick<ChatActions, 'setDraft'>, source: Pick<MesFollowupSource, 'conversationId' | 'requestId'>, suggestion: FollowUpSuggestion): boolean {
    const current = getMesFollowupSource(state);
    if (!current || current.conversationId !== source.conversationId || current.requestId !== source.requestId || !current.suggestions.some(item => item.title === suggestion.title && item.prompt === suggestion.prompt)) return false;
    actions.setDraft(suggestion.prompt);
    return true;
}

/** 條件摘要直接使用後端保存文字，舊紀錄或未沿用時不加提示。 */
export function inheritedQueryScopeSummary(message: Message): string | null {
    return message.scope_inherited === true && typeof message.query_scope_summary === 'string' && message.query_scope_summary.trim() ? message.query_scope_summary : null;
}
