import core from './core';
import {ChatApi, ChatApiError, errorText, reportPath, turnPath} from './api';
import {decodeReport, ReportDecodeError} from './report-decoder';
import {decodeSupplementaryAnalysis, supplementaryAnalysisPending} from './supplementary-analysis';
import type {ChatConfig, ChatState, Message, Report, ReportEntry, ReportViewSelection, SupplementaryAnalysis, SupplementaryAnalysisReadError, Turn} from './types';

interface AnalysisWatch {childId: string; conversationId: string; token: string; listeners: Set<symbol>; controller: AbortController | null; timer: ReturnType<typeof setTimeout> | null; sequence: number}
interface ReportCacheEntry extends ReportEntry {promise: Promise<ReportEntry> | null; controller: AbortController | null; token: string | null; inlineSequence?: number}
interface SavedResultHost {
    scope(): {opened: boolean; conversationId: string | null; selecting: boolean; disposed: boolean};
    message(requestId: string): Message | undefined;
    replaceAnalysis(requestId: string, analysis: SupplementaryAnalysis): void;
    reportChanged(requestId: string | null, report: Report | null): void;
    isArchived(conversationId: string): boolean;
    publish(): void;
    notify(message: string): void;
}
type SavedResultSnapshot = Pick<ChatState, 'reports' | 'exporting' | 'presentationSaving' | 'presentationErrors' | 'supplementaryAnalysisErrors'>;

/** 由唯一 ChatController 擁有；保存結果的讀寫、去重與失效共用同一生命週期。 */
export class SavedResultState {
    private analysisWatches = new Map<string, AnalysisWatch>();
    private reportCache = new Map<string, ReportCacheEntry>();
    private reportOwners = new Map<string, string>();
    private retiredReports = new Set<string>();
    private deletedConversations = new Set<string>();
    private reportDownloads = new Map<string, AbortController>();
    private presentationWrites = new Map<string, AbortController>();
    private presentationErrors: Record<string, string> = {};
    private analysisErrors: Record<string, SupplementaryAnalysisReadError> = {};
    private readonly api: ChatApi;
    private readonly config: Pick<ChatConfig, 'apiRequestTimeoutMs' | 'exportRequestTimeoutMs'> & {pollIntervalMs: number};
    private readonly host: SavedResultHost;
    constructor(api: ChatApi, config: Pick<ChatConfig, 'apiRequestTimeoutMs' | 'exportRequestTimeoutMs'> & {pollIntervalMs: number}, host: SavedResultHost) {this.api = api; this.config = config; this.host = host;}
    snapshot(): SavedResultSnapshot {
        return {reports: Object.fromEntries([...this.reportCache].map(([id, entry]) => [id, this.cacheEntry(entry)])), exporting: [...this.reportDownloads.keys()], presentationSaving: [...this.presentationWrites.keys()], presentationErrors: {...this.presentationErrors}, supplementaryAnalysisErrors: {...this.analysisErrors}};
    }
    remember(id: string, messages: Message[]): void {
        for (const message of messages) if (message.request_id) {
            this.reportOwners.set(message.request_id, id);
            // 編輯遭明確拒絕後，重新讀到的可見歷史仍是後端保存的權威結果。
            this.retiredReports.delete(message.request_id);
        }
    }
    private stopAnalysisWatch(requestId: string): void {
        const watch = this.analysisWatches.get(requestId);
        if (watch) {watch.controller?.abort(); if (watch.timer) clearTimeout(watch.timer); this.analysisWatches.delete(requestId);}
    }
    private stopAnalysisWatches(): void {for (const id of this.analysisWatches.keys()) this.stopAnalysisWatch(id);}
    observeAnalysis(requestId: string): () => void {
        let analysis;
        try {analysis = decodeSupplementaryAnalysis(this.host.message(requestId)?.supplementary_analysis);} catch {return () => {};}
        const token = this.api.session()?.tokenKey, conversationId = this.host.scope().conversationId;
        if (!analysis || !supplementaryAnalysisPending(analysis) || !token || !conversationId || !this.host.scope().opened || this.host.scope().selecting || !this.allows(requestId)) return () => {};
        let watch = this.analysisWatches.get(requestId);
        const listener = Symbol(requestId);
        if (!watch) {
            watch = {childId: analysis.request_id, conversationId, token, listeners: new Set([listener]), controller: null, timer: null, sequence: -1};
            this.analysisWatches.set(requestId, watch);
            if (!this.analysisErrors?.[requestId]) void this.pollSupplementaryAnalysis(requestId, watch);
        } else watch.listeners.add(listener);
        const current = watch;
        return () => {current.listeners.delete(listener); if (!current.listeners.size && this.analysisWatches.get(requestId) === current) this.stopAnalysisWatch(requestId);};
    }
    retryAnalysis(requestId: string): void {
        const watch = this.analysisWatches.get(requestId);
        if (!watch || watch.controller || watch.timer || this.analysisErrors?.[requestId]?.retryable === false) return;
        delete this.analysisErrors?.[requestId]; this.host.publish();
        void this.pollSupplementaryAnalysis(requestId, watch);
    }
    private async pollSupplementaryAnalysis(requestId: string, watch: AnalysisWatch): Promise<void> {
        const current = () => this.analysisWatches.get(requestId) === watch && this.host.scope().opened && this.host.scope().conversationId === watch.conversationId && this.api.session()?.tokenKey === watch.token && this.allows(requestId) && this.host.message(requestId)?.supplementary_analysis?.request_id === watch.childId;
        if (!current()) return;
        const controller = new AbortController(); watch.controller = controller;
        const timeout = setTimeout(() => controller.abort(), Math.max(1000, Number(this.config.apiRequestTimeoutMs) || 30000));
        let repeat = false;
        try {
            let turn: Turn, parentSnapshot = false;
            try {turn = await this.api.json<Turn>(turnPath(watch.conversationId, watch.childId), {signal: controller.signal});}
            catch (error) {
                if ((error as ChatApiError).status !== 404 || !current()) throw error;
                // 主答先發布，背景回合可能尚未建立；只讀回父回合核對保存關聯，不重送問題。
                turn = await this.api.json<Turn>(turnPath(watch.conversationId, requestId), {signal: controller.signal});
                parentSnapshot = true;
            }
            if (!current()) return;
            if (parentSnapshot && (turn.request_id !== requestId || turn.conversation_id && turn.conversation_id !== watch.conversationId || turn.supplementary_analysis?.request_id !== watch.childId)) {
                const unavailable = new ChatApiError('補充分析保存關聯已不存在'); unavailable.status = 404; throw unavailable;
            }
            if (!parentSnapshot && (turn.request_id !== watch.childId || turn.conversation_id && turn.conversation_id !== watch.conversationId)) throw new Error('補充分析來源無法核對');
            const analysis = decodeSupplementaryAnalysis(turn.supplementary_analysis, watch.childId);
            if (!analysis) throw new Error('補充分析資料格式無法讀取');
            if (!parentSnapshot) {
                if (typeof turn.event_sequence === 'number' && turn.event_sequence < watch.sequence) {repeat = true; return;}
                watch.sequence = turn.event_sequence ?? watch.sequence;
            }
            const previous = this.host.message(requestId)?.supplementary_analysis;
            if (previous && !supplementaryAnalysisPending(previous)) return;
            this.host.replaceAnalysis(requestId, analysis);
            delete this.analysisErrors?.[requestId]; repeat = supplementaryAnalysisPending(analysis); this.host.publish();
        } catch (error) {
            if (!current()) return;
            const status = (error as ChatApiError).status;
            this.analysisErrors = {...this.analysisErrors, [requestId]: {message: status === 404 ? '補充分析已不存在；原回答仍可使用' : status === 401 || status === 403 ? '請重新登入後查看補充分析' : '補充分析進度暫時無法讀取；原回答仍可使用', retryable: status !== 404 && status !== 401 && status !== 403}};
            this.host.publish();
        } finally {
            clearTimeout(timeout); if (watch.controller === controller) watch.controller = null;
            if (repeat && current()) watch.timer = setTimeout(() => {watch.timer = null; void this.pollSupplementaryAnalysis(requestId, watch);}, this.config.pollIntervalMs);
        }
    }
    allows(requestId: string): boolean {
        const owner = this.reportOwners.get(requestId);
        return !this.host.scope().disposed && !!this.api.session() && !this.retiredReports.has(requestId) && (!owner || !this.deletedConversations.has(owner));
    }
    private unavailableReport(): ReportEntry {return {state: 'missing', report: null, message: '這份查詢資料已刪除或取代'};}
    private cacheEntry(entry: ReportCacheEntry): ReportEntry {return {state: entry.state, report: entry.report, message: entry.message};}
    leaveView(cancelWrites = true): void {
        this.stopAnalysisWatches();
        for (const [id, entry] of this.reportCache) if (entry.state === 'loading') {
            entry.controller?.abort(); this.reportCache.delete(id);
        }
        this.reportDownloads.forEach(controller => controller.abort()); this.reportDownloads.clear();
        // PUT 可能已保存到伺服器；中止只代表不接收回應，重開須以 GET 確認。
        if (cancelWrites) for (const id of this.presentationWrites.keys()) this.remove(id);
    }
    reset(): void {
        this.leaveView(); this.analysisErrors = {}; this.presentationErrors = {};
        this.reportCache.clear(); this.host.reportChanged(null, null);
    }
    expireConversation(conversationId: string): void {
        for (const [requestId, owner] of this.reportOwners) if (owner === conversationId) this.remove(requestId);
    }
    retireConversation(conversationId: string): void {
        this.deletedConversations.add(conversationId);
        this.invalidate([...this.reportOwners].filter(([, owner]) => owner === conversationId).map(([id]) => id));
    }
    recordTurn(turn: Turn, conversationId: string): void {
        if (!turn.request_id) return;
        this.reportOwners.set(turn.request_id, conversationId);
        if (core.isTerminal(turn) && turn.report != null) this.cacheInlineReport(turn.request_id, turn.report, turn.event_sequence);
    }
    private remove(id: string): void {
        this.stopAnalysisWatch(id); delete this.analysisErrors[id];
        this.reportCache.get(id)?.controller?.abort(); this.reportCache.delete(id);
        this.reportDownloads.get(id)?.abort(); this.reportDownloads.delete(id);
        this.presentationWrites.get(id)?.abort(); this.presentationWrites.delete(id); delete this.presentationErrors[id];
        this.host.reportChanged(id, null);
    }
    invalidate(ids: string[]): void {
        for (const id of ids) {this.retiredReports.add(id); this.remove(id);}
    }
    private cacheInlineReport(requestId: string, raw: unknown, sequence?: number): void {
        if (!this.allows(requestId) || sequence !== undefined && this.reportCache.get(requestId)?.inlineSequence === sequence) return;
        const entry: ReportCacheEntry = {state: 'ready', report: null, message: '', promise: null, controller: null, inlineSequence: sequence, token: this.api.session()?.tokenKey || null};
        try {entry.report = decodeReport(raw, requestId);}
        catch (error) {entry.state = 'unavailable'; entry.message = error instanceof ReportDecodeError ? error.message : '保存報告格式無法讀取，仍可閱讀回答';}
        if ((this.reportCache.get(requestId)?.report?.view_preferences?.revision || 0) > (entry.report?.view_preferences?.revision || 0)) return;
        this.reportCache.get(requestId)?.controller?.abort(); this.reportCache.set(requestId, entry);
    }
    load(requestId: string, retry = false): Promise<ReportEntry> {
        if (!this.allows(requestId)) return Promise.resolve(this.unavailableReport());
        const token = this.api.session()?.tokenKey || null;
        let cached = this.reportCache.get(requestId);
        if (cached && cached.token !== token) {cached.controller?.abort(); this.reportCache.delete(requestId); cached = undefined;}
        if (cached && (!retry || cached.state !== 'retryable-error' && !this.presentationErrors?.[requestId])) return cached.promise || Promise.resolve(this.cacheEntry(cached));
        const controller = new AbortController();
        const owner = this.reportOwners.get(requestId) || this.host.scope().conversationId;
        if (owner) this.reportOwners.set(requestId, owner);
        const entry: ReportCacheEntry = {state: 'loading', report: null, message: '', promise: null, controller, token};
        this.reportCache.set(requestId, entry);
        const timeout = setTimeout(() => controller.abort(), Math.max(1000, Number(this.config.apiRequestTimeoutMs) || 30000));
        entry.promise = this.api.json<unknown>(reportPath(requestId), {signal: controller.signal}).then(raw => {
            if (controller.signal.aborted) throw new DOMException('報告讀取已中止', 'AbortError');
            entry.report = decodeReport(raw, requestId); entry.state = 'ready'; return entry;
        }).catch(error => {
            const status = (error as ChatApiError).status;
            entry.state = status === 404 ? 'missing' : error instanceof ReportDecodeError || status === 401 || status === 403 || status && status >= 400 && status < 500 && ![408, 429].includes(status) ? 'unavailable' : 'retryable-error';
            entry.message = status === 404 ? '這份紀錄尚無數據報告，仍可閱讀回答與已保存依據' : status === 401 || status === 403 ? errorText(error) : error instanceof ReportDecodeError ? error.message : '數據報告目前無法讀取，仍可閱讀回答';
            return entry;
        }).then(result => {
            if (!this.allows(requestId) || token !== this.api.session()?.tokenKey) {
                // 憑證更新後，舊請求只能移除自己的 entry，不能留下永久 loading 或清掉新請求。
                if (this.reportCache.get(requestId) === entry) {this.reportCache.delete(requestId); this.host.publish();}
                return this.unavailableReport();
            }
            if (this.reportCache.get(requestId) !== entry) {const current = this.reportCache.get(requestId); return current ? this.cacheEntry(current) : this.unavailableReport();}
            if (retry && result.state === 'ready') delete this.presentationErrors?.[requestId];
            this.host.publish(); return this.cacheEntry(result);
        }).finally(() => {clearTimeout(timeout); entry.promise = null; entry.controller = null;});
        this.host.publish(); return entry.promise;
    }
    async download(requestId: string): Promise<void> {
        if (!this.allows(requestId) || this.reportDownloads.has(requestId)) return; const controller = new AbortController(); this.reportDownloads.set(requestId, controller); this.host.publish(); const timeout = setTimeout(() => controller.abort(), Math.max(1000, Number(this.config.exportRequestTimeoutMs) || 60000));
        try {
            const response = await this.api.request('/api/chat/history/' + encodeURIComponent(requestId) + '/export.xlsx', {headers: {Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}, signal: controller.signal}); const contentType = String(response.headers.get('Content-Type') || '').toLowerCase(); if (!contentType.includes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') && !contentType.includes('application/octet-stream')) throw new Error('export-format');
            const blob = await response.blob(); if (controller.signal.aborted) return; let filename = 'MES報告-' + requestId + '.xlsx'; const disposition = response.headers.get('Content-Disposition') || ''; const encoded = /filename\*=UTF-8''([^;]+)/i.exec(disposition); const plain = /filename="([^"]+)"|filename=([^;]+)/i.exec(disposition);
            try { if (encoded) filename = decodeURIComponent(encoded[1]); else if (plain) filename = plain[1] || plain[2]; } catch { /* 無法解析下載檔名時沿用本地預設名稱。 */ }
            filename = filename.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim(); if (!/\.xlsx$/i.test(filename)) filename += '.xlsx';
            const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = filename; link.hidden = true; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000); this.host.notify('已下載這次查詢的 Excel 報告');
        } catch (error) { if ((error as Error).name !== 'AbortError' && !controller.signal.aborted) this.host.notify(errorText(error)); else if (this.host.scope().opened) this.host.notify('Excel 下載已停止，可再按一次匯出'); }
        finally { clearTimeout(timeout); if (this.reportDownloads.get(requestId) === controller) this.reportDownloads.delete(requestId); this.host.publish(); }
    }
    async savePresentation(requestId: string, cardId: string, selection: ReportViewSelection | null): Promise<boolean> {
        const report = this.reportCache.get(requestId)?.report;
        const owner = this.reportOwners.get(requestId);
        if (!this.allows(requestId) || owner && this.host.isArchived(owner) || this.presentationWrites.has(requestId) || !report?.view_preferences_editable || !report.cards.some(card => card.id === cardId)) return false;
        const token = this.api.session()?.tokenKey, controller = new AbortController();
        this.presentationWrites.set(requestId, controller);
        this.presentationErrors = {...this.presentationErrors, [requestId]: ''}; this.host.publish();
        const current = () => !controller.signal.aborted && this.presentationWrites.get(requestId) === controller && token === this.api.session()?.tokenKey && this.allows(requestId);
        const timeout = setTimeout(() => controller.abort(), Math.max(1000, Number(this.config.apiRequestTimeoutMs) || 30000));
        try {
            const raw = await this.api.json<unknown>('/api/chat/history/' + encodeURIComponent(requestId) + '/presentation', {
                method: 'PUT', signal: controller.signal, body: JSON.stringify({expected_revision: report.view_preferences?.revision ?? 0, card_id: cardId, selection}),
            });
            if (!current()) return false;
            const saved = decodeReport(raw, requestId);
            const choice = saved.view_preferences?.selections.find(item => item.card_id === cardId);
            const choiceMatches = selection ? choice?.mark === selection.mark && JSON.stringify(choice.metrics) === JSON.stringify(selection.metrics) : !choice;
            if (saved.view_preferences_reason || !saved.view_preferences || saved.view_preferences.revision < (report.view_preferences?.revision || 0) || !choiceMatches) throw new Error('保存回應的版本無法核對');
            if ((this.reportCache.get(requestId)?.report?.view_preferences?.revision || 0) > saved.view_preferences.revision) {
                this.presentationErrors = {...this.presentationErrors, [requestId]: '已保留較新的呈現設定，請確認目前選擇'};
                return false;
            }
            const entry: ReportCacheEntry = {state: 'ready', report: saved, message: '', promise: null, controller: null, token: token || null};
            this.reportCache.get(requestId)?.controller?.abort(); this.reportCache.set(requestId, entry);
            this.host.reportChanged(requestId, saved);
            return true;
        } catch (error) {
            if (this.presentationWrites.get(requestId) !== controller || token !== this.api.session()?.tokenKey || !this.allows(requestId)) return false;
            const status = (error as ChatApiError).status;
            if (status === 404) {this.invalidate([requestId]); this.host.publish(); return false;}
            this.presentationErrors = {...this.presentationErrors, [requestId]: status === 409 ? '呈現設定已在其他頁面更新，已重新讀取，請再選擇一次' : controller.signal.aborted ? '呈現保存逾時，請重新載入確認；不會自動重送' : '呈現未能保存，請重新載入後再試'};
            if (status === 409) {
                this.reportCache.delete(requestId);
                await this.load(requestId);
            }
            return false;
        } finally {
            clearTimeout(timeout);
            if (this.presentationWrites.get(requestId) === controller) this.presentationWrites.delete(requestId);
            this.host.publish();
        }
    }
}
