import type { CopilotConfig } from './chat/types'

declare const PROJECT_SAVE_NAME: string | undefined
declare const originalFetch: typeof fetch | undefined

declare global {
  interface Window {
    MES_AI_COPILOT_CONFIG?: CopilotConfig
    __MES_AI_CHAT_INITIALIZED__?: boolean
  }
}

export const defaultConfig: CopilotConfig = {
  apiBaseUrl: '', productionLabel: 'EMERALD', inputPlaceholder: '輸入生產問題…',
  historyPageSize: 20, metricsDays: 30, apiRequestTimeoutMs: 30000,
  watchTimeoutMs: 120000, pollIntervalMs: 2000,
}

export function hostEnvironment() {
  return {
    prefix: typeof PROJECT_SAVE_NAME === 'string' ? PROJECT_SAVE_NAME : '',
    config: {
      ...defaultConfig, ...window.MES_AI_COPILOT_CONFIG,
      // 保留 MES 宿主的原始 fetch，避免包裝器提前消耗 SSE 回應。
      fetchImpl: (typeof originalFetch === 'function' ? originalFetch : window.fetch).bind(window),
    },
  }
}

export function previewEnvironment() {
  const params = new URLSearchParams(location.search)
  const prefix = 'MES_AI_PREVIEW'
  const apiBaseUrl = params.get('apiBaseUrl') || 'http://127.0.0.1:8000'
  // 這份入口僅供本機預覽；正式 widget 完全沿用 MES 宿主登入資料。
  localStorage.setItem(prefix + '_BI_accountNo', params.get('account') || 'ADMINV2')
  localStorage.setItem(prefix + '_BI_userName', '預覽使用者')
  if (params.get('missingToken') === '1') localStorage.removeItem(prefix + '_BI_TokenKey')
  else localStorage.setItem(prefix + '_BI_TokenKey', 'preview-session-not-for-production')
  localStorage.setItem(prefix + '_BI_TokenExpiry', new Date(Date.now() + (params.get('expired') === '1' ? -1000 : 3600000)).toISOString())
  return { prefix, config: { ...defaultConfig, apiBaseUrl, fetchImpl: window.fetch.bind(window) } }
}
