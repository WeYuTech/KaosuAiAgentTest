import { MesAssistantProvider } from '@/chat/assistant-runtime';
import { MesUiProvider } from '@/chat/mes-ui-context';
import { useChatController } from '@/chat/useChatController';
import type { ChatConfig } from '@/chat/types';
import { AssistantModal } from '@/components/assistant-ui/elements/assistant-modal.aui';
import { TooltipProvider } from '@/components/ui/tooltip';
import { PortalContext } from '@/features/common/UiContext';
import { MesReportDialog } from '@/features/mes/MesReportDialog';
import {readSession} from '@/chat/core';
import {ChatThemeProvider} from '@/features/preferences/theme';
import {ProviderSettingsProvider} from '@/features/preferences/provider-settings';
import {ProviderSettingsDialog} from '@/features/preferences/ProviderSettingsDialog';
import {ConversationActionsProvider} from '@/features/conversations/conversation-actions';
import {ConversationActionsDialog} from '@/features/conversations/ConversationActionsDialog';
import {OperationsProvider} from '@/features/operations/operations';
import {OperationsDialog} from '@/features/operations/OperationsDialog';

export interface AppProps {config: ChatConfig; prefix: string; assetBaseUrl?: string}

/** 官方 assistant-ui 呈現聊天；既有 MES 控制器仍掌管請求與狀態。 */
export default function App({config, prefix, assetBaseUrl = './'}: AppProps) {
    const controller = useChatController(config, prefix);
    const portal = document.getElementById('mes-ai-chat-root');
    const brandLogoUrl = new URL('weyu-brand.svg', new URL(assetBaseUrl, document.baseURI)).href;
    const storage = config.storage ?? window.localStorage;
    const accountNo = readSession(storage, prefix)?.accountNo ?? '';
    if (!controller.state.enabled) return null;
    return <PortalContext.Provider value={portal}>
        <ChatThemeProvider projectKey={prefix || config.productionLabel || 'EMERALD'} accountNo={accountNo} storage={storage} rootElement={portal}>
        <MesUiProvider {...controller}>
            <ProviderSettingsProvider>
            <OperationsProvider>
            <MesAssistantProvider {...controller}>
                <TooltipProvider delayDuration={250}>
                    <ConversationActionsProvider>
                    <AssistantModal brandLogoUrl={brandLogoUrl} />
                    <MesReportDialog />
                    <ProviderSettingsDialog />
                    <ConversationActionsDialog />
                    <OperationsDialog />
                    </ConversationActionsProvider>
                </TooltipProvider>
            </MesAssistantProvider>
            </OperationsProvider>
            </ProviderSettingsProvider>
        </MesUiProvider>
        </ChatThemeProvider>
    </PortalContext.Provider>;
}
