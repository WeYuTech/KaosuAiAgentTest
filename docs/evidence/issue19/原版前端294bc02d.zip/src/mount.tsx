import { createRoot } from 'react-dom/client'
import App from './App'
import core from './chat/core'
import type { CopilotConfig } from './chat/types'

export function mountCopilot(config: CopilotConfig, prefix: string, assetBaseUrl = './') {
  if (window.__MES_AI_CHAT_INITIALIZED__ || document.getElementById('mes-ai-chat-root')) return
  try { if (!core.readSession(localStorage, prefix)) return } catch { return }
  const element = document.createElement('div')
  element.id = 'mes-ai-chat-root'
  element.dataset.framework = 'react-assistant-ui'
  element.dataset.chatRuntime = 'assistant-ui'
  element.dataset.uiVersion = 'mes-assistant-ui-20261011-r39'
  document.body.appendChild(element)
  const root = createRoot(element)
  window.__MES_AI_CHAT_INITIALIZED__ = true
  root.render(<App config={config} prefix={prefix} assetBaseUrl={assetBaseUrl} />)
  return () => {
    root.unmount()
    element.remove()
    window.__MES_AI_CHAT_INITIALIZED__ = false
  }
}
