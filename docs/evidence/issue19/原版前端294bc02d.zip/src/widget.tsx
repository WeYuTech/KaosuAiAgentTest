import { hostEnvironment } from './environment'
import { mountCopilot } from './mount'
import './styles.css'

const script = document.currentScript as HTMLScriptElement | null
const base = script?.src ? new URL('../', script.src).href : './'
const environment = hostEnvironment()
mountCopilot(environment.config, environment.prefix, base)
