import {createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode} from 'react';
import {useMesUi} from '@/chat/mes-ui-context';
import {budgetDraft, buildBudgetUpdate, operationErrorText, ScheduleCreationIdentity, type BudgetDraft, type BudgetScope, type BudgetSnapshot, type ParsedSchedule, type ReportSchedule, type ScheduleRun} from '@/chat/operations';
import {SidebarBudgetRefresh} from '@/chat/sidebar-budget';

export type OperationsSection = 'budget' | 'schedules';

/** 共用額度快照與本次 Dialog 草稿；請求與登入全部交回原控制器 */
function useOperationsState() {
    const {state, actions} = useMesUi();
    const [section, setSection] = useState<OperationsSection | null>(null);
    const [budget, setBudget] = useState<BudgetSnapshot | null>(null);
    const [budgetSnapshot, setBudgetSnapshot] = useState<BudgetSnapshot | null>(null);
    const [budgetStatus, setBudgetStatus] = useState<'idle' | 'loading' | 'ready' | 'unavailable'>('idle');
    const [sidebarVisible, setSidebarVisible] = useState(false);
    const [scope, setScope] = useState<BudgetScope>('account');
    const [drafts, setDrafts] = useState<Record<BudgetScope, BudgetDraft> | null>(null);
    const [schedules, setSchedules] = useState<ReportSchedule[]>([]);
    const [sourceText, setSourceText] = useState('');
    const [parsed, setParsed] = useState<ParsedSchedule | null>(null);
    const [runs, setRuns] = useState<ScheduleRun[] | null>(null);
    const [runScope, setRunScope] = useState('');
    const [selectedRun, setSelectedRun] = useState<ScheduleRun | null>(null);
    const [deleteTarget, setDeleteTarget] = useState<ReportSchedule | null>(null);
    const [busy, setBusy] = useState<'read' | 'write' | null>(null);
    const [error, setError] = useState(''), [notice, setNotice] = useState('');
    const epoch = useRef(0), pending = useRef(false);
    const creation = useRef(new ScheduleCreationIdentity());
    const runSchedule = useRef<ReportSchedule | undefined>(undefined);
    const budgetEpoch = useRef(0), budgetRefresh = useRef(new SidebarBudgetRefresh());
    const latest = useRef({expired: state.expired, section, actions});
    latest.current = {expired: state.expired, section, actions};

    // 背景只更新共用顯示快照，不改 Dialog 草稿、管理權或設定 revision
    const refreshSidebarBudget = useCallback(async () => {
        if (latest.current.expired || latest.current.section === 'budget') return;
        const current = ++budgetEpoch.current, owner = actions;
        setBudgetStatus('loading');
        try {
            const value = await actions.loadBudget();
            if (current === budgetEpoch.current && !latest.current.expired && owner === latest.current.actions) {setBudgetSnapshot(value); setBudgetStatus('ready');}
        } catch {
            if (current === budgetEpoch.current && owner === latest.current.actions) setBudgetStatus('unavailable');
        }
    }, [actions]);

    useEffect(() => {
        budgetEpoch.current++; budgetRefresh.current = new SidebarBudgetRefresh();
        epoch.current++; pending.current = false; setSection(null); setBusy(null); setBudget(null); setDrafts(null);
        setBudgetSnapshot(null); setBudgetStatus('idle');
        // 控制器範圍切換時，報告／排程與表單也必須清除，不讓新範圍看見前一份暫存
        setSchedules([]); setSourceText(''); setParsed(null); setRuns(null); setRunScope(''); setSelectedRun(null); setDeleteTarget(null);
        setError(''); setNotice(''); runSchedule.current = undefined;
    }, [actions]);
    useEffect(() => {
        if (state.expired) {budgetEpoch.current++; setBudgetSnapshot(null); setBudgetStatus('idle');}
        if (budgetRefresh.current.observe({...state, visible: sidebarVisible, editingBudget: section === 'budget'})) void refreshSidebarBudget();
    }, [state.opened, state.expired, state.submitting, state.activeTurn?.request_id, state.activeTurn?.execution_state, state.activeTurn?.status, sidebarVisible, section, refreshSidebarBudget]);

    function applyBudget(value: BudgetSnapshot) {
        budgetEpoch.current++; setBudgetSnapshot(value); setBudgetStatus('ready');
        setBudget(value); setDrafts({system: budgetDraft(value.system.config), account: budgetDraft(value.account.config)});
    }
    async function perform<T>(kind: 'read' | 'write', request: () => Promise<T>, success: (value: T) => void) {
        if (pending.current || state.expired) return;
        pending.current = true; const current = ++epoch.current;
        setBusy(kind); setError(''); setNotice('');
        try {const value = await request(); if (current === epoch.current) success(value);}
        catch (failure) {if (current === epoch.current) setError(operationErrorText(failure));}
        finally {if (current === epoch.current) {pending.current = false; setBusy(null);}}
    }
    function close() {
        if (section === 'budget') budgetRefresh.current.invalidate();
        epoch.current++; pending.current = false; setSection(null); setBusy(null); setError(''); setNotice('');
        setBudget(null); setDrafts(null); setSchedules([]); setSourceText(''); setParsed(null);
        setRuns(null); setRunScope(''); setSelectedRun(null); setDeleteTarget(null); runSchedule.current = undefined;
    }
    function open(value: OperationsSection) {
        if (value === 'budget') budgetEpoch.current++;
        epoch.current++; pending.current = false; setBusy(null); setSection(value); setError(''); setNotice('');
        setDeleteTarget(null); setSelectedRun(null);
        if (value === 'budget') void reloadBudget(); else void reloadSchedules();
    }
    function reloadBudget() {
        if (pending.current || state.expired) return;
        const current = ++budgetEpoch.current; setBudgetStatus('loading');
        return perform('read', async () => {
            try {return await actions.loadBudget();}
            catch (failure) {if (current === budgetEpoch.current) setBudgetStatus('unavailable'); throw failure;}
        }, applyBudget);
    }
    function reloadSchedules() {return perform('read', () => actions.loadSchedules(), value => {
        setSchedules(value.items);
        // 409 後明確重新讀取才更新確認目標版本，不自行重送刪除
        setDeleteTarget(previous => previous ? value.items.find(item => item.schedule_id === previous.schedule_id) ?? null : null);
    });}
    function setBudgetValue(field: keyof BudgetDraft, value: string) {setDrafts(previous => previous && {...previous, [scope]: {...previous[scope], [field]: value}});}
    async function saveBudget() {
        if (!budget || !drafts || !budget.management.write_allowed || pending.current) return;
        try {
            const update = buildBudgetUpdate(budget[scope], drafts[scope]);
            if (!['monthly_token_limit', 'warning_percent', 'per_turn_reservation_tokens'].some(key => key in update)) {setNotice('設定未變更'); return;}
            await perform('write', () => actions.saveBudget(update), value => {applyBudget(value); setNotice('已保存額度設定，立即生效');});
        } catch (failure) {setError(operationErrorText(failure));}
    }
    function changeSourceText(value: string) {setSourceText(value); setParsed(null); setNotice('');}
    function parse() {if (sourceText.trim()) return perform('read', () => actions.parseSchedule(sourceText.trim()), setParsed);}
    function create() {
        const text = sourceText.trim(); if (!text || pending.current) return;
        // 不明結果重試仍沿用同一識別碼；不自動重送，成功才清除此暫存
        const client_schedule_id = creation.current.forText(text);
        return perform('write', () => actions.createSchedule({client_schedule_id, text}), value => {
            setSchedules(previous => [value, ...previous.filter(item => item.schedule_id !== value.schedule_id)]);
            creation.current.confirmed(); setSourceText(''); setParsed(null); setNotice('已建立排程，報告會依台北時間產生');
        });
    }
    function toggle(schedule: ReportSchedule) {
        return perform('write', () => actions.updateSchedule(schedule.schedule_id, {revision: schedule.revision, status: schedule.status === 'active' ? 'paused' : 'active'}), value => {
            setSchedules(previous => previous.map(item => item.schedule_id === value.schedule_id ? value : item));
            setNotice(value.status === 'active' ? '已恢復排程' : '已暫停排程');
        });
    }
    function remove() {
        if (!deleteTarget) return;
        const target = deleteTarget;
        return perform('write', () => actions.deleteSchedule(target.schedule_id, target.revision), () => {
            setSchedules(previous => previous.filter(item => item.schedule_id !== target.schedule_id));
            setDeleteTarget(null); setNotice('已刪除排程，既有報告仍可查看');
        });
    }
    function showRuns(schedule?: ReportSchedule) {
        return perform('read', () => schedule ? actions.loadScheduleRuns(schedule.schedule_id) : actions.loadSavedScheduleReports(), value => {
            runSchedule.current = schedule; setRuns(value.items); setRunScope(schedule?.report_request || '已保存報告'); setSelectedRun(null);
        });
    }
    return {section, open, close, budget, budgetSnapshot, budgetStatus, setSidebarVisible, refreshSidebarBudget, scope, setScope, draft: drafts?.[scope], setBudgetValue,
        schedules, sourceText, setSourceText: changeSourceText, parsed, parse, create, toggle, deleteTarget, setDeleteTarget, remove,
        runs, runScope, selectedRun, setSelectedRun, showRuns, backToSchedules: () => {setRuns(null); setSelectedRun(null); runSchedule.current = undefined;},
        reloadReports: () => runs === null ? reloadSchedules() : showRuns(runSchedule.current),
        busy, error, notice, expired: state.expired, reloadBudget, reloadSchedules, saveBudget};
}
type OperationsContextValue = ReturnType<typeof useOperationsState>;
const OperationsContext = createContext<OperationsContextValue | null>(null);
export function OperationsProvider({children}: {children: ReactNode}) {
    const value = useOperationsState();
    return <OperationsContext.Provider value={value}>{children}</OperationsContext.Provider>;
}
export function useOperations() {const value = useContext(OperationsContext); if (!value) throw new Error('用量與排程需要共用操作 Provider'); return value;}
