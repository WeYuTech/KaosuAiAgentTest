import {useId} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import {Textarea} from '@/components/ui/textarea';
import {Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle} from '@/components/ui/dialog';
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from '@/components/ui/select';
import {Table, TableBody, TableCell, TableHead, TableHeader, TableRow} from '@/components/ui/table';
import {usePortalContainer} from '@/features/common/UiContext';
import {useDialogFocus} from '@/features/common/useDialogFocus';
import {scheduleTimeText, scheduledReportDisplay, tokenText, type BudgetDraft, type BudgetScope, type ScheduleRun, type ScheduledReportRow} from '@/chat/operations';
import {useOperations} from './operations';

function dateText(value?: string | null): string {
    if (!value) return '尚未取得';
    const date = new Date(value);
    return Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat('zh-TW', {timeZone: 'Asia/Taipei', dateStyle: 'short', timeStyle: 'short'}).format(date) : '尚未取得';
}
const runLabels: Record<ScheduleRun['status'], string> = {claimed: '等候執行', running: '處理中', completed: '已完成', failed: '未完成', missed: '錯過執行時間', interrupted: '已中斷', submission_unknown: '結果待確認'};

/** 用量與排程只用一個共用 Dialog，請求皆由 Provider 交回原 controller */
export function OperationsDialog() {
    const operations = useOperations(), portal = usePortalContainer(), focus = useDialogFocus();
    const disabled = !!operations.busy || operations.expired;
    return <Dialog open={operations.section !== null} onOpenChange={open => {if (!open) operations.close();}}>
        <DialogContent portalContainer={portal} {...focus} className="min-w-0 grid-cols-1 max-h-(--aui-settings-max-height) overflow-y-auto sm:max-w-2xl" data-slot="mes-operations-dialog">
            <DialogHeader><DialogTitle>{operations.section === 'budget' ? '用量額度' : '排程報告'}</DialogTitle><DialogDescription>{operations.section === 'budget' ? '查看用量與調整額度' : '定期產生生產報告（台北時間）'}</DialogDescription></DialogHeader>
            <div className="flex flex-wrap gap-2" aria-label="用量與報告功能"><Button variant={operations.section === 'budget' ? 'secondary' : 'ghost'} disabled={disabled} aria-pressed={operations.section === 'budget'} onClick={() => operations.open('budget')}>用量額度</Button><Button variant={operations.section === 'schedules' ? 'secondary' : 'ghost'} disabled={disabled} aria-pressed={operations.section === 'schedules'} onClick={() => operations.open('schedules')}>排程報告</Button></div>
            {operations.busy && <p role="status" className="text-sm text-muted-foreground">{operations.busy === 'write' ? '儲存中…' : '讀取中…'}</p>}
            {operations.section === 'budget' ? <BudgetPanel /> : <SchedulesPanel />}
            {operations.expired && <p role="status" className="text-sm text-muted-foreground">登入已逾時，請重新登入 MES</p>}
            {operations.error && <p role="alert" className="text-sm text-destructive">{operations.error}</p>}
            {operations.notice && <p role="status" className="text-sm text-muted-foreground">{operations.notice}</p>}
            <DialogFooter><Button variant="outline" disabled={disabled} onClick={() => void (operations.section === 'budget' ? operations.reloadBudget() : operations.reloadReports())}>重新讀取</Button><Button variant="outline" onClick={operations.close}>關閉</Button>{operations.section === 'budget' && <Button disabled={disabled || !operations.budget?.management.write_allowed || !operations.draft} onClick={() => void operations.saveBudget()}>儲存額度</Button>}</DialogFooter>
        </DialogContent>
    </Dialog>;
}

function BudgetPanel() {
    const operations = useOperations(), portal = usePortalContainer(), id = useId();
    const {budget, draft, scope} = operations;
    const disabled = !!operations.busy || operations.expired;
    const fields: {key: keyof BudgetDraft; label: string; hint?: string}[] = [{key: 'monthlyTokenLimit', label: '每月 Token 上限', hint: '留空表示未限制'}, {key: 'warningPercent', label: '提醒比例（%）'}, {key: 'reservationTokens', label: '每題預留 Token'}];
    return <div className="min-w-0 w-full space-y-4 break-words" data-slot="mes-budget-panel">
        {budget && <>
            <p className="text-sm text-muted-foreground">{budget.period} · 台北時間</p>
            {[budget.system, budget.account].filter(value => value.reached || value.near_limit).map(value => <p key={value.scope} role={value.reached ? 'alert' : 'status'} className={value.reached ? 'text-sm text-destructive' : 'text-sm'}>{value.scope === 'system' ? '系統' : '目前帳號'}{value.reached ? '額度已達上限' : `用量已達 ${value.config.warning_percent}% 提醒門檻`}</p>)}
            <Select value={scope} onValueChange={value => operations.setScope(value as BudgetScope)} disabled={disabled}><SelectTrigger aria-label="額度範圍" className="w-full"><SelectValue /></SelectTrigger><SelectContent portalContainer={portal}><SelectItem value="account">目前帳號</SelectItem><SelectItem value="system">整個系統</SelectItem></SelectContent></Select>
            <Table><TableHeader><TableRow><TableHead>用量項目</TableHead><TableHead className="text-right">Token／數量</TableHead></TableRow></TableHeader><TableBody>{[
                ['已確認 Token', tokenText(budget[scope].confirmed_tokens)], ['預留 Token', tokenText(budget[scope].reserved_tokens)], ['待確認請求', tokenText(budget[scope].unknown_request_count)], ['分析中的請求', tokenText(budget[scope].active_request_count)], ['可用額度', budget[scope].limit === null ? '未設定上限' : tokenText(budget[scope].remaining_tokens)],
            ].map(([label, value]) => <TableRow key={label}><TableCell>{label}</TableCell><TableCell className="text-right tabular-nums">{value}</TableCell></TableRow>)}</TableBody></Table>
            <p className="text-xs text-muted-foreground">{budget[scope].usage_status === 'known' ? '用量已確認' : '含待確認用量'}；費用依帳單為準。</p>
            {draft && <div className="space-y-4">{fields.map(field => <div key={field.key} className="space-y-2"><Label htmlFor={id + field.key}>{field.label}</Label><Input id={id + field.key} inputMode="numeric" autoComplete="off" value={draft[field.key]} onChange={event => operations.setBudgetValue(field.key, event.target.value)} disabled={disabled || !budget.management.write_allowed} />{field.hint && <p className="text-xs text-muted-foreground">{field.hint}</p>}</div>)}</div>}
            <p className="text-xs text-muted-foreground">{budget.management.write_allowed ? '儲存後立即生效' : '僅供查看；額度由管理員調整。'}</p>
        </>}
    </div>;
}

function SchedulesPanel() {
    const operations = useOperations(), id = useId();
    const disabled = !!operations.busy || operations.expired;
    if (operations.runs !== null) return <div className="min-w-0 w-full space-y-4 break-words" data-slot="mes-schedule-runs"><div className="flex flex-wrap items-center justify-between gap-2"><p className="min-w-0 text-sm font-medium">{operations.runScope}</p><Button variant="outline" size="sm" disabled={disabled} onClick={operations.backToSchedules}>返回排程</Button></div>
        {!operations.runs.length ? <p className="text-sm text-muted-foreground">尚未產生報告</p> : <Table><TableHeader><TableRow><TableHead>原訂時間</TableHead><TableHead>狀態</TableHead><TableHead>報告</TableHead></TableRow></TableHeader><TableBody>{operations.runs.map(run => <TableRow key={run.run_id}><TableCell>{dateText(run.due_at)}</TableCell><TableCell>{runLabels[run.status] || '尚未取得'}</TableCell><TableCell><Button variant="ghost" size="sm" disabled={disabled} onClick={() => operations.setSelectedRun(run)}>{scheduledReportDisplay(run).kind === 'ready' ? '查看報告' : '查看狀態'}</Button></TableCell></TableRow>)}</TableBody></Table>}
        {operations.selectedRun && <ScheduledReportView run={operations.selectedRun} />}
    </div>;
    return <div className="min-w-0 w-full space-y-4 break-words" data-slot="mes-schedules-panel">
        <div className="space-y-2"><Label htmlFor={id}>排程需求</Label><Textarea id={id} value={operations.sourceText} onChange={event => operations.setSourceText(event.target.value)} placeholder="每天早上九點給我機台和報工人員及產出報告" disabled={disabled} maxLength={1000} /></div>
        <div className="flex flex-wrap gap-2"><Button variant="outline" disabled={disabled || !operations.sourceText.trim()} onClick={() => void operations.parse()}>解析時間</Button><Button disabled={disabled || !operations.sourceText.trim()} onClick={() => void operations.create()}>建立排程</Button><Button variant="ghost" disabled={disabled} onClick={() => void operations.showRuns()}>已保存報告</Button></div>
        {operations.parsed && <div className="space-y-1 border-l-2 ps-3 text-sm"><p>{scheduleTimeText(operations.parsed)}</p><p>{operations.parsed.scope_label}</p><p className="text-muted-foreground">前一完整生產日 · 下次 {dateText(operations.parsed.next_run_at)}</p></div>}
        {!operations.schedules.length ? <p className="text-sm text-muted-foreground">尚未建立排程</p> : <Table><TableHeader><TableRow><TableHead>排程</TableHead><TableHead>狀態</TableHead><TableHead>操作</TableHead></TableRow></TableHeader><TableBody>{operations.schedules.map(schedule => <TableRow key={schedule.schedule_id}><TableCell><p className="font-medium">{schedule.report_request}</p><p className="text-xs text-muted-foreground">{scheduleTimeText(schedule)}</p><p className="text-xs text-muted-foreground">下次 {dateText(schedule.next_run_at)} · 前一完整生產日</p></TableCell><TableCell>{schedule.status === 'active' ? '執行中' : '已暫停'}</TableCell><TableCell><div className="flex flex-wrap gap-1"><Button size="sm" variant="ghost" disabled={disabled} onClick={() => void operations.showRuns(schedule)}>查看報告</Button><Button size="sm" variant="ghost" disabled={disabled} onClick={() => void operations.toggle(schedule)}>{schedule.status === 'active' ? '暫停' : '恢復'}</Button><Button size="sm" variant="ghost" disabled={disabled} onClick={() => operations.setDeleteTarget(schedule)}>刪除排程</Button></div></TableCell></TableRow>)}</TableBody></Table>}
        {operations.deleteTarget && <div className="space-y-2 border-t pt-3" role="alert"><p className="text-sm">刪除此排程後不再產生新報告，已保存報告仍可查看</p><div className="flex flex-wrap gap-2"><Button variant="outline" disabled={disabled} onClick={() => operations.setDeleteTarget(null)}>取消刪除</Button><Button variant="destructive" disabled={disabled} onClick={() => void operations.remove()}>確認刪除排程</Button></div></div>}
    </div>;
}

function ProductionTable({rows, identity, label}: {rows: (ScheduledReportRow & {machine_id?: string; personnel_id?: string})[]; identity: 'machine_id' | 'personnel_id'; label: string}) {
    return <Table><TableHeader><TableRow><TableHead>{label}</TableHead><TableHead className="text-right">良品</TableHead><TableHead className="text-right">不良品</TableHead><TableHead className="text-right">總產出</TableHead><TableHead className="text-right">報工筆數</TableHead></TableRow></TableHeader><TableBody>{rows.map((row, index) => <TableRow key={row[identity] || index}><TableCell>{row[identity] || '尚未取得'}</TableCell>{(['good_qty', 'scrap_qty', 'total_qty', 'task_count'] as const).map(key => <TableCell key={key} className="text-right tabular-nums">{tokenText(row[key])}</TableCell>)}</TableRow>)}</TableBody></Table>;
}
function ScheduledReportView({run}: {run: ScheduleRun}) {
    const display = scheduledReportDisplay(run);
    if (display.kind !== 'ready') return <section className="min-w-0 w-full space-y-2 break-words border-t pt-4" data-slot="mes-schedule-report-status"><h3 className="text-base font-semibold">{display.title}</h3><p role="status" className="text-sm text-muted-foreground">{display.message}</p></section>;
    const report = display.report;
    return <section className="min-w-0 w-full space-y-4 break-words border-t pt-4" data-slot="mes-scheduled-report"><h3 className="text-base font-semibold">{report.title}</h3><p className="text-xs text-muted-foreground">{dateText(report.period_start)} 至 {dateText(report.period_end)} · 台北時間</p>{report.status === 'no_data' && <p role="status" className="text-sm">此期間沒有可用報工資料</p>}
        <Table><TableHeader><TableRow><TableHead>彙總項目</TableHead><TableHead className="text-right">數量</TableHead></TableRow></TableHeader><TableBody>{([
            ['good_qty', '良品'], ['scrap_qty', '不良品'], ['total_qty', '總產出'], ['task_count', '報工筆數'], ['machine_count', '機台數'], ['personnel_count', '不同報工人員數'], ['reporting_group_count', '報工人員組合數'],
        ] as const).filter(([key]) => key !== 'reporting_group_count' || report.summary[key] !== undefined).map(([key, label]) => <TableRow key={key}><TableCell>{label}</TableCell><TableCell className="text-right tabular-nums">{tokenText(report.summary[key])}</TableCell></TableRow>)}</TableBody></Table>
        <h4 className="text-sm font-medium">機台產出</h4><ProductionTable rows={report.machines} identity="machine_id" label="機台" /><h4 className="text-sm font-medium">報工人員／組合產出</h4><ProductionTable rows={report.personnel} identity="personnel_id" label="報工人員／組合" />
        {report.warnings?.length > 0 && <ul className="list-disc space-y-1 ps-5 text-sm text-muted-foreground">{report.warnings.map((warning, index) => <li key={index}>{warning}</li>)}</ul>}<p className="text-xs text-muted-foreground">資料來源：{report.data_source} · 產生時間：{dateText(report.generated_at)}</p>
    </section>;
}
