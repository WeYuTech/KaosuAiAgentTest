import {useEffect} from 'react';
import {Button} from '@/components/ui/button';
import {Progress} from '@/components/ui/progress';
import {Tooltip, TooltipContent, TooltipTrigger} from '@/components/ui/tooltip';
import {sidebarBudgetSummary, type SidebarBudgetSummary} from '@/chat/sidebar-budget';
import {usePortalContainer} from '@/features/common/UiContext';
import {useOperations} from './operations';

/** 只掛載在滿版大螢幕側欄，與既有用量 Dialog 共用 Provider 快照 */
export function SidebarBudget() {
    const operations = useOperations(), portal = usePortalContainer();
    const {setSidebarVisible} = operations;
    useEffect(() => {setSidebarVisible(true); return () => setSidebarVisible(false);}, [setSidebarVisible]);
    const summary = operations.budgetSnapshot && sidebarBudgetSummary(operations.budgetSnapshot);
    const limit = summary && operations.budgetSnapshot?.[summary.scope].limit;
    const limitKind = limit === null ? 'unlimited' : limit === 0 ? 'zero' : 'configured';
    return <div className="shrink-0 border-t px-3 py-2" data-slot="mes-sidebar-budget">
        <SidebarBudgetControl summary={summary} limitKind={limitKind} status={operations.budgetStatus} expired={operations.expired}
            portal={portal} onOpen={() => operations.open('budget')} />
    </div>;
}

interface SidebarBudgetControlProps {
    summary: SidebarBudgetSummary | null;
    limitKind: 'unlimited' | 'zero' | 'configured';
    status: 'idle' | 'loading' | 'ready' | 'unavailable';
    expired: boolean;
    portal?: HTMLElement | null;
    onOpen(): void;
}

/** 純呈現：文字摘要與細進度條，詳細資訊沿用原 Tooltip 與 Dialog */
export function SidebarBudgetControl({summary, limitKind, status, expired, portal, onOpen}: SidebarBudgetControlProps) {
    const available = !expired && status !== 'unavailable' && summary;
    const loading = status === 'loading' || status === 'idle';
    const statusText = expired ? '登入已逾時，請重新登入 MES 後查看用量' : status === 'unavailable' ? '暫時無法讀取用量，不能當成零用量' : '正在讀取用量';
    const description = available ? summary.accessibleText + (loading ? '，正在更新用量' : '') : statusText;
    const unknown = !!available && (summary.note.includes('待確認') || summary.note.includes('尚未確認'));
    const percentage = available ? summary.percentage : null;
    const valueText = expired ? '登入逾時' : status === 'unavailable' ? '讀取失敗' : loading ? '更新中'
        : !available ? '尚未取得' : limitKind === 'unlimited' ? '未設上限' : limitKind === 'zero' ? '額度為 0'
        : percentage === null ? '待確認' : summary.percentageText + (unknown ? ' · 待確認' : '');
    return <Tooltip><TooltipTrigger asChild>
        <Button variant="ghost" className="h-auto min-w-0 w-full flex-col items-stretch gap-2 px-2 py-2 text-muted-foreground"
            data-slot="mes-sidebar-budget-control" data-scope={available ? summary.scope : undefined}
            aria-label={`查看用量額度，${description}`} aria-busy={!expired && loading} onClick={onOpen}>
            <span className="flex min-w-0 items-center justify-between gap-2 text-xs">
                <span>Token 用量</span>
                <span data-slot="mes-sidebar-budget-value" className={available && summary.warning || expired || status === 'unavailable' ? 'tabular-nums text-destructive' : 'tabular-nums'}>{valueText}</span>
            </span>
            <Progress value={percentage} aria-hidden className={percentage === null
                ? 'h-1.5 min-w-0 w-full bg-muted [&_[data-slot=progress-indicator]]:hidden'
                : summary?.reached ? 'h-1.5 min-w-0 w-full [&_[data-slot=progress-indicator]]:bg-destructive' : 'h-1.5 min-w-0 w-full'} />
        </Button>
    </TooltipTrigger><TooltipContent portalContainer={portal} side="right" className="max-w-xs">
        {description}，點擊查看額度設定
    </TooltipContent></Tooltip>;
}
