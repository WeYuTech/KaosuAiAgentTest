import { useCallback, useRef } from 'react';
import {usePortalContainer} from './UiContext';
import {restoreAvailableFocus} from './restoreFocus';

/* 由程式開啟的 Dialog／Sheet 沒有 Radix Trigger，統一保存並還原焦點。 */
export function useDialogFocus() {
    const portal = usePortalContainer();
    const returnTarget = useRef<HTMLElement | null>(null);
    const onOpenAutoFocus = useCallback((event: Event) => {
        returnTarget.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        event.preventDefault();
        if (event.target instanceof HTMLElement) event.target.focus();
    }, []);
    const onCloseAutoFocus = useCallback((event: Event) => {
        event.preventDefault();
        restoreAvailableFocus(returnTarget.current, portal || document.getElementById('mes-ai-chat-root'));
    }, [portal]);
    return { onOpenAutoFocus, onCloseAutoFocus };
}
