/** 排除隱藏、停用與 inert 區域，避免關閉 Dialog 後焦點落到無法操作的控制項 */
export function availableFocusTarget(target: HTMLElement | null): target is HTMLElement {
    return !!target?.isConnected && !!target.getClientRects().length && !target.matches(':disabled')
        && !target.closest('[inert], [hidden], [aria-hidden="true"]')
        && (target.tabIndex >= 0 || target.hasAttribute('tabindex'));
}

/** 只在助理 Portal 內選替代目標，不改宿主 MES 的焦點 */
export function restoreAvailableFocus(previous: HTMLElement | null, root: HTMLElement | null): boolean {
    const candidates = root?.querySelectorAll<HTMLElement>('[data-slot="aui_thread-list-search"] input:not([disabled]), .aui-composer-input:not([disabled]), .aui-modal-title');
    const target = availableFocusTarget(previous) ? previous : Array.from(candidates || []).find(availableFocusTarget);
    if (!target) return false;
    target.focus(); return true;
}
