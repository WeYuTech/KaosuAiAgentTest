import {LoaderCircleIcon} from 'lucide-react';
import {useState} from 'react';
import {Button} from '@/components/ui/button';
import {useMesUi} from '@/chat/mes-ui-context';
import {chatExecutionStatus} from '@/chat/progress';
import {readExecutionTrace} from '@/chat/execution-trace';
import {statusText} from '@/chat/report';

/** 有活動摘要時不再顯示第二個載入提示；取消、連線與保存錯誤仍保留 */
export function ChatExecutionStatus() {
    const {state, actions} = useMesUi();
    const [connecting, setConnecting] = useState(false);
    if (state.expired || state.sessionNotice) return null;
    const progress = chatExecutionStatus(state);
    if (!progress.spinning && state.activeTurn?.execution_state === 'submission_unknown'
        && progress.text === statusText(state.activeTurn)) return null;
    if (progress.spinning && !state.reconnectNeeded && !state.connectionStatus.startsWith('觀看連線中斷')
        && state.activeTurn && readExecutionTrace(state.activeTurn).length > 0) return null;
    if (!progress.text && !progress.spinning) return null;
    return <div data-slot="mes-chat-progress" className="flex items-center gap-2 px-4 pb-2 text-xs text-muted-foreground" role="status" aria-live="polite" aria-atomic="true" aria-label="處理進度">
        {progress.spinning && <LoaderCircleIcon data-slot="mes-chat-spinner" className="size-3.5 shrink-0 animate-spin" aria-hidden />}
        <span key={progress.text} className="animate-in fade-in duration-200 motion-reduce:animate-none">{progress.text}</span>
        {!state.runtime && !state.submitting && <Button variant="outline" size="sm" className="shrink-0" disabled={connecting}
            onClick={async () => {setConnecting(true); try {await actions.reconnect();} finally {setConnecting(false);}}}>
            {connecting ? '正在連線' : '重新連線'}
        </Button>}
    </div>;
}
