import {useEffect, useRef, useState} from 'react';
import {useScrollLock} from '@assistant-ui/react';
import {Check, ChevronDown, Circle, CircleAlert, LoaderCircle} from 'lucide-react';
import type {Turn} from '@/chat/types';
import {activityPresentation, waitingDuration} from '@/chat/activity-presentation';
import {Button} from '@/components/ui/button';
import {Collapsible, CollapsibleContent, CollapsibleTrigger} from '@/components/ui/collapsible';
import {ANIMATION_DURATION} from '@/components/assistant-ui/elements/reasoning';

interface ExecutionTraceProps {
    turn: Turn;
    defaultOpen?: boolean;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    paused?: boolean;
    local?: boolean;
}

/** 精簡活動摘要與按需展開的業務查詢；不以五個內部階段建立空白清單 */
export function ExecutionTrace({turn, defaultOpen = false, open: controlledOpen, onOpenChange, paused = false, local = false}: ExecutionTraceProps) {
    const [localOpen, setLocalOpen] = useState(defaultOpen);
    const panel = useRef<HTMLDivElement>(null);
    const lockScroll = useScrollLock(panel, ANIMATION_DURATION);
    const open = controlledOpen ?? localOpen;
    const activity = activityPresentation(turn, paused);
    const [clock, setClock] = useState(Date.now);
    const running = !!activity?.running;
    useEffect(() => {
        if (!running) return;
        setClock(Date.now());
        const timer = setInterval(() => setClock(Date.now()), 1000);
        return () => clearInterval(timer);
    }, [running, turn.request_id]);
    if (!activity) return null;
    const elapsed = waitingDuration(turn, clock);
    const waiting = running && elapsed !== null ? <span data-slot="mes-waiting-duration" className="text-xs text-muted-foreground">
        已等待 {elapsed} 秒{local && elapsed >= 15 ? ' · 本地模型處理較慢，可隨時停止' : ''}
    </span> : null;
    const summary = <>
        {activity.running && <LoaderCircle className="size-3.5 shrink-0 animate-spin" aria-hidden="true" />}
        <span className="text-sm" role="status" aria-live="polite" aria-atomic="true">{activity.label}</span>
    </>;
    if (!activity.queries.length) return <div data-slot="mes-execution-trace" className="mb-3 flex min-w-0 flex-wrap items-center gap-2 px-2 py-2 text-muted-foreground">{summary}{waiting}</div>;
    return <Collapsible ref={panel} open={open} onOpenChange={value => {setLocalOpen(value); onOpenChange?.(value);}}
        data-slot="mes-execution-trace" className="mb-3 min-w-0 px-2">
        <CollapsibleTrigger asChild>
            <Button type="button" variant="ghost" className="mes-trace-trigger h-auto min-h-11 max-w-full justify-start gap-2 whitespace-normal px-0 text-muted-foreground hover:bg-transparent hover:text-foreground"
                aria-label={open ? '收合查詢過程' : '展開查詢過程'}>
                {summary}
                <ChevronDown className={open ? 'mes-trace-chevron size-4 shrink-0 rotate-180' : 'mes-trace-chevron size-4 shrink-0'} aria-hidden="true" />
            </Button>
        </CollapsibleTrigger>
        {waiting}
        <CollapsibleContent className="mes-trace-panel overflow-hidden" onAnimationStart={event => {
            if (event.target === event.currentTarget) lockScroll();
        }}>
            <ol className="space-y-3 pb-3 pt-1" aria-label="查詢過程">
                {activity.queries.map(query => {
                    const Icon = query.running ? LoaderCircle : query.failed ? CircleAlert
                        : ['結果待確認', '等待更新', '已停止'].includes(query.status) ? Circle : Check;
                    return <li key={query.id} data-trace-id={query.id} className="flex min-w-0 gap-2">
                        <Icon className={`mt-1 size-3.5 shrink-0 text-muted-foreground${query.running ? ' animate-spin' : ''}`} aria-hidden="true" />
                        <div className="min-w-0 space-y-1">
                            <p className="flex flex-wrap items-baseline gap-x-2 text-sm"><span>{query.label}</span><span className="text-xs text-muted-foreground">{query.status}</span></p>
                            {query.detail && <p className="break-words text-xs text-muted-foreground">{query.detail}</p>}
                        </div>
                    </li>;
                })}
            </ol>
        </CollapsibleContent>
    </Collapsible>;
}
