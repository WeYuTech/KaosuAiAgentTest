import {hasAnswerFailure, hasDataLimitation} from '@/chat/conversation-presentation';
import { ActionBarPrimitive, useAuiState } from '@assistant-ui/react';
import { useId, useState } from 'react';
import { ChevronDown, Database, FileText, Info, Link2, ThumbsDown, ThumbsUp } from 'lucide-react';
import { isTerminal } from '@/chat/core';
import { inheritedQueryScopeSummary } from '@/chat/follow-ups';
import {readExecutionTrace} from '@/chat/execution-trace';
import { useMesUi } from '@/chat/mes-ui-context';
import { formatDate, formatNumber, sourceNoticeLabels, sourceText, statusText } from '@/chat/report';
import type { Message, Report } from '@/chat/types';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ToolFallback } from '@/components/assistant-ui/elements/tool-fallback.aui';
import { TooltipIconButton } from '@/components/assistant-ui/elements/tooltip-icon-button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useDialogFocus } from '@/features/common/useDialogFocus';
import { usePortalContainer } from '@/features/common/UiContext';
import { MesSavedReportChart } from './MesReportChart';
import { MesAnswerPresentation } from './MesReportTable';
import { MesExportButton, MesReportFormula, MesReportMetrics } from './MesReportDialog';
import {useVisibleReport} from './useVisibleReport';
import {MesSupplementaryAnalysis} from './MesSupplementaryAnalysis';

function useMesMessage() {return useAuiState(state => state.message.metadata.custom.mesMessage as Message | undefined);}

function MesSavedReport({report}: {report: Report}) {
    const {actions} = useMesUi();
    const [open, setOpen] = useState(false);
    const cards = report.cards.filter(card => card && typeof card === 'object' && card.display.answer);
    return <ToolFallback.Root open={open} onOpenChange={setOpen} data-slot="mes-saved-result"><CollapsibleTrigger asChild><Button type="button" variant="ghost" className="w-fit gap-2 px-0 py-1.5 text-sm text-muted-foreground hover:bg-transparent hover:text-foreground" aria-label="展開 MES 查詢資料"><Database className="size-4" aria-hidden="true" />MES 查詢資料{cards.length > 0 && <span>· {cards.length} 項</span>}<ChevronDown className={open ? 'size-4 transition-transform motion-reduce:transition-none' : 'size-4 -rotate-90 transition-transform motion-reduce:transition-none'} aria-hidden="true" /></Button></CollapsibleTrigger><ToolFallback.Content><div className="space-y-5">{cards.length ? cards.map(card => <section key={card.id} className="space-y-3" data-card-id={card.id} data-kind={card.kind}><div className="space-y-1"><h3 className="text-sm font-medium">{card.title || '查詢資料'}</h3><p className="text-xs text-muted-foreground">{card.source_label || sourceText(card)}{card.data_time && ` · 資料日期 ${card.data_time}`}</p></div><MesReportMetrics card={card} /><MesReportFormula card={card} /><div className="flex flex-wrap gap-1"><Button type="button" variant="ghost" size="sm" data-action="report-detail" onClick={() => void actions.openReport(report.request_id, card.id, 'detail')}><FileText aria-hidden="true" />查看明細</Button><Button type="button" variant="ghost" size="sm" data-action="report-evidence" onClick={() => void actions.openReport(report.request_id, card.id, 'evidence')}><Link2 aria-hidden="true" />查看依據</Button></div></section>) : <p className="text-sm text-muted-foreground">這次查詢沒有可顯示的數據資料，請參考回答與查詢依據</p>}</div></ToolFallback.Content></ToolFallback.Root>;
}

/** 附加已保存 MES 結果；正文與訊息版型仍由官方 Thread 呈現。 */
export function MesMessageExtras() {
    const message = useMesMessage();
    const hasErrorBox = useAuiState(s => {
        const status = s.message.status;
        return status?.type === 'incomplete' && status.reason === 'error';
    });
    const {state, actions} = useMesUi();
    const [traceOpen, setTraceOpen] = useState(false);
    const reportRef = useVisibleReport(message, message?.request_id ? state.reports[message.request_id] : undefined, actions.loadReport);
    if (!message || message.role !== 'assistant') return null;
    const requestId = message.request_id;
    const entry = requestId ? state.reports[requestId] : undefined;
    const report = entry?.state === 'ready' ? entry.report : null;
    const terminal = isTerminal(message) || !message.execution_state && !message.status;
    const fallback: Report = {report_version: 'mes-report-v1', request_id: requestId || '', cards: [], evidence: message.evidence, warnings: message.warnings};
    const answerCards = (report?.cards || []).filter(card => card && typeof card === 'object' && card.display.answer);
    const presentation = report?.answer_presentation;
    const directPresentation = presentation && presentation.mode !== 'auto';
    const sourceNotices = [...new Set(answerCards.filter(card => card.provenance !== 'mes_database').map(card => (sourceNoticeLabels[card.provenance || 'unknown'] || sourceNoticeLabels.unknown) + (card.data_time ? ` · 資料日期 ${card.data_time}` : '')))];
    // 生成中的 unavailable 是稽核結果尚未確定，只有終態才呈現稽核故障。
    const auditUnavailable = terminal && message.audit_status === 'unavailable';
    const inheritedScope = inheritedQueryScopeSummary(message);
    return (<div ref={reportRef} className="mt-3 space-y-3 text-sm" data-request-id={requestId} data-slot="mes-message-extras">{inheritedScope && <p className="text-xs text-muted-foreground" data-slot="mes-inherited-query-scope">沿用查詢條件：{inheritedScope}
        </p>}
        {(terminal || message.execution_state === 'submission_unknown') && !message.content && !readExecutionTrace(message).length && <p role="status" className="text-muted-foreground">{statusText(message)}
        </p>}
        {message.error_message && !hasErrorBox && message.content.trim() !== message.error_message.trim() && <p className="text-destructive">{message.error_message}
        </p>}
        {hasDataLimitation(message) && <p className="text-muted-foreground">部分資料不足</p>}
        {hasAnswerFailure(message) && <p className="text-muted-foreground" data-slot="mes-answer-incomplete">回答未完成</p>}
        {entry?.state === 'loading' && <p role="status" className="text-muted-foreground">正在讀取查詢數據…</p>}
        {entry && ['missing', 'unavailable', 'retryable-error'].includes(entry.state) && <p className="text-muted-foreground">{entry.message}
        </p>}
        {entry?.state === 'retryable-error' && requestId && <Button type="button" variant="ghost" size="sm" disabled={state.expired} onClick={() => void actions.retryReport(requestId)}>重新載入</Button>}
        {report?.view_preferences_reason && <p role="status" className="text-muted-foreground">{report.view_preferences_reason}</p>}
        {requestId && state.presentationErrors?.[requestId] && <div role="status" className="text-muted-foreground">{state.presentationErrors[requestId]}<Button type="button" variant="ghost" size="sm" disabled={state.expired || state.presentationSaving?.includes(requestId)} onClick={() => void actions.retryReport(requestId)}>重新載入</Button></div>}
        {terminal && report && directPresentation ? <MesAnswerPresentation report={report} presentation={presentation} warnings={message.warnings} /> : terminal && answerCards.map(card => <section key={card.id} className="min-w-0 space-y-4" data-slot="mes-report-overview"><MesReportMetrics card={card} variant="summary" /><MesSavedReportChart card={card} report={report!} /></section>)}
        {report && !!answerCards.length && !directPresentation && <MesSavedReport report={report} />}
        {terminal && requestId && message.supplementary_analysis && <MesSupplementaryAnalysis requestId={requestId} value={message.supplementary_analysis} />}
        {sourceNotices.map(notice => <p className="flex items-start gap-2 text-xs text-muted-foreground" key={notice}>
        <Info className="size-4 shrink-0" aria-hidden="true" />{notice}
        </p>)}
        {terminal && (message.content || message.error_message || report) && <Collapsible open={traceOpen} onOpenChange={setTraceOpen}>
        <div className="flex flex-wrap items-center gap-1" data-slot="mes-report-actions">{report && <>{!!answerCards.length && <Button type="button" variant="ghost" size="sm" data-action="report-detail" onClick={() => void actions.openReport(report.request_id, null, 'detail')}>
        <FileText aria-hidden="true" />{directPresentation ? '查看原始報表' : '查看明細'}</Button>}<Button type="button" variant="ghost" size="sm" data-action="report-evidence" onClick={() => void actions.openReport(report.request_id, null, 'evidence')}>
        <Link2 aria-hidden="true" />查看依據</Button>{!!answerCards.length && <MesExportButton requestId={report.request_id} />}
        </>}
        {!report && requestId && !!(message.evidence?.length || message.warnings?.length) && <Button type="button" variant="ghost" size="sm" data-action="report-evidence" onClick={() => void actions.openReport(requestId, null, 'evidence', fallback)}>
        <Link2 aria-hidden="true" />查看回答依據</Button>}<CollapsibleTrigger asChild>
        <Button type="button" variant="ghost" size="sm">
        <Info aria-hidden="true" />查詢資訊<ChevronDown className={traceOpen ? 'size-4 rotate-180' : 'size-4'} aria-hidden="true" />
        </Button>
        </CollapsibleTrigger>
        </div>
        <CollapsibleContent>
        <dl className="mt-2 grid gap-2 rounded-lg border p-4 text-xs">
        <dt className="text-muted-foreground">Request ID</dt>
        <dd className="break-all font-mono">{requestId || '尚未取得'}
        </dd>
        <dt className="text-muted-foreground">時間</dt>
        <dd>{formatDate(message.completed_at || message.created_at || message.started_at) || '尚未取得'}
        </dd>
        <dt className="text-muted-foreground">Token</dt>
        <dd>{message.usage_known === false || !message.usage || message.usage.total_tokens == null ? '尚未取得' : formatNumber(message.usage.total_tokens)}
        </dd>{!!message.definition_sources?.length && <>
        <dt className="text-muted-foreground">業務定義</dt>
        <dd>{message.definition_sources.map(source => source.label).join("；")}
        </dd>
        </>}
        {message.model_name && <>
        <dt className="text-muted-foreground">模型</dt>
        <dd>{message.model_name}
        </dd>
        </>}
        </dl>
        </CollapsibleContent>
        </Collapsible>}
        {message.response_kind === 'rewrite' && message.source_request_id && <p className="text-xs text-muted-foreground" data-slot="mes-saved-result-notice">沿用已保存的查詢結果整理，沒有重新查詢 MES</p>}
        {auditUnavailable && <p className="text-muted-foreground">稽核紀錄暫時未能保存；已保存的聊天與查詢報告仍可讀取</p>}
        </div>);
}

/** 官方評價 primitives 保留；負評原因以既有 MES 回饋契約保存。 */
export function MesFeedbackControls() {
    const message = useMesMessage();
    const {state, actions} = useMesUi();
    const [opened, setOpened] = useState(false), [reason, setReason] = useState('wrong_number'), [note, setNote] = useState('');
    const id = useId(), portal = usePortalContainer(), focus = useDialogFocus();
    const requestId = message?.request_id;
    if (!message || message.role !== 'assistant' || !requestId || message.audit_status === 'unavailable' || !['succeeded', 'insufficient_data', undefined].includes(message.status)) return null;
    const saving = state.feedbackSaving.includes(requestId);
    return <><ActionBarPrimitive.FeedbackPositive asChild disabled={saving || state.expired}><TooltipIconButton type="button" tooltip="有幫助" aria-label="有幫助" aria-pressed={message.feedback?.rating === 'up'}><ThumbsUp aria-hidden="true" /></TooltipIconButton></ActionBarPrimitive.FeedbackPositive><ActionBarPrimitive.FeedbackNegative asChild disabled={saving || state.expired} onClick={event => {event.preventDefault(); setOpened(true);}}><TooltipIconButton type="button" tooltip="回報問題" aria-label="回報問題" aria-pressed={message.feedback?.rating === 'down'}><ThumbsDown aria-hidden="true" /></TooltipIconButton></ActionBarPrimitive.FeedbackNegative><Dialog open={opened} onOpenChange={setOpened}><DialogContent portalContainer={portal} {...focus}><DialogHeader><DialogTitle>回報回答問題</DialogTitle><DialogDescription>協助我們了解這次 MES 回答需要改善的地方</DialogDescription></DialogHeader><form className="space-y-4" onSubmit={event => {event.preventDefault(); if (!saving && !state.expired) void actions.saveFeedback(requestId, {rating: 'down', reason, note: note.trim()}).then(ok => {if (ok) setOpened(false);});}}><div className="space-y-2"><Label htmlFor={`${id}-reason`}>問題類型</Label><Select value={reason} onValueChange={setReason} disabled={saving || state.expired}><SelectTrigger id={`${id}-reason`} className="w-full" aria-label="問題類型"><SelectValue /></SelectTrigger><SelectContent portalContainer={portal}>{[['wrong_number', '數字不對'], ['wrong_tool', '工具選錯'], ['unclear', '說明不清楚'], ['other', '其他']].map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}</SelectContent></Select></div><div className="space-y-2"><Label htmlFor={`${id}-note`}>補充說明（選填）</Label><Textarea id={`${id}-note`} rows={3} maxLength={500} value={note} onChange={event => setNote(event.target.value)} disabled={saving || state.expired} /></div><DialogFooter><Button type="button" variant="ghost" onClick={() => setOpened(false)}>取消</Button><Button type="submit" disabled={saving || state.expired} aria-busy={saving}>送出回報</Button></DialogFooter></form></DialogContent></Dialog></>;
}
