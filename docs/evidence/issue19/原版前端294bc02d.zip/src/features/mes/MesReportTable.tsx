import {useState} from 'react';
import {ChevronDown, FileText} from 'lucide-react';
import type {AnswerPresentation, Report, ReportCard} from '@/chat/types';
import {Button} from '@/components/ui/button';
import {Collapsible, CollapsibleContent, CollapsibleTrigger} from '@/components/ui/collapsible';
import {Table, TableBody, TableCell, TableHead, TableHeader, TableRow} from '@/components/ui/table';
import {MesSavedReportChart} from './MesReportChart';
import {MesWarningList} from './MesReportDialog';

/** 表格只讀保存時已核對的顯示值，不解析回答文字或重新計算數量。 */
export function MesReportTable({card}: {card: ReportCard}) {
    const table = card.binding_table;
    return table?.rows.length ? <Table aria-label={`${card.title || '原回答'}保存值`} data-slot="mes-binding-table">
        <TableHeader><TableRow>{table.columns.map(column => <TableHead key={column.key} scope="col">{column.label}</TableHead>)}</TableRow></TableHeader>
        <TableBody>{table.rows.map((row, index) => <TableRow key={index}>{table.columns.map(column => <TableCell key={column.key} className="whitespace-normal break-words">{row[column.key]}</TableCell>)}</TableRow>)}</TableBody>
    </Table> : null;
}

/** 原回答保持不透明文字；來源引用中的數字不成為新的圖表輸入。 */
export function MesSourceAnswer({answer, warnings}: {answer?: string; warnings: string[]}) {
    return <div className="space-y-3">{answer && <p className="whitespace-pre-wrap break-words text-sm" data-slot="mes-source-answer">{answer}</p>}<MesWarningList items={warnings} /></div>;
}

export function MesAnswerPresentation({report, presentation, warnings}: {report: Report; presentation: AnswerPresentation; warnings?: string[]}) {
    const [open, setOpen] = useState(false);
    const cards = report.cards.filter(card => card.display.answer);
    const limits = [...(warnings || []), ...(report.warnings || []), ...cards.flatMap(card => [...(card.warnings || []), ...(card.notes || []), ...(card.evidence || []).flatMap(item => item.warnings || [])]), ...(report.evidence || []).flatMap(item => item.warnings || [])];
    return <div className="min-w-0 space-y-4" data-slot="mes-answer-presentation" data-presentation-mode={presentation.mode}>
        {cards.map(card => <section key={card.id} className="min-w-0 space-y-3" data-card-id={card.id}>
            <h3 className="text-sm font-medium">{card.title || '原回答保存資料'}</h3>
            <MesSavedReportChart card={card} report={report} presentation={presentation} />
        </section>)}
        <Collapsible open={open} onOpenChange={setOpen}><CollapsibleTrigger asChild><Button type="button" variant="ghost" size="sm"><FileText aria-hidden="true" />原回答與重要限制<ChevronDown className={open ? 'size-4 rotate-180' : 'size-4'} aria-hidden="true" /></Button></CollapsibleTrigger>
            <CollapsibleContent><MesSourceAnswer answer={report.source_answer} warnings={limits} /></CollapsibleContent>
        </Collapsible>
    </div>;
}
