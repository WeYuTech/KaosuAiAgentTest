import {useEffect, useRef} from 'react';
import {LoaderCircle} from 'lucide-react';
import {decodeSupplementaryAnalysis, supplementaryAnalysisLabel, supplementaryAnalysisPending} from '@/chat/supplementary-analysis';
import {useMesUi} from '@/chat/mes-ui-context';
import type {SupplementaryAnalysis, SupplementaryAnalysisReadError} from '@/chat/types';
import {Button} from '@/components/ui/button';

/** 只有正在閱讀的區塊需要觀看進度；離開畫面不取消後端工作。 */
export function observeVisibleAnalysis(element: Element, start: () => () => void): () => void {
    if (typeof IntersectionObserver === 'undefined') return start();
    let stop: (() => void) | null = null, active = true;
    const observer = new IntersectionObserver(entries => {
        if (!active) return;
        const visible = entries.some(entry => entry.isIntersecting);
        if (visible && !stop) stop = start();
        else if (!visible && stop) {stop(); stop = null;}
    });
    observer.observe(element);
    return () => {active = false; observer.disconnect(); stop?.();};
}

export function SupplementaryAnalysisContent({analysis, error, disabled, watching = true, onFollowUp, onRetry}: {
    analysis: SupplementaryAnalysis; error?: SupplementaryAnalysisReadError; disabled?: boolean; watching?: boolean; onFollowUp: (question: string) => void; onRetry: () => void;
}) {
    const running = supplementaryAnalysisPending(analysis) && !error && watching;
    return <section className="space-y-3 rounded-lg border p-4" data-slot="mes-supplementary-analysis" data-state={analysis.state} aria-label="補充分析">
        <h3 className="text-sm font-medium">補充分析</h3>
        <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status">
            {running && <LoaderCircle className="size-4 shrink-0 animate-spin" aria-hidden="true" />}
            {error?.message || supplementaryAnalysisLabel(analysis)}
        </p>
        {!error && analysis.reason && <p className="text-sm text-muted-foreground">{analysis.reason}</p>}
        {!error && analysis.findings.map(finding => <article key={finding.id} className="space-y-2" data-finding-id={finding.id}>
            <h4 className="text-sm font-medium">{finding.title}</h4>
            <p>{finding.observation}</p>
            <p className="text-xs text-muted-foreground">{finding.scope} · {finding.comparison}</p>
            <Button type="button" variant="outline" size="sm" disabled={disabled} onClick={() => onFollowUp(finding.follow_up.question)}>{finding.follow_up.label}</Button>
        </article>)}
        {error?.retryable && <Button type="button" variant="ghost" size="sm" disabled={disabled} onClick={onRetry}>重新載入分析</Button>}
    </section>;
}

export function MesSupplementaryAnalysis({requestId, value}: {requestId: string; value: unknown}) {
    const {state, actions} = useMesUi(), ref = useRef<HTMLDivElement>(null);
    let analysis: SupplementaryAnalysis | null = null;
    try {analysis = decodeSupplementaryAnalysis(value);} catch {/* 壞分析保持局部不可用，原答案繼續呈現。 */}
    const childId = analysis?.request_id, pending = !!analysis && supplementaryAnalysisPending(analysis);
    const enabled = state.opened && state.view === 'chat' && !state.inputDisabled && !state.expired;
    useEffect(() => {
        if (!enabled || !pending || !childId || !ref.current) return;
        return observeVisibleAnalysis(ref.current, () => actions.observeSupplementaryAnalysis(requestId));
    }, [actions, requestId, childId, enabled, pending]);
    if (!analysis) return value == null ? null : <p className="text-sm text-muted-foreground" data-slot="mes-supplementary-analysis-unavailable">補充分析資料無法讀取；原回答仍可使用</p>;
    return <div ref={ref}><SupplementaryAnalysisContent analysis={analysis} error={state.supplementaryAnalysisErrors?.[requestId]} disabled={state.inputDisabled} watching={enabled}
        onFollowUp={question => actions.setDraft(question)} onRetry={() => actions.retrySupplementaryAnalysis(requestId)} /></div>;
}
