import {useEffect, useRef} from 'react';
import {isTerminal} from '@/chat/core';
import type {Message, ReportEntry} from '@/chat/types';

export function messageHasReport(message?: Message): boolean {
    if (!message || message.role !== 'assistant' || !message.request_id || message.report_available === false) return false;
    return (isTerminal(message) || !message.execution_state && !message.status) &&
        (message.report_available === true || ['succeeded', 'insufficient_data', undefined].includes(message.status));
}

/** 只在訊息進入實際可見範圍時讀取保存資料，重試由使用者明確觸發。 */
export function observeVisibleReport(element: Element, load: () => void): () => void {
    if (typeof IntersectionObserver === 'undefined') {load(); return () => {};}
    let active = true;
    const observer = new IntersectionObserver(entries => {
        if (active && entries.some(entry => entry.isIntersecting)) {active = false; observer.disconnect(); load();}
    });
    observer.observe(element);
    return () => {active = false; observer.disconnect();};
}

export function useVisibleReport(message: Message | undefined, entry: ReportEntry | undefined, load: (requestId: string) => Promise<ReportEntry>) {
    const ref = useRef<HTMLDivElement>(null);
    const requestId = message?.request_id;
    const eligible = messageHasReport(message);
    useEffect(() => {
        if (!ref.current || !requestId || !eligible || entry) return;
        return observeVisibleReport(ref.current, () => {void load(requestId);});
    }, [requestId, eligible, entry, load]);
    return ref;
}
