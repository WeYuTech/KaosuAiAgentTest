import {useState, type ReactNode} from 'react';
import {useAuiState} from '@assistant-ui/react';
import {useMesUi} from '@/chat/mes-ui-context';
import {readExecutionTrace} from '@/chat/execution-trace';
import {observeAnalysis, toggleAnalysis} from '@/chat/analysis-presentation';
import type {Message} from '@/chat/types';
import {ExecutionTrace} from './ExecutionTrace';

/** 已公開回答立即交給官方渲染器；查詢過程只控制自身的開合 */
export function MesAnalysisMessage({children}: {children: ReactNode}) {
    const message = useAuiState(s => s.message.metadata.custom.mesMessage as Message | undefined);
    const identity = useAuiState(s => s.message.id);
    const {state} = useMesUi();
    const [presentation, setPresentation] = useState(() => observeAnalysis(null, identity));
    const next = observeAnalysis(presentation, identity);
    if (next !== presentation) setPresentation(next);
    const paused = !state.opened || state.view !== 'chat' || state.expired || state.cancelling
        || state.unknownSubmission || state.reconnectNeeded || !!message?.watch_unavailable
        || state.connectionStatus.startsWith('觀看連線中斷');
    return <div data-slot="mes-analysis-message" data-presentation="ready">
        {message && <ExecutionTrace turn={message} open={next.open}
            onOpenChange={open => setPresentation(value => toggleAnalysis(value, open))} paused={paused}
            local={state.runtime?.api_provider === 'local'} />}
        <div data-slot="mes-answer-presentation" className={message && readExecutionTrace(message).length ? '[&_[data-slot$=assistant-message-indicator]]:hidden' : undefined}>{children}</div>
    </div>;
}
