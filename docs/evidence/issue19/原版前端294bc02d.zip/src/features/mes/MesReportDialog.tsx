import { MesSavedReportChart } from './MesReportChart';
import { isChartEvidenceNotice } from '@/chat/report';
import { planSavedCharts } from '@/chat/chart-planner';
import { Download } from 'lucide-react';
import { reportText, sourceText, warningKey } from '@/chat/report';
import { useMesUi } from '@/chat/mes-ui-context';
import type { Evidence, Report, ReportCard } from '@/chat/types';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useDialogFocus } from '@/features/common/useDialogFocus';
import { usePortalContainer } from '@/features/common/UiContext';

export function MesWarningList({items}: {items?: string[]}) {
    const warnings = [...new Map((items || []).map(item => [warningKey(item), item])).values()];
    return warnings.length ? <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">{warnings.map(item => <li key={warningKey(item)}>{item}</li>)}</ul> : null;
}

export function MesExportButton({requestId}: {requestId: string}) {
    const {state, actions} = useMesUi();
    const busy = state.exporting.includes(requestId);
    return <Button type="button" variant="ghost" size="sm" disabled={busy || state.expired} aria-busy={busy} data-action="report-export" data-export-request-id={requestId} onClick={() => void actions.downloadReport(requestId)}><Download aria-hidden="true" />匯出 Excel</Button>;
}

export function MesReportMetrics({card, variant = 'table'}: {card: ReportCard; variant?: 'table' | 'summary'}) {
    if (variant === 'summary') {
        const highlights = card.display.highlights;
        if (!highlights.length) return null;
        return <section className="space-y-2" data-slot="mes-report-highlights" aria-label={`${card.title || '查詢'}重點`}>
            <h3 className="text-sm font-medium">{card.title || '查詢'} · 重點</h3>
            <dl className="grid grid-cols-1 gap-3 sm:grid-cols-2">{highlights.map(item => <div key={item.key} className="min-w-0 space-y-1">
                <dt className="text-xs text-muted-foreground">{item.label}</dt>
                <dd className="text-sm font-medium tabular-nums">{item.value}{item.unit && ` ${item.unit}`}</dd>
                {item.detail && <dd className="break-words text-xs text-muted-foreground">{item.detail}</dd>}
            </div>)}</dl>
        </section>;
    }
    const metrics = card.display.metrics;
    if (!metrics.length) return null;
    return <Table aria-label={`${card.title || 'MES 查詢'}指標`}><TableHeader><TableRow><TableHead scope="col">項目</TableHead><TableHead scope="col">數值</TableHead><TableHead scope="col">說明</TableHead></TableRow></TableHeader><TableBody>{metrics.map(metric =>
        <TableRow key={metric.key} data-metric-key={metric.key}><TableCell>{metric.label}</TableCell><TableCell className="font-mono tabular-nums">{metric.value}{metric.unit && ` ${metric.unit}`}</TableCell><TableCell className="whitespace-normal text-muted-foreground">{metric.detail || '—'}</TableCell></TableRow>
    )}</TableBody></Table>;
}

export function MesReportFormula({card}: {card: ReportCard}) {
    if (!card.formula) return null;
    return <div className="space-y-1 text-sm"><h4 className="font-medium">{card.formula.label || '計算方式'}</h4>{card.formula.expression && <p className="break-words font-mono">{card.formula.expression}</p>}{card.formula.substitution && <p>{card.formula.substitution}</p>}</div>;
}

export function MesEvidence({items}: {items?: Evidence[]}) {
    if (!items?.length) return <p className="text-sm text-muted-foreground">這份紀錄沒有保存查詢依據</p>;
    return <div className="space-y-4">{items.map((item, index) => <section key={index} className="space-y-2"><h3 className="text-sm font-medium">{item.tool_label || item.tool_name || 'MES 查詢'}</h3><dl className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-4"><dt className="text-muted-foreground">參數</dt><dd className="break-all font-mono sm:col-span-3">{JSON.stringify(item.arguments || {})}</dd><dt className="text-muted-foreground">期間</dt><dd className="sm:col-span-3">{[item.query_start, item.query_end].filter(Boolean).join(' ～ ') || '未提供'}</dd><dt className="text-muted-foreground">資料來源</dt><dd className="break-words sm:col-span-3">{item.data_source || '未提供'}</dd><dt className="text-muted-foreground">計算方式</dt><dd className="break-words sm:col-span-3">{item.calculation || '未提供'}</dd><dt className="text-muted-foreground">資料狀態</dt><dd className="sm:col-span-3">{item.status || '未提供'}</dd></dl></section>)}</div>;
}

export function MesReportDetails({card, report}: {card: ReportCard; report: Report}) {
    const columns = card.display.columns, rows = card.detail?.rows || [];
    return <section className="min-w-0 space-y-3" data-card-id={card.id}><h3 className="text-sm font-medium">{card.title || '查詢資料'}</h3><p className="text-xs text-muted-foreground">{card.source_label || sourceText(card)}{card.data_time && ` · 資料日期 ${card.data_time}`}</p><MesSavedReportChart card={card} report={report} /><MesReportMetrics card={card} />{columns.length && rows.length ? <div role="region" aria-label="報告明細，可左右捲動" tabIndex={0}><Table><TableHeader><TableRow>{columns.map(column => <TableHead key={column.key} scope="col">{column.label}</TableHead>)}</TableRow></TableHeader><TableBody>{rows.map((row, index) => <TableRow key={index}>{columns.map(column => <TableCell key={column.key}>{reportText(row[column.key])}</TableCell>)}</TableRow>)}</TableBody></Table></div> : <p className="text-sm text-muted-foreground">這次查詢沒有保存額外的明細列</p>}<MesReportFormula card={card} /></section>;
}

/** 明細與依據僅讀取控制器保存的報告，開啟不會建立新的模型回合。 */
export function MesReportDialog() {
    const {state, actions} = useMesUi();
    const portal = usePortalContainer(), focus = useDialogFocus(), dialog = state.reportDialog;
    const card = dialog?.report.cards.find(item => item && item.id === dialog.cardId);
    const cards = card ? [card] : (dialog?.report.cards || []).filter(item => item && typeof item === 'object');
    const message = state.displayMessages.find(item => item.role === 'assistant' && item.request_id === dialog?.requestId);
    const evidence = card?.evidence?.length ? card.evidence : dialog?.report.evidence;
    const warnings = [
        ...(message?.warnings || []),
        ...(dialog?.report.warnings || []),
        ...cards.flatMap(item => [...(item.notes || []), ...(item.warnings || [])]),
        ...(evidence || []).flatMap(item => item.warnings || []),
        ...cards.flatMap(item => {const plan = planSavedCharts(item); return [...plan.recommended, ...plan.alternatives].flatMap(panel => panel.notices.filter(isChartEvidenceNotice));}),
    ];
    return <Dialog open={!!dialog} onOpenChange={open => {if (!open) actions.closeReport();}}>
        <DialogContent portalContainer={portal} {...focus} className="max-h-svh overflow-y-auto sm:max-w-4xl" data-slot="mes-report-dialog">
            <DialogHeader>
                <DialogTitle>{card?.title || '查詢報告'} · {dialog?.view === 'detail' ? '查看明細' : '查看依據'}</DialogTitle>
                <DialogDescription>{card ? `${card.source_label || sourceText(card)}${card.data_time ? ` · 資料日期 ${card.data_time}` : ''}` : '依這次查詢已保存的資料'}</DialogDescription>
            </DialogHeader>
            <div className="min-w-0 space-y-5">
                {dialog?.view === 'detail'
                    ? cards.length ? cards.filter(item => item.display.answer).map(item => <MesReportDetails card={item} report={dialog!.report} key={item.id} />) : <p className="text-sm text-muted-foreground">這次查詢沒有保存額外的明細列</p>
                    : <>
                        <MesEvidence items={evidence} />
                        {cards.filter(item => !item.display.answer).map(item => <MesReportDetails card={item} report={dialog!.report} key={item.id} />)}
                        {!!warnings.length && <section className="space-y-2" data-slot="mes-evidence-limitations">
                            <h3 className="text-sm font-medium">資料口徑與限制</h3>
                            <MesWarningList items={warnings} />
                        </section>}
                    </>}
            </div>
            <DialogFooter>
                {dialog?.report.report_version === 'mes-report-v1' && <MesExportButton requestId={dialog.requestId} />}
                <Button type="button" variant="outline" onClick={actions.closeReport} data-action="report-close">關閉</Button>
            </DialogFooter>
        </DialogContent>
    </Dialog>;
}
