import { useEffect, useId, useRef, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Line, LineChart, ReferenceLine, Scatter, ScatterChart, XAxis, YAxis } from 'recharts';
import { ChevronDown } from 'lucide-react';
import { chartSelection, chartTimeAxis, findChartSelection, formatChartTimeTick, planBoundCharts, planSavedCharts, type ChartSpec } from '@/chat/chart-planner';
import { isChartEvidenceNotice } from '@/chat/report';
import { reportText, sourceText } from '@/chat/report';
import { savedSemanticMetricAvailable } from '@/chat/semantic-availability';
import type { AnswerPresentation, Report, ReportCard, ReportViewSelection } from '@/chat/types';
import {useMesUi} from '@/chat/mes-ui-context';
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const colors = ['var(--chart-2)', 'var(--chart-1)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)'];
const markLabels: Record<ChartSpec['mark'], string> = {bar: '長條圖', line: '折線圖', point: '點圖', scatter: '散佈圖', heatmap: '熱圖', stacked: '堆疊圖', value: '數值重點', bullet: '目標達成圖'};
const compactNumber = (value: number) => new Intl.NumberFormat('zh-TW', {notation: 'compact', maximumFractionDigits: 1}).format(value);
const numericDomain = ([min, max]: readonly [number, number]): [number, number] => [Math.min(0, min), Math.max(0, max) || 1];
const fieldLabel = (data: ChartSpec, key: string) => data.columns.find(column => column.name === key)?.label || key;
const fieldUnit = (data: ChartSpec, key: string) => data.columns.find(column => column.name === key)?.unit || '';
const metricText = (data: ChartSpec, key: string) => `${fieldLabel(data, key)}${fieldUnit(data, key) ? `（${fieldUnit(data, key)}）` : ''}`;

/** 熱度只影響顏色；格子直接顯示保存原值，缺少交叉列保持未知。 */
function SavedHeatmap({data}: {data: ChartSpec}) {
    const {x, y, series} = data.encoding, metric = series[0];
    const categories = (key: string) => [...new Map(data.points.map(point => [JSON.stringify(point.dimensions[key]), point.dimensions[key]])).entries()];
    const xs = categories(x), ys = categories(y);
    const known = data.points.map(point => point.values[metric]).filter((value): value is number => value !== null && Number.isFinite(value));
    const min = Math.min(...known), max = Math.max(...known);
    return <div className="space-y-2" data-slot="mes-report-heatmap">
        <p className="text-xs text-muted-foreground">{fieldLabel(data, y)} × {fieldLabel(data, x)} · {metricText(data, metric)} · 色彩由淺至深：{reportText(min)} ～ {reportText(max)}</p>
        <Table aria-label={`${data.title}熱圖`}><TableHeader><TableRow><TableHead scope="col">{fieldLabel(data, y)}／{fieldLabel(data, x)}</TableHead>{xs.map(([key, value]) => <TableHead key={key} scope="col">{reportText(value)}</TableHead>)}</TableRow></TableHeader><TableBody>
            {ys.map(([yKey, yValue]) => <TableRow key={yKey}><TableHead scope="row">{reportText(yValue)}</TableHead>{xs.map(([xKey]) => {
                const point = data.points.find(item => JSON.stringify(item.dimensions[x]) === xKey && JSON.stringify(item.dimensions[y]) === yKey);
                const value = point?.values[metric] ?? null;
                const tone = value === null ? undefined : max === min ? 2 : Math.min(3, Math.floor((value - min) / (max - min) * 4));
                return <TableCell key={xKey} data-tone={tone} className={value === null ? 'bg-muted text-muted-foreground text-center' : 'mes-report-heat-cell text-center font-mono tabular-nums'}>{!point ? '未顯示' : value === null ? '未知' : reportText(value)}</TableCell>;
            })}</TableRow>)}
        </TableBody></Table>
        <p className="text-xs text-muted-foreground">「未知」表示該列缺值；「未顯示」表示本圖未含該交叉列，兩者皆不能視為零。</p>
    </div>;
}

function SavedChartPanel({card, data}: {card: ReportCard; data: ChartSpec}) {
    const id = useId(), [valuesOpen, setValuesOpen] = useState(false);
    const plot = useRef<HTMLDivElement>(null), [barSize, setBarSize] = useState<number>();
    const [edgePadding, setEdgePadding] = useState(0);
    useEffect(() => {
        if (!plot.current) return;
        const size = parseFloat(getComputedStyle(plot.current).getPropertyValue('--mes-chart-bar-size'));
        if (Number.isFinite(size) && size > 0) setBarSize(size);
        const padding = parseFloat(getComputedStyle(plot.current).getPropertyValue('--mes-chart-edge-padding'));
        if (Number.isFinite(padding) && padding > 0) setEdgePadding(padding);
    }, []);
    // 固定內部鍵避免保存欄位名稱成為 Recharts 路徑或 CSS 變數。
    const keys = data.mark === 'scatter' ? [data.encoding.x, data.encoding.y] : data.encoding.series;
    const series = keys.map((key, index) => ({key, label: fieldLabel(data, key), dataKey: `series${index}`, color: colors[index % colors.length]}));
    const timeAxis = chartTimeAxis(data);
    const points: Record<string, unknown>[] = data.points.map((point, index) => ({label: point.label, timePosition: timeAxis?.positions[index], ...Object.fromEntries(series.map(item => [item.dataKey, point.values[item.key]]))}));
    const config = Object.fromEntries(series.map(item => [item.dataKey, {label: item.label, color: item.color}]));
    const targetKey = data.mark === 'bullet' ? data.columns.find(column => column.name === data.encoding.series[0])?.target_field : undefined;
    const target = targetKey ? data.points[0]?.values[targetKey] : undefined;
    const targetValue = typeof target === 'number' && Number.isFinite(target) && target > 0 ? target : undefined;
    const targetDomain: [number, number] | undefined = targetValue === undefined ? undefined : [0, Math.max(targetValue, ...data.points.map(point => point.values[data.encoding.series[0]] || 0))];
    const period = card.query_period as {production_from?: string; production_to?: string} | undefined;
    const tooltip = <ChartTooltip cursor={false} content={<ChartTooltipContent labelFormatter={(_, payload) => payload?.[0]?.payload?.label} formatter={(value, name) => <div className="flex flex-1 items-center justify-between gap-3"><span className="text-muted-foreground">{name}</span><span className="font-mono tabular-nums">{reportText(value)}{data.unit && ` ${data.unit}`}</span></div>} />} />;
    const legend = series.length > 1 ? <ChartLegend itemSorter={null} content={<ChartLegendContent className="flex-wrap gap-2" />} /> : null;
    return <figure className="min-w-0 space-y-2" data-slot="mes-report-chart" data-kind={card.kind} data-chart-kind={data.mark} data-axis-kind={timeAxis ? 'time' : data.mark === 'scatter' ? 'numeric' : 'category'} aria-labelledby={id}>
        <figcaption className="space-y-1"><h3 id={id} className="text-sm font-medium">{data.title}</h3><p className="break-words text-xs text-muted-foreground">{card.source_label || sourceText(card)}{card.data_time && ` · 資料日期 ${card.data_time}`}{period?.production_from && ` · 生產日 ${period.production_from} ～ ${period.production_to || period.production_from}`}</p></figcaption>
        <p className="text-xs text-muted-foreground" data-slot="mes-chart-reason">{data.reason}</p>
        {data.mark === 'value' ? <dl className="grid gap-2 text-sm" data-slot="mes-report-values">{data.points.map(point => <div key={point.rowIndex} className="space-y-2"><dt className="text-muted-foreground">{point.label}</dt><dd><dl className="grid gap-2">{series.map(item => <div key={item.key} className="flex flex-wrap items-baseline justify-between gap-2"><dt>{item.label}</dt><dd className="font-mono tabular-nums">{reportText(point.values[item.key])}{fieldUnit(data, item.key) && ` ${fieldUnit(data, item.key)}`}</dd></div>)}</dl></dd></div>)}</dl> : data.mark === 'heatmap' ? <SavedHeatmap data={data} /> : <>
            <p className="text-xs text-muted-foreground">{data.mark === 'scatter' ? `橫軸：${metricText(data, data.encoding.x)} · 縱軸：${metricText(data, data.encoding.y)}` : `${data.measure}${data.unit ? `（${data.unit}）` : ''}${timeAxis ? ` · ${fieldLabel(data, data.encoding.x)}${timeAxis.grain === 'instant' ? '（UTC）' : ''}` : ''}`}</p>
            <ChartContainer ref={plot} className={data.points.length > 4 || series.length > 1 ? 'mes-report-chart-plot mes-report-chart-plot-tall w-full aspect-auto' : 'mes-report-chart-plot w-full aspect-auto'} config={config}>
                {data.mark === 'scatter' ? <ScatterChart accessibilityLayer margin={{left: 0, right: edgePadding, top: edgePadding, bottom: 0}}>
                    <CartesianGrid stroke="var(--border)" />
                    <XAxis dataKey="series0" name={series[0].label} type="number" tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} domain={numericDomain} tickFormatter={compactNumber} />
                    <YAxis dataKey="series1" name={series[1].label} type="number" tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} width="auto" domain={numericDomain} tickFormatter={compactNumber} />
                    <ChartTooltip cursor={false} content={({active, payload}) => active && payload?.[0] ? <div className="rounded-lg border border-border bg-background p-3 text-xs shadow-xl"><p className="font-medium">{payload[0].payload.label}</p>{series.map(item => <p key={item.key}>{metricText(data, item.key)}：{reportText(payload[0].payload[item.dataKey])}</p>)}</div> : null} />
                    <Scatter data={points.filter(point => point.series0 != null && point.series1 != null)} fill="var(--chart-2)" isAnimationActive={false} />
                </ScatterChart> : data.mark === 'line' || data.mark === 'point' ? <LineChart accessibilityLayer data={points} margin={{left: 0, right: 0, top: 0, bottom: 0}}>
                    <CartesianGrid vertical={false} stroke="var(--border)" />
                    {timeAxis ? <XAxis dataKey="timePosition" type="number" scale="linear" domain={timeAxis.domain} ticks={timeAxis.positions.length <= 5 ? timeAxis.positions : undefined} tickCount={5} allowDecimals={false} tickFormatter={value => formatChartTimeTick(value, timeAxis.grain)} tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} minTickGap={edgePadding} padding={{left: edgePadding, right: edgePadding}} /> : <XAxis dataKey="label" tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} interval="preserveStartEnd" padding={{left: edgePadding, right: edgePadding}} />}
                    <YAxis type="number" tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} width="auto" padding={{top: edgePadding, bottom: 0}} domain={numericDomain} tickFormatter={compactNumber} />
                    {tooltip}{legend}
                    {series.map((item, index) => <Line key={item.key} type="linear" dataKey={item.dataKey} name={item.label} stroke={data.mark === 'point' ? 'none' : `var(--color-${item.dataKey})`} strokeWidth="var(--mes-chart-line-width)" strokeDasharray={index === 1 ? 'var(--mes-chart-line-dash)' : undefined} connectNulls={false} dot={{fill: `var(--color-${item.dataKey})`, stroke: `var(--color-${item.dataKey})`}} isAnimationActive={false} />)}
                </LineChart> : <BarChart accessibilityLayer layout="vertical" data={points} margin={{left: 0, right: 0, top: 0, bottom: 0}}>
                    <CartesianGrid horizontal={false} stroke="var(--border)" />
                    <XAxis type="number" tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} domain={targetDomain || numericDomain} tickFormatter={compactNumber} />
                    <YAxis dataKey="label" type="category" tick={{fill: 'var(--muted-foreground)'}} tickLine={false} axisLine={false} width="auto" tickFormatter={value => String(value).length > 11 ? String(value).slice(0, 10) + '…' : String(value)} interval={0} />
                    {tooltip}{legend}
                    {series.map(item => <Bar key={item.key} dataKey={item.dataKey} name={item.label} fill={`var(--color-${item.dataKey})`} stackId={data.mark === 'stacked' ? 'saved-components' : undefined} maxBarSize={barSize} isAnimationActive={false} />)}
                    {targetValue !== undefined && <ReferenceLine x={targetValue} stroke="var(--chart-4)" strokeWidth="var(--mes-chart-line-width)" label={{value: `${fieldLabel(data, targetKey!)} ${reportText(targetValue)}`, position: 'insideTopRight', fill: 'var(--foreground)'}} />}
                </BarChart>}
            </ChartContainer>
        </>}
        {data.mark === 'bullet' && targetValue !== undefined && <p className="text-sm font-mono tabular-nums">{metricText(data, data.encoding.series[0])} {reportText(data.points[0].values[data.encoding.series[0]])} · {metricText(data, targetKey!)} {reportText(targetValue)}</p>}
        {data.mark !== 'value' && <Collapsible open={valuesOpen} onOpenChange={setValuesOpen}><CollapsibleTrigger asChild><Button type="button" variant="ghost" size="sm" aria-label={`查看${data.title}圖表數值`}>圖表數值<ChevronDown className={valuesOpen ? 'size-4 rotate-180' : 'size-4'} aria-hidden="true" /></Button></CollapsibleTrigger><CollapsibleContent><Table aria-label={`${data.title}圖表數值`}><TableHeader><TableRow><TableHead scope="col">項目</TableHead>{series.map(item => <TableHead key={item.key} scope="col">{metricText(data, item.key)}</TableHead>)}</TableRow></TableHeader><TableBody>{data.points.map((point, index) => <TableRow key={index}><TableCell className="whitespace-normal break-words">{point.label}</TableCell>{series.map(item => <TableCell key={item.key} className="font-mono tabular-nums">{point.values[item.key] == null ? '未知' : reportText(point.values[item.key])}</TableCell>)}</TableRow>)}</TableBody></Table></CollapsibleContent></Collapsible>}
        {data.notices.filter(notice => !isChartEvidenceNotice(notice)).map(notice => <p key={notice} className="text-xs text-muted-foreground">{notice}</p>)}
    </figure>;
}

interface MesReportChartProps {
    card: ReportCard;
    presentation?: AnswerPresentation;
    selection?: ReportViewSelection | null;
    saving?: boolean;
    editable?: boolean;
    onSelectionChange?: (selection: ReportViewSelection | null) => void;
}

/** 主回答、直接呈現與明細共用保存偏好及寫入入口，不另存本地選擇。 */
export function MesSavedReportChart({card, report, presentation = report.answer_presentation || undefined}: {card: ReportCard; report: Report; presentation?: AnswerPresentation}) {
    const {state, actions} = useMesUi();
    return <MesReportChart card={card} presentation={presentation} selection={report.view_preferences?.selections.find(item => item.card_id === card.id)}
        saving={state.presentationSaving?.includes(report.request_id)} editable={!state.expired && !state.conversation?.is_archived && !!report.view_preferences_editable}
        onSelectionChange={selection => {void actions.savePresentation(report.request_id, card.id, selection);}} />;
}

/** 推薦與切換皆讀取同一保存快照；保存交由唯一 Controller，不建立模型請求。 */
export function MesReportChart({card, presentation, selection, saving = false, editable = true, onSelectionChange}: MesReportChartProps) {
    const plan = presentation ? planBoundCharts(card, presentation) : planSavedCharts(card);
    const [local, setLocal] = useState<{cardId: string; selection: ReportViewSelection | null}>({cardId: card.id, selection: null});
    const selected = onSelectionChange || selection !== undefined ? selection : local.cardId === card.id ? local.selection : null;
    const candidates = [...new Map([...plan.recommended, ...plan.alternatives].map(spec => [JSON.stringify(chartSelection(spec)), spec])).values()];
    const bound = presentation && presentation.mode !== 'auto';
    const table = bound ? card.binding_table : card.detail;
    const columns = table?.columns || [];
    const rows: Record<string, unknown>[] = table?.rows || [];
    const canShowTable = card.chart_contract !== 'unavailable' && columns.length > 0 && rows.length > 0;
    const chosen = selected && selected.mark !== 'table' ? findChartSelection(candidates, selected) : undefined;
    const selectedTable = selected?.mark === 'table' && selected.metrics.length === 0 && canShowTable;
    const invalidSelection = !!selected && !chosen && !selectedTable;
    const panels = chosen ? [chosen] : plan.recommended;
    const showTable = selectedTable || !chosen && (presentation?.mode === 'table' || plan.fallback === 'table' || !!bound && !panels.length && canShowTable);
    const reason = presentation?.mode === 'table' && !canShowTable ? card.binding_reason || '原回答沒有可核對的保存引用，無法直接轉換為表格，請查看原始報表。' : plan.reason || card.chart_reason;
    const tableValue = (row: Record<string, unknown>, key: string) => {
        const metadata = card.chart_input?.columns || [];
        const column = !bound && metadata.find(item => item.name === key && item.role !== 'dimension');
        return row[key] == null || column && !savedSemanticMetricAvailable(column, row, metadata) ? '未知' : reportText(row[key]);
    };
    const change = (value: string) => {
        const candidate = candidates.find(spec => spec.id === value);
        const next = value === 'table' ? {mark: 'table' as const, metrics: []} : candidate ? chartSelection(candidate) : null;
        if (onSelectionChange) onSelectionChange(next);
        else setLocal({cardId: card.id, selection: next});
    };
    if (!panels.length && !canShowTable && !invalidSelection) return reason ? <p role="status" className="text-sm text-muted-foreground">{reason}</p> : null;
    if (!panels.length && !showTable && !invalidSelection) return reason ? <p role="status" className="text-sm text-muted-foreground">{reason}</p> : null;
    return <div className="min-w-0 space-y-5">
        {(candidates.length > 0 || canShowTable) && <Select value={selectedTable ? 'table' : chosen?.id || 'auto'} disabled={saving || !!onSelectionChange && !editable} onValueChange={change}><SelectTrigger size="sm" className="max-w-full" aria-label="圖表呈現方式"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="auto">自動推薦</SelectItem>{canShowTable && <SelectItem value="table">保存值表格</SelectItem>}{candidates.map(candidate => <SelectItem key={candidate.id} value={candidate.id}>{markLabels[candidate.mark]} · {candidate.measure}</SelectItem>)}</SelectContent></Select>}
        {saving && <p role="status" className="text-xs text-muted-foreground">正在保存呈現方式…</p>}
        {invalidSelection && <p role="status" className="text-sm text-muted-foreground">已保存的呈現方式不適用於這份資料，已回到自動推薦。</p>}
        {showTable ? <div className="min-w-0 space-y-2" data-slot="mes-report-auto-table">
            {reason && <p role="status" className="text-sm text-muted-foreground">{reason}</p>}
            {canShowTable ? <Table aria-label={`${card.title || '保存結果'}原值表格`} data-slot={bound ? 'mes-binding-table' : undefined}><TableHeader><TableRow>{columns.map(column => <TableHead key={column.key}>{column.label || column.key}</TableHead>)}</TableRow></TableHeader><TableBody>{rows.map((row, index) => <TableRow key={index}>{columns.map(column => <TableCell key={column.key}>{tableValue(row, column.key)}</TableCell>)}</TableRow>)}</TableBody></Table> : <p role="status" className="text-sm text-muted-foreground">{card.binding_reason || card.chart_reason || '沒有可核對的保存值表格。'}</p>}
        </div> : panels.map(panel => <SavedChartPanel key={panel.id} card={card} data={panel} />)}
    </div>;
}
