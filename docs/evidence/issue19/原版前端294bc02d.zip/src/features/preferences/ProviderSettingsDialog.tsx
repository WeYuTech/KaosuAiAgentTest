import {useId, type ChangeEvent, type ReactNode} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import {Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle} from '@/components/ui/dialog';
import {Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue} from '@/components/ui/select';
import type {ProviderValues, SettingsField} from '@/chat/settings';
import {usePortalContainer} from '@/features/common/UiContext';
import {useDialogFocus} from '@/features/common/useDialogFocus';
import {useProviderSettings} from './provider-settings';
import {MODEL_OPTIONS, MODEL_PRICE_CHECKED_AT, MODEL_PRICING_URL, modelOption, modelPriceLabel} from './model-catalog';

function SettingsFieldRow({label, locked = false, children}: {label: string; locked?: boolean; children: ReactNode}) {
    return <div className="space-y-2"><div className="flex items-center justify-between gap-2"><span className="text-sm font-medium">{label}</span>{locked && <span className="text-xs text-muted-foreground">環境變數控制</span>}</div>{children}</div>;
}
function TextSetting({label, value, onChange, disabled, locked, placeholder}: {
    label: string; value: string; onChange(value: string): void; disabled: boolean; locked: boolean; placeholder?: string;
}) {
    const id = useId();
    return <div className="space-y-2"><div className="flex items-center justify-between gap-2"><Label htmlFor={id}>{label}</Label>{locked && <span className="text-xs text-muted-foreground">環境變數控制</span>}</div><Input id={id} value={value} onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)} disabled={disabled || locked} placeholder={placeholder} autoComplete="off" /></div>;
}
function ChoiceSetting({label, value, values, onChange, disabled, locked, renderChoice, descriptionId, choiceHeading}: {
    label: string; value: string; values: readonly string[]; onChange(value: string): void; disabled: boolean; locked: boolean;
    renderChoice?(value: string): ReactNode; descriptionId?: string; choiceHeading?: string;
}) {
    const portal = usePortalContainer();
    // 既有自訂模型或環境設定仍可顯示，不因選單清單不同而遺失原值。
    const choices = value && !values.includes(value) ? [...values, value] : values;
    return <SettingsFieldRow label={label} locked={locked}><Select value={value} onValueChange={onChange} disabled={disabled || locked}><SelectTrigger aria-label={label} aria-describedby={descriptionId} className="w-full"><SelectValue placeholder="請選擇">{value || undefined}</SelectValue></SelectTrigger><SelectContent portalContainer={portal} position={renderChoice ? 'popper' : 'item-aligned'} className={renderChoice ? 'w-(--radix-select-trigger-width)' : undefined}><SelectGroup>{choiceHeading && <SelectLabel>{choiceHeading}</SelectLabel>}{choices.map(choice => <SelectItem key={choice} value={choice} textValue={choice}>{renderChoice ? renderChoice(choice) : choice}</SelectItem>)}</SelectGroup></SelectContent></Select></SettingsFieldRow>;
}
function ModelSetting(props: {label: string; value: string; onChange(value: string): void; disabled: boolean; locked: boolean}) {
    const descriptionId = useId();
    return <div className="space-y-2">
        <ChoiceSetting {...props} descriptionId={descriptionId} choiceHeading="標準費率 · 美元／每百萬 Token" values={MODEL_OPTIONS.map(model => model.id)} renderChoice={id => <span className="flex min-w-0 flex-col gap-1 text-left"><span className="font-medium">{id}</span><span className="text-xs text-muted-foreground">{modelOption(id)?.description || '既有自訂模型'} · {modelPriceLabel(id)}</span></span>} />
        <p id={descriptionId} className="text-xs text-muted-foreground">每百萬 Token（美元）· {modelPriceLabel(props.value)}</p>
    </div>;
}
function EffortSetting({agent, ...props}: {
    label: string; value: string; onChange(value: string): void; disabled: boolean; locked: boolean; agent?: boolean;
}) {
    const values = agent ? ['none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] : ['none', 'low', 'medium', 'high', 'xhigh', 'max'];
    return <ChoiceSetting {...props} values={values} />;
}

/** 使用同一設定 Dialog 與基礎元件；不讀回現有秘密或探測付費 API。 */
export function ProviderSettingsDialog() {
    const preferences = useProviderSettings();
    const {section, settings, draft, setDraft, loading, saving, blocked, expired} = preferences;
    const portal = usePortalContainer(), focus = useDialogFocus();
    const disabled = loading || saving || expired;
    const local = draft?.api.provider === 'local';
    const locked = (field: SettingsField) => !!settings?.locked_fields.includes(field);
    function updateApi(name: 'model' | 'reasoning_effort', value: string) {setDraft(previous => previous && {...previous, api: {...previous.api, [name]: value}});}
    function updateAgent(name: keyof ProviderValues['agent'], value: string) {setDraft(previous => previous && {...previous, agent: {...previous.agent, [name]: value}});}
    return <Dialog open={section !== null} onOpenChange={open => {if (!open) preferences.closeSettings();}}>
        <DialogContent portalContainer={portal} {...focus} className="max-h-(--aui-settings-max-height) overflow-y-auto" data-slot="mes-provider-settings">
            <DialogHeader><DialogTitle>{section === 'agent' ? 'Agent API 設定' : 'API 設定'}</DialogTitle><DialogDescription>儲存後於新聊天生效</DialogDescription></DialogHeader>
            {loading && <p role="status" className="text-sm text-muted-foreground">讀取設定中…</p>}
            {settings && draft && <div className="space-y-4">
                <SettingsFieldRow label="API 來源" locked={locked('api.provider')}><Select value={draft.api.provider} disabled={disabled || locked('api.provider')} onValueChange={value => setDraft(previous => previous && {...previous, api: {...previous.api, provider: value as 'cloud' | 'local'}, mode: value === 'local' ? 'API' : previous.mode})}><SelectTrigger className="w-full" aria-label="API 來源"><SelectValue /></SelectTrigger><SelectContent portalContainer={portal}><SelectItem value="cloud">雲端 API</SelectItem><SelectItem value="local" disabled={locked('mode') && draft.mode === 'AGENT'}>本地 API</SelectItem></SelectContent></Select></SettingsFieldRow>
                <SettingsFieldRow label="預設執行模式" locked={locked('mode')}><Select value={draft.mode} disabled={disabled || locked('mode')} onValueChange={value => setDraft(previous => previous && {...previous, mode: value as ProviderValues['mode']})}><SelectTrigger className="w-full" aria-label="預設執行模式"><SelectValue /></SelectTrigger><SelectContent portalContainer={portal}><SelectItem value="API">API</SelectItem><SelectItem value="AGENT" disabled={local}>AGENT</SelectItem></SelectContent></Select></SettingsFieldRow>
                {local ? <>
                    <TextSetting label="本地 API 網址" value={draft.local.base_url} onChange={value => setDraft(previous => previous && {...previous, local: {...previous.local, base_url: value}})} disabled={disabled} locked={locked('local.base_url')} placeholder="http://127.0.0.1:8081/v1" />
                    <TextSetting label="本地模型" value={draft.local.model} onChange={value => setDraft(previous => previous && {...previous, local: {...previous.local, model: value}})} disabled={disabled} locked={locked('local.model')} placeholder="留空使用服務唯一已載入的模型" />
                    <TextSetting label="本地上下文 Token 上限" value={String(draft.local.context_tokens)} onChange={value => setDraft(previous => previous && {...previous, local: {...previous.local, context_tokens: Number(value)}})} disabled={disabled} locked={locked('local.context_tokens')} />
                    <p className="text-xs text-muted-foreground">使用本地模型，僅支援 API 模式。</p>
                </> : section === 'api' ? <>
                    <ModelSetting label="API 模型" value={draft.api.model} onChange={value => updateApi('model', value)} disabled={disabled} locked={locked('api.model')} />
                    <EffortSetting label="API 推理強度" value={draft.api.reasoning_effort} onChange={value => updateApi('reasoning_effort', value)} disabled={disabled} locked={locked('api.reasoning_effort')} />
                </> : <>
                    <TextSetting label="Agent ID" value={draft.agent.id} onChange={value => updateAgent('id', value)} disabled={disabled} locked={locked('agent.id')} placeholder="agent_…" />
                    <TextSetting label="Project ID" value={draft.agent.project_id} onChange={value => updateAgent('project_id', value)} disabled={disabled} locked={locked('agent.project_id')} placeholder="proj_…" />
                    <ModelSetting label="Agent 模型" value={draft.agent.model} onChange={value => updateAgent('model', value)} disabled={disabled} locked={locked('agent.model')} />
                    <EffortSetting label="Agent 推理強度" value={draft.agent.reasoning_effort} onChange={value => updateAgent('reasoning_effort', value)} disabled={disabled} locked={locked('agent.reasoning_effort')} agent />
                </>}
                {!local && <p className="text-xs text-muted-foreground"><a className="underline underline-offset-4" href={MODEL_PRICING_URL} target="_blank" rel="noreferrer">官方費率</a>（{MODEL_PRICE_CHECKED_AT}），實際費用依帳單為準。</p>}
                <p className="text-xs text-muted-foreground">目前：{settings.effective.api.provider === 'local' ? '本地 API' : '雲端 API'} · {settings.effective.mode} · {settings.effective.api.provider === 'local' ? settings.effective.local?.model || '服務已載入模型' : settings.effective.mode === 'API' ? settings.effective.api.model : settings.effective.agent.model}{settings.restart_required ? ' · 待重啟' : ''}</p>
            </div>}
            {blocked && <p role="status" className="text-sm text-muted-foreground">{expired ? '登入已逾時，請重新登入 MES' : '回合尚未結束，暫時無法儲存。'}</p>}
            {preferences.error && <p role="alert" className="text-sm text-destructive">{preferences.error}</p>}
            {preferences.notice && <p role="status" className="text-sm text-muted-foreground">{preferences.notice}</p>}
            <DialogFooter><Button variant="outline" disabled={loading || saving || expired} onClick={() => void preferences.reload()}>重新讀取</Button><Button variant="outline" onClick={preferences.closeSettings}>關閉</Button><Button disabled={disabled || blocked || !settings || !draft} onClick={() => void preferences.save()}>{saving ? '儲存中…' : '儲存設定'}</Button></DialogFooter>
        </DialogContent>
    </Dialog>;
}
