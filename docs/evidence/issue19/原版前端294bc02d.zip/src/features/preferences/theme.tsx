import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useState } from 'react';
import type { ReactNode } from 'react';

export type ChatTheme = 'light' | 'dark' | 'navy';
export type ThemeStorage = Pick<Storage, 'getItem' | 'setItem'>;

export const CHAT_THEMES = [
    { value: 'light', label: '明亮' },
    { value: 'dark', label: '黑暗' },
    { value: 'navy', label: '深藍' },
] as const satisfies ReadonlyArray<{ value: ChatTheme; label: string }>;

export function isChatTheme(value: unknown): value is ChatTheme {
    return value === 'light' || value === 'dark' || value === 'navy';
}

/** 設定按專案與帳號隔離；不使用共用的匿名儲存鍵。 */
export function themeStorageKey(projectKey: string, accountNo: string): string | null {
    const project = projectKey.trim();
    const account = accountNo.trim().toUpperCase();
    if (!project || !account) return null;
    return `MES_AI_THEME:${encodeURIComponent(project)}:${encodeURIComponent(account)}`;
}

export function readStoredTheme(storage: ThemeStorage | null, key: string | null): ChatTheme {
    if (!storage || !key) return 'light';
    try {
        const value = storage.getItem(key);
        return isChatTheme(value) ? value : 'light';
    } catch { return 'light'; }
}

/** 僅寫入主題值；瀏覽器禁止儲存時仍可在本次頁面使用所選主題。 */
export function persistTheme(storage: ThemeStorage | null, key: string | null, theme: ChatTheme): boolean {
    if (!storage || !key || !isChatTheme(theme)) return false;
    try { storage.setItem(key, theme); return true; }
    catch { return false; }
}

function browserStorage(): ThemeStorage | null {
    try { return typeof window === 'undefined' ? null : window.localStorage; }
    catch { return null; }
}

interface ChatThemeContextValue {
    theme: ChatTheme;
    setTheme(theme: ChatTheme): void;
}

const ChatThemeContext = createContext<ChatThemeContextValue | null>(null);

export interface ChatThemeProviderProps {
    children: ReactNode;
    projectKey: string;
    accountNo: string;
    storage?: ThemeStorage | null;
    rootElement?: HTMLElement | null;
}

export function ChatThemeProvider({ children, projectKey, accountNo, storage: providedStorage, rootElement }: ChatThemeProviderProps) {
    const storage = providedStorage === undefined ? browserStorage() : providedStorage;
    const key = themeStorageKey(projectKey, accountNo);
    const identity = JSON.stringify([projectKey.trim(), accountNo.trim().toUpperCase()]);
    const [selection, setSelection] = useState(() => ({ identity, theme: readStoredTheme(storage, key) }));
    // identity 改變時立即讀取新帳號設定，不沿用前一帳號的主題。
    const theme = selection.identity === identity ? selection.theme : readStoredTheme(storage, key);

    useEffect(() => {
        if (selection.identity !== identity) setSelection({ identity, theme });
    }, [identity, theme, selection.identity]);

    const setTheme = useCallback((next: ChatTheme) => {
        if (!isChatTheme(next)) return;
        setSelection({ identity, theme: next });
        persistTheme(storage, key, next);
    }, [identity, key, storage]);

    useLayoutEffect(() => {
        const root = rootElement === undefined ? document.getElementById('mes-ai-chat-root') : rootElement;
        if (!root || root.id !== 'mes-ai-chat-root') return;
        const originalDark = root.classList.contains('dark');
        const originalTheme = root.getAttribute('data-theme');
        root.classList.toggle('dark', theme !== 'light');
        root.dataset.theme = theme;
        return () => {
            root.classList.toggle('dark', originalDark);
            if (originalTheme === null) root.removeAttribute('data-theme');
            else root.setAttribute('data-theme', originalTheme);
        };
    }, [theme, rootElement]);

    return <ChatThemeContext.Provider value={{ theme, setTheme }}>{children}</ChatThemeContext.Provider>;
}

export function useChatTheme(): ChatThemeContextValue {
    const context = useContext(ChatThemeContext);
    if (!context) throw new Error('useChatTheme 必須在 ChatThemeProvider 內使用');
    return context;
}
