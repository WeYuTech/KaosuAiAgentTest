import {createContext, useContext, useEffect, useRef, useState, type ReactNode} from 'react';
import {useMesUi} from '@/chat/mes-ui-context';
import {ChatApiError} from '@/chat/api';
import {buildSettingsUpdate, settingsDraft, type ProviderSettings, type ProviderDraft, type SettingsUpdate} from '@/chat/settings';

export type SettingsSection = 'api' | 'agent';
function settingError(error: unknown): string {
    if ((error as ChatApiError)?.status === 403) return '此入口未開放設定，請由後端管理。';
    return (error as ChatApiError)?.userMessage || '無法讀取或儲存設定，請稍後再試';
}

function useProviderSettingsState() {
    const {state, actions} = useMesUi();
    const [section, setSection] = useState<SettingsSection | null>(null);
    const [settings, setSettings] = useState<ProviderSettings | null>(null);
    const [draft, setDraft] = useState<ProviderDraft | null>(null);
    const [loading, setLoading] = useState(false), [saving, setSaving] = useState(false);
    const [error, setError] = useState(''), [notice, setNotice] = useState('');
    const epoch = useRef(0);
    useEffect(() => {
        epoch.current++; setSection(null); setSettings(null); setDraft(null);
        setLoading(false); setSaving(false); setError(''); setNotice('');
        return () => {epoch.current++;};
    }, [actions]);
    async function load() {
        const current = ++epoch.current;
        setLoading(true); setError(''); setNotice('');
        try {
            const result = await actions.loadProviderSettings();
            if (current !== epoch.current) return;
            setSettings(result); setDraft(settingsDraft(result));
        } catch (failure) {if (current === epoch.current) setError(settingError(failure));}
        finally {if (current === epoch.current) setLoading(false);}
    }
    function openSettings(next: SettingsSection) {
        setSection(next); setSettings(null); setDraft(null); setSaving(false);
        void load();
    }
    function closeSettings() {
        epoch.current++; setSection(null);
        setSettings(null); setDraft(null); setError(''); setNotice(''); setLoading(false); setSaving(false);
    }
    const blocked = state.expired || state.submitting || state.showStop || state.unknownSubmission || !!settings?.blocked_reason;
    async function save() {
        if (!settings || !draft || saving || loading || blocked) return;
        let update: SettingsUpdate;
        try {update = buildSettingsUpdate(settings, draft);}
        catch (failure) {setError(failure instanceof Error ? failure.message : '設定格式不正確'); return;}
        if (Object.keys(update).length === 1) {setNotice('設定沒有變更'); return;}
        const current = ++epoch.current;
        setSaving(true); setError(''); setNotice('');
        try {
            const result = await actions.saveProviderSettings(update);
            if (current !== epoch.current) return;
            setSettings(result); setDraft(settingsDraft(result));
            setNotice(result.message || (result.apply === 'immediate' ? '設定已生效，請開啟新聊天使用' : '設定已儲存，重啟後端服務後生效'));
        } catch (failure) {if (current === epoch.current) setError(settingError(failure));}
        finally {if (current === epoch.current) setSaving(false);}
    }
    return {section, settings, draft, setDraft,
        loading, saving, error, notice, blocked, expired: state.expired, openSettings, closeSettings, reload: () => load(), save};
}
type Preferences = ReturnType<typeof useProviderSettingsState>;
const PreferencesContext = createContext<Preferences | null>(null);

/** 只管理模型設定草稿；金鑰與管理憑證由後端維護。 */
export function ProviderSettingsProvider({children}: {children: ReactNode}) {
    const value = useProviderSettingsState();
    return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>;
}
export function useProviderSettings() {
    const value = useContext(PreferencesContext);
    if (!value) throw new Error('設定畫面需要 ProviderSettingsProvider');
    return value;
}
