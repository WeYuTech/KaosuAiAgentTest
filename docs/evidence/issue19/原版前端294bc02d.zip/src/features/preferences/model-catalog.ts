/** 官方標準文字 Token 費率快照；不代表帳號可用模型或每題固定費用 */
export interface ModelOption {
    id: string;
    description: string;
    inputUsd: number;
    outputUsd: number;
}
export const MODEL_PRICE_CHECKED_AT = '2026-10-11';
export const MODEL_PRICING_URL = 'https://developers.openai.com/api/docs/pricing';
export const MODEL_OPTIONS: readonly ModelOption[] = [
    {id: 'gpt-6.1-sol', description: '複雜問答，兼顧能力與成本', inputUsd: 2, outputUsd: 10},
    {id: 'gpt-6-astra', description: '高難度推理與複雜分析', inputUsd: 10, outputUsd: 50},
    {id: 'gpt-6-sol', description: '多步工具使用與複雜工作', inputUsd: 2, outputUsd: 10},
    {id: 'gpt-6-luna', description: '大量日常查詢，低成本', inputUsd: 0.1, outputUsd: 0.5},
    {id: 'gpt-5.6-sol', description: '複雜專業任務', inputUsd: 4, outputUsd: 20},
    {id: 'gpt-5.6-terra', description: '日常分析，兼顧能力與成本', inputUsd: 2, outputUsd: 12},
    {id: 'gpt-5.6-luna', description: '大量簡單查詢，低成本', inputUsd: 0.2, outputUsd: 1.2},
];
export function modelOption(id: string): ModelOption | undefined {
    return MODEL_OPTIONS.find(option => option.id === id);
}
export function modelPriceLabel(id: string): string {
    const option = modelOption(id);
    if (!option) return '尚未取得官方價格';
    return `輸入 $${option.inputUsd.toFixed(2)} · 輸出 $${option.outputUsd.toFixed(2)}`;
}
