import {BotIcon, CalendarClockIcon, GaugeIcon, Settings2Icon, MoreHorizontalIcon, MoonIcon, PaletteIcon, SunIcon} from 'lucide-react';
import {useMesUi} from '@/chat/mes-ui-context';
import {TooltipIconButton} from '@/components/assistant-ui/elements/tooltip-icon-button';
import {DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuRadioGroup,
    DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuTrigger} from '@/components/ui/dropdown-menu';
import {usePortalContainer} from '@/features/common/UiContext';
import {CHAT_THEMES, useChatTheme, type ChatTheme} from './theme';
import {useProviderSettings} from './provider-settings';
import {useOperations} from '@/features/operations/operations';

/** 共用更多選單；聊天、設定與外觀各自交回既有控制器或專用 hook。 */
export function AssistantMoreMenu() {
    const {state, actions} = useMesUi();
    const {theme, setTheme} = useChatTheme();
    const {openSettings} = useProviderSettings();
    const operations = useOperations();
    const portal = usePortalContainer();
    const icons = {light: SunIcon, dark: MoonIcon, navy: PaletteIcon};
    return <DropdownMenu modal={false}>
        <DropdownMenuTrigger asChild><TooltipIconButton tooltip="更多功能" aria-label="更多功能"
            className="size-7 rounded-md p-0 text-muted-foreground hover:text-foreground"><MoreHorizontalIcon className="size-3.5" /></TooltipIconButton></DropdownMenuTrigger>
        <DropdownMenuContent portalContainer={portal} align="end">
            <DropdownMenuItem disabled={state.expired} onSelect={() => openSettings('api')}><Settings2Icon />API 設定</DropdownMenuItem>
            <DropdownMenuItem disabled={state.expired} onSelect={() => openSettings('agent')}><BotIcon />Agent API 設定</DropdownMenuItem>
            <DropdownMenuItem disabled={state.expired} onSelect={() => operations.open('budget')}><GaugeIcon />用量額度</DropdownMenuItem>
            <DropdownMenuItem disabled={state.expired} onSelect={() => operations.open('schedules')}><CalendarClockIcon />排程報告</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuLabel>介面外觀</DropdownMenuLabel>
            <DropdownMenuRadioGroup value={theme} onValueChange={value => setTheme(value as ChatTheme)}>
                {CHAT_THEMES.map(item => {const Icon = icons[item.value]; return <DropdownMenuRadioItem value={item.value} key={item.value}><Icon />{item.label}模式</DropdownMenuRadioItem>;})}
            </DropdownMenuRadioGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => void actions.loadMetrics()}>使用統計</DropdownMenuItem>
            <DropdownMenuItem onSelect={actions.closeChat}>收合聊天室</DropdownMenuItem>
        </DropdownMenuContent>
    </DropdownMenu>;
}
