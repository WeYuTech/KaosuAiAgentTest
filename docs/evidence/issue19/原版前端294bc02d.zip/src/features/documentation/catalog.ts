import {safeUrl} from '../../chat/core';

export interface DocumentEntry {
    id: string;
    title: string;
    summary: string;
    source: string;
    asset: string;
    bytes: number;
    sha256: string;
}
export interface DocumentCatalog {version: 1; documents: DocumentEntry[]}
const maximumBytes = 2 * 1024 * 1024;

/** 索引只接受靜態、無路徑的雜湊資產，不把 query string 當成檔案路徑。 */
export function parseDocumentCatalog(value: unknown): DocumentCatalog {
    if (!value || typeof value !== 'object') throw new Error('文件索引格式不正確');
    const candidate = value as Record<string, unknown>;
    if (candidate.version !== 1 || !Array.isArray(candidate.documents) || candidate.documents.length > 30) throw new Error('文件索引格式不正確');
    const seen = new Set<string>();
    const documents = candidate.documents.map((item: unknown): DocumentEntry => {
        if (!item || typeof item !== 'object') throw new Error('文件索引格式不正確');
        const entry = item as Record<string, unknown>;
        if (typeof entry.id !== 'string' || !/^[a-z-]{1,48}$/.test(entry.id) || seen.has(entry.id)
            || typeof entry.asset !== 'string' || !new RegExp('^' + entry.id + '-[a-f0-9]{12}\\.md$').test(entry.asset)
            || typeof entry.title !== 'string' || !entry.title.trim() || entry.title.length > 100
            || typeof entry.summary !== 'string' || entry.summary.length > 200
            || typeof entry.source !== 'string' || !/^docs\/[^/\\]+\.md$/.test(entry.source) || /\.\./.test(entry.source)
            || typeof entry.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(entry.sha256)
            || !entry.asset.endsWith(entry.sha256.slice(0, 12) + '.md')
            || typeof entry.bytes !== 'number' || !Number.isSafeInteger(entry.bytes) || entry.bytes < 1 || entry.bytes > maximumBytes) throw new Error('文件索引格式不正確');
        seen.add(entry.id);
        return {id: entry.id, title: entry.title, summary: entry.summary, source: entry.source, asset: entry.asset, bytes: entry.bytes, sha256: entry.sha256};
    });
    return {version: 1, documents};
}

export function chooseDocument(documents: DocumentEntry[], selection: string | null): DocumentEntry | undefined {
    if (!selection) return documents.find(document => document.id === 'capabilities') || documents[0];
    return documents.find(document => document.id === selection || document.source === selection || document.source.slice(5) === selection);
}

export function filterDocuments(documents: DocumentEntry[], search: string): DocumentEntry[] {
    const terms = search.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
    return documents.filter(document => terms.every(term => `${document.title} ${document.summary} ${document.source}`.toLocaleLowerCase().includes(term)));
}

export function documentHref(currentUrl: string, id: string, hash = ''): string {
    const url = new URL(currentUrl);
    url.pathname = '/docs';
    url.searchParams.set('file', id);
    url.hash = hash;
    return url.pathname + url.search + url.hash;
}

export type DocumentLink = {kind: 'document'; id: string; hash: string} | {kind: 'anchor'; hash: string} | {kind: 'external'; href: string} | {kind: 'blocked'};
/** Markdown 相對路徑先對照白名單；其餘合法 repo 路徑只能連到 GitHub，不讀取本機檔案。 */
export function resolveDocumentLink(href: string, source: string, documents: DocumentEntry[]): DocumentLink {
    if (!href || /[\u0000-\u0020\u007f\\]/.test(href) || /^[A-Za-z]:/.test(href) || href.startsWith('//')) return {kind: 'blocked'};
    if (href.startsWith('#')) return {kind: 'anchor', hash: href};
    if (/^[a-z][a-z0-9+.-]*:/i.test(href)) {
        const absolute = safeUrl(href);
        if (!absolute) return {kind: 'blocked'};
        const url = new URL(absolute);
        if (url.username || url.password) return {kind: 'blocked'};
        return {kind: 'external', href: absolute};
    }
    try {
        let depth = source.split('/').length - 1;
        for (const segment of decodeURIComponent(href.split(/[?#]/)[0]).split('/')) {
            if (segment === '..') {if (--depth < 0) return {kind: 'blocked'};}
            else if (segment && segment !== '.') depth++;
        }
        const base = 'https://repo.invalid/';
        const target = new URL(href, base + source);
        const decoded = decodeURIComponent(target.pathname).slice(1);
        if (/[\u0000-\u0020\u007f\\]/.test(decoded) || /(^|\/)\.\.?($|\/)/.test(decoded) || target.search) return {kind: 'blocked'};
        const document = documents.find(item => item.source === decoded);
        if (document) return {kind: 'document', id: document.id, hash: target.hash};
        // 只允許工程來源路徑，輸出／設定及未公開證據不變成下載接口。
        if (!/^(?:app|frontend|scripts|tests|docs)\//.test(decoded) || /(?:appsettings|\.env|diagnostic|token|secret)/i.test(decoded)) return {kind: 'blocked'};
        return {kind: 'external', href: 'https://github.com/WeYuTech/WeYu-MesAiAgent/blob/Emerald/' + decoded.split('/').map(encodeURIComponent).join('/') + target.hash};
    } catch { return {kind: 'blocked'}; }
}

export async function verifyDocumentBytes(raw: ArrayBuffer, entry: DocumentEntry): Promise<string> {
    if (raw.byteLength !== entry.bytes || raw.byteLength > maximumBytes) throw new Error('文件資產不完整，請重新讀取');
    const digest = await crypto.subtle.digest('SHA-256', raw);
    const sha256 = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
    if (sha256 !== entry.sha256) throw new Error('文件資產版本不符，請重新讀取');
    return new TextDecoder('utf-8', {fatal: true}).decode(raw);
}
