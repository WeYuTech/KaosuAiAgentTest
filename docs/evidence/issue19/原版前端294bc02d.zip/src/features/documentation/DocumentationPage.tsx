import {useCallback, useEffect, useId, useMemo, useRef, useState} from 'react';
import {ArrowLeftIcon, BookOpenIcon, FileTextIcon, LoaderCircleIcon, MenuIcon, RotateCwIcon} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import {Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger} from '@/components/ui/sheet';
import {DocumentMarkdown} from '@/components/ui/document-markdown';
import {chooseDocument, documentHref, filterDocuments, parseDocumentCatalog, resolveDocumentLink, verifyDocumentBytes} from './catalog';
import type {DocumentCatalog, DocumentEntry} from './catalog';
import type {Components} from 'react-markdown';

const assetsBase = '/documentation/';
const readSelection = () => new URL(location.href).searchParams.get('file');

function DocumentNavigation({documents, current, onSelect}: {documents: DocumentEntry[]; current?: string; onSelect: (document: DocumentEntry) => void}) {
    const [search, setSearch] = useState('');
    const searchId = useId();
    const filtered = filterDocuments(documents, search);
    return <div className="flex min-h-0 flex-1 flex-col gap-3">
        <div className="space-y-2 px-4"><Label htmlFor={searchId}>搜尋文件</Label><Input id={searchId} type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="名稱或關鍵字" /></div>
        <nav aria-label="工程文件" className="min-h-0 flex-1 space-y-1 overflow-y-auto px-2 pb-4">
            {filtered.map(document => <Button key={document.id} variant={current === document.id ? 'secondary' : 'ghost'} className="h-auto w-full justify-start gap-2 px-3 py-3 text-start" aria-current={current === document.id ? 'page' : undefined} onClick={() => onSelect(document)}>
                <FileTextIcon className="size-4 shrink-0" aria-hidden="true" /><span className="min-w-0 whitespace-normal"><span className="block font-medium">{document.title}</span><span className="mt-1 block text-xs font-normal text-muted-foreground">{document.summary}</span></span>
            </Button>)}
            {!filtered.length && <p className="px-3 py-4 text-sm text-muted-foreground">找不到符合的文件</p>}
        </nav>
    </div>;
}

export function DocumentationPage() {
    const [catalog, setCatalog] = useState<DocumentCatalog | null>(null);
    const [indexError, setIndexError] = useState('');
    const [selection, setSelection] = useState(readSelection);
    const [fragment, setFragment] = useState(location.hash);
    const [drawer, setDrawer] = useState(false);
    const [content, setContent] = useState<{sha256: string; text: string | null; error: string}>({sha256: '', text: null, error: ''});
    const [indexRevision, setIndexRevision] = useState(0);
    const [documentRevision, setDocumentRevision] = useState(0);
    const cache = useRef(new Map<string, string>());
    const article = useRef<HTMLElement>(null);
    const documents = catalog?.documents || [];
    const selected = chooseDocument(documents, selection);
    const markdown = content.sha256 === selected?.sha256 ? content.text : null;
    const documentError = content.sha256 === selected?.sha256 ? content.error : '';

    useEffect(() => {
        const controller = new AbortController();
        setIndexError('');
        setCatalog(null);
        fetch(assetsBase + 'index.json', {signal: controller.signal, cache: 'no-cache'})
            .then(async response => {
                if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) throw new Error('無法載入文件索引');
                return parseDocumentCatalog(await response.json());
            }).then(value => {if (!controller.signal.aborted) setCatalog(value);})
            .catch(() => {if (!controller.signal.aborted) setIndexError('無法載入文件索引，請重新讀取');});
        return () => controller.abort();
    }, [indexRevision]);

    useEffect(() => {
        const onPopState = () => {setSelection(readSelection()); setFragment(location.hash); setDrawer(false);};
        window.addEventListener('popstate', onPopState);
        return () => window.removeEventListener('popstate', onPopState);
    }, []);

    useEffect(() => {
        if (!selected) return;
        setContent({sha256: selected.sha256, text: null, error: ''});
        document.title = selected.title + '｜Emerald 文件';
        const cached = cache.current.get(selected.sha256);
        if (cached !== undefined) {setContent({sha256: selected.sha256, text: cached, error: ''}); return;}
        const controller = new AbortController();
        fetch(assetsBase + selected.asset, {signal: controller.signal})
            .then(async response => {
                if (!response.ok || response.headers.get('content-type')?.includes('text/html')) throw new Error('文件不存在');
                const raw = await response.arrayBuffer();
                return verifyDocumentBytes(raw, selected);
            }).then(value => {
                if (controller.signal.aborted) return;
                cache.current.set(selected.sha256, value);
                setContent({sha256: selected.sha256, text: value, error: ''});
            }).catch(() => {if (!controller.signal.aborted) setContent({sha256: selected.sha256, text: null, error: '無法載入文件或版本不符，請重新讀取'});});
        return () => controller.abort();
    }, [selected?.sha256, documentRevision]);

    useEffect(() => {
        if (markdown === null) return;
        if (fragment) {
            try {
                const target = document.getElementById(decodeURIComponent(fragment.slice(1)));
                if (target && article.current?.contains(target)) {target.scrollIntoView({block: 'start'}); return;}
            } catch { /* 無效 hash 仍可正常閱讀 */ }
        }
        article.current?.scrollTo({top: 0});
    }, [markdown, fragment, selected?.id]);

    const selectDocument = useCallback((entry: DocumentEntry, hash = '') => {
        history.pushState(null, '', documentHref(location.href, entry.id, hash));
        setSelection(entry.id);
        setFragment(hash);
        setDrawer(false);
    }, []);

    const link = useMemo<NonNullable<Components['a']>>(() => function DocumentAnchor({href, children}) {
        const target = resolveDocumentLink(href || '', selected?.source || 'docs/README.md', documents);
        if (target.kind === 'blocked') return <span className="text-muted-foreground" title="此來源不在公開文件範圍">{children}</span>;
        if (target.kind === 'anchor') return <a className="underline underline-offset-4" href={target.hash}>{children}</a>;
        if (target.kind === 'external') return <a className="underline underline-offset-4" href={target.href} target="_blank" rel="noopener noreferrer">{children}</a>;
        return <a className="underline underline-offset-4" href={documentHref(location.href, target.id, target.hash)} onClick={event => {
            if (event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
            const entry = documents.find(document => document.id === target.id);
            if (entry) {event.preventDefault(); selectDocument(entry, target.hash);}
        }}>{children}</a>;
    }, [documents, selected?.source, selectDocument]);

    const home = new URL(location.href);
    home.pathname = '/';
    home.searchParams.delete('file');
    home.hash = '';
    return <main className="mes-documentation flex h-dvh min-h-0 flex-col bg-background text-foreground">
        <header className="flex shrink-0 items-center gap-3 border-b border-border px-4 py-3">
            <img src="/weyu-brand.svg" className="aui-modal-brand" alt="威友科技" />
            <span className="border-s border-border ps-3 text-sm font-medium">工程文件</span>
            <Button asChild variant="ghost" size="sm" className="ms-auto"><a href={home.pathname + home.search}><ArrowLeftIcon className="size-4" />返回助理</a></Button>
        </header>
        <div className="flex min-h-0 flex-1">
            <aside className="mes-documentation-sidebar hidden shrink-0 flex-col gap-4 border-e border-border bg-sidebar py-4 md:flex" aria-label="文件側欄">
                <div className="flex items-center gap-2 px-4 text-sm font-medium"><BookOpenIcon className="size-4" />文件目錄</div>
                {catalog && <DocumentNavigation documents={documents} current={selected?.id} onSelect={selectDocument} />}
            </aside>
            <section className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-center gap-3 border-b border-border px-4 py-3 md:hidden">
                    <Sheet open={drawer} onOpenChange={setDrawer}><SheetTrigger asChild><Button variant="outline" size="sm"><MenuIcon className="size-4" />選擇文件</Button></SheetTrigger>
                        <SheetContent side="left" portalContainer={document.getElementById('mes-ai-preview-root')} className="min-w-0">
                            <SheetHeader><SheetTitle>工程文件</SheetTitle><SheetDescription>選擇要閱讀的 Markdown 文件</SheetDescription></SheetHeader>
                            {catalog && <DocumentNavigation documents={documents} current={selected?.id} onSelect={selectDocument} />}
                        </SheetContent>
                    </Sheet><p className="min-w-0 truncate text-sm text-muted-foreground">{selected?.title || '文件目錄'}</p>
                </div>
                <article ref={article} className="min-h-0 min-w-0 flex-1 overflow-y-auto px-4 py-6 sm:px-6" aria-label={selected ? selected.title : '文件內容'} aria-busy={!indexError && (!catalog || !!selected && markdown === null && !documentError)}>
                    <div className="mes-documentation-reading mx-auto min-w-0">
                        {(!catalog || !selected) && <h1 className="mb-4 text-lg font-semibold">工程文件</h1>}
                        {indexError ? <div role="alert" className="space-y-3"><p>{indexError}</p><Button variant="outline" onClick={() => setIndexRevision(revision => revision + 1)}><RotateCwIcon className="size-4" />重新讀取</Button></div>
                            : !catalog ? <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status"><LoaderCircleIcon className="size-4 animate-spin motion-reduce:animate-none" />正在載入文件目錄</p>
                            : !documents.length ? <p role="status" className="text-sm text-muted-foreground">目前沒有已發布文件</p>
                            : !selected ? <div role="alert" className="space-y-3"><p>找不到這份文件，請從目錄選擇已發布文件</p><Button variant="outline" onClick={() => selectDocument(documents[0])}>開啟文件導覽</Button></div>
                            : <><div className="mb-6 border-b border-border pb-4"><p className="text-xs text-muted-foreground">Markdown · {selected.source}</p>
                                {(markdown === null || !/^#\s+\S/m.test(markdown)) && <h1 className="mt-2 text-lg font-semibold">{selected.title}</h1>}</div>
                                {documentError ? <div role="alert" className="space-y-3"><p>{documentError}</p><Button variant="outline" onClick={() => {cache.current.delete(selected.sha256); setDocumentRevision(revision => revision + 1);}}><RotateCwIcon className="size-4" />重新讀取</Button></div>
                                    : markdown === null ? <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status"><LoaderCircleIcon className="size-4 animate-spin motion-reduce:animate-none" />正在載入文件</p>
                                    : <DocumentMarkdown text={markdown} link={link} />}</>}
                    </div>
                </article>
            </section>
        </div>
    </main>;
}
