import {useId, useRef} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import {Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle} from '@/components/ui/dialog';
import {usePortalContainer} from '@/features/common/UiContext';
import {useConversationActions} from './conversation-actions';

export function ConversationActionsDialog() {
    const management = useConversationActions();
    const {dialog, title, error, saving, reloading, conflicted, dialogNotice, expired} = management;
    const portal = usePortalContainer(), inputId = useId(), input = useRef<HTMLInputElement | null>(null), composing = useRef(false);
    const rename = dialog?.kind === 'rename';
    return <Dialog open={dialog !== null} onOpenChange={open => {if (!open) management.closeDialog();}}>
        <DialogContent portalContainer={portal} data-slot="mes-conversation-dialog"
            onOpenAutoFocus={event => {composing.current = false; event.preventDefault(); if (rename) {input.current?.focus(); input.current?.select();} else if (event.target instanceof HTMLElement) event.target.focus();}}
            onCloseAutoFocus={management.restoreFocus}>
            <DialogHeader><DialogTitle>{rename ? '重新命名聊天室' : '刪除聊天室？'}</DialogTitle>
                <DialogDescription>{rename ? '修改聊天清單顯示的名稱，聊天內容保持不變' : '此聊天室會從聊天清單移除，不會刪除 MES 業務資料或稽核紀錄'}</DialogDescription>
            </DialogHeader>
            <form className="space-y-4" onSubmit={event => {event.preventDefault(); if (!composing.current) void management.confirm();}}>
                {rename ? <div className="space-y-2"><Label htmlFor={inputId}>聊天室名稱</Label><Input ref={input} id={inputId} value={title} maxLength={100} onChange={event => management.setTitle(event.target.value)} disabled={saving || reloading || expired} autoComplete="off"
                    onCompositionStart={() => {composing.current = true;}} onCompositionEnd={() => {composing.current = false;}}
                    onKeyDown={event => {if (event.key === 'Enter' && (composing.current || event.nativeEvent.isComposing || event.nativeEvent.keyCode === 229)) event.preventDefault();}} />
                    {dialogNotice && <p className="break-words text-xs text-muted-foreground">目前名稱：{dialog?.conversation.title || '新聊天'}</p>}</div>
                    : <p className="break-words text-sm font-medium">{dialog?.conversation.title || '新聊天'}</p>}
                {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
                {dialogNotice && <p role="status" className="text-sm text-muted-foreground">{dialogNotice}</p>}
                {expired && <p role="status" className="text-sm text-muted-foreground">登入已逾時，請重新登入 MES</p>}
                <DialogFooter>{(conflicted || dialogNotice || reloading) && <Button type="button" variant="outline" className="min-h-11 sm:min-h-9" disabled={saving || reloading || expired} onClick={() => void management.reloadDialog()}>{reloading ? '讀取中…' : '重新讀取'}</Button>}
                    <Button type="button" variant="outline" className="min-h-11 sm:min-h-9" onClick={management.closeDialog}>取消</Button>
                    <Button type="submit" className="min-h-11 sm:min-h-9" variant={rename ? 'default' : 'destructive'} disabled={saving || reloading || conflicted || expired || rename && !title.trim()}>{saving ? '處理中…' : rename ? '儲存名稱' : '刪除聊天室'}</Button>
                </DialogFooter>
            </form>
        </DialogContent>
    </Dialog>;
}
