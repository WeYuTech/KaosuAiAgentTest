import {createContext, useContext, useEffect, useRef, useState, type ReactNode} from 'react';
import {useMesUi} from '@/chat/mes-ui-context';
import type {ChatApiError} from '@/chat/api';
import type {Conversation, ConversationUpdate} from '@/chat/types';
import {usePortalContainer} from '@/features/common/UiContext';
import {restoreAvailableFocus} from '@/features/common/restoreFocus';

type ConversationDialog = {kind: 'rename' | 'delete'; conversation: Conversation};

function operationError(error: unknown): string {
    return (error as ChatApiError)?.userMessage || '無法更新聊天室，請稍後再試';
}

/** 選單與 Dialog 只保存暫存 UI；所有資料修改沿用既有控制器。 */
function useConversationActionsState() {
    const {state, actions} = useMesUi();
    const portal = usePortalContainer();
    const [dialog, setDialog] = useState<ConversationDialog | null>(null);
    const [title, setTitle] = useState('');
    const [error, setError] = useState('');
    const [notice, setNotice] = useState('');
    const [dialogNotice, setDialogNotice] = useState('');
    const [saving, setSaving] = useState(false);
    const [reloading, setReloading] = useState(false);
    const [conflicted, setConflicted] = useState(false);
    const returnTarget = useRef<HTMLElement | null>(null);
    const epoch = useRef(0);
    const owner = useRef(actions); owner.current = actions;
    useEffect(() => {
        epoch.current++; returnTarget.current = null; setDialog(null); setTitle(''); setError(''); setNotice('');
        setDialogNotice(''); setSaving(false); setReloading(false); setConflicted(false);
        return () => {epoch.current++;};
    }, [actions]);

    function openDialog(kind: ConversationDialog['kind'], conversation: Conversation, trigger: HTMLElement | null) {
        epoch.current++;
        returnTarget.current = trigger;
        setDialog({kind, conversation}); setTitle(conversation.title || '新聊天');
        setError(''); setNotice(''); setDialogNotice(''); setSaving(false); setReloading(false); setConflicted(false);
    }
    function closeDialog() {
        epoch.current++; setDialog(null); setTitle(''); setError(''); setDialogNotice(''); setSaving(false); setReloading(false); setConflicted(false);
    }
    async function confirm() {
        if (!dialog || saving || reloading || conflicted || state.expired || dialog.kind === 'rename' && !title.trim()) return;
        const current = ++epoch.current;
        setSaving(true); setError(''); setDialogNotice('');
        try {
            const {conversation, kind} = dialog;
            if (kind === 'rename') await actions.updateConversation(conversation.conversation_id, {title: title.trim()}, conversation.metadata_version);
            else await actions.deleteConversation(conversation.conversation_id, conversation.metadata_version);
            if (current === epoch.current) closeDialog();
        } catch (failure) {if (current === epoch.current) {setError(operationError(failure)); setConflicted((failure as ChatApiError)?.status === 409);}}
        finally {if (current === epoch.current) setSaving(false);}
    }
    async function reloadDialog() {
        if (!dialog || saving || reloading || state.expired) return;
        const current = ++epoch.current;
        setReloading(true); setError(''); setDialogNotice('');
        try {
            const updated = await actions.loadConversationMetadata(dialog.conversation.conversation_id);
            if (current !== epoch.current) return;
            setDialog(previous => previous && {...previous, conversation: updated});
            setConflicted(false); setDialogNotice('已讀取最新狀態，請確認後再次操作');
        } catch (failure) {if (current === epoch.current) setError(operationError(failure));}
        finally {if (current === epoch.current) setReloading(false);}
    }
    async function update(conversation: Conversation, patch: ConversationUpdate) {
        const currentOwner = actions;
        setNotice('');
        try {await actions.updateConversation(conversation.conversation_id, patch, conversation.metadata_version); return currentOwner === owner.current;}
        catch (failure) {if (currentOwner === owner.current) setNotice(operationError(failure)); return false;}
    }
    async function showArchived(archived: boolean) {
        const currentOwner = actions;
        setNotice('');
        try {await actions.showArchivedConversations(archived);}
        catch (failure) {if (currentOwner === owner.current) setNotice(operationError(failure));}
    }
    function focusTriggerOrFallback(previous: HTMLElement | null) {
        restoreAvailableFocus(previous, portal || document.getElementById('mes-ai-chat-root'));
    }
    function restoreFocus(event: Event) {
        event.preventDefault(); focusTriggerOrFallback(returnTarget.current);
    }
    return {dialog, title, setTitle, error, notice, dialogNotice, clearNotice: () => setNotice(''), saving, reloading, conflicted,
        expired: state.expired, openDialog, closeDialog, confirm, reloadDialog, update, showArchived, restoreFocus, focusTriggerOrFallback};
}

type ConversationActions = ReturnType<typeof useConversationActionsState>;
const ConversationActionsContext = createContext<ConversationActions | null>(null);

export function ConversationActionsProvider({children}: {children: ReactNode}) {
    const value = useConversationActionsState();
    return <ConversationActionsContext.Provider value={value}>{children}</ConversationActionsContext.Provider>;
}
export function useConversationActions() {
    const value = useContext(ConversationActionsContext);
    if (!value) throw new Error('聊天室管理需要 ConversationActionsProvider');
    return value;
}
