import {useRef} from 'react';
import {ArchiveIcon, ArchiveRestoreIcon, EllipsisIcon, PencilIcon, PinIcon, PinOffIcon, Trash2Icon} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger} from '@/components/ui/dropdown-menu';
import {useMesUi} from '@/chat/mes-ui-context';
import type {Conversation, ConversationUpdate} from '@/chat/types';
import {usePortalContainer} from '@/features/common/UiContext';
import {useConversationActions} from './conversation-actions';

/** 操作按鈕是聊天室 Trigger 的同層元素，不觸發切換聊天。 */
export function ConversationActionsMenu({conversation}: {conversation: Conversation}) {
    const {state} = useMesUi(), management = useConversationActions();
    const portal = usePortalContainer();
    const trigger = useRef<HTMLButtonElement | null>(null), openedDialog = useRef(false);
    const disabled = state.expired || state.conversationSaving.includes(conversation.conversation_id);
    const title = conversation.title || '新聊天';
    function open(kind: 'rename' | 'delete') {
        openedDialog.current = true;
        management.openDialog(kind, conversation, trigger.current);
    }
    async function update(patch: ConversationUpdate) {
        const previous = trigger.current;
        await management.update(conversation, patch);
        requestAnimationFrame(() => {
            const active = document.activeElement;
            if (!active || active === document.body || active === document.getElementById('mes-ai-chat-root')) management.focusTriggerOrFallback(previous);
        });
    }
    return <DropdownMenu onOpenChange={open => {if (open) openedDialog.current = false;}}>
        <DropdownMenuTrigger asChild><Button ref={trigger} type="button" variant="ghost" size="icon" disabled={disabled}
            aria-label={`聊天室選單：${title}`} data-slot="mes-conversation-menu-trigger" data-conversation-id={conversation.conversation_id}
            className="text-muted-foreground me-0.5 size-11 shrink-0 rounded-md opacity-100 sm:size-8 sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100 data-[state=open]:opacity-100"
            onPointerDown={event => event.stopPropagation()} onClick={event => event.stopPropagation()}>
            <EllipsisIcon className="size-4" /><span className="sr-only">聊天室操作</span>
        </Button></DropdownMenuTrigger>
        <DropdownMenuContent portalContainer={portal} align="end" data-slot="mes-conversation-menu"
            onPointerDown={event => event.stopPropagation()} onClick={event => event.stopPropagation()}
            onCloseAutoFocus={event => {if (openedDialog.current) event.preventDefault();}}>
            <DropdownMenuItem className="min-h-11 sm:min-h-8" disabled={disabled} onSelect={() => open('rename')}><PencilIcon />重新命名</DropdownMenuItem>
            <DropdownMenuItem className="min-h-11 sm:min-h-8" disabled={disabled} onSelect={() => void update({is_pinned: !conversation.is_pinned})}>
                {conversation.is_pinned ? <PinOffIcon /> : <PinIcon />}{conversation.is_pinned ? '取消釘選' : '釘選'}
            </DropdownMenuItem>
            <DropdownMenuItem className="min-h-11 sm:min-h-8" disabled={disabled} onSelect={() => void update({is_archived: !conversation.is_archived})}>
                {conversation.is_archived ? <ArchiveRestoreIcon /> : <ArchiveIcon />}{conversation.is_archived ? '取消封存' : '封存'}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="min-h-11 sm:min-h-8" variant="destructive" disabled={disabled} onSelect={() => open('delete')}><Trash2Icon />刪除</DropdownMenuItem>
        </DropdownMenuContent>
    </DropdownMenu>;
}
