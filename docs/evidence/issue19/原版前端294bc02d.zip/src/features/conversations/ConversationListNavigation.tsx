import {ArrowLeftIcon, ArchiveIcon, XIcon} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {useMesUi} from '@/chat/mes-ui-context';
import {useConversationActions} from './conversation-actions';

/** 滿版側欄與浮窗聊天紀錄重用同一個封存入口。 */
export function ConversationListNavigation() {
    const {state} = useMesUi(), management = useConversationActions();
    return <div className="space-y-1" data-slot="mes-conversation-navigation">
        <Button type="button" variant="ghost" className="min-h-11 w-full justify-start gap-2 px-2.5 text-sm font-normal sm:min-h-8"
            disabled={state.historyLoading || state.expired} onClick={() => void management.showArchived(!state.historyArchived)}
            data-action={state.historyArchived ? 'history-active' : 'history-archived'}>
            {state.historyArchived ? <ArrowLeftIcon className="size-4" /> : <ArchiveIcon className="size-4" />}{state.historyArchived ? '返回聊天' : '封存聊天室'}
        </Button>
        {state.historyArchived && <p className="px-2.5 py-1 text-xs text-muted-foreground">封存聊天室仍可查看內容與取消封存</p>}
        {management.notice && <div className="flex items-start gap-1 px-2.5 py-2"><p role="alert" className="min-w-0 flex-1 break-words text-xs text-destructive">{management.notice}</p><Button type="button" variant="ghost" size="icon" className="size-11 shrink-0 sm:size-6" aria-label="關閉聊天操作訊息" onClick={management.clearNotice}><XIcon className="size-3.5" /></Button></div>}
    </div>;
}
