"use client";

import { BotIcon, ChevronDownIcon, HistoryIcon, PlusIcon, Maximize2Icon, Minimize2Icon, XIcon } from "lucide-react";

import {ChatExecutionStatus} from '@/features/common/ChatExecutionStatus';
import {
  type ComponentPropsWithoutRef,
  type FC,
  type KeyboardEvent,
  type PointerEvent,
  type RefObject,
  forwardRef,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import {
  AssistantModalPrimitive,
  ThreadListPrimitive,
  useAuiEvent,
} from "@assistant-ui/react";

import { Thread } from "@/components/assistant-ui/elements/thread.aui";
import {
  ThreadList,
  ThreadListItems,
  ThreadListRoot,
  ThreadListSearch,
} from "@/components/assistant-ui/elements/thread-list.aui";
import { TooltipIconButton } from "@/components/assistant-ui/elements/tooltip-icon-button";
import { useMesUi } from "@/chat/mes-ui-context";
import {SidebarBudget} from '@/features/operations/SidebarBudget';
import { createOverflowLock } from "@/chat/core";
import { usePortalContainer } from "@/features/common/UiContext";
import { MesStatistics } from "@/features/mes/MesStatistics";
import { Button } from "@/components/ui/button";
import {AssistantMoreMenu} from '@/features/preferences/AssistantMoreMenu';
import {ConversationListNavigation} from '@/features/conversations/ConversationListNavigation';

type ModalView = "thread" | "list";

type ModalSize = { readonly width: number; readonly height: number };

type ResizeDrag = {
  readonly pointerId: number;
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
  readonly direction: 1 | -1;
  last: ModalSize | null;
};

const SIZE_STORAGE_KEY = "aui-modal-size";
const MIN_SIZE: ModalSize = { width: 320, height: 400 };
// The trigger and its offsets sit below the modal, so the height leaves room for them.
const VIEWPORT_INSET: ModalSize = { width: 32, height: 96 };
const RESIZE_STEP = 16;

const clampSize = ({ width, height }: ModalSize): ModalSize => ({
  width: Math.round(
    Math.max(
      MIN_SIZE.width,
      Math.min(width, window.innerWidth - VIEWPORT_INSET.width),
    ),
  ),
  height: Math.round(
    Math.max(
      MIN_SIZE.height,
      Math.min(height, window.innerHeight - VIEWPORT_INSET.height),
    ),
  ),
});

const readStoredSize = (): ModalSize | null => {
  if (typeof window === "undefined") return null;
  try {
    const stored: unknown = JSON.parse(
      window.localStorage.getItem(SIZE_STORAGE_KEY) ?? "null",
    );
    if (typeof stored !== "object" || stored === null) return null;
    const { width, height } = stored as Record<string, unknown>;
    if (typeof width !== "number" || typeof height !== "number") return null;
    return clampSize({ width, height });
  } catch {
    return null;
  }
};

const storeSize = (size: ModalSize | null) => {
  try {
    if (size) {
      window.localStorage.setItem(SIZE_STORAGE_KEY, JSON.stringify(size));
    } else {
      window.localStorage.removeItem(SIZE_STORAGE_KEY);
    }
  } catch {
    // Without storage the size lasts until the page reloads.
  }
};

const isRtl = (element: Element) =>
  getComputedStyle(element).direction === "rtl";

const useModalSize = (contentRef: RefObject<HTMLDivElement | null>) => {
  const [size, setSize] = useState(readStoredSize);
  const dragRef = useRef<ResizeDrag | null>(null);

  const commitSize = (next: ModalSize | null) => {
    setSize(next);
    storeSize(next);
  };

  const sizeFromPointer = (
    drag: ResizeDrag,
    event: PointerEvent<HTMLElement>,
  ) =>
    clampSize({
      width: drag.width - (event.clientX - drag.x) * drag.direction,
      height: drag.height - (event.clientY - drag.y),
    });

  const takeDrag = (event: PointerEvent<HTMLElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return null;
    dragRef.current = null;
    return drag;
  };

  const reset = () => {
    dragRef.current = null;
    commitSize(null);
  };

  return {
    size,
    reset,
    handleProps: {
      onPointerDown: (event: PointerEvent<HTMLElement>) => {
        const content = contentRef.current;
        if (event.button !== 0 || !content) return;
        const rect = content.getBoundingClientRect();
        dragRef.current = {
          pointerId: event.pointerId,
          x: event.clientX,
          y: event.clientY,
          width: rect.width,
          height: rect.height,
          direction: isRtl(content) ? -1 : 1,
          last: null,
        };
        event.currentTarget.setPointerCapture(event.pointerId);
        event.preventDefault();
      },
      onPointerMove: (event: PointerEvent<HTMLElement>) => {
        const drag = dragRef.current;
        if (!drag || drag.pointerId !== event.pointerId) return;
        if (!drag.last && event.clientX === drag.x && event.clientY === drag.y)
          return;
        drag.last = sizeFromPointer(drag, event);
        setSize(drag.last);
      },
      onPointerUp: (event: PointerEvent<HTMLElement>) => {
        const drag = takeDrag(event);
        if (!drag) return;
        if (drag.last || event.clientX !== drag.x || event.clientY !== drag.y) {
          commitSize(sizeFromPointer(drag, event));
        }
      },
      onPointerCancel: (event: PointerEvent<HTMLElement>) => {
        const drag = takeDrag(event);
        if (drag?.last) commitSize(drag.last);
      },
      onKeyDown: (event: KeyboardEvent<HTMLElement>) => {
        const content = contentRef.current;
        if (!content) return;
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          reset();
          return;
        }
        const step = event.shiftKey ? RESIZE_STEP * 4 : RESIZE_STEP;
        const rtl = isRtl(content);
        const changes: Record<string, readonly [number, number]> = {
          ArrowUp: [0, step],
          ArrowDown: [0, -step],
          [rtl ? "ArrowRight" : "ArrowLeft"]: [step, 0],
          [rtl ? "ArrowLeft" : "ArrowRight"]: [-step, 0],
        };
        const change = changes[event.key];
        if (!change) return;
        event.preventDefault();
        const rect = content.getBoundingClientRect();
        commitSize(
          clampSize({
            width: rect.width + change[0],
            height: rect.height + change[1],
          }),
        );
      },
    },
  };
};

export const AssistantModal: FC<{brandLogoUrl: string}> = ({brandLogoUrl}) => {
  const {state, actions} = useMesUi();
  const portal = usePortalContainer();
  const [mobile, setMobile] = useState(() => matchMedia('(max-width: 640px)').matches);
  const [wide, setWide] = useState(() => matchMedia('(min-width: 900px)').matches);
  const contentRef = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const { size, reset, handleProps } = useModalSize(contentRef);
  const full = state.expanded || mobile;
  const sidebar = state.expanded && wide;
  const view: ModalView = state.historyOpen ? 'list' : 'thread';
  const previousView = useRef(view);
  const previousPage = useRef(state.view);
  const focusThread = () => {
    const content = contentRef.current;
    const input = content?.querySelector<HTMLTextAreaElement>('.aui-composer-input:not([disabled])');
    if (input) input.focus(); else content?.querySelector<HTMLElement>('.aui-modal-title')?.focus();
  };
  useLayoutEffect(() => {
    const changed = previousView.current !== view;
    const pageChanged = previousPage.current !== state.view;
    previousView.current = view; previousPage.current = state.view;
    if (!state.opened) return;
    if (pageChanged && state.view === 'metrics') contentRef.current?.querySelector<HTMLElement>('#mes-statistics-title')?.focus();
    else if (changed && view === 'list' && !sidebar) {
      const search = contentRef.current?.querySelector<HTMLInputElement>('.aui-modal-thread-list input');
      if (search) search.focus(); else contentRef.current?.querySelector<HTMLElement>('.aui-modal-title')?.focus();
    } else if (changed || pageChanged) focusThread();
  }, [view, state.view, state.opened, sidebar]);
  useLayoutEffect(() => {
    if (!state.opened || !state.inputDisabled) return;
    const active = document.activeElement;
    if (!active || active === document.body || active === document.documentElement ||
        active instanceof HTMLTextAreaElement && active.matches('.aui-composer-input') && active.disabled) focusThread();
  }, [state.opened, state.inputDisabled]);
  useEffect(() => {
    const narrow = matchMedia('(max-width: 640px)'), desktop = matchMedia('(min-width: 900px)');
    const update = () => {setMobile(narrow.matches); setWide(desktop.matches);};
    narrow.addEventListener('change', update); desktop.addEventListener('change', update);
    return () => {narrow.removeEventListener('change', update); desktop.removeEventListener('change', update);};
  }, []);
  useEffect(() => {
    if (state.opened && !state.historyLoaded && !state.historyLoading && !state.expired) void actions.loadHistory(true);
  }, [state.opened, state.expired]);
  useEffect(() => {
    if (!state.opened || !full) return;
    const lock = createOverflowLock([document.documentElement.style, document.body.style]);
    lock.setLocked(true);
    return () => lock.setLocked(false);
  }, [state.opened, full]);
  useAuiEvent('thread.runStart', () => actions.closeHistory());
  return <AssistantModalPrimitive.Root open={state.opened} unstable_openOnRunStart={false}
    onOpenChange={open => {if (open) void actions.openChat(); else actions.closeChat();}}>
    <AssistantModalPrimitive.Anchor className="aui-root aui-modal-anchor fixed end-4 bottom-4 size-11">
      <AssistantModalPrimitive.Trigger asChild><AssistantModalButton /></AssistantModalPrimitive.Trigger>
    </AssistantModalPrimitive.Anchor>
    <AssistantModalPrimitive.Content ref={contentRef} sideOffset={16} portalProps={{container: portal}}
      aria-labelledby={titleId} aria-describedby={undefined} data-expanded={full} style={full ? undefined : size ?? undefined}
      onOpenAutoFocus={event => {event.preventDefault(); focusThread();}}
      onCloseAutoFocus={event => {event.preventDefault(); portal?.querySelector<HTMLButtonElement>('.aui-modal-button')?.focus();}}
      onEscapeKeyDown={event => {
        if (state.reportDialog) {event.preventDefault(); actions.closeReport();}
        else if (state.historyOpen) {event.preventDefault(); actions.closeHistory();}
        else if (state.expanded) {event.preventDefault(); actions.toggleExpanded();}
      }}
      onKeyDown={event => {
        if (!full || event.key !== 'Tab' || !event.currentTarget.contains(event.target as Node)) return;
        const nodes = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('button:not([disabled]), textarea:not([disabled]), input:not([disabled]), a[href], [tabindex="0"]')).filter(node => !node.closest('[inert]') && node.getClientRects().length);
        const first = nodes[0], last = nodes.at(-1);
        const insideTabOrder = nodes.some(node => node === document.activeElement);
        if (event.shiftKey && (document.activeElement === first || !insideTabOrder)) {event.preventDefault(); last?.focus();}
        else if (!event.shiftKey && (document.activeElement === last || !insideTabOrder)) {event.preventDefault(); first?.focus();}
      }}
      className="group/modal aui-root aui-modal-content bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 data-[state=open]:slide-in-from-bottom-2 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=closed]:slide-out-to-bottom-2 [&[data-state=open]_.aui-thread-viewport-footer]:animate-in [&[data-state=open]_.aui-thread-viewport-footer]:fade-in-0 [&[data-state=open]_.aui-thread-viewport-footer]:slide-in-from-bottom-2 [&[data-state=open]_.aui-thread-viewport-footer]:fill-mode-backwards [&_.aui-thread-viewport-footer]:bg-popover ring-foreground/10 z-50 flex h-125 max-h-(--radix-popover-content-available-height) w-100 max-w-[calc(100vw-2rem)] origin-(--radix-popover-content-transform-origin) flex-col overflow-clip overscroll-contain rounded-xl p-0 antialiased shadow-[0_16px_48px_-24px_rgb(0_0_0/0.25)] ring-1 transition-none ease-[cubic-bezier(0.32,0.72,0,1)] outline-none data-[state=closed]:duration-200 data-[state=open]:duration-300 motion-reduce:animate-none dark:shadow-[0_16px_48px_-24px_rgb(0_0_0/0.6)] [&_.aui-thread-root]:bg-inherit motion-reduce:[&_.aui-thread-viewport-footer]:animate-none [&_[data-slot=aui\_thread-viewport]]:[scrollbar-gutter:stable_both-edges] [&[data-state=open]_.aui-thread-viewport-footer]:delay-100 [&[data-state=open]_.aui-thread-viewport-footer]:duration-300 [&[data-state=open]_.aui-thread-viewport-footer]:ease-[cubic-bezier(0.32,0.72,0,1)]">
      {!full && <AssistantModalResizeHandle {...handleProps} onDoubleClick={reset} />}
      <AssistantModalHeader titleId={titleId} view={view} sidebar={sidebar} mobile={mobile} brandLogoUrl={brandLogoUrl} />
      {(state.sessionNotice || state.readOnlyNotice) && <div className="border-b px-4 py-2 text-sm text-muted-foreground" role="status">{state.sessionNotice || state.readOnlyNotice}</div>}
      <div className="aui-modal-body relative flex min-h-0 flex-1">
        {sidebar && <aside className="flex min-h-0 w-64 shrink-0 flex-col border-e bg-muted/30" aria-label="聊天紀錄"><div className="min-h-0 flex-1 overflow-y-auto p-3"><ThreadList /></div><SidebarBudget /></aside>}
        <div data-slot="aui_modal-main" className="relative flex min-h-0 min-w-0 flex-1 flex-col">
          <div className="relative min-h-0 flex-1">
            <div ref={node => {if (node) node.inert = view === 'list' && !sidebar || state.view === 'metrics';}}
              className="aui-modal-thread h-full" hidden={state.view === 'metrics'}><Thread autoFocus={false} /></div>
            {state.view === 'metrics' && <MesStatistics />}
            {view === 'list' && !sidebar && <AssistantModalThreadList onSelect={actions.closeHistory} />}
          </div>
          {state.unknownSubmission && <div className="space-y-2 border-t p-3 text-sm" role="status">
            <p>送出結果尚未確認系統不會自動重送，以免重複計費</p>
            <Button variant="outline" size="sm" disabled={state.expired} onClick={() => void actions.reconnect()}>重新確認送出狀態</Button>
          </div>}
          {state.reconnectNeeded && !state.unknownSubmission && <div className="border-t p-2 text-center"><Button variant="outline" size="sm" onClick={() => void actions.reconnect()}>重新連線查看進度</Button></div>}
          <ChatExecutionStatus />
          {state.toast && !state.expired && !state.sessionNotice && <p className="border-t px-4 py-2 text-sm" role="status" aria-live="polite">{state.toast}</p>}
          <p data-slot="aui_modal-copyright" className="aui-modal-copyright shrink-0 px-3 py-2 text-center text-xs text-muted-foreground">
            Corp. 2026 WeYu Technology Co., Ltd. All Rights Reserved.
          </p>
        </div>
      </div>
    </AssistantModalPrimitive.Content>
  </AssistantModalPrimitive.Root>;
};

const AssistantModalHeader: FC<{titleId: string; view: ModalView; sidebar: boolean; mobile: boolean; brandLogoUrl: string}> = ({titleId, view, sidebar, mobile, brandLogoUrl}) => {
  const {state, actions} = useMesUi();
  return <div className="aui-modal-header border-foreground/10 flex h-11 shrink-0 items-center gap-2 border-b ps-3.5 pe-2">
    <img data-slot="aui_modal-brand" className="aui-modal-brand shrink-0 object-contain" src={brandLogoUrl} width={205} height={48} alt="威友科技" />
    <h2 id={titleId} tabIndex={-1} className="aui-modal-title min-w-0 flex-1 truncate text-[13px] font-medium outline-none">
      {view === 'list' && !sidebar ? state.historyArchived ? '封存聊天室' : '聊天紀錄' : state.conversationTitle === '新聊天' ? '生產情報助理' : state.conversationTitle}
    </h2>
    <div className="aui-modal-header-actions flex shrink-0 items-center gap-0.5">
      {!sidebar && <TooltipIconButton tooltip="聊天紀錄" aria-label="聊天紀錄" side="bottom" aria-pressed={view === 'list'}
        className="aui-modal-threads text-muted-foreground hover:text-foreground aria-pressed:bg-muted aria-pressed:text-foreground size-7 rounded-md p-0"
        onClick={actions.toggleHistory}><HistoryIcon className="size-3.5" /></TooltipIconButton>}
      {!sidebar && <ThreadListPrimitive.New asChild><TooltipIconButton tooltip="新聊天" aria-label="新聊天" side="bottom"
        className="aui-modal-new text-muted-foreground hover:text-foreground size-7 rounded-md p-0"><PlusIcon className="size-3.5" /></TooltipIconButton></ThreadListPrimitive.New>}
      {!mobile && <TooltipIconButton tooltip={state.expanded ? '縮小聊天室' : '放大聊天室'} aria-label={state.expanded ? '縮小聊天室' : '放大聊天室'}
        className="text-muted-foreground hover:text-foreground size-7 rounded-md p-0" onClick={actions.toggleExpanded}>{state.expanded ? <Minimize2Icon className="size-3.5" /> : <Maximize2Icon className="size-3.5" />}</TooltipIconButton>}
      <AssistantMoreMenu />
      <TooltipIconButton tooltip="收合聊天室" aria-label="收合聊天室" className="text-muted-foreground hover:text-foreground size-7 rounded-md p-0" onClick={actions.closeChat}><XIcon className="size-3.5" /></TooltipIconButton>
    </div>
  </div>;
};

const AssistantModalThreadList: FC<{ onSelect: () => void }> = ({
  onSelect,
}) => {
  const [search, setSearch] = useState("");
  const {state} = useMesUi();
  const hasThreads = state.conversations.length > 0;

  return (
    <ThreadListRoot
      className="aui-modal-thread-list bg-popover absolute inset-0 overflow-y-auto p-2"
      onClick={(event) => {
        const target = event.target as Element;
        if (target.closest("[data-slot='aui_thread-list-item-trigger']")) {
          onSelect();
        }
      }}
    >
      <ConversationListNavigation />
      {hasThreads && (
        <ThreadListSearch value={search} onValueChange={setSearch} />
      )}
      <ThreadListItems searchQuery={hasThreads ? search : ""} />
    </ThreadListRoot>
  );
};

const AssistantModalResizeHandle: FC<ComponentPropsWithoutRef<"button">> = (
  props,
) => {
  return (
    <button
      type="button"
      aria-label="調整聊天室大小"
      className="aui-modal-resize-handle group-hover/modal:border-foreground/15 hover:border-foreground/40 focus-visible:border-ring absolute start-0 top-0 z-10 size-6 cursor-nwse-resize touch-none rounded-ss-xl border-s-2 border-t-2 border-transparent transition-colors outline-none [clip-path:polygon(0_0,100%_0,100%_6px,6px_6px,6px_100%,0_100%)] motion-reduce:transition-none rtl:cursor-nesw-resize rtl:[clip-path:polygon(0_0,100%_0,100%_100%,calc(100%_-_6px)_100%,calc(100%_-_6px)_6px,0_6px)]"
      {...props}
    />
  );
};

type AssistantModalButtonProps = { "data-state"?: "open" | "closed" };

const AssistantModalButton = forwardRef<
  HTMLButtonElement,
  AssistantModalButtonProps
>(({ "data-state": state, ...rest }, ref) => {
  const tooltip = state === "open" ? "收合聊天室" : "開啟生產情報助理";

  return (
    <TooltipIconButton
      variant="ghost"
      tooltip={tooltip}
      aria-label={tooltip}
      side="left"
      {...rest}
      className="aui-modal-button bg-background text-foreground border-border/60 hover:border-border hover:bg-background size-full rounded-full border transition-[border-color,scale] duration-150 ease-out active:scale-96 motion-reduce:transition-none"
      ref={ref}
    >
      <BotIcon
        data-state={state}
        className="aui-modal-button-closed-icon absolute size-5 transition-[scale,opacity,filter] duration-200 ease-[cubic-bezier(0.2,0,0,1)] data-[state=closed]:scale-100 data-[state=closed]:opacity-100 data-[state=closed]:blur-[0px] data-[state=open]:scale-25 data-[state=open]:opacity-0 data-[state=open]:blur-[4px] motion-reduce:transition-none"
      />

      <ChevronDownIcon
        data-state={state}
        className="aui-modal-button-open-icon absolute size-5 transition-[scale,opacity,filter] duration-200 ease-[cubic-bezier(0.2,0,0,1)] data-[state=closed]:scale-25 data-[state=closed]:opacity-0 data-[state=closed]:blur-[4px] data-[state=open]:scale-100 data-[state=open]:opacity-100 data-[state=open]:blur-[0px] motion-reduce:transition-none"
      />
    </TooltipIconButton>
  );
});

AssistantModalButton.displayName = "AssistantModalButton";
