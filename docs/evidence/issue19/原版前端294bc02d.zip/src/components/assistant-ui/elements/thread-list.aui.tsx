"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { groupConversations } from "@/chat/core";
import { useMesUi } from "@/chat/mes-ui-context";
import type { Conversation } from "@/chat/types";
import { ConversationActionsMenu } from "@/features/conversations/ConversationActionsMenu";
import { ConversationListNavigation } from "@/features/conversations/ConversationListNavigation";
import {
  AuiIf,
  ThreadListItemPrimitive,
  ThreadListPrimitive,
  useAuiState,
} from "@assistant-ui/react";
import {
  Loader2Icon,
  PinIcon,
  PlusIcon,
  SearchIcon,
} from "lucide-react";
import {
  forwardRef,
  Fragment,
  useMemo,
  useState,
  useSyncExternalStore,
  type ComponentPropsWithoutRef,
  type FC,
} from "react";

export const ThreadList: FC = () => {
  const [search, setSearch] = useState("");
  const hasThreads = useAuiState((s) => s.threads.threadIds.length > 0);

  return (
    <ThreadListRoot>
      <ThreadListNew />
      <ConversationListNavigation />
      {hasThreads && (
        <ThreadListSearch value={search} onValueChange={setSearch} />
      )}
      <ThreadListItems searchQuery={hasThreads ? search : ""} />
    </ThreadListRoot>
  );
};

export const ThreadListSearch = forwardRef<
  HTMLInputElement,
  Omit<ComponentPropsWithoutRef<typeof Input>, "value" | "onChange"> & {
    value: string;
    onValueChange: (value: string) => void;
  }
>(({ className, value, onValueChange, ...props }, ref) => {
  return (
    <div data-slot="aui_thread-list-search" className="relative px-0.5 py-1">
      <SearchIcon
        data-slot="aui_thread-list-search-icon"
        className="text-muted-foreground pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2"
      />
      <Input
        ref={ref}
        type="search"
        value={value}
        onChange={(event) => onValueChange(event.target.value)}
        aria-label="搜尋已載入的聊天"
        placeholder="搜尋聊天"
        className={cn("h-8 ps-8 text-sm", className)}
        {...props}
      />
    </div>
  );
});

ThreadListSearch.displayName = "ThreadListSearch";

export const ThreadListRoot: FC<
  ComponentPropsWithoutRef<typeof ThreadListPrimitive.Root>
> = ({ className, ...props }) => {
  return (
    <ThreadListPrimitive.Root
      data-slot="aui_thread-list-root"
      className={cn("flex flex-col gap-0.5", className)}
      {...props}
    />
  );
};

export const ThreadListItems: FC<
  ComponentPropsWithoutRef<"div"> & { searchQuery?: string }
> = ({ className, searchQuery = "", ...props }) => {
  const {state, actions} = useMesUi();
  return (
    <div
      data-slot="aui_thread-list-items"
      className={cn("flex flex-col gap-0.5", className)}
      {...props}
    >
      <AuiIf condition={(s) => s.threads.isLoading && s.threads.threadIds.length === 0}>
        <ThreadListSkeleton />
      </AuiIf>
      <AuiIf condition={(s) => !s.threads.isLoading || s.threads.threadIds.length > 0}>
        <ThreadListItemGroups searchQuery={searchQuery} />
      </AuiIf>
      {state.historyStatus && !state.expired && !state.sessionNotice && <p role="status" className="text-muted-foreground px-2.5 py-2 text-xs">{state.historyStatus}</p>}
      {state.historyCursor && <Button type="button" variant="ghost" className="h-8 justify-center text-sm font-normal" disabled={state.historyLoading || state.expired} onClick={() => void actions.loadHistory(false)} data-action="history-more">載入更多聊天</Button>}
    </div>
  );
};

const startOfLocalDay = (date: Date) =>
  new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();

const subscribeToNextDay = (onDayChange: () => void) => {
  let timeout: number;
  const scheduleNextDay = () => {
    const now = new Date();
    const startOfTomorrow = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 1,
    ).getTime();
    timeout = window.setTimeout(() => {
      onDayChange();
      scheduleNextDay();
    }, startOfTomorrow - now.getTime());
  };
  scheduleNextDay();
  return () => window.clearTimeout(timeout);
};

const getStartOfToday = () => startOfLocalDay(new Date());

// 保留官方午夜更新與 SSR 行為，日期分組使用 MES 保存的活動時間。
const getServerStartOfToday = () => undefined;

const useStartOfToday = () =>
  useSyncExternalStore<number | undefined>(
    subscribeToNextDay,
    getStartOfToday,
    getServerStartOfToday,
  );

export type ThreadListGroup = { label: string; indices: number[] };

/** 只搜尋已載入的標題；分組沿用控制器的日期契約，不增加搜尋 API。 */
export const useThreadListGroups = (searchQuery = "") => {
  const threadIds = useAuiState((s) => s.threads.threadIds);
  const threadItems = useAuiState((s) => s.threads.threadItems);

  const query = searchQuery.trim().toLowerCase();
  const startOfToday = useStartOfToday();

  return useMemo(() => {
    const itemsById = new Map(threadItems.map((item) => [item.id, item]));
    const filteredIndices = threadIds
      .map((id, index) => ({ id, index }))
      .filter(
        ({ id }) =>
          !query ||
          (itemsById.get(id)?.title || "新聊天")
            .toLowerCase()
            .includes(query),
      )
      .map(({ index }) => index);
    if (startOfToday === undefined) {
      return { threadIds, filteredIndices, groups: null };
    }
    const datedItems = filteredIndices.map(index => {
      const item = itemsById.get(threadIds[index]);
      const conversation = item?.custom?.mesConversation as Conversation | undefined;
      return {index, is_pinned: conversation?.is_pinned, updated_at: conversation?.updated_at || item?.lastMessageAt?.toISOString(), created_at: conversation?.created_at};
    });
    const result: ThreadListGroup[] = groupConversations(datedItems, startOfToday)
      .map(group => ({label: group.label, indices: group.items.map(item => item.index)}));
    return { threadIds, filteredIndices, groups: result };
  }, [threadIds, threadItems, query, startOfToday]);
};

const ThreadListItemGroups: FC<{ searchQuery?: string }> = ({
  searchQuery = "",
}) => {
  const { threadIds, filteredIndices, groups } =
    useThreadListGroups(searchQuery);
  const query = searchQuery.trim();
  const {state} = useMesUi();

  if (query && filteredIndices.length === 0) {
    return (
      <div
        data-slot="aui_thread-list-empty"
        className="text-muted-foreground px-2.5 py-4 text-sm"
      >
        找不到符合的聊天
      </div>
    );
  }

  if (!groups) {
    return filteredIndices.map((index) => (
      <ThreadListPrimitive.ItemByIndex
        key={threadIds[index]}
        index={index}
        components={{ ThreadListItem }}
      />
    ));
  }

  if (!groups.length) return <p className="text-muted-foreground px-2.5 py-4 text-sm">{state.historyArchived ? '還沒有封存聊天室' : '還沒有歷史聊天'}</p>;

  return groups.map((group) => (
    <Fragment key={group.label}>
      <div
        data-slot="aui_thread-list-group-label"
        className="text-muted-foreground px-2.5 pt-3 pb-1 text-xs font-medium"
      >
        {group.label}
      </div>
      {group.indices.map((index) => (
        <ThreadListPrimitive.ItemByIndex
          key={threadIds[index]}
          index={index}
          components={{ ThreadListItem }}
        />
      ))}
    </Fragment>
  ));
};

export const ThreadListNew = forwardRef<
  HTMLButtonElement,
  ComponentPropsWithoutRef<typeof Button> & { labelClassName?: string }
>(({ className, labelClassName, children, ...props }, ref) => {
  return (
    <ThreadListPrimitive.New asChild>
      <Button
        ref={ref}
        type="button"
        variant="ghost"
        data-slot="aui_thread-list-new"
        data-action="new"
        className={cn(
          "hover:bg-muted data-active:bg-muted h-8 justify-start gap-2 rounded-md px-2.5 text-sm font-normal",
          className,
        )}
        {...props}
      >
        {children ?? (
          <>
            <PlusIcon
              data-slot="aui_thread-list-new-icon"
              className="size-4 shrink-0"
            />
            <span
              data-slot="aui_thread-list-new-label"
              className={cn("whitespace-nowrap", labelClassName)}
            >
              新聊天
            </span>
          </>
        )}
      </Button>
    </ThreadListPrimitive.New>
  );
});

ThreadListNew.displayName = "ThreadListNew";

const ThreadListSkeleton: FC = () => {
  return (
    <div className="flex flex-col gap-0.5">
      {Array.from({ length: 5 }, (_, i) => (
        <div
          key={i}
          role="status"
          aria-label="正在載入聊天"
          data-slot="aui_thread-list-skeleton-wrapper"
          className="flex h-8 items-center px-2.5"
        >
          <Skeleton
            data-slot="aui_thread-list-skeleton"
            className="h-3.5 w-full"
          />
        </div>
      ))}
    </div>
  );
};

export const ThreadListItem: FC = () => {
  const isRunning = useAuiState((s) => s.threadListItem.isRunning);
  const title = useAuiState((s) => s.threadListItem.title) || '新聊天';
  const conversation = useAuiState((s) => s.threadListItem.custom?.mesConversation as Conversation | undefined);
  const readOnly = conversation?.read_only || conversation?.legacy;

  return (
    <ThreadListItemPrimitive.Root
      data-slot="aui_thread-list-item"
      className="group hover:bg-muted focus-visible:bg-muted data-active:bg-muted has-focus-visible:bg-muted has-data-[state=open]:bg-muted relative flex h-11 items-center rounded-md transition-colors focus-visible:outline-none sm:h-8"
    >
      <ThreadListItemPrimitive.Trigger
        data-slot="aui_thread-list-item-trigger"
        data-conversation-id={conversation?.conversation_id}
        title={title}
        aria-label={readOnly ? `${title}，唯讀` : title}
        className="focus-visible:ring-ring/50 flex h-full min-w-0 flex-1 items-center rounded-md px-2.5 text-start text-sm outline-none focus-visible:ring-1"
      >
        {isRunning && (
          <Loader2Icon
            aria-hidden
            data-slot="aui_thread-list-item-running"
            className="text-muted-foreground me-1.5 size-3.5 shrink-0 animate-spin"
          />
        )}
        {conversation?.is_pinned && <PinIcon className="text-muted-foreground me-1.5 size-3.5 shrink-0" aria-label="已釘選" />}
        <span data-slot="aui_thread-list-item-title" className="min-w-0 flex-1 truncate">
          <ThreadListItemPrimitive.Title fallback="新聊天" />
        </span>
        {readOnly && <span className="text-muted-foreground ms-2 shrink-0 text-xs">唯讀</span>}
        {isRunning && <span className="sr-only">正在分析</span>}
      </ThreadListItemPrimitive.Trigger>
      {conversation && <ConversationActionsMenu conversation={conversation} />}
    </ThreadListItemPrimitive.Root>
  );
};
