import * as React from 'react';
import ReactMarkdown from 'react-markdown';
import type {Components} from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {Table, TableBody, TableCell, TableHead, TableHeader, TableRow} from './table';
import {cn} from '@/lib/utils';
import {headingSlug} from '@/lib/markdown-headings';

interface MarkdownNode {type: string; value?: string; depth?: number; children?: MarkdownNode[]; data?: {hProperties?: Record<string, unknown>}}
const headingText = (node: MarkdownNode): string => node.value || (node.children || []).map(headingText).join('');
function headingIds() {
    return (tree: MarkdownNode) => {
        const seen = new Map<string, number>();
        const visit = (node: MarkdownNode) => {
            if (node.type === 'heading') {
                const slug = headingSlug(headingText(node));
                const count = seen.get(slug) || 0;
                seen.set(slug, count + 1);
                node.data = {...node.data, hProperties: {...node.data?.hProperties, id: count ? slug + '-' + count : slug}};
            }
            node.children?.forEach(visit);
        };
        visit(tree);
    };
}

/** 非聊天文件的共用安全呈現層，使用與 assistant-ui 相同的 Markdown 引擎。 */
export function DocumentMarkdown({text, link, className}: {
    text: string;
    link: NonNullable<Components['a']>;
    className?: string;
}) {
    const components = React.useMemo<Components>(() => ({
        a: link,
        img: ({alt}) => <span className="text-muted-foreground">{alt || '圖片'}</span>,
        h1: ({children, id}) => <h1 id={id} className="mt-6 mb-3 text-xl font-semibold first:mt-0">{children}</h1>,
        h2: ({children, id}) => <h2 id={id} className="mt-6 mb-3 text-lg font-semibold">{children}</h2>,
        h3: ({children, id}) => <h3 id={id} className="mt-5 mb-2 text-base font-semibold">{children}</h3>,
        h4: ({children, id}) => <h4 id={id} className="mt-4 mb-2 text-base font-medium">{children}</h4>,
        p: ({children}) => <p className="my-3 leading-relaxed first:mt-0">{children}</p>,
        ul: ({children}) => <ul className="my-3 ms-5 list-disc space-y-1">{children}</ul>,
        ol: ({children}) => <ol className="my-3 ms-5 list-decimal space-y-1">{children}</ol>,
        blockquote: ({children}) => <blockquote className="my-3 border-s-2 border-border ps-4 text-muted-foreground">{children}</blockquote>,
        hr: () => <hr className="my-6 border-border" />,
        pre: ({children}) => <pre className="my-3 overflow-x-auto rounded-md bg-muted p-4 text-sm leading-relaxed">{children}</pre>,
        code: ({children}) => <code className="rounded-sm bg-muted px-1 font-mono text-sm">{children}</code>,
        table: ({children}) => <div className="my-4 min-w-0" role="region" tabIndex={0} aria-label="文件表格，可左右捲動"><Table>{children}</Table></div>,
        thead: ({children}) => <TableHeader>{children}</TableHeader>,
        tbody: ({children}) => <TableBody>{children}</TableBody>,
        tr: ({children}) => <TableRow>{children}</TableRow>,
        th: ({children, align}) => <TableHead className={align === 'right' ? 'text-right' : align === 'center' ? 'text-center' : ''}>{children}</TableHead>,
        td: ({children, align}) => <TableCell className={cn('whitespace-normal', align === 'right' ? 'text-right' : align === 'center' ? 'text-center' : '')}>{children}</TableCell>,
    }), [link]);
    return <div className={cn('min-w-0 break-words text-sm', className)}>
        <ReactMarkdown remarkPlugins={[remarkGfm, headingIds]} components={components} skipHtml urlTransform={url => url}>{text}</ReactMarkdown>
    </div>;
}
