import { createRoot } from 'react-dom/client'
import { previewEnvironment } from './environment'
import { mountCopilot } from './mount'
import { PreviewHost } from './preview'
import './styles.css'
import './preview.css'

const host = document.getElementById('mes-ai-preview-root')
if (location.pathname.replace(/\/$/, '') === '/docs') {
    // 文件是獨立的唯讀預覽入口，不建立聊天控制器、不讀登入／金鑰、不呼叫模型。
    if (host) import('./features/documentation/DocumentationPage').then(({DocumentationPage}) => {
        createRoot(host).render(<DocumentationPage />)
    }).catch(() => {
        createRoot(host).render(<main className="min-h-dvh bg-background p-6 text-foreground" role="alert">無法載入文件頁，請重新整理</main>)
    })
} else {
    const environment = previewEnvironment()
    if (host) createRoot(host).render(<PreviewHost apiBaseUrl={environment.config.apiBaseUrl} />)
    mountCopilot(environment.config, environment.prefix, import.meta.env.BASE_URL)
}
