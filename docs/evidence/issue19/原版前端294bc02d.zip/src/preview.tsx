import {useState, type FormEvent} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';

/** 預覽宿主不是產品畫面，僅提供本機 API 設定。 */
export function PreviewHost({apiBaseUrl = ''}: {apiBaseUrl?: string}) {
    const [address, setAddress] = useState(apiBaseUrl);
    function update(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        const url = new URL(location.href);
        url.searchParams.set('apiBaseUrl', address.trim().replace(/\/$/, ''));
        location.assign(url.href);
    }
    return <main className="min-h-dvh bg-background p-6 text-foreground sm:p-10">
        <section className="mx-auto max-w-xl space-y-6 pt-10">
            <div className="space-y-2"><h1 className="text-xl font-medium">Emerald 生產情報助理</h1>
                <p className="text-sm text-muted-foreground">從右下角開啟 assistant-ui 聊天介面</p></div>
            <form id="preview-settings" className="space-y-2" onSubmit={update}>
                <Label htmlFor="preview-api-base">AI API 服務網址</Label>
                <div className="flex flex-col gap-2 sm:flex-row"><Input id="preview-api-base" type="url" required value={address}
                    onChange={event => setAddress(event.target.value)} placeholder="http://127.0.0.1:8000" />
                    <Button type="submit">更新網址</Button></div>
            </form>
            <Button asChild variant="outline"><a href="/docs">查看工程文件</a></Button>
        </section>
    </main>;
}
