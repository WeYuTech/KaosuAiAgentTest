'use strict';
// 讓視覺規範在建置時生效，避免頁面再次引入自訂色碼或尺寸。
const fs = require('node:fs');
const path = require('node:path');
const postcss = require('postcss');
const valueParser = require('postcss-value-parser');
const root = path.resolve(__dirname, '..');
const tokenFile = path.join(root, 'design-tokens.css');
const stylesFile = path.join(root, 'src/styles.css');
const manifestFile = path.join(root, 'src/components/assistant-ui/來源清單.json');
const sourceThemeFile = path.join(root, 'src/components/assistant-ui/上游來源/starter-globals.css');
const originalFiles = new Set();
if (fs.existsSync(manifestFile)) {
    const manifest = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
    for (const registry of manifest.登錄 || []) for (const file of registry.檔案 || []) originalFiles.add(path.resolve(root, file.專案檔案));
}
const officialDeclarations = new Set();
const declarationKey = decl => decl.prop + ':' + decl.value.replace(/\s+/g, ' ').trim();
if (fs.existsSync(sourceThemeFile)) postcss.parse(fs.readFileSync(sourceThemeFile, 'utf8')).walkDecls(decl => officialDeclarations.add(declarationKey(decl)));
const protectedType = /^(?:font(?:-.+)?|line-height|letter-spacing|border(?:-.+)?-radius)$/;
const namedColors = /^(?:white|black|red|blue|green|gray|grey|yellow|orange|purple|pink|navy|teal|aqua|lime|maroon|olive|silver|fuchsia|rebeccapurple|transparent)$/i;
const sizeUnit = /^-?(?:\d+\.?\d*|\.\d+)(?:px|rem|em|vw|vh|dvh|svh|vmin|vmax|ch|ex|pt|pc|cm|mm|q|in)$/i;
const spacingProperty = /^(?:margin|padding)(?:-.+)?$|^(?:gap|row-gap|column-gap)$/;
const colorProperty = /^(?:color|background(?:-color)?|border(?:-(?:top|right|bottom|left))?(?:-(?:color|width|style))?|outline(?:-(?:color|width|style))?|box-shadow|text-shadow|fill|stroke|caret-color|accent-color|text-decoration-color)$/;
const structuralWords = new Set(['none', 'solid', 'dashed', 'dotted', 'double', 'inset', 'outset', 'inherit', 'initial', 'unset', 'currentcolor', 'revert', 'repeat', 'no-repeat', 'cover', 'contain', 'center', 'left', 'right', 'top', 'bottom', 'scroll', 'fixed', 'local', 'border-box', 'padding-box', 'content-box', 'normal']);

function filesIn(directory) {
    return fs.readdirSync(directory, {withFileTypes: true}).flatMap(entry => {
        if (['node_modules', 'tests', 'scripts', 'dist', '上游來源'].includes(entry.name)) return [];
        const full = path.join(directory, entry.name);
        return entry.isDirectory() ? filesIn(full) : [full];
    });
}
function auditCss(source, filename, tokens) {
    const errors = [];
    const report = (decl, reason) => errors.push(path.basename(filename) + ':' + decl.source.start.line + ' ' + reason);
    postcss.parse(source, {from: filename}).walkDecls(decl => {
        // 原始值唯一允許出現在 token 宣告檔；其他檔只可引用它們。
        if (path.resolve(filename) === tokenFile) {
            if (!decl.prop.startsWith('--')) report(decl, 'tokens 檔只能定義設計變數');
            return;
        }
        // 本機字型的官方 family、weight、unicode-range 與資產來源描述不屬於頁面視覺值。
        if (path.resolve(filename) === stylesFile && decl.parent.type === 'atrule' && decl.parent.name === 'font-face') return;
        // 只允許官方 Starter 已記錄的宣告保留原始數值；自訂樣式仍受 tokens 規範。
        if (path.resolve(filename) === stylesFile && officialDeclarations.has(declarationKey(decl))) return;
        if (/#(?:[a-f\d]{3,8})\b|\b(?:rgb|rgba|hsl|hsla|oklch|oklab|lab|lch|color)\(/i.test(decl.value)) report(decl, '禁止直接使用色碼，請引用色彩 token');
        if (/gradient\(|backdrop-filter/i.test(decl.value + ' ' + decl.prop)) report(decl, '自訂頁面不得新增漸層或毛玻璃裝飾');
        valueParser(decl.value).walk(node => {
            if (node.type === 'function' && node.value === 'var') {
                const name = node.nodes.find(item => item.type === 'word')?.value;
                if (!name?.startsWith('--') || !tokens.has(name)) report(decl, '未定義的語意 token：' + name);
                if (node.nodes.some(item => item.type === 'div' && item.value === ',')) report(decl, '禁止在頁面替 token 設定任意 fallback');
                return false;
            }
            if (node.type !== 'word') return;
            if (namedColors.test(node.value) || colorProperty.test(decl.prop) && /^[a-z]+$/i.test(node.value) && !structuralWords.has(node.value.toLowerCase())) report(decl, '顏色須使用語意 token：' + node.value);
            // 100% 視窗寬高是滿版結構；其他任意 vw/vh 數值仍必須集中於 tokens。
            const fullscreen = /^100(?:vw|vh|dvh|svh)$/.test(node.value) && /^(?:width|height|min-width|max-width|min-height|max-height)$/.test(decl.prop);
            if (sizeUnit.test(node.value) && parseFloat(node.value) !== 0 && !fullscreen) report(decl, '固定尺寸或間距須使用 token：' + node.value);
            if (spacingProperty.test(decl.prop) && /^-?(?:\d+\.?\d*|\.\d+)%$/.test(node.value) && parseFloat(node.value) !== 0) report(decl, '比例間距須使用 token：' + node.value);
            if (protectedType.test(decl.prop) && /^-?(?:\d+\.?\d*|\.\d+)(?:%)?$/.test(node.value) && Number(node.value) !== 0) report(decl, '字型或圓角數值須使用 token：' + node.value);
            if (decl.prop === 'font-weight' && /^(bold|bolder|lighter)$/.test(node.value)) report(decl, '字重須使用 token');
        });
    });
    return errors;
}
function auditScript(source, filename) {
    const errors = [];
    const official = originalFiles.has(path.resolve(filename));
    source.split(/\r?\n/).forEach((line, index) => {
        const where = path.basename(filename) + ':' + (index + 1);
        if (!official && (/\.style\.(?:padding|margin|gap|fontSize|fontFamily|fontWeight|lineHeight|letterSpacing|color|background|backgroundColor|borderRadius)\s*=/.test(line) || /\bstyle\s*=\s*["']/.test(line))) errors.push(where + ' 禁止頁面行內視覺樣式，請使用共用類別及 tokens');
        const foundation = /[\\/]components[\\/]ui[\\/]/.test(filename);
        // 非 HTTPS 宿主保留既有剪貼簿相容橋接；節點只在複製當下存在並立即移除。
        const clipboardBridge = path.basename(filename) === 'controller.ts' && /temp\.className = 'mes-ai-copy-target'/.test(line) && /document\.execCommand\('copy'\)/.test(line) && /temp\.remove\(\)/.test(line);
        if (/\.(?:js|jsx|ts|tsx)$/.test(filename) && !foundation && !official && !clipboardBridge && /(?:createElement|el)\(["'](?:button|input|textarea|aside|details|table)["']|<(?:button|input|textarea|dialog|table)\b/.test(line)) errors.push(where + ' 聊天優先重用 assistant-ui，基礎控制項重用既有 shadcn 元件');
        if (/window\.MesAiUI|dangerouslySetInnerHTML|\.innerHTML\s*=/.test(line)) errors.push(where + ' 不得恢復 DOM 工廠或直接插入資料 HTML');
        if (!foundation && !official && /(?:bg|text|border|ring|outline|fill|stroke)-(?:slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-\d/.test(line)) errors.push(where + ' 頁面色彩須引用語意 tokens');
        if (!foundation && !official && /(?:p[trblxyse]?|m[trblxyse]?|gap|text|font|rounded(?:-[trblse]+)?|border)-\[(?:#[^\]]+|\d[^\]]*)\]/.test(line)) errors.push(where + ' Tailwind 視覺任意值須改為設計尺度');
    });
    return errors;
}
function check() {
    const tokens = new Set();
    postcss.parse(fs.readFileSync(tokenFile, 'utf8')).walkDecls(decl => tokens.add(decl.prop));
    for (const theme of [stylesFile, path.join(root, 'node_modules/tailwindcss/theme.css')]) {
        if (fs.existsSync(theme)) postcss.parse(fs.readFileSync(theme, 'utf8')).walkDecls(decl => { if (decl.prop.startsWith('--')) tokens.add(decl.prop); });
    }
    const errors = [];
    if (fs.existsSync(stylesFile)) {
        const source = fs.readFileSync(stylesFile, 'utf8');
        // Tailwind 攤平套件 CSS 時不會替 ./files 重設基準；須保留顯式本機資產 URL。
        if (/@import\s+["']@fontsource/.test(source)) errors.push('styles.css 字型須使用顯式本機 @font-face，不能以套件 CSS @import 產生失效 ./files 路徑');
        postcss.parse(source, {from: stylesFile}).walkAtRules('font-face', rule => {
            rule.walkDecls('src', decl => valueParser(decl.value).walk(node => {
                if (node.type !== 'function' || node.value !== 'url') return;
                const url = node.nodes.find(item => item.type === 'string' || item.type === 'word')?.value;
                const target = url ? path.resolve(path.dirname(stylesFile), url) : '';
                if (!target.startsWith(path.join(root, 'node_modules') + path.sep) || !target.endsWith('.woff2') || !fs.existsSync(target)) errors.push('styles.css 字型資產必須指向存在的本機 WOFF2：' + url);
                return false;
            }));
        });
    }
    const files = filesIn(path.join(root, 'src')).concat([tokenFile]);
    for (const file of files) {
        if (file.endsWith('.css')) errors.push(...auditCss(fs.readFileSync(file, 'utf8'), file, tokens));
        if (/\.(?:js|jsx|ts|tsx|html)$/.test(file)) errors.push(...auditScript(fs.readFileSync(file, 'utf8'), file));
    }
    if (errors.length) throw new Error('設計規範檢查失敗：\n' + errors.join('\n'));
    console.log('設計規範檢查通過：官方 assistant-ui 模板、語意主題與自訂頁面 tokens 符合規範。');
}
if (require.main === module) check();
module.exports = {auditCss, auditScript, check};
