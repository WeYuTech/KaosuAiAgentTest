'use strict';
// 只發布人工核准的工程文件，不遍歷檔案或匯出本機設定、原始資料與診斷。
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const frontend = path.resolve(__dirname, '..');
const repository = path.resolve(frontend, '../..');
const output = path.join(frontend, 'public/documentation');
const published = [
    ['capabilities', '可查模組與問法', '工單、產量、OEE、查詢範例與目前限制', 'docs/Emerald_目前能力與接口.md'],
    ['deployment', '安裝與部署', '設定、資料來源、啟動及宿主整合', 'docs/Emerald_正式資料模式與部署.md'],
    ['architecture', '系統架構', '模型、查詢、驗證與保存的責任邊界', 'docs/Emerald_LangGraph問答架構.md'],
    ['conversation', '多輪對話契約', '澄清承接、回應種類與授權保存結果整理', 'docs/Emerald_多輪對話.md'],
    ['semantics', 'MES 業務語意契約', '表與欄位定義、資料關係及核准限制', 'docs/EMERALD_業務語意契約.md'],
    ['overview', '文件導覽', '六份核心文件、技術參考與封存入口', 'docs/README.md'],
];
function createCatalog() {
    return published.flatMap(([id, title, summary, source]) => {
        const absolute = path.resolve(repository, source);
        if (!absolute.startsWith(repository + path.sep)) throw new Error('文件來源超出專案目錄');
        if (!fs.existsSync(absolute)) throw new Error('缺少白名單文件：' + source);
        const raw = fs.readFileSync(absolute);
        if (raw.length > 2 * 1024 * 1024) throw new Error('文件過大：' + source);
        const markdown = raw.toString('utf8');
        // 未通過時僅回報檔名，不回印疑似秘密值。
        if (/\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}/.test(markdown) || /\b(?:Password|Pwd)\s*=\s*[^\s;<${][^;\s]{5,}/i.test(markdown)) throw new Error('文件含疑似秘密，拒絕發布：' + source);
        const sha256 = crypto.createHash('sha256').update(raw).digest('hex');
        return [{id, title, summary, source, asset: id + '-' + sha256.slice(0, 12) + '.md', bytes: raw.length, sha256, raw}];
    });
}
function generate() {
    const documents = createCatalog();
    fs.mkdirSync(output, {recursive: true});
    // 此目錄專用於固定清單產物，只清理相同命名契約的舊 Markdown。
    const names = new Set(documents.map(document => document.asset));
    for (const name of fs.readdirSync(output)) {
        if (/^[a-z-]+-[a-f0-9]{12}\.md$/.test(name) && !names.has(name)) fs.unlinkSync(path.join(output, name));
    }
    for (const document of documents) fs.writeFileSync(path.join(output, document.asset), document.raw);
    const catalog = {version: 1, documents: documents.map(({raw, ...document}) => document)};
    fs.writeFileSync(path.join(output, 'index.json'), JSON.stringify(catalog, null, 2) + '\n', 'utf8');
    console.log('已發布白名單工程文件：' + documents.length + ' 份，僅供預覽 /docs 使用');
}
if (require.main === module) generate();
module.exports = {createCatalog};
