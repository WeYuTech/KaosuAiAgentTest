'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// 使用鎖檔列出的非開發相依套件，加上產生正式 CSS 的套件與複製的 shadcn 原文。
// 只讀授權與 package.json，不掃描宿主設定，也不需要連網或金鑰。
const root = path.resolve(__dirname, '..');
const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
const overrides = JSON.parse(fs.readFileSync(path.join(__dirname, 'license-overrides.json'), 'utf8'));
const buildCss = new Set(['node_modules/tailwindcss', 'node_modules/tw-animate-css']);
const groups = new Map();
const missing = [];
let count = 0;

function addLicense(label, text, source) {
  const normalized = text.replace(/\r\n/g, '\n').trim();
  if (!normalized) throw new Error('授權原文為空：' + label);
  const hash = crypto.createHash('sha256').update(normalized).digest('hex');
  const group = groups.get(hash) || {text: normalized, labels: [], sources: []};
  group.labels.push(label);
  if (source && !group.sources.includes(source)) group.sources.push(source);
  groups.set(hash, group);
}

for (const [relative, metadata] of Object.entries(lock.packages).sort(([a], [b]) => a.localeCompare(b, 'en'))) {
  if (!relative || (metadata.dev && !buildCss.has(relative))) continue;
  const directory = path.resolve(root, relative);
  if (!directory.startsWith(path.join(root, 'node_modules') + path.sep)) throw new Error('相依套件位置超出 node_modules');
  const pkg = JSON.parse(fs.readFileSync(path.join(directory, 'package.json'), 'utf8'));
  const label = `${pkg.name} ${pkg.version}`;
  const files = fs.readdirSync(directory).filter(name => /^(licen[cs]e|copying|notice)(\.|$)/i.test(name) && fs.statSync(path.join(directory, name)).isFile()).sort();
  count += 1;
  if (files.length) {
    for (const name of files) addLicense(label, fs.readFileSync(path.join(directory, name), 'utf8'));
  } else if (overrides[pkg.name]?.原文) {
    addLicense(label, overrides[pkg.name].原文, overrides[pkg.name].來源);
  } else {
    const declared = typeof pkg.license === 'string' ? pkg.license : metadata.license || '未宣告';
    const repository = typeof pkg.repository === 'string' ? pkg.repository : pkg.repository?.url || pkg.homepage || '';
    missing.push({label, declared, repository});
  }
}
addLicense('shadcn/ui 官方複製元件', fs.readFileSync(path.join(root, 'src/components/ui/LICENSE.md'), 'utf8'), 'https://github.com/shadcn-ui/ui/blob/main/LICENSE.md');

const sections = ['# 第三方元件與授權原文', '',
  '本檔由 `npm run licenses` 依 `package-lock.json` 與本機套件授權檔產生，隨靜態部署包保留著作權及授權原文。英文法律文字依上游保留，不改寫。相同原文合併列示；套件列入清單不代表它的全部功能都會執行。', '',
  'assistant-ui 採 MIT 授權；本專案使用外部狀態 runtime，未啟用 Assistant Cloud 服務。清單仍保留非開發相依套件的授權，包含其傳遞相依套件。', '',
  `共核對 ${count} 個非開發／正式 CSS 套件項目與 shadcn 複製元件。`, ''];
let index = 0;
for (const group of groups.values()) {
  sections.push(`## 授權原文 ${++index}`, '', `套件：${group.labels.join('、')}`, '');
  if (group.sources.length) sections.push('補充原文來源：' + group.sources.map(url => `[官方儲存庫](${url})`).join('、'), '');
  sections.push('```text', group.text, '```', '');
}
if (missing.length) {
  sections.push('## 上游未提供完整授權原文的套件', '',
    '以下套件的發布內容未附獨立授權／著作權檔；保留上游 `package.json` 的授權宣告與儲存庫，不自行補造作者或著作權文字。需要新增上游授權原文時，將可核對來源加入 `scripts/license-overrides.json` 後重新產生。', '');
  for (const item of missing) sections.push(`- ${item.label}：宣告 ${item.declared}；來源 ${item.repository ? `[官方儲存庫](${item.repository.replace(/^git\+/, '').replace(/\.git$/, '')})` : '未提供'}。`);
  sections.push('');
}
fs.writeFileSync(path.join(root, 'THIRD_PARTY_LICENSES.md'), sections.join('\n'), 'utf8');
console.log(`已產生第三方授權：${count} 個套件項目、${groups.size} 份不同原文；${missing.length} 個發布套件未附獨立原文。`);
