'use strict';
const fs = require('node:fs');
const path = require('node:path');
const source = path.resolve(__dirname, '..');
const destination = path.resolve(source, '../../outputs/wwwroot-mes-ai-copilot-folder-v2/wwwroot/mes-ai-copilot');
const artifacts = ['loader.js', 'config.js', 'assets/mes-ai-widget.js', 'assets/mes-ai-widget.css', 'weyu-logo.png', 'weyu-brand.svg'];
const documents = ['README.md', 'DESIGN_SYSTEM.md', 'THIRD_PARTY_LICENSES.md'];
// 只移除已由 React 取代的已知舊資源，避免部署時同時執行兩套聊天程式。
const obsolete = ['chat.js', 'chat-core.js', 'ui-components.js', 'chat.css', 'components.css', 'design-tokens.css', 'tailwind.css', 'package.json', 'package-lock.json', 'tailwind.config.cjs', 'src/tailwind.input.css', 'scripts/check-design-system.cjs'];
for (const relative of artifacts) {
    const file = path.join(source, 'dist', relative);
    if (!fs.existsSync(file)) throw new Error('缺少 React 建置資源：' + relative);
}
fs.mkdirSync(destination, {recursive: true});
for (const relative of artifacts) {
    const target = path.resolve(destination, relative);
    if (!target.startsWith(destination + path.sep)) throw new Error('部署資源超出目錄');
    fs.mkdirSync(path.dirname(target), {recursive: true});
    fs.copyFileSync(path.join(source, 'dist', relative), target);
}
for (const relative of documents) fs.copyFileSync(path.join(source, relative), path.join(destination, relative));
for (const relative of obsolete) {
    const target = path.resolve(destination, relative);
    if (!target.startsWith(destination + path.sep)) throw new Error('舊資源超出目錄');
    if (fs.existsSync(target) && fs.statSync(target).isFile()) fs.unlinkSync(target);
}
console.log('已同步 assistant-ui 正式部署資源：' + (artifacts.length + documents.length) + ' 個檔案。');
