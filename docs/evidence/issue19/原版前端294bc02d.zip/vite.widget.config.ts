import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [react()],
  define: { 'process.env.NODE_ENV': JSON.stringify('production') },
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  build: {
    outDir: 'dist', emptyOutDir: false, copyPublicDir: false,
    lib: {
      entry: fileURLToPath(new URL('./src/widget.tsx', import.meta.url)),
      name: 'EmeraldMesAiWidget', formats: ['iife'], fileName: () => 'assets/mes-ai-widget.js', cssFileName: 'assets/mes-ai-widget',
    },
    sourcemap: false,
  },
})
