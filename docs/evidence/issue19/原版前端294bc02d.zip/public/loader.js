/* 正式 MES 的輕量嵌入入口；聊天畫面由編譯後的 assistant-ui 官方元件呈現。 */
(function loadEmeraldReactWidget() {
    'use strict';
    const current = document.currentScript;
    const prefix = typeof PROJECT_SAVE_NAME === 'string' ? PROJECT_SAVE_NAME : '';
    try {
        const account = String(localStorage.getItem(prefix + '_BI_accountNo') || '').trim().toUpperCase();
        if (account !== 'ADMINV2' || !localStorage.getItem(prefix + '_BI_TokenKey') || !(Date.parse(localStorage.getItem(prefix + '_BI_TokenExpiry') || '') > Date.now())) return;
    } catch (_error) { return; }
    if (!current || window.__MES_AI_CHAT_INITIALIZED__ || document.querySelector('script[data-mes-ai-copilot-react]')) return;
    const loaderUrl = new URL(current.src);
    const base = new URL('.', loaderUrl);
    function asset(name) { const url = new URL(name, base); url.search = loaderUrl.search; return url.href; }
    function script(name, marker) {
        return new Promise(function (resolve, reject) {
            const element = document.createElement('script');
            element.src = asset(name); element.onload = resolve; element.onerror = reject;
            if (marker) element.dataset.mesAiCopilotReact = 'true';
            document.head.appendChild(element);
        });
    }
    function stylesheet() {
        return new Promise(function (resolve, reject) {
            const element = document.createElement('link');
            element.rel = 'stylesheet'; element.href = asset('assets/mes-ai-widget.css');
            element.dataset.mesAiCopilotStyle = 'assistant-ui';
            element.onload = resolve; element.onerror = reject; document.head.appendChild(element);
        });
    }
    script('config.js').then(stylesheet).then(function () {
        return script('assets/mes-ai-widget.js', true);
    }).catch(function () { console.warn('生產情報助理資源載入失敗，請重新載入頁面'); });
})();
