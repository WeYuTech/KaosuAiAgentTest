window.MES_AI_COPILOT_CONFIG = Object.assign({
    apiBaseUrl: '',
    productionLabel: 'EMERALD',
    brandSubtitle: 'AI × 製造數據洞察・即時解答生產現場問題',
    inputPlaceholder: '輸入生產問題…',
    historyPageSize: 20,
    metricsDays: 30,
    apiRequestTimeoutMs: 30000,
    watchTimeoutMs: 120000,
    pollIntervalMs: 2000,
    adminAccounts: ['ADMINV2']
}, window.MES_AI_COPILOT_CONFIG || {});
