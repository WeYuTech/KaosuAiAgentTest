import {readFileSync} from 'node:fs';
import {transformSync} from 'esbuild';

/** 執行實際 Provider 原始碼與生命週期，僅替換其控制器及 React hook 邊界 */
export function createProviderHarness<T>(file: URL, exportedName: string, dependencies: Record<string, unknown>) {
    const slots: any[] = [];
    let cursor = 0, dirty = true, current: T, stopped = false, effects: (() => void)[] = [];
    const same = (a: unknown[] | undefined, b: unknown[] | undefined) => a && b && a.length === b.length && a.every((value, index) => Object.is(value, b[index]));
    const react = {
        createContext: (value: unknown) => ({Provider: {}, value}),
        useContext: (context: {value: unknown}) => context.value,
        useState(initial: unknown) {
            const index = cursor++, slot = slots[index] ??= {value: typeof initial === 'function' ? initial() : initial};
            return [slot.value, (next: unknown) => {
                if (stopped) return;
                const value = typeof next === 'function' ? next(slot.value) : next;
                if (!Object.is(value, slot.value)) {slot.value = value; dirty = true;}
            }];
        },
        useRef(initial: unknown) {return slots[cursor++] ??= {current: initial};},
        useMemo(factory: () => unknown, deps: unknown[]) {
            const index = cursor++, previous = slots[index];
            if (!previous || !same(previous.deps, deps)) slots[index] = {deps, value: factory()};
            return slots[index].value;
        },
        useCallback(callback: unknown, deps: unknown[]) {return react.useMemo(() => callback, deps);},
        useEffect(effect: () => unknown, deps: unknown[]) {
            const index = cursor++, previous = slots[index];
            if (!previous || !same(previous.deps, deps)) {
                const slot = slots[index] ??= {}; slot.deps = deps;
                effects.push(() => {slot.cleanup?.(); slot.cleanup = effect();});
            }
        },
        useLayoutEffect(effect: () => unknown, deps: unknown[]) {react.useEffect(effect, deps);},
    };
    const modules: Record<string, unknown> = {...dependencies, react, 'react/jsx-runtime': {jsx: (_type: unknown, props: unknown) => props, jsxs: (_type: unknown, props: unknown) => props}};
    const code = transformSync(readFileSync(file, 'utf8'), {loader: 'tsx', format: 'cjs', jsx: 'automatic', target: 'es2022'}).code;
    const module = {exports: {} as Record<string, (props: {children: null}) => {value: T}>};
    new Function('require', 'module', 'exports', code)((name: string) => {
        if (!(name in modules)) throw new Error(`測試未提供依賴 ${name}`);
        return modules[name];
    }, module, module.exports);
    const Provider = module.exports[exportedName]!;
    function flush() {
        for (let round = 0; dirty; round++) {
            if (round === 30) throw new Error('Provider 未能穩定');
            dirty = false; cursor = 0; effects = []; current = Provider({children: null}).value;
            const queued = effects; effects = []; queued.forEach(effect => effect());
        }
        return current;
    }
    return {
        render() {if (stopped) throw new Error('Provider 已卸載'); dirty = true; return flush();},
        get current() {return current;},
        act<R>(action: (value: T) => R) {const result = action(current); flush(); return result;},
        async settle() {await new Promise(resolve => setImmediate(resolve)); return flush();},
        unmount() {stopped = true; slots.forEach(slot => slot?.cleanup?.());},
    };
}

export function deferred<T>() {
    let resolve!: (value: T) => void, reject!: (reason?: unknown) => void;
    const promise = new Promise<T>((accept, decline) => {resolve = accept; reject = decline;});
    return {promise, resolve, reject};
}
