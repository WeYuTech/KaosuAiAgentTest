import {decodeReportCard} from '../src/chat/report-decoder';
import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import type {RawReportCard as ReportCard, SemanticReportColumn} from '../src/chat/types';

// 使用產品元件與實際 JSX 設定，不以模擬表格取代摘要及明細的呈現分支
const scoped = register({namespace: 'report-summary-presentation', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {MesReportMetrics} = await scoped.import('../src/features/mes/MesReportDialog.tsx', import.meta.url) as typeof import('../src/features/mes/MesReportDialog');

function render(card: ReportCard, variant: 'summary' | 'table'): string {
    return renderToStaticMarkup(createElement(MesReportMetrics, {card: decodeReportCard(card), variant}));
}
function text(html: string): string {return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();}
function metricRow(html: string, key: string): string {
    const row = html.match(new RegExp(`<tr\\b[^>]*data-metric-key="${key}"[^>]*>[\\s\\S]*?<\\/tr>`));
    assert.ok(row, `必須呈現 ${key} 指標列`);
    return text(row[0]);
}
function workOrder(overrides: Partial<ReportCard> = {}): ReportCard {
    return {
        id: 'work-order', kind: 'work_order', title: '工單摘要', status: 'ok',
        metrics: [
            {key: 'completion_percent', label: '完成率', value: 0, unit: '%'},
            {key: 'produced_quantity', label: '已報工', value: 0},
            {key: 'planned_quantity', label: '目標', value: 100},
        ],
        detail: {rows: [{work_order_no: 'W1'}]},
        ...overrides,
    };
}
function semantic(): ReportCard {
    const columns: SemanticReportColumn[] = [
        {name: 'machine_id', label: '機台', role: 'dimension', data_type: 'string'},
        {name: 'good_quantity', label: '良品量', role: 'metric', data_type: 'number', unit: '公斤', completeness_required: true, required_missing_fields: ['missing_good_count']},
        {name: 'scrap_quantity', label: '不良量', role: 'metric', data_type: 'number', unit: '公斤', completeness_required: true, required_missing_fields: ['missing_scrap_count']},
        {name: 'negative_count', label: '異常紀錄數', role: 'quality', data_type: 'number'},
    ];
    return {
        id: 'semantic', kind: 'semantic_query', title: '保存報工資料', status: 'ok', semantic_fingerprint: 'saved-version', semantic_columns: columns,
        summary: {good_quantity: 77, scrap_quantity: 2, operation_count: 5, missing_good_count: 0, missing_scrap_count: 0, negative_count: 3},
        metrics: [
            {key: 'good_quantity', label: '良品量', value: 9999, unit: '公斤'},
            {key: 'scrap_quantity', label: '不良量', value: 2, unit: '公斤'},
            {key: 'negative_count', label: '異常紀錄數', value: 3, unit: '筆', detail: '已保存品質計數'},
        ],
        detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows: []},
    };
}

test('實際概要與指標表都把缺量工單的相容零完成率保留為未知', () => {
    for (const saved of [workOrder({quantity_complete: false}), workOrder({detail: {rows: [{quantity_complete: false}]}})]) {
        const before = structuredClone(saved);
        const summary = render(saved, 'summary'), table = render(saved, 'table');
        assert.match(summary, /<dt\b[^>]*>完成率<\/dt><dd\b[^>]*>未知<\/dd>/);
        assert.match(text(summary), /資料未完整取得/);
        assert.doesNotMatch(summary, /%/);
        assert.equal(metricRow(table, 'completion_percent'), '報工完成率 未知 資料未完整取得');
        assert.match(text(summary), /已知部分/);
        assert.match(metricRow(table, 'produced_quantity'), /已知部分/);
        assert.deepEqual(saved, before);
    }
});

test('有效零完成率在概要與指標表皆保留，不能一律遮蔽真正的零', () => {
    const saved = workOrder({quantity_complete: true});
    assert.match(text(render(saved, 'summary')), /完成率 0 %/);
    assert.equal(metricRow(render(saved, 'table'), 'completion_percent'), '報工完成率 0 % —');
});

test('語意摘要衝突在兩種實際呈現皆未知，另一個有效指標仍保留', () => {
    const saved = semantic(), before = structuredClone(saved);
    for (const variant of ['summary', 'table'] as const) {
        const html = render(saved, variant), visible = text(html);
        assert.match(visible, /良品量 未知 保存摘要數值不一致/);
        assert.doesNotMatch(visible, /\b77\b|9,999|9999/);
        assert.match(visible, /不良量 2 公斤/);
    }
    assert.equal(metricRow(render(saved, 'table'), 'good_quantity'), '良品量 未知 保存摘要數值不一致');
    assert.deepEqual(saved, before);
});

test('重點未涵蓋的品質計數仍留在指標表，不能因安全摘要而遺失原值與說明', () => {
    const saved = semantic();
    assert.doesNotMatch(text(render(saved, 'summary')), /異常紀錄數|已保存品質計數/);
    assert.equal(metricRow(render(saved, 'table'), 'negative_count'), '異常紀錄數 3 筆 已保存品質計數');
});
