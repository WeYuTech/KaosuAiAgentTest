import test from 'node:test';
import assert from 'node:assert/strict';
import {copyTextWithFallback} from '../src/hooks/use-copy-to-clipboard';

const content = '工單 145861\n完成率 = 已報工量 ÷ 目標量\n  SELECT [工單] FROM [MES];';

test('原生複製成功保留完整中文與換行，且不重複呼叫相容流程', async () => {
    const values: string[] = []; let fallbackCalls = 0;
    assert.equal(await copyTextWithFallback(content, {writeText: async value => {values.push(value);}}, () => {fallbackCalls++;}), true);
    assert.deepEqual(values, [content]); assert.equal(fallbackCalls, 0);
});

test('HTTP 宿主沒有 Clipboard API 時以原控制器複製一次，不把未知結果顯示為已複製', async () => {
    const values: string[] = [];
    assert.equal(await copyTextWithFallback(content, undefined, async value => {values.push(value);}), false);
    assert.deepEqual(values, [content]);
});

test('Clipboard 權限被拒後仍能交回原相容流程，失敗 Promise 不向外拋出', async () => {
    const values: string[] = [];
    assert.equal(await copyTextWithFallback(content, {writeText: async () => {throw new Error('denied');}}, value => {values.push(value);}), false);
    assert.deepEqual(values, [content]);
    assert.equal(await copyTextWithFallback(content, undefined, async () => {throw new Error('failed');}), false);
});

test('沒有文字或任何複製能力時不呼叫操作，也不產生假的成功狀態', async () => {
    let calls = 0;
    assert.equal(await copyTextWithFallback('', {writeText: async () => {calls++;}}, () => {calls++;}), false);
    assert.equal(await copyTextWithFallback(content), false); assert.equal(calls, 0);
});
