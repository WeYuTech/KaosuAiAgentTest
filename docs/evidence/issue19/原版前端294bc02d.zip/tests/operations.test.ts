import test from 'node:test';
import assert from 'node:assert/strict';
import {ChatController} from '../src/chat/controller';
import {ChatApi, ChatApiError, errorText} from '../src/chat/api';
import {budgetDraft, buildBudgetUpdate, isScheduledReport, ScheduleCreationIdentity, scheduledReportDisplay, scheduleTimeText, tokenText, type BudgetSnapshot, type BudgetUsage, type ParsedSchedule, type ScheduledReport} from '../src/chat/operations';

function usage(scope: 'system' | 'account'): BudgetUsage {
    return {scope, ...(scope === 'account' ? {account_no: 'ADMINV2'} : {}), config: {monthly_token_limit: null, warning_percent: 80, per_turn_reservation_tokens: 10000, revision: 2},
        confirmed_tokens: 12000, reserved_tokens: 10000, unknown_request_count: 1, active_request_count: 1, limit: null, reached: false, near_limit: false,
        remaining_tokens: null, usage_status: 'mixed', committed_tokens: 22000, used_percent: null};
}
function budget(): BudgetSnapshot {return {period: '2026-10', timezone: 'Asia/Taipei', billing_note: '用量紀錄不能當成精確帳單', system: usage('system'), account: usage('account'), management: {write_allowed: true}};}
const parsed: ParsedSchedule = {source_text: '每天早上九點給我機台和報工人員及產出報告', report_request: '上一個完整生產日的全廠機台、報工人員／組合與報工產出報告', report_scope: 'plant_machine_personnel_output', scope_label: '全廠機台、報工人員／組合與產出', frequency: 'daily', hour: 9, minute: 0, timezone: 'Asia/Taipei', data_window: 'previous_complete_production_day', next_run_at: '2026-10-09T01:00:00Z'};
const report: ScheduledReport = {title: '產出報告', status: 'ok', period_start: '2026-10-07T08:00:00+08:00', period_end: '2026-10-08T08:00:00+08:00', timezone: 'Asia/Taipei', data_source: '記憶體測試', generated_at: '2026-10-08T09:00:05+08:00',
    summary: {good_qty: 100, scrap_qty: 0, total_qty: 100, task_count: 1, machine_count: 1, personnel_count: 2}, machines: [{machine_id: 'M01', good_qty: 100, scrap_qty: 0, total_qty: 100, task_count: 1}], personnel: [{personnel_id: 'P01,P02', good_qty: 100, scrap_qty: null, total_qty: 100, task_count: 1}], warnings: ['多人共同報工以組合呈現']};

test('真正失敗或待確認callback報告不讀summary、不當成功數字，狀態優先於殘留完整報表', () => {
    const failed = {status: 'failed' as const, title: '報告查詢失敗'}, unknown = {status: 'submission_unknown' as const, title: '內部診斷訊息不應出現在介面'};
    assert.equal(isScheduledReport(failed), false);
    assert.equal(scheduledReportDisplay({status: 'failed', report: failed}).kind, 'unavailable');
    assert.equal(scheduledReportDisplay({status: 'completed', report: failed}).kind, 'unavailable');
    assert.equal(scheduledReportDisplay({status: 'failed', report}).kind, 'unavailable');
    const pending = scheduledReportDisplay({status: 'submission_unknown', report: unknown});
    assert.equal(pending.kind, 'unavailable'); assert.equal(JSON.stringify(pending).includes(unknown.title), false);
    assert.match(JSON.stringify(pending), /不能當成零產出/);
    assert.equal(scheduledReportDisplay({status: 'running', report}).kind, 'unavailable');
    assert.equal(scheduledReportDisplay({status: 'failed', report: null}).kind, 'unavailable');
});

test('完整保存報告才可顯示，缺漏summary／數字／列資料安全拒絕，已知0與null保持原值', () => {
    assert.equal(isScheduledReport(report), true);
    const ready = scheduledReportDisplay({status: 'completed', report});
    assert.equal(ready.kind, 'ready'); if (ready.kind === 'ready') {assert.equal(ready.report, report); assert.equal(ready.report.summary.scrap_qty, 0); assert.equal(ready.report.personnel[0]!.scrap_qty, null);}
    assert.equal(scheduledReportDisplay({status: 'completed', report: {...report, status: 'no_data'}}).kind, 'ready');
    for (const invalid of [{status: 'ok', title: '缺漏資料'}, {...report, summary: undefined}, {...report, summary: {...report.summary, total_qty: undefined}}, {...report, machines: [{}]}, {...report, personnel: null}, {...report, warnings: [null]}]) assert.equal(isScheduledReport(invalid), false);
});

test('額度只傳差異、原 revision 與帳號，留空解除上限而不是自動寫零', () => {
    const account = usage('account'), before = structuredClone(account), draft = budgetDraft(account.config);
    assert.deepEqual(buildBudgetUpdate(account, draft), {scope: 'account', account_no: 'ADMINV2', revision: 2});
    draft.monthlyTokenLimit = ' 0 '; draft.warningPercent = '90';
    assert.deepEqual(buildBudgetUpdate(account, draft), {scope: 'account', account_no: 'ADMINV2', revision: 2, monthly_token_limit: 0, warning_percent: 90});
    account.config.monthly_token_limit = 50000;
    assert.equal(buildBudgetUpdate(account, {...draft, monthlyTokenLimit: ''}).monthly_token_limit, null);
    assert.deepEqual(before.config, {monthly_token_limit: null, warning_percent: 80, per_turn_reservation_tokens: 10000, revision: 2});
    assert.deepEqual(buildBudgetUpdate(usage('system'), budgetDraft(usage('system').config)), {scope: 'system', revision: 2});
});

test('額度拒絕超限、負值、非整數，不讓介面四捨五入或偷偷改成合法設定', () => {
    const account = usage('account'), draft = budgetDraft(account.config);
    for (const value of ['-1', '1.5', '1e4', '9000000000000001', '文字']) assert.throws(() => buildBudgetUpdate(account, {...draft, monthlyTokenLimit: value}));
    for (const value of ['0', '101']) assert.throws(() => buildBudgetUpdate(account, {...draft, warningPercent: value}));
    for (const value of ['0', '1000000001']) assert.throws(() => buildBudgetUpdate(account, {...draft, reservationTokens: value}));
    assert.equal(buildBudgetUpdate(account, {...draft, monthlyTokenLimit: '9000000000000000', reservationTokens: '1000000000'}).monthly_token_limit, 9000000000000000);
});

test('未知用量不呈現零費用，排程預覽遵循後端台北時間而非瀏覽器時區', () => {
    for (const unknown of [undefined, null, '0', NaN]) assert.equal(tokenText(unknown), '尚未取得');
    assert.equal(tokenText(0), '0'); assert.equal(tokenText(12000), '12,000');
    assert.equal(scheduleTimeText(parsed), '每天 09:00（台北時間）');
    assert.equal(scheduleTimeText({...parsed, frequency: 'weekdays', minute: 15}), '週一至週五 09:15（台北時間）');
});

test('同一需求建立結果不明時保留識別碼，確認成功後才容許建立另一份', () => {
    let sequence = 0; const identity = new ScheduleCreationIdentity(() => `fixture-${++sequence}`);
    assert.equal(identity.forText('每天九點報告'), 'fixture-1');
    assert.equal(identity.forText('每天九點報告'), 'fixture-1');
    identity.confirmed(); assert.equal(identity.forText('每天九點報告'), 'fixture-2');
    assert.equal(identity.forText('每週一到五九點報告'), 'fixture-3');
});

function environment() {
    const values = new Map<string, string>([['X_BI_accountNo', 'ADMINV2'], ['X_BI_TokenKey', 'fixture-session'], ['X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString()]]);
    const storage = {getItem(key: string) {return values.get(key) ?? null;}, setItem(key: string, value: string) {values.set(key, value);}} as Storage;
    const originalWindow = globalThis.window;
    globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    return {storage, values, restore() {globalThis.window = originalWindow;}};
}
function json(value: unknown, status = 200) {return new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});}

test('用量／排程控制器統一帶 MES 登入並編碼識別碼，設定管理憑證僅進入該次請求', async () => {
    const env = environment(), calls: {url: string; options: RequestInit}[] = [];
    const controller = new ChatController({storage: env.storage, fetchImpl: async (url, options = {}) => {calls.push({url: String(url), options}); if (options.method === 'DELETE') return new Response(null, {status: 204}); if (String(url) === '/api/chat/schedules' && options.method === 'POST') return json({schedule_id: 'fixture-created', client_schedule_id: JSON.parse(String(options.body)).client_schedule_id}); return json(String(url).includes('/budget') ? budget() : {items: []});}}, 'X');
    try {
        controller.actions.setDraft('保留聊天草稿'); const before = controller.getSnapshot();
        await controller.actions.loadBudget('  fixture-management  ');
        const update = {scope: 'account' as const, account_no: 'ADMINV2', revision: 2, monthly_token_limit: 60000};
        await controller.actions.saveBudget(update, 'fixture-management');
        await controller.actions.loadSchedules(); await controller.actions.parseSchedule(parsed.source_text!);
        await controller.actions.createSchedule({client_schedule_id: 'fixture-create', text: parsed.source_text!});
        await controller.actions.updateSchedule('schedule/fixture', {revision: 4, status: 'paused'});
        await controller.actions.deleteSchedule('schedule/fixture', 5); await controller.actions.loadScheduleRuns('schedule/fixture');
        await controller.actions.loadSavedScheduleReports(); await controller.actions.loadScheduleRun('schedule/fixture', 'run/fixture');
        assert.equal(calls.length, 10); assert.equal(calls.some(call => /messages|cancel/.test(call.url)), false);
        assert.deepEqual(calls.map(call => call.options.method || 'GET'), ['GET', 'PATCH', 'GET', 'POST', 'POST', 'PATCH', 'DELETE', 'GET', 'GET', 'GET']);
        assert.equal(calls[6]!.url, '/api/chat/schedules/schedule%2Ffixture?revision=5');
        assert.equal(calls[9]!.url, '/api/chat/schedules/schedule%2Ffixture/runs/run%2Ffixture');
        for (const call of calls) {const headers = new Headers(call.options.headers); assert.equal(headers.get('TokenKey'), 'fixture-session'); assert.equal(headers.get('X-MES-Account-No'), 'ADMINV2');}
        assert.equal(new Headers(calls[0]!.options.headers).get('X-MES-Settings-Token'), 'fixture-management');
        for (const call of calls.slice(2)) assert.equal(new Headers(call.options.headers).has('X-MES-Settings-Token'), false);
        assert.deepEqual(JSON.parse(String(calls[1]!.options.body)), update);
        assert.equal(controller.getSnapshot().draft, '保留聊天草稿'); assert.equal(controller.getSnapshot(), before);
        assert.equal([...env.values.values()].some(value => value.includes('fixture-management')), false);
    } finally {controller.dispose(); env.restore();}
});

test('額度衝突不自動重送或重啟模型，管理403不讓有效登入失效', async () => {
    const env = environment(); let requests = 0;
    const controller = new ChatController({storage: env.storage, fetchImpl: async () => {requests++; return json({code: 'settings_conflict', detail: '設定已更新，請重新讀取'}, 409);}}, 'X');
    try {
        await assert.rejects(controller.actions.saveBudget({scope: 'system', revision: 1, monthly_token_limit: 10}), (error: unknown) => error instanceof ChatApiError && error.code === 'settings_conflict');
        assert.equal(requests, 1); assert.equal(controller.getSnapshot().expired, false);
    } finally {controller.dispose(); env.restore();}
    let notices = 0;
    const api = new ChatApi({fetchImpl: async () => json({detail: '需要管理憑證'}, 403)}, 'X', 'ADMINV2', env.storage, {notifySession() {notices++;}, rateLimited() {}});
    await assert.rejects(api.json('/api/chat/budget', {}, {notifySessionErrors: false})); assert.equal(notices, 0);
});

test('月額度429顯示額度訊息，不誤顯示60秒頻率倒數、不重試、不取消', async () => {
    const env = environment(); let requests = 0, rateLimits = 0;
    const api = new ChatApi({fetchImpl: async () => {requests++; return json({code: 'quota_exceeded', message: '本月 Token 額度不足，請調整額度或等待下個月'}, 429);}}, 'X', 'ADMINV2', env.storage, {notifySession() {}, rateLimited() {rateLimits++;}});
    try {
        await assert.rejects(api.json('/api/chat/conversations/c1/messages', {method: 'POST', body: '{}'}), (error: unknown) => error instanceof ChatApiError && error.code === 'quota_exceeded' && errorText(error) === '本月 Token 額度不足，請調整額度或等待下個月');
        assert.equal(requests, 1); assert.equal(rateLimits, 0); assert.notEqual(api.session(), null);
        const generic = new ChatApi({fetchImpl: async () => json({detail: '稍後再試'}, 429)}, 'X', 'ADMINV2', env.storage, {notifySession() {}, rateLimited() {rateLimits++;}});
        await assert.rejects(generic.json('/api/chat/runtime')); assert.equal(rateLimits, 1);
    } finally {env.restore();}
});

test('排程401沿用登入逾時，之後操作不再發請求；切換帳號不能沿用舊控制器', async () => {
    const env = environment(); let requests = 0;
    const controller = new ChatController({storage: env.storage, fetchImpl: async () => {requests++; return json({detail: '登入已逾時'}, 401);}}, 'X');
    try {
        await assert.rejects(controller.actions.loadSchedules()); assert.equal(controller.getSnapshot().expired, true);
        await assert.rejects(controller.actions.createSchedule({client_schedule_id: 'fixture-id', text: '每天九點報告'})); assert.equal(requests, 1);
        env.values.set('X_BI_accountNo', 'OTHER'); env.values.set('X_BI_TokenKey', 'other-account-token');
        await assert.rejects(controller.actions.loadBudget()); assert.equal(requests, 1);
    } finally {controller.dispose(); env.restore();}
});

test('建立回應遺失後重建控制器不自動POST，同需求人工重試沿用原nonce，成功才清除', async () => {
    const env = environment(), bodies: {client_schedule_id: string; text: string}[] = [];
    const fetchImpl: typeof fetch = async (_url, options = {}) => {
        const body = JSON.parse(String(options.body)); bodies.push(body);
        if (bodies.length === 1) throw new TypeError('模擬回應遺失');
        return json({schedule_id: 'fixture-created', client_schedule_id: body.client_schedule_id});
    };
    const first = new ChatController({storage: env.storage, fetchImpl}, 'X'); let restored: ChatController | undefined;
    try {
        await assert.rejects(first.actions.createSchedule({client_schedule_id: 'original-nonce', text: parsed.source_text!}), (error: unknown) => error instanceof ChatApiError && error.userMessage?.includes('結果待確認') === true);
        assert.deepEqual(JSON.parse(env.storage.getItem('X_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING')!), [{source_text: parsed.source_text, client_schedule_id: 'original-nonce'}]);
        first.dispose(); restored = new ChatController({storage: env.storage, fetchImpl}, 'X');
        assert.equal(bodies.length, 1);
        await restored.actions.createSchedule({client_schedule_id: 'ui-after-refresh', text: parsed.source_text!});
        assert.equal(bodies.length, 2); assert.equal(bodies[1]!.client_schedule_id, 'original-nonce');
        assert.deepEqual(JSON.parse(env.storage.getItem('X_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING')!), []);
        await restored.actions.createSchedule({client_schedule_id: 'new-confirmed-demand', text: parsed.source_text!});
        assert.equal(bodies[2]!.client_schedule_id, 'new-confirmed-demand');
    } finally {first.dispose(); restored?.dispose(); env.restore();}
});

test('排程同需求並行不重送，其他專案及帳號不能讀到舊nonce', async () => {
    const env = environment(); let requests = 0, resolve!: (response: Response) => void;
    const pending = new Promise<Response>(done => {resolve = done;});
    const controller = new ChatController({storage: env.storage, fetchImpl: async () => {requests++; return pending;}}, 'X');
    try {
        const first = controller.actions.createSchedule({client_schedule_id: 'concurrent-one', text: parsed.source_text!});
        const second = controller.actions.createSchedule({client_schedule_id: 'concurrent-two', text: parsed.source_text!});
        assert.equal(requests, 1);
        assert.equal(env.storage.getItem('Y_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING'), null);
        assert.equal(env.storage.getItem('X_MES_AI_CHAT_OTHER_SCHEDULE_PENDING'), null);
        resolve(json({schedule_id: 'fixture-created', client_schedule_id: 'concurrent-one'}));
        const results = await Promise.all([first, second]); assert.equal(results[0].schedule_id, results[1].schedule_id);
        assert.equal(requests, 1);
    } finally {controller.dispose(); env.restore();}
});

test('儲存被拒或識別碼損毀時先阻擋新POST並明示待確認，不無聲更換nonce', async () => {
    const env = environment(); let requests = 0;
    const storage = {getItem: env.storage.getItem.bind(env.storage), setItem() {throw new Error('模擬儲存被拒');}} as unknown as Storage;
    const controller = new ChatController({storage, fetchImpl: async () => {requests++; return json({});}}, 'X');
    try {
        await assert.rejects(controller.actions.createSchedule({client_schedule_id: 'blocked', text: parsed.source_text!}), (error: unknown) => error instanceof ChatApiError && error.userMessage?.includes('結果待確認') === true);
        assert.equal(requests, 0);
        env.values.set('X_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING', 'invalid json');
        await assert.rejects(controller.actions.createSchedule({client_schedule_id: 'another', text: parsed.source_text!})); assert.equal(requests, 0);
        for (const id of ['', 'invalid id', 'x'.repeat(129)]) {
            const persisted = JSON.stringify([{source_text: parsed.source_text!, client_schedule_id: id}]);
            env.values.set('X_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING', persisted);
            await assert.rejects(controller.actions.createSchedule({client_schedule_id: 'new-valid-id', text: parsed.source_text!}));
            assert.equal(requests, 0); assert.equal(env.storage.getItem('X_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING'), persisted);
        }
    } finally {controller.dispose(); env.restore();}
});

test('缺少建立確認識別碼的成功HTTP仍保留nonce，不把未知結果當成功', async () => {
    const env = environment(); const controller = new ChatController({storage: env.storage, fetchImpl: async () => json({items: []})}, 'X');
    try {
        await assert.rejects(controller.actions.createSchedule({client_schedule_id: 'unknown-json', text: parsed.source_text!}));
        assert.equal(JSON.parse(env.storage.getItem('X_MES_AI_CHAT_ADMINV2_SCHEDULE_PENDING')!)[0].client_schedule_id, 'unknown-json');
    } finally {controller.dispose(); env.restore();}
});
