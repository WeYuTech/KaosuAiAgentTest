import {decodeReportCard} from '../src/chat/report-decoder';
import test from 'node:test';
import assert from 'node:assert/strict';
import { CHART_CANDIDATE_RULES, chartSelection, chartTimeAxis, findChartSelection, formatChartTimeTick, planSavedCharts as decodedPlanSavedCharts } from '../src/chat/chart-planner';
import type { ChartPlan } from '../src/chat/chart-planner';
import type { RawReportCard as ReportCard, SemanticReportColumn } from '../src/chat/types';
const planSavedCharts = (card: ReportCard, preference?: Parameters<typeof decodedPlanSavedCharts>[1]) => decodedPlanSavedCharts(decodeReportCard(card, card.primary_metrics !== undefined ? 2 : 1), preference);

const dimension = (name = 'station', grain?: SemanticReportColumn['temporal_grain']): SemanticReportColumn => ({name, label: name, role: 'dimension', data_type: 'string', ...(grain ? {temporal_grain: grain} : {})});
const measure = (name: string, extra: Partial<SemanticReportColumn> = {}): SemanticReportColumn => ({name, label: name, role: 'metric', data_type: 'number', comparison_group: 'approved_measurement', unit: null, ...extra});
const quality = (name: string): SemanticReportColumn => ({name, label: name, role: 'quality', data_type: 'number'});
const complete = (name: string, role: 'component' | 'total', missing: string[]): SemanticReportColumn => measure(name, {
    completeness_required: true, required_missing_fields: missing, availability_count_field: 'samples', interpretation: 'complete', composition: {group: 'approved_composition', role},
});
const compositionColumns = [dimension(), complete('alpha', 'component', ['alpha_missing']), complete('beta', 'component', ['beta_missing']), complete('whole', 'total', ['alpha_missing', 'beta_missing']), quality('samples'), quality('alpha_missing'), quality('beta_missing')];
const compositionRows = [
    {station: 'A', alpha: 9, beta: 1, whole: 10, samples: 2, alpha_missing: 0, beta_missing: 0},
    {station: 'B', alpha: 0, beta: 0, whole: 0, samples: 1, alpha_missing: 0, beta_missing: 0},
    {station: 'C', alpha: 18, beta: 2, whole: 20, samples: 3, alpha_missing: 0, beta_missing: 0},
];
function card(columns: SemanticReportColumn[] = [dimension(), measure('alpha'), measure('beta')], rows: Record<string, unknown>[] = [{station: 'B', alpha: 20, beta: 3}, {station: 'A', alpha: 0, beta: 7}], overrides: Partial<ReportCard> = {}): ReportCard {
    return {id: 'authorized-snapshot', source_call_id: 'call', kind: 'semantic_query', title: '保存查詢', status: 'ok', semantic_fingerprint: 'approved', chart_intent: 'auto', semantic_columns: structuredClone(columns), detail: {columns: columns.map(column => ({key: column.name})), rows: structuredClone(rows)}, ...overrides};
}
const all = (plan: ChartPlan) => [...plan.recommended, ...plan.alternatives];
const marks = (saved: ReportCard) => all(planSavedCharts(saved)).map(spec => spec.mark);

test('合法候選登錄表涵蓋六種圖型及數值與達成呈現，新欄位依metadata直接推薦並保留來源', () => {
    assert.deepEqual(CHART_CANDIDATE_RULES.map(rule => rule.mark).sort(), ['bar', 'bullet', 'heatmap', 'line', 'point', 'scatter', 'stacked', 'value']);
    const saved = card(), selected = planSavedCharts(saved).recommended[0];
    assert.equal(selected.mark, 'bar');
    assert.equal(selected.sourceRef, saved.id);
    assert.equal(selected.version, 1);
    assert.deepEqual(selected.encoding.series, ['alpha', 'beta']);
    assert.deepEqual(selected.points.map(point => point.label), ['B', 'A']);
    assert.deepEqual(selected.points.map(point => point.values.alpha), [20, 0]);
    assert.equal(selected.missing, 'gap');
    assert.equal(selected.order, 'source');
});

test('任意欄名與報表種類變更後，意圖與資料相同仍有相同候選', () => {
    const saved = card(compositionColumns, compositionRows, {chart_intent: 'composition'});
    const rename = new Map(saved.semantic_columns!.map((column, index) => [column.name, `field_${index}`]));
    const columns = saved.semantic_columns!.map(column => ({...column, name: rename.get(column.name)!,
        ...(column.required_missing_fields ? {required_missing_fields: column.required_missing_fields.map(field => rename.get(field)!)} : {}),
        ...(column.availability_count_field ? {availability_count_field: rename.get(column.availability_count_field)!} : {}),
    }));
    const renamed = card(columns, saved.detail!.rows!.map(row => Object.fromEntries(Object.entries(row).map(([key, value]) => [rename.get(key)!, value]))), {kind: 'future_approved_query', chart_intent: 'composition'});
    const original = planSavedCharts(saved), changed = planSavedCharts(renamed);
    assert.deepEqual(changed.recommended.map(spec => spec.mark), original.recommended.map(spec => spec.mark));
    assert.deepEqual(changed.alternatives.map(spec => spec.mark), original.alternatives.map(spec => spec.mark));
    assert.deepEqual(changed.recommended[0].points.map(point => Object.values(point.values)), original.recommended[0].points.map(point => Object.values(point.values)));
    assert.equal(changed.recommended[0].mark, 'stacked');
});

test('同份保存資料依比較、關係與組成意圖選不同合法視圖，不解析問題文字', () => {
    const saved = card(compositionColumns, compositionRows);
    assert.equal(planSavedCharts(saved, 'comparison').recommended[0].mark, 'bar');
    assert.equal(planSavedCharts(saved, 'relationship').recommended[0].mark, 'scatter');
    assert.equal(planSavedCharts(saved, 'composition').recommended[0].mark, 'stacked');
    assert.equal(planSavedCharts({...saved, question: '請畫環圈並把所有數字相加'}).recommended[0].mark, 'bar');
});

test('組成只堆入互斥component，總量只用來核對，零仍保留', () => {
    const spec = planSavedCharts(card(compositionColumns, compositionRows, {chart_intent: 'composition'})).recommended[0];
    assert.equal(spec.mark, 'stacked');
    assert.deepEqual(spec.encoding.series, ['alpha', 'beta']);
    assert.equal(spec.points[1].values.whole, 0);
    assert.equal(spec.points[1].values.alpha, 0);
    assert.equal(spec.scope.paginated, false);
    assert.ok(!spec.encoding.series.includes('whole'));
});

test('主指標只指定兩個組成時仍用保存總量核對，主圖不額外顯示總量', () => {
    for (const primary_metrics of [['alpha', 'beta'], ['beta', 'alpha']]) {
        const saved = card(compositionColumns, compositionRows, {chart_intent: 'composition', primary_metrics});
        const before = structuredClone(saved), plan = planSavedCharts(saved);
        assert.equal(plan.recommended.length, 1);
        assert.equal(plan.recommended[0].mark, 'stacked');
        assert.deepEqual(plan.recommended[0].encoding.series, ['alpha', 'beta']);
        assert.equal(plan.recommended[0].points[0].values.whole, 10);
        assert.deepEqual(saved, before);
    }
});

test('主組成不完整、缺少保存總量、總量不符或第三個組成都不能偷改成指定兩部分堆疊', () => {
    const cases = [
        card(compositionColumns, compositionRows, {chart_intent: 'composition', primary_metrics: ['alpha']}),
        card(compositionColumns.filter(column => column.name !== 'whole'), compositionRows, {chart_intent: 'composition', primary_metrics: ['alpha', 'beta']}),
        card(compositionColumns, compositionRows.map((row, index) => index ? row : {...row, whole: 100}), {chart_intent: 'composition', primary_metrics: ['alpha', 'beta']}),
        card(compositionColumns, compositionRows.map((row, index) => index ? row : {...row, alpha_missing: 1}), {chart_intent: 'composition', primary_metrics: ['alpha', 'beta']}),
        card(compositionColumns.map(column => column.name === 'alpha' ? {...column, interpretation: 'known_partial'} : column), compositionRows, {chart_intent: 'composition', primary_metrics: ['alpha', 'beta']}),
        card([...compositionColumns, complete('gamma', 'component', ['alpha_missing'])], compositionRows.map(row => ({...row, gamma: 1, whole: row.whole + 1})), {chart_intent: 'composition', primary_metrics: ['alpha', 'beta']}),
    ];
    for (const saved of cases) assert.ok(!planSavedCharts(saved).recommended.some(spec => spec.mark === 'stacked'));
    assert.ok(all(planSavedCharts(cases[0])).some(spec => spec.mark === 'stacked'));
    assert.ok(all(planSavedCharts(cases[5])).some(spec => spec.mark === 'stacked' && spec.encoding.series.includes('gamma')));
});

test('組成的缺量、負數、不同總量、未知關係、兩個總量與部分量都拒絕堆疊', () => {
    const cases = [
        card(compositionColumns, compositionRows.map((row, index) => index ? row : {...row, alpha_missing: 1})),
        card(compositionColumns, compositionRows.map((row, index) => index ? row : {...row, alpha: -1, beta: 11})),
        card(compositionColumns, compositionRows.map((row, index) => index ? row : {...row, whole: 100})),
        card(compositionColumns.map(column => column.name === 'alpha' ? {...column, composition: undefined} : column), compositionRows),
        card(compositionColumns.map(column => column.name === 'alpha' ? {...column, composition: {group: 'approved_composition', role: 'total'}} : column), compositionRows),
        card(compositionColumns.map(column => column.name === 'alpha' ? {...column, interpretation: 'known_partial'} : column), compositionRows),
    ];
    for (const saved of cases) assert.ok(!marks(saved).includes('stacked'));
});

test('分頁、offset、截斷與跨列重複禁止組成，仍能比較保存的本頁值', () => {
    for (const pagination of [{has_more: true}, {truncated: true}, {offset: 1}]) {
        const plan = planSavedCharts(card(compositionColumns, compositionRows, {pagination, chart_intent: 'composition'}));
        assert.ok(!all(plan).some(spec => spec.mark === 'stacked'));
        assert.equal(plan.recommended[0].mark, 'bar');
        assert.equal(plan.recommended[0].scope.paginated, true);
        assert.ok(plan.recommended[0].notices.some(notice => notice.includes('分頁')));
    }
    assert.ok(!marks(card(compositionColumns, [...compositionRows, compositionRows[0]])).includes('stacked'));
});

test('有限精度只核對保存組成，不計算比例或修改原值', () => {
    const rows = [{station: 'A', alpha: .1, beta: .2, whole: .3, samples: 1, alpha_missing: 0, beta_missing: 0}];
    const saved = card(compositionColumns, rows), before = JSON.stringify(saved);
    const spec = all(planSavedCharts(saved)).find(item => item.mark === 'stacked')!;
    assert.deepEqual(spec.points[0].values, {alpha: .1, beta: .2, whole: .3});
    assert.equal(JSON.stringify(saved), before);
});

test('連續日期與月份依明確grain選折線，沒有固定月份欄名', () => {
    for (const [grain, dates] of [['day', ['2026-10-01', '2026-10-02', '2026-10-03']], ['month', ['2026-09', '2026-10', '2026-11']]] as const) {
        const saved = card([dimension('arbitrary_period', grain), measure('value')], dates.map((arbitrary_period, index) => ({arbitrary_period, value: index === 1 ? null : index})));
        const selected = planSavedCharts(saved).recommended[0];
        assert.equal(selected.mark, 'line');
        assert.deepEqual(selected.points.map(point => point.values.value), [0, null, 2]);
        assert.deepEqual(selected.points.map(point => point.dimensions.arbitrary_period), dates);
    }
});

test('單一時間維度加完整固定分類可畫折線，時間軸不丟棄完整主體', () => {
    const columns = [dimension('machine'), dimension('period', 'day'), dimension('shift'), measure('alpha')];
    const rows = [{machine: 'SC01', period: '2026-07-01', shift: '早', alpha: 0}, {machine: 'SC01', period: '2026-07-02', shift: '早', alpha: null}, {machine: 'SC01', period: '2026-07-03', shift: '早', alpha: 8}];
    for (const ordered of [columns, [...columns].reverse()]) {
        const saved = card(ordered, rows, {chart_intent: 'trend', primary_metrics: ['alpha']}), before = structuredClone(saved);
        const chart = planSavedCharts(saved).recommended[0];
        assert.equal(chart.mark, 'line');
        assert.equal(chart.encoding.x, 'period');
        assert.deepEqual(chart.points.map(point => point.values.alpha), [0, null, 8]);
        assert.ok(chart.points.every(point => point.dimensions.machine === 'SC01' && point.dimensions.shift === '早' && point.label.includes('SC01') && point.label.includes('早')));
        assert.deepEqual(chart.points.map(point => point.dimensions.period), ['2026-07-01', '2026-07-02', '2026-07-03']);
        assert.deepEqual(saved, before);
    }
});

test('時間系列的分類變動、分類缺值、時間缺口及重複仍禁止折線，不自動聚合', () => {
    const columns = [dimension('machine'), dimension('period', 'day'), dimension('shift'), measure('alpha')];
    const rows = [{machine: 'SC01', period: '2026-07-01', shift: '早', alpha: 1}, {machine: 'SC01', period: '2026-07-02', shift: '早', alpha: 2}];
    const cases = [
        [rows[0], {...rows[1], machine: 'SC02'}], [rows[0], {...rows[1], shift: '晚'}],
        rows.map(row => ({...row, machine: null})), rows.map(row => ({...row, shift: ''})),
        [rows[0], {...rows[1], period: '2026-07-03'}], [rows[0], {...rows[1], period: '2026-07-01'}],
        [rows[1], rows[0]],
    ];
    for (const savedRows of cases) assert.ok(!all(planSavedCharts(card(columns, savedRows, {chart_intent: 'trend'}))).some(chart => chart.mark === 'line'));
});

test('缺少模型偏好的核准時間系列仍依保存結構自動選點圖，缺日不補零且保留全部列', () => {
    const periods = ['2026-07-01', '2026-07-08', '2026-07-09', '2026-07-10', '2026-07-11', '2026-07-13', '2026-07-14', '2026-07-15', '2026-07-16'];
    const rows = periods.map((period, index) => ({machine: 'A', period, alpha: index === 2 ? null : index}));
    for (const dimensions of [[dimension('period', 'day')], [dimension('machine'), dimension('period', 'day')]]) {
        const saved = card([...dimensions, measure('alpha')], rows, {chart_intent: 'auto', primary_metrics: ['alpha']}), before = structuredClone(saved);
        const plan = planSavedCharts(saved), chart = plan.recommended[0];
        assert.equal(chart.mark, 'point');
        assert.equal(chart.points.length, periods.length);
        assert.deepEqual(chart.points.map(point => point.dimensions.period), periods);
        assert.deepEqual(chart.points.map(point => point.values.alpha), [0, 1, null, 3, 4, 5, 6, 7, 8]);
        assert.ok(!all(plan).some(candidate => candidate.mark === 'line'));
        assert.ok(chart.notices.some(notice => notice.includes('不以等距折線連接')));
        assert.equal(planSavedCharts(saved, 'comparison').recommended[0].mark, 'bar');
        assert.deepEqual(saved, before);
    }
});

test('時間點圖採真實時間座標，七日距離為一日的七倍，日期刻度簡短而完整主體不變', () => {
    const periods = ['2026-07-01', '2026-07-08', '2026-07-09'];
    const saved = card([dimension('machine'), dimension('period', 'day'), measure('alpha')], periods.map((period, index) => ({machine: 'SC01', period, alpha: index})), {primary_metrics: ['alpha']});
    const before = structuredClone(saved), chart = planSavedCharts(saved).recommended[0], axis = chartTimeAxis(chart)!;
    assert.equal(chart.mark, 'point');
    assert.equal(chart.encoding.x, 'period');
    assert.equal(axis.grain, 'day');
    assert.deepEqual(axis.positions, periods.map(period => Date.parse(period + 'T00:00:00Z')));
    assert.equal((axis.positions[1] - axis.positions[0]) / (axis.positions[2] - axis.positions[1]), 7);
    assert.deepEqual(axis.domain, [axis.positions[0], axis.positions[2]]);
    assert.deepEqual(axis.positions.map(value => formatChartTimeTick(value, axis.grain)), ['07/01', '07/08', '07/09']);
    assert.deepEqual(chart.points.map(point => point.label), periods.map(period => 'SC01 · ' + period));
    assert.match(chart.reason, /依保存時間位置/);
    assert.deepEqual(saved, before);
});

test('月份與有時區時間戳維持保存間隔；一般分類及無效日期不冒充時間軸', () => {
    for (const [grain, periods, ratio] of [
        ['month', ['2026-01', '2026-03', '2026-04'], 2],
        ['instant', ['2026-07-01T10:00:00+08:00', '2026-07-01T10:15:00+08:00', '2026-07-01T10:45:00+08:00'], .5],
    ] as const) {
        const chart = planSavedCharts(card([dimension('time', grain), measure('alpha')], periods.map((time, index) => ({time, alpha: index})))).recommended[0];
        const axis = chartTimeAxis(chart)!;
        assert.equal(chart.mark, 'point');
        assert.equal((axis.positions[1] - axis.positions[0]) / (axis.positions[2] - axis.positions[1]), ratio);
        assert.equal(axis.positions.length, periods.length);
        assert.ok(axis.positions.every(value => formatChartTimeTick(value, grain)));
    }
    const category = all(planSavedCharts(card())).find(chart => chart.mark === 'point')!;
    assert.equal(chartTimeAxis(category), null);
    const invalid = planSavedCharts(card([dimension('time', 'day'), measure('alpha')], [{time: '2026-02-28', alpha: 1}, {time: '2026-02-30', alpha: 2}])).recommended[0];
    assert.equal(invalid.mark, 'point');
    assert.equal(chartTimeAxis(invalid), null);
    assert.doesNotMatch(invalid.reason, /時間位置|時間間隔/);
});

test('缺日期、缺月、倒序、重複、無效日與不等間距時間不能畫等距折線', () => {
    const cases: [SemanticReportColumn['temporal_grain'], string[]][] = [
        ['day', ['2026-10-01', '2026-10-03']], ['day', ['2026-10-02', '2026-10-01']], ['day', ['2026-10-01', '2026-10-01']],
        ['day', ['2026-02-28', '2026-02-30']], ['month', ['2026-07', '2026-09']], ['month', ['2026-12', '2026-13']],
        ['instant', ['2026-10-01T10:00:00+08:00', '2026-10-01T11:00:00+08:00', '2026-10-01T13:00:00+08:00']],
        ['instant', ['2026-10-01T10:00:00', '2026-10-01T11:00:00']],
    ];
    for (const [grain, dates] of cases) {
        const plan = planSavedCharts(card([dimension('time_field', grain), measure('alpha')], dates.map(time_field => ({time_field, alpha: 1})), {chart_intent: 'trend'}));
        assert.ok(!all(plan).some(spec => spec.mark === 'line'));
        assert.equal(plan.recommended[0].mark, 'point');
        assert.ok(plan.recommended[0].notices.some(notice => notice.includes('不以等距折線')));
    }
});

test('有明確時區且實際間距一致的時間戳可以畫折線', () => {
    const saved = card([dimension('time_field', 'instant'), measure('alpha')], [
        {time_field: '2026-10-01T10:00:00+08:00', alpha: 1}, {time_field: '2026-10-01T03:00:00Z', alpha: 2}, {time_field: '2026-10-01T12:00:00+08:00', alpha: 3},
    ]);
    assert.equal(planSavedCharts(saved).recommended[0].mark, 'line');
});

test('只有date型別但沒有temporal_grain，不能推斷成連續時間', () => {
    const saved = card([{...dimension('new_time'), data_type: 'date'}, measure('alpha')], [{new_time: '2026-10-01', alpha: 1}, {new_time: '2026-10-02', alpha: 2}]);
    assert.ok(!marks(saved).includes('line'));
});

test('兩維唯一格自動熱圖，多指標可各自使用同一保存格', () => {
    const columns = [dimension('station'), dimension('period', 'day'), measure('alpha'), measure('beta')];
    const rows = [{station: 'A', period: '2026-10-01', alpha: 0, beta: 10}, {station: 'B', period: '2026-10-01', alpha: null, beta: 11}, {station: 'A', period: '2026-10-02', alpha: 7, beta: 12}];
    const saved = card(columns, rows), plan = planSavedCharts(saved);
    assert.equal(plan.recommended[0].mark, 'heatmap');
    assert.deepEqual(plan.recommended.map(spec => spec.encoding.series), [['alpha'], ['beta']]);
    const heatmaps = all(plan).filter(spec => spec.mark === 'heatmap');
    assert.equal(heatmaps.length, 2);
    assert.deepEqual(heatmaps[0].encoding, {x: 'station', y: 'period', series: ['alpha']});
    assert.deepEqual(heatmaps[0].points.map(point => point.values.alpha), [0, null, 7]);
    assert.equal(heatmaps[0].points.length, 3);
    assert.deepEqual(heatmaps[0].points[2].dimensions, {station: 'A', period: '2026-10-02', __saved_identity: 'A · 2026-10-02'});
    assert.equal(planSavedCharts(saved, 'relationship').recommended[0].mark, 'scatter');
});

test('重複格、額外粒度、未知維度與沒有交叉維度變化時，不擅自聚合成熱圖', () => {
    const columns = [dimension('station'), dimension('period'), measure('alpha')];
    const rows = [{station: 'A', period: 'P1', alpha: 0}, {station: 'B', period: 'P2', alpha: 5}];
    const cases = [card(columns, [...rows, rows[0]]), card([...columns, dimension('operator')], rows.map(row => ({...row, operator: 'X'}))),
        card(columns, rows.map((row, index) => index ? {...row, station: null} : row)), card(columns, rows.map(row => ({...row, period: 'P1'})))];
    for (const saved of cases) assert.ok(!marks(saved).includes('heatmap'));
});

test('不同單位的兩量測各自作散佈軸，每點保留同列完整主體及缺值', () => {
    const saved = card([dimension('station'), dimension('operator'), measure('heat', {comparison_group: 'thermal', unit: '°C'}), measure('duration', {comparison_group: 'time', unit: '秒'})], [
        {station: 'A', operator: 'U1,U2', heat: 10, duration: 20}, {station: 'A', operator: 'U3', heat: null, duration: 30}, {station: 'B', operator: 'U1', heat: 0, duration: 0},
    ], {chart_intent: 'relationship'});
    const selected = planSavedCharts(saved).recommended[0];
    assert.equal(selected.mark, 'scatter');
    assert.deepEqual(selected.encoding, {x: 'heat', y: 'duration', series: []});
    assert.deepEqual(selected.points.map(point => point.label), ['A · U1,U2', 'A · U3', 'B · U1']);
    assert.equal(selected.points[1].values.heat, null);
    assert.deepEqual(selected.points[2].values, {heat: 0, duration: 0});
    assert.equal(selected.unit, '');
    assert.equal(selected.columns.find(column => column.name === 'duration')!.unit, '秒');
});

test('未知單位不能單憑同為null就共軸，核准群組可提供額外同量綱證據', () => {
    const columns = [dimension(), measure('alpha', {comparison_group: undefined}), measure('beta', {comparison_group: undefined})];
    assert.deepEqual(planSavedCharts(card(columns)).recommended.map(spec => spec.encoding.series), [['alpha'], ['beta']]);
    assert.deepEqual(planSavedCharts(card()).recommended[0].encoding.series, ['alpha', 'beta']);
    assert.deepEqual(planSavedCharts(card([dimension(), measure('alpha', {unit: '秒'}), measure('beta', {unit: '件'})])).recommended.map(spec => spec.encoding.series), [['alpha'], ['beta']]);
});

test('完整量與已知部分量分開，部分量不能成組成或與完整量成關係圖', () => {
    const partial = measure('partial', {interpretation: 'known_partial', completeness_required: false, required_missing_fields: [], availability_count_field: 'samples'});
    const columns = [dimension(), complete('alpha', 'component', ['alpha_missing']), partial, quality('samples'), quality('alpha_missing')];
    const saved = card(columns, [{station: 'A', alpha: 5, partial: 4, samples: 1, alpha_missing: 0}, {station: 'B', alpha: 6, partial: 5, samples: 1, alpha_missing: 0}]);
    const plan = planSavedCharts(saved);
    assert.equal(plan.recommended.length, 2);
    assert.ok(!all(plan).some(spec => ['scatter', 'stacked'].includes(spec.mark)));
    assert.match(plan.recommended[1].measure, /已知部分/);
    assert.ok(plan.recommended[1].notices.some(notice => notice.includes('不能當成完整產量')));
});

test('新意圖加上一般metric metadata即可選圖，不要求每個指標都有比較或組成關係', () => {
    const columns = [dimension(), measure('any_count', {comparison_group: undefined, interpretation: 'count', completeness_required: false, required_missing_fields: []})];
    const saved = card(columns, [{station: 'A', any_count: 0}, {station: 'B', any_count: 2}], {kind: 'future_query', chart_intent: 'distribution'});
    assert.equal(planSavedCharts(saved).recommended[0].mark, 'point');
    assert.deepEqual(planSavedCharts(saved).recommended[0].points.map(point => point.values.any_count), [0, 2]);
});

test('每個指標獨立使用metadata缺項，不讓單一缺良品遮蔽完整不良', () => {
    const saved = card(compositionColumns, compositionRows.map((row, index) => index ? row : {...row, alpha_missing: 1}));
    const first = planSavedCharts(saved).recommended[0].points[0];
    assert.deepEqual(first.values, {alpha: null, beta: 1, whole: null});
    assert.ok(!marks(saved).includes('stacked'));
});

test('完整性count與missing引用需核准數字欄，正整數與零缺項才可呈現完整量', () => {
    for (const samples of [null, 0, -1, 1.5, true, '2']) {
        const saved = card(compositionColumns, compositionRows.map(row => ({...row, samples})));
        assert.deepEqual(planSavedCharts(saved), {recommended: [], alternatives: []});
    }
    for (const availability_count_field of ['unknown_count', 'alpha_missing', 'station']) {
        const columns = compositionColumns.map(column => column.role === 'metric' ? {...column, availability_count_field} : column);
        assert.deepEqual(planSavedCharts(card(columns, compositionRows)), {recommended: [], alternatives: []});
    }
    const columns = compositionColumns.map(column => column.role === 'metric' ? {...column, required_missing_fields: ['station']} : column);
    assert.deepEqual(planSavedCharts(card(columns, compositionRows)), {recommended: [], alternatives: []});
});

test('null、非數字、NaN、無限大不補零；完整保留第九列與之前的未知位置', () => {
    const rows = [null, '3', true, NaN, Infinity, undefined, {}, null, 0].map((alpha, index) => ({station: String(index), alpha}));
    const saved = card([dimension(), measure('alpha')], rows);
    assert.deepEqual(planSavedCharts(saved).recommended[0].points.map(point => point.values.alpha), [null, null, null, null, null, null, null, null, 0]);
    saved.detail!.rows![0].alpha = 0;
    const spec = planSavedCharts(saved).recommended[0];
    assert.equal(spec.points.length, 9);
    assert.deepEqual(spec.points.map(point => point.values.alpha), [0, null, null, null, null, null, null, null, 0]);
    assert.equal(spec.scope.totalRows, 9);
    assert.equal(spec.scope.shownRows, 9);
    assert.ok(!spec.notices.some(notice => notice.includes('前 8 項')));
});

test('主圖只顯示已核准焦點，其他指標仍保留合法候選；同群組也不夾帶附帶指標', () => {
    for (const comparison_group of ['approved_measurement', undefined]) {
        const saved = card([dimension(), measure('alpha'), measure('beta', {comparison_group})], undefined, {primary_metrics: ['alpha']});
        const plan = planSavedCharts(saved);
        assert.deepEqual(plan.recommended.map(spec => spec.encoding.series), [['alpha']]);
        assert.ok(plan.alternatives.some(spec => spec.encoding.series.includes('beta')));
        assert.equal(plan.recommended[0].points[0].values.beta, 3);
    }
});

test('來源模型偏好優先於一般焦點，指定配對不受欄位重排影響且其餘候選仍可使用', () => {
    const columns = [dimension(), measure('alpha'), measure('beta'), measure('gamma')];
    const rows = [{station: 'A', alpha: 2, beta: 8, gamma: 4}, {station: 'B', alpha: 3, beta: 9, gamma: 5}];
    const preference = {call_id: 'call', intent: 'relationship', metrics: ['beta', 'alpha']};
    for (const ordered of [columns, [...columns].reverse()]) {
        const plan = decodedPlanSavedCharts(decodeReportCard(card(ordered, rows, {source_call_id: 'call', primary_metrics: ['gamma'], chart_preference: preference}), 2));
        assert.deepEqual(chartSelection(plan.recommended[0]), {mark: 'scatter', metrics: ['beta', 'alpha']});
        assert.equal(findChartSelection(all(plan), {mark: 'scatter', metrics: ['beta', 'alpha']}), plan.recommended[0]);
        assert.ok(findChartSelection(all(plan), {mark: 'scatter', metrics: ['alpha', 'beta']}));
        assert.ok(plan.alternatives.some(spec => spec.encoding.series.includes('gamma')));
    }
});

test('手動保存的散佈配對在欄位重排後保持原座標方向，不借用第三欄或放寬可用性', () => {
    const columns = [dimension(), measure('alpha'), measure('beta'), measure('gamma')];
    const rows = [{station: 'A', alpha: 2, beta: 8, gamma: 4}, {station: 'B', alpha: 3, beta: 9, gamma: 5}];
    const before = card(columns, rows), original = all(planSavedCharts(before)).find(spec => spec.mark === 'scatter' && spec.encoding.x === 'alpha' && spec.encoding.y === 'beta')!;
    const savedSelection = JSON.parse(JSON.stringify(chartSelection(original)));
    const reordered = card([...columns].reverse(), rows);
    const restored = findChartSelection(all(planSavedCharts(reordered)), savedSelection)!;
    assert.deepEqual(restored.encoding, {x: 'alpha', y: 'beta', series: []});
    assert.deepEqual(restored.points.map(point => [point.values[restored.encoding.x], point.values[restored.encoding.y]]), [[2, 8], [3, 9]]);
    assert.deepEqual(chartSelection(restored), savedSelection);
    const unavailable = card([...columns].reverse(), rows.map(row => ({...row, beta: null})));
    assert.equal(findChartSelection(all(planSavedCharts(unavailable)), savedSelection), undefined);
    assert.equal(findChartSelection(all(planSavedCharts(reordered)), {mark: 'scatter', metrics: ['alpha', 'absent']}), undefined);
    assert.equal(findChartSelection(all(planSavedCharts(reordered)), {mark: 'scatter', metrics: ['alpha', 'alpha']}), undefined);
});

test('新卡沒有可信主指標只推薦一張，不能以其他指標代替缺值的明確主指標', () => {
    const columns = [dimension(), measure('alpha', {comparison_group: undefined}), measure('beta', {comparison_group: undefined})];
    assert.equal(planSavedCharts(card(columns, undefined, {primary_metrics: []})).recommended.length, 1);
    const rows = [{station: 'A', alpha: null, beta: 8}, {station: 'B', alpha: null, beta: 9}];
    const plan = planSavedCharts(card(columns, rows, {primary_metrics: ['alpha']}));
    assert.equal(plan.recommended.length, 0);
    assert.match(plan.reason || '', /主要指標沒有/);
    assert.ok(plan.alternatives.some(spec => spec.encoding.series.includes('beta')));
});

test('折線、散佈與熱圖保留超過八列的完整保存值，不截短資料範圍', () => {
    const rows = Array.from({length: 31}, (_, index) => ({period: `2026-07-${String(index + 1).padStart(2, '0')}`, alpha: index, beta: index * 2}));
    const saved = card([dimension('period', 'day'), measure('alpha'), measure('beta')], rows);
    const plan = planSavedCharts(saved), line = all(plan).find(spec => spec.mark === 'line')!, scatter = all(plan).find(spec => spec.mark === 'scatter')!;
    for (const spec of [line, scatter]) {
        assert.equal(spec.points.length, 31);
        assert.equal(spec.points[30].values.alpha, 30);
        assert.equal(spec.scope.shownRows, spec.scope.totalRows);
    }
});

test('缺少完整主體的一列保留位置且不使用數字，不讓後列錯位', () => {
    const saved = card([dimension(), measure('alpha')], [{station: 'A', alpha: 2}, {alpha: 99}, {station: 'C', alpha: 3}]);
    const spec = planSavedCharts(saved).recommended[0];
    assert.deepEqual(spec.points.map(point => point.rowIndex), [0, 1, 2]);
    assert.deepEqual(spec.points.map(point => point.values.alpha), [2, null, 3]);
    assert.equal(spec.points[1].label, '未知');
});

test('全未知、品質欄位、無維度、未完成與證據卡不新增圖表', () => {
    const cases = [card([dimension(), measure('alpha')], [{station: 'A', alpha: null}]), card([dimension(), quality('alpha')], [{station: 'A', alpha: 3}]),
        card([measure('alpha')], [{alpha: 3}]), card(undefined, undefined, {status: 'failed'}), card(undefined, undefined, {status: 'no_data'}), card(undefined, undefined, {presentation: 'evidence'})];
    for (const saved of cases) assert.deepEqual(planSavedCharts(saved), {recommended: [], alternatives: []});
});

test('非法metadata與欄位引用拒絕，不回退猜測另一個指標', () => {
    const cases = [card(undefined, undefined, {semantic_fingerprint: ''}), card(undefined, undefined, {semantic_columns: [dimension(), measure('missing')]}),
        card([dimension(), measure('alpha', {comparison_group: 'invalid group'})]), card([dimension(), measure('alpha', {temporal_grain: 'day'})]),
        card([dimension(), measure('alpha'), measure('alpha')]), card([dimension(), measure('alpha')], undefined, {chart_intent: 'unknown' as never})];
    for (const saved of cases) assert.deepEqual(planSavedCharts(saved), {recommended: [], alternatives: []});
});

test('推薦層不修改快照，回傳內容也是副本', () => {
    const saved = card(compositionColumns, compositionRows), before = JSON.stringify(saved);
    const plan = planSavedCharts(saved), spec = plan.recommended[0];
    spec.points[0].values.alpha = 999;
    spec.points[0].dimensions.station = '改寫';
    spec.columns[1].required_missing_fields!.push('fake');
    spec.columns[1].composition!.role = 'total';
    assert.equal(JSON.stringify(saved), before);
});

test('歷史無推薦metadata快照維持舊長條／折線，不由新意圖任意擴張', () => {
    const saved: ReportCard = {id: 'old', kind: 'machine_production', chart_intent: 'composition', status: 'ok', detail: {rows: [{machine_id: 'A', produced_quantity: 10}, {machine_id: 'B', produced_quantity: 0}]}};
    const plan = planSavedCharts(saved);
    assert.equal(plan.recommended[0].mark, 'bar');
    assert.deepEqual(plan.recommended[0].points.map(point => point.values.value), [10, 0]);
    assert.deepEqual(plan.alternatives, []);
    assert.equal(findChartSelection(all(plan), chartSelection(plan.recommended[0])), plan.recommended[0]);
});

test('舊語意完整性欄位加上重新投影的auto意圖，仍保留原圖與逐指標缺值', () => {
    const columns: SemanticReportColumn[] = [dimension('machine_id'),
        {name: 'good_quantity', label: '良品量', role: 'metric', data_type: 'number', unit: null, completeness_required: true, required_missing_fields: ['missing_good_count'], interpretation: 'complete'},
        quality('operation_count'), quality('missing_good_count')];
    const rows = [{machine_id: 'A', good_quantity: 0, operation_count: 1, missing_good_count: 0}, {machine_id: 'B', good_quantity: 5, operation_count: 1, missing_good_count: 1}];
    const original = planSavedCharts(card(columns, rows, {chart_intent: undefined}));
    const projected = planSavedCharts(card(columns, rows, {chart_intent: 'auto'}));
    assert.deepEqual(projected, original);
    assert.equal(projected.recommended[0].mark, 'bar');
    assert.deepEqual(projected.recommended[0].points.map(point => point.values.good_quantity), [0, null]);
    assert.deepEqual(projected.alternatives, []);
});

test('舊語意已知部分欄位加上預設auto意圖，仍保留原部分量圖', () => {
    const columns: SemanticReportColumn[] = [dimension('machine_id'),
        {name: 'known_good_quantity', label: '已知良品量', role: 'metric', data_type: 'number', unit: null, completeness_required: false, required_missing_fields: [], interpretation: 'known_partial'},
        quality('operation_count')];
    const rows = [{machine_id: 'A', known_good_quantity: 0, operation_count: 1}, {machine_id: 'B', known_good_quantity: 5, operation_count: 1}];
    const projected = planSavedCharts(card(columns, rows, {chart_intent: 'auto'}));
    assert.equal(projected.recommended[0].mark, 'bar');
    assert.deepEqual(projected.recommended[0].points.map(point => point.values.known_good_quantity), [0, 5]);
    assert.ok(projected.recommended[0].notices.some(notice => notice.includes('已知部分')));
});
