import test from 'node:test';
import assert from 'node:assert/strict';
import { fromThreadMessageLike } from '@assistant-ui/react';
import type { AppendMessage } from '@assistant-ui/react';
import { createMesExternalStoreAdapter, convertMesMessage } from '../src/chat/assistant-runtime';

test('同一失敗原因只交給錯誤框，保留不同的正文與原始 metadata', () => {
    const text = '本地模型輸出達到上限，回答被截斷';
    const message: Message = {role: 'assistant', content: text, error_message: text, execution_state: 'failed', status: 'failed'};
    const converted = convertMesMessage(message, 0);
    assert.deepEqual(converted.content, []);
    assert.deepEqual(converted.status, {type: 'incomplete', reason: 'error', error: text});
    assert.equal(converted.metadata?.custom?.mesMessage, message);
    assert.deepEqual(convertMesMessage({...message, content: '保留的完整說明'}, 0).content, [{type: 'text', text: '保留的完整說明'}]);
    assert.deepEqual(convertMesMessage({...message, role: 'user'}, 0).content, [{type: 'text', text}]);
});
import { ChatController } from '../src/chat/controller';
import {getMesFollowupSource, setMesFollowupDraft} from '../src/chat/follow-ups';
import type { ChatActions, ChatState, Message } from '../src/chat/types';

function state(overrides: Partial<ChatState> = {}): ChatState {
    return {enabled: true, opened: true, expanded: false, historyOpen: false, view: 'chat', runtime: {mode: 'API', continuous_context: false, supports_message_edit: true}, conversationId: 'c1', conversationTitle: '測試聊天', conversation: null, conversations: [], historyCursor: null, historyLoading: false, historyLoaded: true, historyStatus: '', historyArchived: false, conversationSaving: [], messages: [], activeTurn: null, displayMessages: [], draft: '工單產量？', submitting: false, cancelling: false, connectionStatus: '', sessionNotice: '', expired: false, readOnly: false, readOnlyNotice: '', hint: '', sendDisabled: false, inputDisabled: false, showStop: false, unknownSubmission: false, reconnectNeeded: false, reports: {}, exporting: [], feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null, ...overrides};
}
function fakeActions() {
    const calls: {name: string; values: unknown[]}[] = [];
    const actions = {
        setDraft: (...values: unknown[]) => { calls.push({name: 'draft', values}); },
        submitQuestion: async () => { calls.push({name: 'submit', values: []}); },
        resubmitQuestion: async (...values: unknown[]) => {calls.push({name: 'edit', values});},
        cancelTurn: async () => { calls.push({name: 'cancel', values: []}); },
        reconnect: async () => { calls.push({name: 'reconnect', values: []}); },
        selectConversation: async (...values: unknown[]) => { calls.push({name: 'select', values}); },
        newChat: () => { calls.push({name: 'new', values: []}); },
        saveFeedback: async (...values: unknown[]) => { calls.push({name: 'feedback', values}); return true; },
    } as unknown as ChatActions;
    return {actions, calls};
}
function append(text: string): AppendMessage {
    return {role: 'user', content: [{type: 'text', text}], createdAt: new Date('2026-10-07T08:00:00Z'), attachments: [], metadata: {custom: {}}, parentId: null, sourceId: null, runConfig: undefined};
}

test('觀看保存故障停止 assistant-ui 生成動畫，保留原回合與明確取消能力', async () => {
    const {actions, calls} = fakeActions();
    const message: Message = {role: 'assistant', conversation_id: 'c1', request_id: 'r1', content: '保存尚未確認', execution_state: 'queued', status: 'started', watch_unavailable: true};
    const current = state({activeTurn: message, displayMessages: [message], showStop: true, watchUnavailable: true, sendDisabled: true, submitting: true});
    const before = structuredClone(message);
    const adapter = createMesExternalStoreAdapter({state: current, actions});
    assert.equal(adapter.isRunning, false); assert.equal(adapter.isSendDisabled, true);
    assert.deepEqual(adapter.convertMessage!(message, 0).status, {type: 'incomplete', reason: 'other'});
    await adapter.onNew!(append('不可重送')); await adapter.onCancel!();
    assert.deepEqual(calls, [{name: 'cancel', values: []}]);
    assert.equal(current.activeTurn?.execution_state, 'queued'); assert.deepEqual(message, before);
});

test('訊息轉換保留 Request ID、原始 MES 訊息及完整數字，不修改來源', () => {
    const message: Message = {role: 'assistant', request_id: 'r1', content: '107,102 ÷ 130,000 = 82.39%', execution_state: 'completed', status: 'succeeded', created_at: '2026-08-20T00:00:00Z', evidence: [{calculation: '總報工量 ÷ 目標量'}]};
    const before = JSON.stringify(message);
    const converted = convertMesMessage(message, 0, 'c1');
    assert.equal(converted.id, 'c1:assistant:r1');
    assert.deepEqual(converted.content, [{type: 'text', text: message.content}]);
    assert.equal(converted.metadata?.custom?.mesMessage, message);
    assert.equal(converted.metadata?.custom?.requestId, 'r1');
    assert.equal(converted.createdAt?.toISOString(), '2026-08-20T00:00:00.000Z');
    assert.equal(JSON.stringify(message), before);
});

function followupMessage(overrides: Partial<Message> = {}): Message {
    return {role: 'assistant', conversation_id: 'c1', request_id: 'r1', content: '已保存的回答', execution_state: 'completed', status: 'succeeded', query_scope: {start_date: '2026-08-01', end_date: '2026-08-31', machine_id: 'MC-03'}, query_scope_summary: '2026 年 8 月 · 機台 MC-03', scope_inherited: true, follow_up_suggestions: [{title: '查看工單明細', prompt: '列出相同期間與機台的工單明細'}, {title: '查看每日趨勢', prompt: '依相同條件查看每日產量'}, {title: '查看報工組合', prompt: '依相同條件查看報工人員組合'}, {title: '第四個項目', prompt: '第四個保存追問'}], ...overrides};
}

test('runtime 僅呈現最後已完成回答的保存建議，最多三項且完整保留查詢條件 metadata', () => {
    const {actions} = fakeActions();
    const saved = followupMessage();
    const before = JSON.stringify(saved);
    const adapter = createMesExternalStoreAdapter({state: state({displayMessages: [saved], draft: '', sendDisabled: true}), actions});
    assert.deepEqual(adapter.suggestions, saved.follow_up_suggestions!.slice(0, 3));
    const converted = adapter.convertMessage!(saved, 0);
    assert.equal(converted.metadata?.custom?.mesMessage, saved);
    assert.deepEqual((converted.metadata?.custom?.mesMessage as Message).query_scope, saved.query_scope);
    assert.equal((converted.metadata?.custom?.mesMessage as Message).scope_inherited, true);
    assert.equal(JSON.stringify(saved), before);
    for (const latest of [{...saved, execution_state: 'cancelled' as const, status: 'cancelled' as const}, {...saved, execution_state: 'failed' as const, status: 'failed' as const}, {...saved, follow_up_suggestions: undefined}, {role: 'user' as const, content: '下一題'}]) {
        assert.deepEqual(createMesExternalStoreAdapter({state: state({displayMessages: [saved, latest]}), actions}).suggestions, []);
    }
    assert.deepEqual(createMesExternalStoreAdapter({state: state({displayMessages: [{role: 'assistant', content: '舊回答包含 42 台機台'}]}), actions}).suggestions, []);
    const invalid = followupMessage({follow_up_suggestions: [{title: '空白', prompt: ' '}, ...saved.follow_up_suggestions!, saved.follow_up_suggestions![0]!]});
    assert.deepEqual(getMesFollowupSource(state({displayMessages: [invalid]}))?.suggestions, saved.follow_up_suggestions!.slice(0, 3));
});

test('點選保存建議只改原草稿，過期、生成中、取消中與舊聊天事件不操作', () => {
    const {actions, calls} = fakeActions();
    const saved = followupMessage();
    const ready = state({displayMessages: [saved], draft: '', sendDisabled: true});
    const source = getMesFollowupSource(ready)!;
    assert.equal(setMesFollowupDraft(ready, actions, source, source.suggestions[0]!), true);
    assert.deepEqual(calls, [{name: 'draft', values: [source.suggestions[0]!.prompt]}]);
    calls.length = 0;
    for (const blocked of [{inputDisabled: true}, {expired: true}, {readOnly: true}, {submitting: true}, {showStop: true}, {cancelling: true}, {unknownSubmission: true}, {opened: false}, {view: 'metrics' as const}, {conversationId: 'c2'}, {conversationId: null}, {displayMessages: []}, {displayMessages: [followupMessage({request_id: 'edited-request'})]}]) {
        const latest = {...ready, ...blocked};
        assert.equal(setMesFollowupDraft(latest, actions, source, source.suggestions[0]!), false);
        assert.deepEqual(createMesExternalStoreAdapter({state: latest, actions}).suggestions, blocked.displayMessages?.[0]?.request_id === 'edited-request' ? saved.follow_up_suggestions!.slice(0, 3) : []);
    }
    assert.equal(setMesFollowupDraft(ready, actions, source, {title: '任意內容', prompt: '不是保存的追問'}), false);
    assert.deepEqual(calls, []);
});

test('串流與保存後使用同一助理 ID，使用者優先使用防重送 ID', () => {
    const running: Message = {role: 'assistant', request_id: 'r1', content: '正在', execution_state: 'running'};
    assert.equal(convertMesMessage(running, 1, 'c1').id, convertMesMessage({...running, content: '已完成', execution_state: 'completed'}, 1, 'c1').id);
    assert.deepEqual(convertMesMessage(running, 1).status, {type: 'running'});
    const user: Message = {role: 'user', client_message_id: 'nonce-1', content: '問題'};
    assert.equal(convertMesMessage(user, 0).id, convertMesMessage({...user, request_id: 'r1'}, 0).id);
    assert.notEqual(convertMesMessage(running, 1, 'c1').id, convertMesMessage(running, 1, 'c2').id);
});

test('空查詢狀態到完整 done 使用相同訊息 ID 與真實完成狀態，不附帶動畫資格', () => {
    const {actions} = fakeActions();
    const active: Message = {role: 'assistant', request_id: 'r1', content: '', answer: '', execution_state: 'running'};
    const current = state({activeTurn: active, displayMessages: [active], showStop: true});
    const adapter = createMesExternalStoreAdapter({state: current, actions});
    const empty = fromThreadMessageLike(adapter.convertMessage!(active, 0), 'fallback', {type: 'running'});
    assert.deepEqual(empty.content, []);
    assert.deepEqual(empty.status, {type: 'running'});
    const complete = {...active, content: '已核對的完整快照', answer: '已核對的完整快照', execution_state: 'completed' as const};
    for (const done of [state({activeTurn: complete, displayMessages: [complete]}), state({activeTurn: null, displayMessages: [complete]}), state({activeTurn: complete, displayMessages: [complete], reconnectNeeded: true})]) {
        const completedAdapter = createMesExternalStoreAdapter({state: done, actions});
        const result = fromThreadMessageLike(completedAdapter.convertMessage!(complete, 0), 'fallback', {type: 'complete', reason: 'stop'});
        assert.equal(result.id, empty.id);
        assert.deepEqual(result.content, [{type: 'text', text: complete.content}]);
        assert.deepEqual(result.status, {type: 'complete', reason: 'stop'});
        assert.equal(result.metadata.custom.mesMessage, complete);
        assert.equal(result.metadata.custom.mesLivePresentation, undefined);
    }
});

test('資料不足、取消、失敗與送出待確認的狀態不被轉成成功或正在生成', () => {
    const message: Message = {role: 'assistant', content: '', status: 'insufficient_data', created_at: '不是日期'};
    assert.deepEqual(convertMesMessage(message, 0).status, {type: 'complete', reason: 'stop'});
    assert.equal(convertMesMessage(message, 0).createdAt, undefined);
    assert.deepEqual(convertMesMessage({...message, status: 'cancelled'}, 0).status, {type: 'incomplete', reason: 'cancelled'});
    assert.deepEqual(convertMesMessage({...message, status: 'failed', error_message: '失敗原因'}, 0).status, {type: 'incomplete', reason: 'error', error: '失敗原因'});
    assert.deepEqual(convertMesMessage({...message, status: undefined, execution_state: 'submission_unknown'}, 0).status, {type: 'incomplete', reason: 'other'});
});

test('送出只橋接既有 setDraft 和 submitQuestion，不傳聊天前文或 runtime 自訂參數', async () => {
    const {actions, calls} = fakeActions();
    const adapter = createMesExternalStoreAdapter({state: state(), actions});
    await adapter.onNew({...append('下一題\n詳細說明'), runConfig: {custom: {model: '不可覆寫'}}});
    assert.deepEqual(calls, [{name: 'draft', values: ['下一題\n詳細說明']}, {name: 'submit', values: []}]);
    assert.equal(adapter.setMessages, undefined); assert.equal(typeof adapter.onEdit, 'function'); assert.equal(adapter.onReload, undefined);
    assert.equal(adapter.queue, undefined); assert.equal(adapter.adapters?.attachments, undefined); assert.equal(adapter.unstable_enableToolInvocations, undefined);
});

test('送出前使用最新 controller gate，唯讀、逾時、送出待確認與進行中不能重送', async () => {
    const {actions, calls} = fakeActions(); let latest = state();
    const adapter = createMesExternalStoreAdapter({state: latest, actions}, () => latest);
    for (const blocked of [{sendDisabled: true}, {inputDisabled: true}, {expired: true}, {readOnly: true}, {submitting: true}, {showStop: true}, {unknownSubmission: true}]) {
        latest = state(blocked); await adapter.onNew(append('不應送出的問題'));
    }
    assert.deepEqual(calls, []);
});

test('空白、非使用者、附件與非文字內容不能觸發 MES 提交', async () => {
    const {actions, calls} = fakeActions();
    const adapter = createMesExternalStoreAdapter({state: state(), actions});
    await adapter.onNew(append('  \n'));
    await adapter.onNew({...append('模型訊息'), role: 'assistant'} as AppendMessage);
    await adapter.onNew({...append('附件'), attachments: [{}]} as AppendMessage);
    await adapter.onNew({...append('非文字'), content: [{type: 'image', image: 'https://example.com/img.png'}]} as AppendMessage);
    assert.deepEqual(calls, []);
});

test('歷史與新聊天只橋接選取，metadata管理走控制器而不啟用runtime產生標題', async () => {
    const {actions, calls} = fakeActions();
    const adapter = createMesExternalStoreAdapter({state: state({conversations: [{conversation_id: 'c1', title: '工單進度', read_only: true}]}), actions});
    const threads = adapter.adapters!.threadList!;
    assert.equal(threads.threadId, 'c1'); assert.equal(threads.threads?.[0]?.remoteId, 'c1');
    assert.deepEqual(threads.threads?.[0]?.custom?.mesConversation, {conversation_id: 'c1', title: '工單進度', read_only: true});
    await threads.onSwitchToThread?.('c2'); await threads.onSwitchToNewThread?.();
    assert.deepEqual(calls, [{name: 'select', values: ['c2', true]}, {name: 'new', values: []}]);
    assert.equal(threads.onRename, undefined); assert.equal(threads.onDelete, undefined); assert.equal(threads.onArchive, undefined);
});

test('舊聊天今天追問後與日期交錯的歷史仍依今天、昨天、更早呈現，不改控制器清單', () => {
    const {actions, calls} = fakeActions();
    const today = new Date(); today.setHours(12, 0, 0, 0);
    const yesterday = new Date(today); yesterday.setDate(yesterday.getDate() - 1);
    const earlier = new Date(today); earlier.setDate(earlier.getDate() - 3);
    const conversations = [
        {conversation_id: 'c4', title: '今日新聊天', updated_at: today.toISOString()},
        {conversation_id: 'c3', title: '三天前的聊天', updated_at: earlier.toISOString()},
        {conversation_id: 'c2', title: '舊聊天今天追問', updated_at: today.toISOString()},
        {conversation_id: 'c1', title: '昨日聊天', updated_at: yesterday.toISOString()},
    ];
    const before = JSON.stringify(conversations);
    const adapter = createMesExternalStoreAdapter({state: state({conversationId: 'c2', conversations}), actions});
    assert.deepEqual(adapter.adapters?.threadList?.threads?.map(thread => thread.id), ['c4', 'c2', 'c1', 'c3']);
    assert.equal(adapter.adapters?.threadList?.threadId, 'c2');
    assert.equal(JSON.stringify(conversations), before);
    assert.equal(adapter.adapters?.threadList?.threads?.[1]?.custom?.mesConversation, conversations[2]);
    assert.deepEqual(calls, []);
});

test('停止只取消明確可停止的回合，重新讀取只用原 reconnect', async () => {
    const {actions, calls} = fakeActions(); let latest = state();
    const adapter = createMesExternalStoreAdapter({state: latest, actions}, () => latest);
    await adapter.onCancel?.();
    latest = state({showStop: true, cancelling: true}); await adapter.onCancel?.();
    latest = state({showStop: true, expired: true}); await adapter.onCancel?.();
    latest = state({showStop: true}); await adapter.onCancel?.(); await adapter.onRefetchThread?.();
    assert.deepEqual(calls, [{name: 'cancel', values: []}, {name: 'reconnect', values: []}]);
});

test('回饋使用原 Request ID 與既有端點，保留已儲存評價並阻擋重複保存', async () => {
    const {actions, calls} = fakeActions(); let latest = state();
    const source: Message = {role: 'assistant', content: '回答', request_id: 'r1', status: 'succeeded', feedback: {rating: 'down', reason: 'wrong_number', note: '數字需核對'}};
    const converted = convertMesMessage(source, 0, 'c1');
    assert.deepEqual(converted.metadata?.submittedFeedback, {type: 'negative', comment: '數字需核對'});
    const message = fromThreadMessageLike(converted, 'fallback', {type: 'complete', reason: 'stop'});
    const adapter = createMesExternalStoreAdapter({state: latest, actions}, () => latest);
    await adapter.adapters?.feedback?.submit({message, type: 'positive'});
    latest = state({feedbackSaving: ['r1']}); await adapter.adapters?.feedback?.submit({message, type: 'positive'});
    assert.deepEqual(calls, [{name: 'feedback', values: ['r1', {rating: 'up', reason: null, note: ''}]}]);
});

class MemoryStorage implements Storage {
    private values = new Map<string, string>();
    get length() { return this.values.size; }
    key(index: number) { return [...this.values.keys()][index] || null; }
    getItem(key: string) { return this.values.get(key) || null; }
    setItem(key: string, value: string) { this.values.set(key, String(value)); }
    removeItem(key: string) { this.values.delete(key); }
    clear() { this.values.clear(); }
}

test('實際控制器點選保存追問只保存草稿，切換歷史與新聊天皆為零 POST', async () => {
    const storage = new MemoryStorage();
    storage.setItem('X_BI_accountNo', 'ADMINV2'); storage.setItem('X_BI_TokenKey', 'local-fixture-token'); storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString());
    storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const originalWindow = globalThis.window;
    globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    let posts = 0;
    const saved = followupMessage();
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = new URL(String(input), 'http://fixture').pathname;
        const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});
        if (options.method === 'POST') {posts++; throw new Error('點選建議不應提交請求');}
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '原聊天', messages: [saved]});
        if (path.endsWith('/c2')) return json({conversation_id: 'c2', title: '另一聊天', messages: []});
        throw new Error('未預期測試請求：' + path);
    };
    const controller = new ChatController({storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat();
        const source = getMesFollowupSource(controller.getSnapshot())!;
        const adapter = createMesExternalStoreAdapter({state: controller.getSnapshot(), actions: controller.actions}, controller.getSnapshot);
        assert.deepEqual(adapter.suggestions, source.suggestions);
        assert.equal(setMesFollowupDraft(controller.getSnapshot(), controller.actions, source, source.suggestions[0]!), true);
        assert.equal(controller.getSnapshot().draft, source.suggestions[0]!.prompt);
        assert.equal(controller.getSnapshot().messages.length, 1);
        assert.equal(JSON.parse(storage.getItem('X_MES_AI_CHAT_ADMINV2_DRAFTS')!).c1, source.suggestions[0]!.prompt);
        const selecting = controller.actions.selectConversation('c2');
        assert.equal(setMesFollowupDraft(controller.getSnapshot(), controller.actions, source, source.suggestions[0]!), false);
        await selecting;
        assert.equal(setMesFollowupDraft(controller.getSnapshot(), controller.actions, source, source.suggestions[0]!), false);
        assert.equal(controller.getSnapshot().draft, '');
        await controller.actions.selectConversation('c1');
        assert.equal(controller.getSnapshot().draft, source.suggestions[0]!.prompt);
        controller.actions.newChat();
        assert.equal(setMesFollowupDraft(controller.getSnapshot(), controller.actions, source, source.suggestions[0]!), false);
        assert.equal(controller.getSnapshot().draft, '');
        assert.equal(posts, 0);
    } finally {controller.dispose(); globalThis.window = originalWindow;}
});

test('實際 controller 搭配 adapter 並行送出只做一次 messages POST，無模型或資料庫連線', async () => {
    const storage = new MemoryStorage();
    storage.setItem('X_BI_accountNo', 'ADMINV2'); storage.setItem('X_BI_TokenKey', 'local-fixture-token'); storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString());
    const originalWindow = globalThis.window;
    globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    let posts = 0;
    const completed = {conversation_id: 'c1', request_id: 'r1', execution_state: 'completed', status: 'succeeded', answer: '已保存的測試回答'};
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = new URL(String(input), 'http://fixture').pathname;
        const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/conversations') && options.method === 'POST') return json({conversation_id: 'c1', title: '測試聊天'}, 201);
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/messages') && options.method === 'POST') { posts++; return json(completed, 202); }
        if (path.includes('/turns/')) return json(completed);
        throw new Error('未預期測試請求：' + path);
    };
    const controller = new ChatController({storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('工單產量？');
        const adapter = createMesExternalStoreAdapter({state: controller.getSnapshot(), actions: controller.actions}, controller.getSnapshot);
        await Promise.all([adapter.onNew(append('工單產量？')), adapter.onNew(append('工單產量？'))]);
        assert.equal(posts, 1);
        assert.equal(controller.getSnapshot().displayMessages.filter(message => message.role === 'assistant').length, 1);
    } finally { controller.dispose(); globalThis.window = originalWindow; }
});


test('編輯只接受目前聊天已送出使用者訊息，保留草稿並使用既有重送動作', async () => {
    const {actions, calls} = fakeActions();
    const source: Message = {role: 'user', content: '原問題', request_id: 'r1', client_message_id: 'm1'};
    let latest = state({draft: '', sendDisabled: true, messages: [source], displayMessages: [source]});
    const adapter = createMesExternalStoreAdapter({state: latest, actions}, () => latest);
    const edit = {...append('修改後的問題'), sourceId: convertMesMessage(source, 0, 'c1').id};
    await adapter.onEdit!(edit);
    assert.deepEqual(calls, [{name: 'edit', values: ['r1', '修改後的問題']}]);
    calls.length = 0;
    await adapter.onEdit!({...edit, sourceId: '另一個聊天室:user:m1'});
    await adapter.onEdit!({...edit, content: [{type: 'text', text: '  '} ]});
    await adapter.onEdit!({...edit, attachments: [{}]} as AppendMessage);
    for (const blocked of [{inputDisabled: true}, {expired: true}, {readOnly: true}, {submitting: true}, {showStop: true}, {unknownSubmission: true}, {runtime: {mode: 'API' as const, continuous_context: false}}]) {
        latest = {...latest, ...blocked};
        await adapter.onEdit!(edit);
        assert.equal(createMesExternalStoreAdapter({state: latest, actions}).onEdit, undefined);
        latest = state({messages: [source], displayMessages: [source]});
    }
    assert.deepEqual(calls, []);
});
