import {decodeReportCard} from '../src/chat/report-decoder';
import test from 'node:test';
import assert from 'node:assert/strict';
import {isChartEvidenceNotice} from '../src/chat/report';
import {planSavedCharts} from '../src/chat/chart-planner';
import type { RawReportCard as ReportCard } from '../src/chat/types';
const reportChartPanels = (card: ReportCard) => planSavedCharts(decodeReportCard(card)).recommended.map(chart => ({...chart, kind: chart.mark, points: chart.points.map(({label, values}) => ({label, values})),
    series: chart.encoding.series.map(key => ({key, label: chart.columns.find(column => column.name === key)!.label})),
}));
const reportChartData = (card: ReportCard) => {
    const chart = reportChartPanels(card)[0];
    if (!chart) return null;
    const key = chart.encoding.y;
    return {...chart, measure: chart.series[0].label, points: chart.points.filter(point => point.values[key] !== null).map(point => ({label: point.label, value: point.values[key]}))};
};

const card = (kind: string, overrides: Partial<ReportCard> = {}): ReportCard => ({id: 'saved', kind, status: 'ok', metrics: [], detail: {rows: []}, ...overrides});
test('工單比較只使用保存的產量與目標，不夾帶百分比或推算剩餘數', () => {
    const saved = card('work_order', {metrics: [{key: 'produced_quantity', label: '已報工', value: 107102}, {key: 'planned_quantity', label: '目標', value: 130000}, {key: 'completion_percent', value: 99.99, unit: '%'}]});
    const before = JSON.stringify(saved), data = reportChartData(saved)!;
    assert.deepEqual(data.points.map(point => point.value), [107102, 130000]);
    assert.equal(data.unit, ''); assert.ok(data.notices.includes('數量單位尚未驗證')); assert.equal(JSON.stringify(saved), before);
});
test('缺值、字串、布林、NaN 與無限大不補零，真實零仍呈現', () => {
    const values = [null, '52', false, NaN, Infinity, 0];
    const data = reportChartData(card('machine_production', {detail: {rows: values.map((value, index) => ({machine_id: `M${index}`, produced_quantity: value}))}}))!;
    assert.deepEqual(data.points, [{label: 'M5', value: 0}]); assert.ok(data.notices.some(notice => notice.startsWith('5 筆')));
});
test('部分工單量有明確限制，不生成百分比', () => {
    const data = reportChartData(card('work_order', {status: 'insufficient_data', metrics: [{key: 'produced_quantity', value: 20}, {key: 'planned_quantity', value: 100}], detail: {rows: [{quantity_complete: false}]}}))!;
    assert.match(data.points[0].label, /已知報工量/); assert.ok(data.notices.some(notice => notice.includes('完整完成率')));
});
test('Cycle 樣本不足不畫圖，有效樣本保留 min avg max 的秒數', () => {
    const saved = card('machine_cycle', {metrics: [{key: 'minimum_cycle_seconds', value: 5, unit: '秒'}, {key: 'average_cycle_seconds', value: 6, unit: '秒'}, {key: 'maximum_cycle_seconds', value: 7, unit: '秒'}, {key: 'interval_sample_count', value: 2}]});
    assert.deepEqual(reportChartData(saved)!.points.map(point => point.value), [5, 6, 7]);
    assert.equal(reportChartData({...saved, status: 'insufficient_data'}), null);
    assert.equal(reportChartData({...saved, metrics: saved.metrics!.filter(item => item.key !== 'interval_sample_count')}), null);
});
test('人員組合不拆人、不重排，負數保留與部分量標記', () => {
    const data = reportChartData(card('personnel_production', {detail: {rows: [{personnel_group: 'A,B', produced_quantity: 15}, {personnel_group: 'C', produced_quantity: -2, quantity_complete: false}]}}))!;
    assert.deepEqual(data.points.map(point => point.value), [15, -2]); assert.equal(data.points[0].label, 'A,B');
    assert.ok(data.notices.some(notice => notice.includes('不拆分'))); assert.ok(data.notices.some(notice => notice.includes('负數') || notice.includes('負數')));
});
test('大量與分頁結果保留前八項和範圍，不宣稱完整排名', () => {
    const data = reportChartData(card('machine_production', {pagination: {truncated: true}, detail: {rows: Array.from({length: 12}, (_, index) => ({machine_id: `M${index}`, produced_quantity: 12 - index}))}}))!;
    assert.equal(data.points.length, 8); assert.equal(data.points[0].label, 'M0');
    assert.ok(data.notices.some(notice => notice.includes('共 12 項'))); assert.ok(data.notices.some(notice => notice.includes('截斷')));
});
test('未知工具、無資料、未保存數字不由回答文字猜圖表', () => {
    for (const saved of [card('unsupported', {answer: '产量99'}), card('work_order', {answer: '產量99'}), card('machine_production', {status: 'no_data'})]) assert.equal(reportChartData(saved), null);
    assert.equal(reportChartData(card('running_orders', {detail: {rows: [{work_order_no: 'same', produced_quantity: 5}, {work_order_no: 'same', produced_quantity: 5}]}})), null);
});
test('不同單位不在同一軸混畫；班別與月份保留資料列意義', () => {
    assert.equal(reportChartData(card('work_order', {metrics: [{key: 'produced_quantity', value: 5, unit: '件'}, {key: 'planned_quantity', value: 5, unit: 'kg'}]})), null);
    const shift = reportChartData(card('shift_production', {detail: {rows: [{work_order_no: 'WO1', machine_id: 'M1', shift_no: 'D', total_quantity: 12}]}}))!;
    assert.equal(shift.points[0].label, 'WO1 · M1 · D'); assert.match(shift.notices.join(' '), /未自行合併/);
    const month = reportChartData(card('reporting_coverage', {presentation: 'answer', months_truncated: true, detail: {rows: [{production_month: '2026-07', produced_quantity: 12}, {production_month: '2026-09', produced_quantity: null}]}}))!;
    assert.deepEqual(month.points, [{label: '2026-07', value: 12}]);
});
test('報工紀錄限本頁，不將多筆明細合成工單總量', () => {
    const data = reportChartData(card('reporting_records', {pagination: {has_more: true}, detail: {rows: [{task_id: 'task1', reported_at: '2026-08-01', produced_quantity: 7}]}}))!;
    assert.equal(data.points[0].label, 'task1 · 2026-08-01'); assert.match(data.notices.join(' '), /本頁/);
});

test('資料範圍預設不畫月份圖表，只有明確月份產量需求可展開', () => {
    const coverage = card('reporting_coverage', {detail: {rows: [{production_month: '2026-08', produced_quantity: 10}]}});
    assert.equal(reportChartData(coverage), null);
    assert.equal(reportChartData({...coverage, presentation: 'evidence'}), null);
    assert.equal(reportChartData({...coverage, presentation: 'answer'})?.points[0]?.value, 10);
});

test('既有工單與 Cycle 圖表保留保存值與限制，未知結果不自行畫圖', () => {
    const saved = card('work_order', {metrics: [{key: 'produced_quantity', label: '已報工', value: 20}, {key: 'planned_quantity', label: '目標', value: 100}], quantity_complete: false});
    const data = reportChartData(saved)!, panel = reportChartPanels(saved)[0];
    assert.equal(panel.kind, 'bar');
    assert.deepEqual(panel.points.map(point => point.values.value), data.points.map(point => point.value));
    assert.deepEqual(panel.notices, data.notices);
    assert.deepEqual(reportChartPanels(card('unsupported')), []);
    assert.deepEqual(reportChartPanels(card('machine_cycle', {status: 'insufficient_data'})), []);
});

test('月份趨勢保留原月份缺值斷點，未升序或重複月份維持長條', () => {
    const saved = card('reporting_coverage', {presentation: 'answer', detail: {rows: [
        {production_month: '2026-07', produced_quantity: 12}, {production_month: '2026-08', produced_quantity: null}, {production_month: '2026-09', produced_quantity: 0},
    ]}});
    const before = JSON.stringify(saved), panel = reportChartPanels(saved)[0];
    assert.equal(panel.kind, 'line');
    assert.deepEqual(panel.points.map(point => point.values.value), [12, null, 0]);
    assert.equal(JSON.stringify(saved), before);
    for (const months of [['2026-08', '2026-07'], ['2026-07', '2026-07'], ['2026-00', '2026-02']]) {
        const other = card('reporting_coverage', {presentation: 'answer', detail: {rows: months.map(production_month => ({production_month, produced_quantity: 12}))}});
        assert.equal(reportChartPanels(other)[0].kind, 'bar');
    }
    assert.deepEqual(reportChartPanels({...saved, presentation: 'evidence'}), []);
});

test('月份趨勢前八項包含缺值位置，總項數與未知單位仍屬依據提示', () => {
    const saved = card('reporting_coverage', {presentation: 'answer', detail: {rows: Array.from({length: 10}, (_, index) => ({production_month: `2026-${String(index + 1).padStart(2, '0')}`, produced_quantity: index === 1 ? null : index}))}});
    const panel = reportChartPanels(saved)[0];
    assert.equal(panel.points.length, 8);
    assert.equal(panel.points[1].values.value, null);
    assert.equal(panel.points[7].label, '2026-08');
    assert.deepEqual(panel.notices.filter(isChartEvidenceNotice), ['數量單位尚未驗證', '顯示已保存順序的前 8 項／共 10 項，完整資料請查看明細']);
});

test('月份相鄰才畫折線，缺月維持保存資料的長條，不補中間月份', () => {
    const saved = card('reporting_coverage', {presentation: 'answer', detail: {rows: [
        {production_month: '2026-07', produced_quantity: 12}, {production_month: '2026-09', produced_quantity: 15},
    ]}});
    const before = JSON.stringify(saved), panel = reportChartPanels(saved)[0];
    assert.equal(panel.kind, 'bar');
    assert.deepEqual(panel.points.map(point => point.label), ['2026-07', '2026-09']);
    assert.equal(JSON.stringify(saved), before);
});

test('月份前八項全部缺值不產生空折線，也不往後挑有值的月份', () => {
    const saved = card('reporting_coverage', {presentation: 'answer', detail: {rows: Array.from({length: 9}, (_, index) => ({production_month: `2026-${String(index + 1).padStart(2, '0')}`, produced_quantity: index === 8 ? 12 : null}))}});
    const before = JSON.stringify(saved);
    assert.deepEqual(reportChartPanels(saved), []);
    assert.equal(JSON.stringify(saved), before);
});
