import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {ChatController} from '../src/chat/controller';
import {decodeSupplementaryAnalysis} from '../src/chat/supplementary-analysis';
import type {SupplementaryAnalysis, Turn} from '../src/chat/types';

const scoped = register({namespace: 'supplementary-analysis', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {SupplementaryAnalysisContent, observeVisibleAnalysis} = await scoped.import('../src/features/mes/MesSupplementaryAnalysis.tsx', import.meta.url) as typeof import('../src/features/mes/MesSupplementaryAnalysis');
const finding = {id: 'change-1', title: '已保存的產量變化', observation: '本期產量比比較期低', scope: 'SC01，同等天數', comparison: '與前期比較', follow_up: {label: '看日期明細', question: '請列出 SC01 本期的日期明細'}};
function analysis(state: SupplementaryAnalysis['state'] = 'running'): SupplementaryAnalysis {return {request_id: 'a1', state, findings: state === 'completed' ? [finding] : []};}
function main(): Turn {return {conversation_id: 'c1', request_id: 'r1', execution_state: 'completed', status: 'succeeded', answer: '主答案保持完整', supplementary_analysis: analysis()};}
function json(value: unknown, status = 200) {return new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});}
function path(input: RequestInfo | URL) {return new URL(String(input), 'http://fixture').pathname;}
function deferred<T>() {let resolve!: (value: T) => void; const promise = new Promise<T>(accept => {resolve = accept;}); return {promise, resolve};}
async function until(check: () => boolean) {for (let n = 0; n < 200; n++) {if (check()) return; await new Promise(resolve => setTimeout(resolve, 2));} assert.fail('預期狀態未出現');}
class MemoryStorage implements Storage {
    values = new Map<string, string>(); get length() {return this.values.size;} key(n: number) {return [...this.values.keys()][n] || null;}
    getItem(key: string) {return this.values.get(key) || null;} setItem(key: string, value: string) {this.values.set(key, value);} removeItem(key: string) {this.values.delete(key);} clear() {this.values.clear();}
}
function setup(child: (options: RequestInit) => Promise<Response>, extra?: (url: string, options: RequestInit) => Response | Promise<Response> | undefined) {
    const original = globalThis.window; globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    const storage = new MemoryStorage(); storage.setItem('X_BI_accountNo', 'ADMINV2'); storage.setItem('X_BI_TokenKey', 'fixture-token'); storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString()); storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const url = path(input), overridden = extra?.(url, options); if (overridden) return overridden;
        if (url.endsWith('/runtime')) return json({mode: 'API', continuous_context: true, supports_message_edit: true});
        if (url.endsWith('/conversations')) return json({items: []});
        if (url.endsWith('/c1')) return json({conversation_id: 'c1', title: '已完成的主題', active_request_id: 'a1', messages: [{role: 'user', content: '原問題', request_id: 'r1'}, {...main(), role: 'assistant', content: main().answer}]});
        if (url.endsWith('/a1')) return child(options);
        throw new Error(url);
    };
    const controller = new ChatController({storage, fetchImpl, pollIntervalMs: 5}, 'X');
    return {controller, storage, restore() {controller.dispose(); globalThis.window = original;}};
}

for (const state of ['pending', 'running', 'completed', 'no_signal', 'insufficient_data', 'failed', 'cancelled'] as const) test(`補充分析 ${state} 明確呈現且只有處理中持續旋轉`, () => {
    const html = renderToStaticMarkup(createElement(SupplementaryAnalysisContent, {analysis: analysis(state), onFollowUp() {}, onRetry() {}}));
    assert.match(html, /補充分析/); assert.match(html, new RegExp(`data-state="${state}"`));
    assert.equal(html.includes('animate-spin'), state === 'pending' || state === 'running');
    assert.equal(html.includes('data-finding-id'), state === 'completed');
    assert.doesNotMatch(html, /motion-reduce:animate-none/);
});
test('分析只解碼公開欄位，損壞單區塊不冒充分析完成', () => {
    assert.deepEqual(decodeSupplementaryAnalysis({...analysis('completed'), private_plan: '不公開'}), analysis('completed'));
    for (const bad of [{...analysis(), state: 'unknown'}, {...analysis(), request_id: 'another'}, {...analysis('completed'), findings: []}, {...analysis(), findings: [finding]}, {...analysis('completed'), findings: [finding, finding]}, {...analysis('completed'), findings: [{...finding, scope: ''}]}]) assert.throws(() => decodeSupplementaryAnalysis(bad, 'a1'));
});
test('分析讀取失敗停止轉圈，404不顯示重試；原回答文案不重複', () => {
    const html = renderToStaticMarkup(createElement(SupplementaryAnalysisContent, {analysis: analysis(), error: {message: '分析已不存在', retryable: false}, onFollowUp() {}, onRetry() {}}));
    assert.doesNotMatch(html, /animate-spin|重新載入分析/); assert.equal(html.match(/分析已不存在/g)?.length, 1);
});
test('可見性控制只觀看可見區域，離開與卸載各自停止，晚到 observer 不恢復', () => {
    const original = globalThis.IntersectionObserver; let callback!: IntersectionObserverCallback, starts = 0, stops = 0;
    globalThis.IntersectionObserver = class {constructor(fn: IntersectionObserverCallback) {callback = fn;} observe() {} disconnect() {}} as unknown as typeof IntersectionObserver;
    try {
        const cleanup = observeVisibleAnalysis({} as Element, () => {starts++; return () => {stops++;};});
        const emit = (visible: boolean) => callback([{isIntersecting: visible}] as IntersectionObserverEntry[], {} as IntersectionObserver);
        emit(true); emit(true); assert.equal(starts, 1); emit(false); assert.equal(stops, 1); emit(true); cleanup(); emit(true);
        assert.equal(starts, 2); assert.equal(stops, 2);
    } finally {globalThis.IntersectionObserver = original;}
});
test('主答案可繼續送問，分析觀察去重且完成後不更動主題、草稿、答案或 activeTurn', async () => {
    const pending = deferred<Response>(); let reads = 0;
    const env = setup(async () => {reads++; return pending.promise;});
    try {
        await env.controller.actions.openChat(); env.controller.actions.setDraft('那八月呢');
        assert.equal(env.controller.getSnapshot().sendDisabled, false); assert.equal(env.controller.getSnapshot().activeTurn, null);
        const first = env.controller.actions.observeSupplementaryAnalysis('r1'), second = env.controller.actions.observeSupplementaryAnalysis('r1');
        assert.equal(reads, 1); first();
        pending.resolve(json({conversation_id: 'c1', request_id: 'a1', event_sequence: 4, supplementary_analysis: analysis('completed')}));
        await until(() => env.controller.getSnapshot().messages[1].supplementary_analysis?.state === 'completed');
        assert.equal(env.controller.getSnapshot().messages[1].content, '主答案保持完整'); assert.equal(env.controller.getSnapshot().draft, '那八月呢'); assert.equal(env.controller.getSnapshot().activeTurn, null); assert.equal(env.controller.getSnapshot().showStop, false); assert.equal(env.controller.getSnapshot().sendDisabled, false); second();
        assert.equal(reads, 1);
    } finally {pending.resolve(json({})); env.restore();}
});
test('分析從保存的 pending 輪詢到終態即停止，零 POST；重開由主答保存結果恢復', async () => {
    let reads = 0, completed = false;
    const env = setup(async () => {
        reads++; completed = reads >= 2;
        return json({request_id: 'a1', event_sequence: reads, supplementary_analysis: analysis(completed ? 'completed' : 'running')});
    }, url => completed && url.endsWith('/c1') ? json({conversation_id: 'c1', messages: [{...main(), role: 'assistant', content: main().answer, supplementary_analysis: analysis('completed')}]}) : undefined);
    try {
        await env.controller.actions.openChat(); const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        await until(() => env.controller.getSnapshot().messages[1].supplementary_analysis?.state === 'completed');
        await new Promise(resolve => setTimeout(resolve, 20)); assert.equal(reads, 2); stop();
        env.controller.actions.closeChat(); await env.controller.actions.openChat();
        assert.equal(env.controller.getSnapshot().messages[0].supplementary_analysis?.findings[0].id, finding.id);
        const stopRestored = env.controller.actions.observeSupplementaryAnalysis('r1'); assert.equal(reads, 2); stopRestored();
    } finally {env.restore();}
});
test('錯聊天或錯分析來源快照只顯示局部錯誤，不覆寫答案', async () => {
    const env = setup(async () => json({conversation_id: 'another-chat', request_id: 'a1', supplementary_analysis: analysis('completed')}));
    try {
        await env.controller.actions.openChat(); const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        await until(() => !!env.controller.getSnapshot().supplementaryAnalysisErrors?.r1);
        assert.equal(env.controller.getSnapshot().messages[1].content, '主答案保持完整');
        assert.equal(env.controller.getSnapshot().messages[1].supplementary_analysis?.state, 'running'); stop();
    } finally {env.restore();}
});
for (const status of [404, 503]) test(`分析讀取 ${status} 不改主答案，不自動重試，503 可明確重試`, async () => {
    let reads = 0;
    const env = setup(async () => {reads++; return reads === 1 ? json({}, status) : json({request_id: 'a1', supplementary_analysis: analysis('no_signal')});}, url => url.endsWith('/r1') ? json({}, 404) : undefined);
    try {
        await env.controller.actions.openChat(); const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        await until(() => !!env.controller.getSnapshot().supplementaryAnalysisErrors?.r1);
        await new Promise(resolve => setTimeout(resolve, 20)); assert.equal(reads, 1);
        assert.equal(env.controller.getSnapshot().messages[1].content, '主答案保持完整');
        assert.equal(env.controller.getSnapshot().supplementaryAnalysisErrors?.r1.retryable, status === 503);
        env.controller.actions.retrySupplementaryAnalysis('r1');
        if (status === 503) await until(() => env.controller.getSnapshot().messages[1].supplementary_analysis?.state === 'no_signal');
        assert.equal(reads, status === 503 ? 2 : 1); stop();
    } finally {env.restore();}
});
test('主答已完成但子回合尚未建立時核對父關聯，持續觀看到分析完成且不重送問題', async () => {
    let childReads = 0, parentReads = 0, posts = 0;
    const env = setup(async () => {
        childReads++;
        return childReads === 1 ? json({}, 404) : json({request_id: 'a1', event_sequence: 1, supplementary_analysis: analysis('completed')});
    }, (url, options) => {
        if (options.method === 'POST') posts++;
        if (url.endsWith('/r1')) {parentReads++; return json({...main(), event_sequence: 100, supplementary_analysis: analysis('pending')});}
    });
    try {
        await env.controller.actions.openChat(); env.controller.actions.setDraft('接著看八月');
        const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        await until(() => env.controller.getSnapshot().messages[1].supplementary_analysis?.state === 'completed');
        assert.equal(env.controller.getSnapshot().supplementaryAnalysisErrors?.r1, undefined);
        assert.equal(env.controller.getSnapshot().messages[1].content, '主答案保持完整');
        assert.equal(env.controller.getSnapshot().sendDisabled, false); assert.equal(env.controller.getSnapshot().draft, '接著看八月');
        await new Promise(resolve => setTimeout(resolve, 20));
        assert.equal(childReads, 2); assert.equal(parentReads, 1); assert.equal(posts, 0); stop();
    } finally {env.restore();}
});
for (const parent of ['missing', 'unlinked', 'changed', 'cross-chat'] as const) test(`子回合404且父回合 ${parent} 時停止觀看，不恢復不存在來源`, async () => {
    let childReads = 0, parentReads = 0;
    const env = setup(async () => {childReads++; return json({}, 404);}, url => {
        if (!url.endsWith('/r1')) return undefined;
        parentReads++;
        if (parent === 'missing') return json({}, 404);
        if (parent === 'unlinked') return json({...main(), supplementary_analysis: null});
        if (parent === 'cross-chat') return json({...main(), conversation_id: 'another-chat'});
        return json({...main(), supplementary_analysis: {...analysis(), request_id: 'another-analysis'}});
    });
    try {
        await env.controller.actions.openChat(); const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        await until(() => !!env.controller.getSnapshot().supplementaryAnalysisErrors?.r1);
        assert.equal(env.controller.getSnapshot().supplementaryAnalysisErrors?.r1.retryable, false);
        env.controller.actions.retrySupplementaryAnalysis('r1');
        await new Promise(resolve => setTimeout(resolve, 20));
        assert.equal(childReads, 1); assert.equal(parentReads, 1); assert.equal(env.controller.getSnapshot().messages[1].content, '主答案保持完整'); stop();
    } finally {env.restore();}
});
test('子回合404後的父快照晚到遇到切換聊天，不恢復已停止的分析', async () => {
    const pending = deferred<Response>(); let parentReads = 0;
    const env = setup(async () => json({}, 404), url => {if (url.endsWith('/r1')) {parentReads++; return pending.promise;}});
    try {
        await env.controller.actions.openChat(); const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        await until(() => parentReads === 1); env.controller.actions.newChat();
        pending.resolve(json({...main(), supplementary_analysis: analysis('completed')}));
        await new Promise(resolve => setTimeout(resolve, 20));
        assert.deepEqual(env.controller.getSnapshot().messages, []); assert.equal(env.controller.getSnapshot().supplementaryAnalysisErrors?.r1, undefined); stop();
    } finally {pending.resolve(json({})); env.restore();}
});
for (const invalidation of ['switch', 'close', 'delete', 'edit', 'account', 'dispose'] as const) test(`分析晚到 ${invalidation} 不恢復不可見來源或污染前景`, async () => {
    const pending = deferred<Response>(); let signal: AbortSignal | null | undefined;
    const env = setup(async options => {signal = options.signal; return pending.promise;}, (url, options) => {
        if (options.method === 'DELETE') return json({deleted: true});
        if (options.method === 'POST' && url.endsWith('/messages')) return json({conversation_id: 'c1', request_id: 'r2', execution_state: 'completed', status: 'succeeded', answer: '修改後答案'});
        if (url.endsWith('/r2')) return json({conversation_id: 'c1', request_id: 'r2', execution_state: 'completed', status: 'succeeded', answer: '修改後答案'});
    });
    try {
        await env.controller.actions.openChat(); const stop = env.controller.actions.observeSupplementaryAnalysis('r1');
        if (invalidation === 'switch') env.controller.actions.newChat();
        if (invalidation === 'close') env.controller.actions.closeChat();
        if (invalidation === 'delete') await env.controller.actions.deleteConversation('c1');
        if (invalidation === 'edit') await env.controller.actions.resubmitQuestion('r1', '修改問題');
        if (invalidation === 'account') env.storage.setItem('X_BI_accountNo', 'other');
        if (invalidation === 'dispose') env.controller.dispose();
        pending.resolve(json({request_id: 'a1', supplementary_analysis: analysis('completed')}));
        await new Promise(resolve => setTimeout(resolve, 15));
        assert.equal(env.controller.getSnapshot().messages.some(message => message.supplementary_analysis?.state === 'completed'), false);
        if (invalidation !== 'account') assert.ok(signal?.aborted);
        if (invalidation === 'edit') assert.equal(env.controller.getSnapshot().activeTurn?.request_id, 'r2'); stop();
    } finally {pending.resolve(json({})); env.restore();}
});
