import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import type {ChatActions, ChatState, Message} from '../src/chat/types';

const scoped = register({namespace: 'saved-answer-presentation', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {ThreadPrimitive, MessagePrimitive, useAuiState, useMessagePartText} = await scoped.import('@assistant-ui/react', import.meta.url) as typeof import('@assistant-ui/react');
const {MesAssistantProvider} = await scoped.import('../src/chat/assistant-runtime.tsx', import.meta.url) as typeof import('../src/chat/assistant-runtime');
const {MesUiProvider, useMesUi} = await scoped.import('../src/chat/mes-ui-context.tsx', import.meta.url) as typeof import('../src/chat/mes-ui-context');

function state(message: Message, overrides: Partial<ChatState> = {}): ChatState {
    return {enabled: true, opened: true, expanded: false, historyOpen: false, view: 'chat', runtime: {mode: 'API', continuous_context: false}, conversationId: 'c1', conversationTitle: '完整呈現測試', conversation: null, conversations: [], historyCursor: null, historyLoading: false, historyLoaded: true, historyStatus: '', historyArchived: false, conversationSaving: [], messages: [message], activeTurn: message, displayMessages: [message], draft: '中文組字中的草稿', submitting: false, cancelling: false, connectionStatus: '', sessionNotice: '', expired: false, readOnly: false, readOnlyNotice: '', hint: '', sendDisabled: true, inputDisabled: false, showStop: message.execution_state === 'running', unknownSubmission: false, reconnectNeeded: false, reports: {}, exporting: [], feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null, ...overrides};
}
function TextContent() {
    const text = useMessagePartText().text;
    const status = useAuiState(value => value.message.status?.type);
    const {state: current} = useMesUi();
    return createElement('span', {'data-status': status, 'data-draft': current.draft}, text);
}
function MessageContent() {
    return createElement(MessagePrimitive.Root, null, createElement(MessagePrimitive.Parts, {components: {Text: TextContent}}));
}
function render(message: Message, overrides: Partial<ChatState> = {}) {
    const props = {state: state(message, overrides), actions: {} as ChatActions};
    return renderToStaticMarkup(createElement(MesUiProvider, props,
        createElement(MesAssistantProvider, props, createElement(ThreadPrimitive.Root, null,
            createElement(ThreadPrimitive.Messages, {components: {Message: MessageContent}})))));
}
function completed(text: string): Message {
    return {role: 'assistant', request_id: 'r1', conversation_id: 'c1', content: text, answer: text, execution_state: 'completed', status: 'succeeded'};
}

for (const origin of ['live', 'history', 'reconnect'] as const) {
    for (const size of [100, 10000]) {
        test(`${origin} 完成答案 ${size} 字第一次呈現即完整，無生成尾巴且原中文草稿不變`, () => {
            const suffix = '已知零 0、未知 —、尾端已核對';
            const text = '數'.repeat(size - suffix.length) + suffix;
            const message = completed(text), before = structuredClone(message);
            const html = render(message, origin === 'history' ? {activeTurn: null} : origin === 'reconnect' ? {reconnectNeeded: true, connectionStatus: '重新讀取保存狀態'} : {});
            assert.ok(html.includes(text));
            assert.match(html, /data-status="complete"/);
            assert.doesNotMatch(html, /data-status="running"/);
            assert.match(html, /data-draft="中文組字中的草稿"/);
            assert.deepEqual(message, before);
        });
    }
}

test('尚無答案的查詢回合只維持真實 running，不製造回答文字', () => {
    const message: Message = {role: 'assistant', request_id: 'r1', content: '', execution_state: 'running', status: 'started'};
    const html = render(message);
    assert.match(html, /data-status="running"[^>]*><\/span>/);
    assert.doesNotMatch(html, /已核對/);
    assert.equal(message.content, '');
});

for (const execution_state of ['cancelled', 'failed', 'submission_unknown'] as const) {
    test(`${execution_state} 保留既有文字與 incomplete 狀態，沒有重播或假成功`, () => {
        const message = {...completed('完整保留已收到的核對內容'), execution_state};
        const html = render(message, {reconnectNeeded: true});
        assert.match(html, /完整保留已收到的核對內容/);
        assert.match(html, /data-status="incomplete"/);
        assert.doesNotMatch(html, /data-status="running"|data-status="complete"/);
    });
}

test('正常與減少動畫偏好均直接呈現相同保存答案，中文草稿不受偏好更新影響', () => {
    const originalWindow = globalThis.window;
    const text = '完整答案：107,102 ÷ 130,000 = 82.39%，零與缺值保持原值';
    try {
        for (const matches of [false, true]) {
            globalThis.window = {matchMedia: () => ({matches, addEventListener() {}, removeEventListener() {}})} as unknown as Window & typeof globalThis;
            const html = render(completed(text));
            assert.ok(html.includes(text));
            assert.match(html, /data-status="complete"/);
            assert.match(html, /data-draft="中文組字中的草稿"/);
        }
    } finally {globalThis.window = originalWindow;}
});

test('關閉後、切換畫面及歷史重新掛載不重設保存文字或原訊息完成狀態', () => {
    const text = '重新開啟仍完整保留的答案';
    for (const overrides of [{opened: false}, {view: 'metrics' as const}, {activeTurn: null, conversationId: 'c2'}]) {
        const html = render(completed(text), overrides);
        assert.ok(html.includes(text));
        assert.match(html, /data-status="complete"/);
    }
});
