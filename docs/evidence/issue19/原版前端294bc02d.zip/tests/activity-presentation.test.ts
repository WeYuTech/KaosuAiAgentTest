import test from 'node:test';
import assert from 'node:assert/strict';
import {activityPresentation, waitingDuration} from '../src/chat/activity-presentation';
import {TRACE_VERSION, applyTraceEvent} from '../src/chat/execution-trace';
import type {TraceStep} from '../src/chat/execution-trace';
import type {Turn} from '../src/chat/types';

const at = '2026-10-12T00:00:00Z';
function step(overrides: Partial<TraceStep> = {}): TraceStep {
    return {id: 'tool:one', stage: 'querying', source: 'tool_start', status: 'running', observed_at: at,
        started_at: at, tool_name: 'get_work_order_summary', ...overrides};
}
function turn(steps: TraceStep[], overrides: Partial<Turn> = {}): Turn {
    return {execution_state: 'running', execution_trace_version: TRACE_VERSION, execution_trace: steps, ...overrides};
}

test('只收到分析事件時，只有一行活動而沒有五階段空列', () => {
    const view = activityPresentation(turn([step({stage: 'understanding', source: 'graph_trace', tool_name: null})]));
    assert.equal(view?.label, '正在分析問題…');
    assert.deepEqual(view?.queries, []);
});

test('等待時間使用回合受理時間，無有效時間與未來時間不造假進度', () => {
    const saved = {started_at: at};
    assert.equal(waitingDuration(saved, Date.parse(at) + 272079), 272);
    assert.equal(waitingDuration(saved, Date.parse(at) + 273000), 273);
    assert.equal(waitingDuration(saved, Date.parse(at) - 1000), 0);
    assert.equal(waitingDuration({}, Date.now()), null);
    assert.equal(waitingDuration({started_at: 'invalid'}, Date.now()), null);
});

test('功能介紹與未查 MES 的完成回合不留下分析報告', () => {
    assert.equal(activityPresentation(turn([step({stage: 'understanding'})], {execution_state: 'completed'})), null);
    assert.equal(activityPresentation({answer: '功能介紹', status: 'succeeded'}), null);
    assert.equal(activityPresentation({...turn([step()]), execution_trace_version: 'unknown'}), null);
});

test('業務名稱取代工具代碼，分頁與敏感條件不放在活動區', () => {
    const view = activityPresentation(turn([step({conditions: [
        {label: '工單', value: '145861'}, {label: '筆數上限', value: 100},
        {label: '略過筆數', value: 0}, {label: '機台', value: 'sk-secret'},
    ]})]));
    assert.equal(view?.label, '正在查詢工單報工摘要…');
    assert.equal(view?.queries[0]?.detail, '工單：145861');
    assert.equal(JSON.stringify(view).includes('get_work_order_summary'), false);
    assert.equal(JSON.stringify(view).includes('sk-secret'), false);
});

test('工具後模型整理與核對只更新單行狀態，不新增診斷列', () => {
    const query = step({status: 'completed', result_status: 'succeeded'});
    const draft = step({id: 'draft', stage: 'answering', source: 'graph_trace', observed_at: '2026-10-12T00:00:01Z'});
    assert.equal(activityPresentation(turn([query, draft]))?.label, '正在整理查詢結果…');
    const verify = {...draft, id: 'verify', stage: 'verifying' as const};
    assert.equal(activityPresentation(turn([query, verify]))?.label, '正在確認查詢結果…');
    assert.equal(activityPresentation(turn([query, verify]))?.queries.length, 1);
});

test('同批完成事件不假裝仍在查詢；無開始事件不推測正在整理', () => {
    const view = activityPresentation(turn([step({status: 'completed', source: 'tool_result'})]));
    assert.equal(view?.label, '正在處理問題…');
    assert.equal(view?.queries[0]?.running, false);
});

test('多查詢依實際開始時間排序，不按內部階段重新排列', () => {
    const late = step({id: 'later', started_at: '2026-10-12T00:00:03Z'});
    const early = step({id: 'earlier', started_at: at, observed_at: '2026-10-12T00:00:05Z'});
    const view = activityPresentation(turn([late, early]));
    assert.deepEqual(view?.queries.map(item => item.id), ['earlier', 'later']);
});

test('已修復的核對細節不放在產品畫面，原事件仍保留', () => {
    const raw = turn([
        step({status: 'completed', result_status: 'succeeded'}),
        step({id: 'reject', stage: 'verifying', status: 'failed', verification: 'rejected'}),
        step({id: 'pass', stage: 'verifying', status: 'completed', verification: 'passed'}),
    ], {execution_state: 'completed'});
    const original = JSON.stringify(raw);
    const view = activityPresentation(raw);
    assert.equal(view?.label, '已查詢工單報工摘要');
    assert.equal(view?.queries.length, 1);
    assert.equal(JSON.stringify(raw), original);
    assert.equal(JSON.stringify(view).includes('rejected'), false);
});

for (const [result_status, expected] of [
    ['no_data', '查無符合資料'], ['insufficient_data', '資料不完整'], ['failed', '查詢未完成'],
] as const) test(`真正的 ${result_status} 不被完成回合掩蓋`, () => {
    const view = activityPresentation(turn([step({status: 'completed', result_status})], {execution_state: 'completed'}));
    assert.equal(view?.queries[0]?.status, expected);
});

for (const execution_state of ['cancelled', 'failed', 'submission_unknown'] as const) test(`${execution_state} 不保留旋轉或將未知工具當成功`, () => {
    const view = activityPresentation(turn([step()], {execution_state}));
    assert.equal(view?.running, false);
    assert.equal(view?.queries[0]?.running, false);
    assert.equal(view?.queries[0]?.status, '結果待確認');
    assert.notEqual(view?.label, '已查詢工單報工摘要');
});

test('暫停觀看保留活動且停止旋轉', () => {
    const view = activityPresentation(turn([step()]), true);
    assert.equal(view?.running, false);
    assert.equal(view?.label, '等待狀態更新…');
    assert.equal(view?.queries[0]?.status, '等待更新');
});

test('相同工具事件沿用原去重機制，不增加活動', () => {
    let value = turn([]);
    for (let index = 0; index < 3; index++) value = applyTraceEvent(value, {version: TRACE_VERSION, step: step()});
    assert.equal(activityPresentation(value)?.queries.length, 1);
});
