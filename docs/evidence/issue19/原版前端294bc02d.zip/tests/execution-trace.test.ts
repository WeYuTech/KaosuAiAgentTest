import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {applyTraceEvent, latestTraceStep, readExecutionTrace, TRACE_VERSION, traceDuration, traceElapsed, traceProgressText} from '../src/chat/execution-trace';
import type {TraceStep} from '../src/chat/execution-trace';
import type {Turn} from '../src/chat/types';
import {ChatController} from '../src/chat/controller';
import {parseEvent} from '../src/chat/core';

const scoped = register({namespace: 'execution-trace', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {ExecutionTrace} = await scoped.import('../src/features/mes/ExecutionTrace.tsx', import.meta.url) as typeof import('../src/features/mes/ExecutionTrace');
const at = '2026-10-12T00:00:00Z';
function step(overrides: Partial<TraceStep> = {}): TraceStep {return {id: 'tool:one', stage: 'querying', source: 'tool_start', status: 'running', observed_at: at, started_at: at, tool_name: 'get_work_order_summary', conditions: [{label: '工單', value: '145861'}], ...overrides};}
function turn(steps: TraceStep[], overrides: Partial<Turn> = {}): Turn {return {conversation_id: 'c1', request_id: 'r1', execution_state: 'running', status: 'started', event_sequence: 0, execution_trace_version: TRACE_VERSION, execution_trace: steps, ...overrides};}

test('同毫秒的連續事件採後一筆；重接快照沿用最新真實工具階段', () => {
    const selection = step({id: 'selection', stage: 'selecting', status: 'completed'});
    const query = step();
    assert.equal(latestTraceStep([selection, query])?.stage, 'querying');
    assert.equal(traceProgressText(turn([selection, query], {execution_state: 'submitting'})), '正在查詢 MES');
});

test('只呈現真正查詢，不補空列，工具名稱使用業務文案', () => {
    assert.deepEqual(readExecutionTrace({answer: '已完成工單查詢'}), []);
    assert.deepEqual(readExecutionTrace({...turn([step()]), execution_trace_version: 'unknown'}), []);
    const html = renderToStaticMarkup(createElement(ExecutionTrace, {turn: turn([step()]), defaultOpen: true}));
    assert.equal(html.includes('未提供紀錄'), false);
    assert.match(html, /工單：145861/);
    assert.match(html, /工單報工摘要/);
    assert.equal(html.includes('get_work_order_summary'), false);
    assert.equal(html.includes('答案通過'), false);
});

test('產品活動不公開診斷耗時、SQL、秘密或草稿，原耗時工具仍可用', () => {
    const malicious = {...step({status: 'completed', duration_ms: 1234, result_status: 'succeeded'}), reasoning: '隱藏推理', sql: 'SELECT secret', draft: '未驗證數字', conditions: [{label: '工單', value: '145861'}, {label: '機台', value: 'sk-secret'}, {label: 'api_key', value: '秘密'}]};
    const html = renderToStaticMarkup(createElement(ExecutionTrace, {turn: turn([malicious, step({id: 'verify:1', stage: 'verifying', source: 'answer_verification', verification: 'passed', status: 'completed'})], {execution_state: 'completed'}), defaultOpen: true}));
    assert.match(html, /已查詢/);
    for (const secret of ['1.23 秒', '答案通過欄位與引用核對', 'SELECT', '隱藏推理', 'sk-secret', '未驗證數字', 'api_key']) assert.equal(html.includes(secret), false);
    assert.equal(traceDuration(step()), '耗時未提供');
    assert.equal(traceElapsed(step(), Date.parse(at) + 2000), '已經過 2.0 秒');
    assert.equal(traceElapsed(step({status: 'observed'}), Date.parse(at) + 2000), '耗時未提供');
});

test('同一工具多次事件以 ID 更新，較舊狀態不覆寫完成，核對修復保留多次紀錄', () => {
    let value = applyTraceEvent(turn([]), {version: TRACE_VERSION, step: step()});
    const completed = step({status: 'completed', source: 'tool_result', observed_at: '2026-10-12T00:00:02Z', duration_ms: 2000});
    value = applyTraceEvent(value, {version: TRACE_VERSION, step: completed});
    value = applyTraceEvent(value, {version: TRACE_VERSION, step: completed});
    value = applyTraceEvent(value, {version: TRACE_VERSION, step: step()});
    value = applyTraceEvent(value, {version: TRACE_VERSION, step: step()});
    assert.equal(value.execution_trace?.length, 1);
    assert.equal(value.execution_trace?.[0]?.status, 'completed');
    assert.equal(applyTraceEvent(value, {version: 'unknown', step: step()}), value);
    assert.equal(parseEvent('id: 42\nevent: execution_trace\ndata: {}')?.id, 42);
    assert.equal(parseEvent('id: abc\ndata: {}')?.id, undefined);
});

test('完成後不顯示內部修復紀錄，暫停觀看不保持旋轉', () => {
    const rejected = step({id: 'verify:1', stage: 'verifying', status: 'failed', source: 'answer_verification', verification: 'rejected', duration_ms: 127});
    const passed = step({id: 'verify:2', stage: 'verifying', status: 'completed', source: 'answer_verification', verification: 'passed', duration_ms: 5});
    const html = renderToStaticMarkup(createElement(ExecutionTrace, {turn: turn([rejected, passed], {execution_state: 'completed'}), defaultOpen: true}));
    assert.equal(html, '');
    const paused = renderToStaticMarkup(createElement(ExecutionTrace, {turn: turn([step()]), defaultOpen: true, paused: true}));
    assert.equal(paused.includes('animate-spin'), false);
    assert.match(paused, /等待狀態更新/);
    assert.match(paused, /等待更新/);
});

for (const status of ['cancelled', 'failed', 'interrupted', 'observed'] as const) test(`終態 ${status} 不顯示執行動畫或捏造步驟完成`, () => {
    const html = renderToStaticMarkup(createElement(ExecutionTrace, {turn: turn([step({status})], {execution_state: status === 'cancelled' ? 'cancelled' : status === 'failed' ? 'failed' : 'completed'}), defaultOpen: true}));
    assert.equal(html.includes('animate-spin'), false);
    assert.equal(html.includes('已完成'), false);
});

class MemoryStorage implements Storage {
    private values = new Map<string, string>();
    get length() {return this.values.size;}
    key(index: number) {return [...this.values.keys()][index] || null;}
    getItem(key: string) {return this.values.get(key) || null;}
    setItem(key: string, value: string) {this.values.set(key, value);}
    removeItem(key: string) {this.values.delete(key);}
    clear() {this.values.clear();}
}
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});
async function until(predicate: () => boolean) {const deadline = Date.now() + 2000; while (!predicate() && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 0)); assert.ok(predicate());}

for (const mode of ['API', 'AGENT'] as const) test(`${mode} 真實控制器收到 SSE 時間軸，重複、歷史與重連不增加 POST`, async () => {
    const storage = new MemoryStorage();
    storage.setItem('X_BI_accountNo', 'ADMINV2'); storage.setItem('X_BI_TokenKey', 'fixture'); storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString());
    storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const previousWindow = globalThis.window;
    globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    let current = turn([]), posts = 0, streams = 0;
    let stream!: ReadableStreamDefaultController<Uint8Array>;
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = new URL(String(input), 'http://fixture').pathname;
        if (path.endsWith('/runtime')) return json({mode, continuous_context: mode === 'AGENT'});
        if (path.endsWith('/conversations')) return json({items: [{conversation_id: 'c1', title: '隔離時間軸'}]});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '隔離時間軸', messages: current.execution_state === 'completed' ? [{...current, role: 'assistant', content: current.answer}] : []});
        if (path.endsWith('/messages')) {assert.equal(options.method, 'POST'); posts++; return json({...current, question: '隔離問題', client_message_id: JSON.parse(String(options.body)).client_message_id});}
        if (path.endsWith('/r1')) return json(current);
        if (path.endsWith('/stream')) {streams++; return new Response(new ReadableStream<Uint8Array>({start(value) {stream = value;}}), {headers: {'Content-Type': 'text/event-stream'}});}
        return json({}, 404);
    };
    const controller = new ChatController({storage, fetchImpl}, 'X');
    const emit = (id: number, event: string, data: unknown) => stream.enqueue(new TextEncoder().encode(`id: ${id}\nevent: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
    try {
        await controller.actions.openChat(); controller.actions.setDraft('隔離問題');
        const sending = controller.actions.submitQuestion();
        await until(() => streams === 1);
        emit(1, 'execution_trace', {version: TRACE_VERSION, step: step()});
        await until(() => controller.getSnapshot().activeTurn?.execution_trace?.length === 1);
        const done = step({status: 'completed', source: 'tool_result', observed_at: '2026-10-12T00:00:02Z', duration_ms: 2000});
        emit(2, 'execution_trace', {version: TRACE_VERSION, step: done});
        emit(2, 'execution_trace', {version: TRACE_VERSION, step: step()});
        emit(3, 'answer_delta', {delta: '唯一回答'}); emit(3, 'answer_delta', {delta: '重複回答'});
        emit(1, 'snapshot', turn([]));
        await until(() => controller.getSnapshot().activeTurn?.answer === '唯一回答');
        assert.equal(controller.getSnapshot().activeTurn?.execution_trace?.[0]?.status, 'completed');
        current = turn([done], {event_sequence: 4, execution_state: 'completed', status: 'succeeded', answer: '唯一回答', audit_status: 'saved'});
        emit(5, 'done', current); stream.close(); await sending;
        await controller.actions.reconnect();
        assert.deepEqual(controller.getSnapshot().displayMessages.at(-1)?.execution_trace, current.execution_trace);
        assert.equal(posts, 1); assert.equal(streams, 1);
        controller.actions.newChat();
        assert.equal(controller.getSnapshot().displayMessages.length, 0); assert.equal(posts, 1);
    } finally {controller.dispose(); globalThis.window = previousWindow;}
});
