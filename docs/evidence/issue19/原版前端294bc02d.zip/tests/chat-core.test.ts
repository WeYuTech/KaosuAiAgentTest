import test from 'node:test';
import assert from 'node:assert/strict';
import core from '../src/chat/core';
import {execFileSync} from 'node:child_process';
function groupsInTimezone(items, now, timezone) {
    const script = 'import core from ' + JSON.stringify(new URL('../src/chat/core.ts', import.meta.url).href) + '; process.stdout.write(JSON.stringify(core.groupConversations(' + JSON.stringify(items) + ', ' + JSON.stringify(now) + ')));';
    return JSON.parse(execFileSync(process.execPath, ['--import', 'tsx', '--input-type=module', '-e', script], {env: Object.assign({}, process.env, {TZ: timezone}), encoding: 'utf8'}));
}
test('版型以面板模式分開：桌面 compact 抽屜、滿版九百像素起才有側欄', () => {
    assert.deepEqual(core.chatLayout(false, 1440), {expanded: false, fullscreen: false, sidebarAvailable: false, sidebar: false, drawer: true});
    assert.deepEqual(core.chatLayout(true, 1440), {expanded: true, fullscreen: true, sidebarAvailable: true, sidebar: true, drawer: false});
    assert.equal(core.chatLayout(true, 900).sidebar, true);
    assert.deepEqual(core.chatLayout(true, 899), {expanded: true, fullscreen: true, sidebarAvailable: false, sidebar: false, drawer: true});
    assert.deepEqual(core.chatLayout(false, 375), {expanded: false, fullscreen: true, sidebarAvailable: false, sidebar: false, drawer: true});
    assert.equal(core.chatLayout(false, 641).fullscreen, false);
    assert.equal(core.chatLayout(false, 640).fullscreen, true);
    assert.deepEqual(core.chatLayout(true, 1440, true), {expanded: true, fullscreen: true, sidebarAvailable: true, sidebar: false, drawer: false});
});
test('草稿依新聊天及 conversation 分開保存，刷新還原且送出不清掉別題草稿', () => {
    const original = {new: '新問題草稿'};
    let drafts = core.saveDraftText(original, 'c1', '第一張工單\n尚未送出');
    drafts = core.saveDraftText(drafts, 'c2', '第二張工單');
    const restored = JSON.parse(JSON.stringify(drafts));
    assert.equal(core.draftText(restored, null), '新問題草稿');
    assert.equal(core.draftText(restored, 'c1'), '第一張工單\n尚未送出');
    const sent = core.saveDraftText(restored, 'c1', '');
    assert.equal(core.draftText(sent, 'c1'), '');
    assert.equal(core.draftText(sent, 'c2'), '第二張工單');
    assert.equal(core.draftText(sent, null), '新問題草稿');
    assert.deepEqual(original, {new: '新問題草稿'});
    assert.equal(core.draftText({c1: 42}, 'c1'), '');
});
test('歷史分組先換算宿主時區，跨午夜與無效日期均正確歸類', () => {
    const items = [
        {conversation_id: 'today-utc', updated_at: '2026-10-05T16:05:00Z'},
        {conversation_id: 'yesterday-offset', updated_at: '2026-10-06T00:10:00+09:00'},
        {conversation_id: 'older', updated_at: '2026-10-04T23:59:00+08:00'},
        {conversation_id: 'invalid', updated_at: '無效日期', created_at: '2026-10-06T00:00:00+08:00'},
        {conversation_id: 'created-only', created_at: '2026-10-06T00:12:00+08:00'},
        {conversation_id: 'missing'}
    ];
    const groups = groupsInTimezone(items, '2026-10-06T00:15:00+08:00', 'Asia/Taipei');
    assert.deepEqual(groups.map(group => [group.label, group.items.map(item => item.conversation_id)]), [
        ['今天', ['today-utc', 'created-only']], ['昨天', ['yesterday-offset']], ['更早', ['older', 'invalid', 'missing']]
    ]);
    assert.equal(items[0].updated_at, '2026-10-05T16:05:00Z');
});
test('昨天以當地曆日判定，跨月份及日光節約時間不使用固定二十四小時', () => {
    const groups = groupsInTimezone([
        {conversation_id: 'today', updated_at: '2026-11-02T00:05:00-05:00'},
        {conversation_id: 'yesterday', updated_at: '2026-11-01T00:05:00-04:00'},
        {conversation_id: 'older', updated_at: '2026-10-31T23:59:00-04:00'}
    ], '2026-11-02T00:15:00-05:00', 'America/New_York');
    assert.deepEqual(groups.map(group => [group.label, group.items.map(item => item.conversation_id)]), [
        ['今天', ['today']], ['昨天', ['yesterday']], ['更早', ['older']]
    ]);
    assert.deepEqual(core.groupConversations([], '2026-10-06T00:15:00+08:00'), []);
    assert.equal(groupsInTimezone([{updated_at: '2026-09-30T23:59:00+08:00'}], '2026-10-01T00:15:00+08:00', 'Asia/Taipei')[0].label, '昨天');
});
test('手機捲動鎖重複開啟不覆蓋原值，解除後還原 inline overflow 與 important', () => {
    function fakeStyle(initial) {
        const values = Object.assign({}, initial);
        return {values: values, getPropertyValue: property => values[property] ? values[property].value : '', getPropertyPriority: property => values[property] ? values[property].priority : '', setProperty: (property, value, priority) => { values[property] = {value: value, priority: priority || ''}; }, removeProperty: property => { delete values[property]; }};
    }
    const html = fakeStyle({'overflow-x': {value: 'clip', priority: 'important'}});
    const body = fakeStyle({overflow: {value: 'auto', priority: ''}, color: {value: 'red', priority: ''}});
    const lock = core.createOverflowLock([html, body]);
    lock.setLocked(false); assert.equal(body.getPropertyValue('overflow'), 'auto');
    lock.setLocked(true); lock.setLocked(true);
    assert.equal(html.getPropertyValue('overflow'), 'hidden'); assert.equal(body.getPropertyPriority('overflow'), 'important');
    body.setProperty('color', 'blue'); lock.setLocked(false); lock.setLocked(false);
    assert.deepEqual(html.values, {'overflow-x': {value: 'clip', priority: 'important'}});
    assert.deepEqual(body.values, {overflow: {value: 'auto', priority: ''}, color: {value: 'blue', priority: ''}});
});
test('SSE 支援任意網路分塊、CRLF、多行 JSON 與最後未結尾事件', () => {
    const events = []; const decoder = core.createEventDecoder(event => events.push(event));
    decoder.push(': heartbeat\r\nevent: snapshot\r\ndata: {"request_id":"r1",\r\ndata: "answer":"口罩"}\r', false);
    decoder.push('\n\r\nevent: answer_delta\r\ndata: {"delta":"完成"}\r\n\r\nevent: done\ndata: {"answer":"已完成"}', true);
    assert.deepEqual(events, [{name: 'snapshot', data: {request_id: 'r1', answer: '口罩'}}, {name: 'answer_delta', data: {delta: '完成'}}, {name: 'done', data: {answer: '已完成'}}]);
});
test('SafeMarkdown 保留 raw HTML 為文字，拒絕執行協定且保留安全連結', () => {
    const blocks = core.parseMarkdown('<img src=x onerror=alert(1)>\n**已完成** `OK_QTY` [危險](javascript:alert) [查詢](https://example.com/mes)\n```html\n<script>alert(1)</script>\n```');
    assert.equal(blocks[0].type, 'paragraph'); assert.equal(blocks[0].content[0].text, '<img src=x onerror=alert(1)>');
    assert.equal(blocks[1].content.filter(item => item.type === 'link').length, 1);
    assert.equal(blocks[1].content.find(item => item.type === 'link').url, 'https://example.com/mes');
    assert.equal(blocks[2].type, 'pre'); assert.equal(blocks[2].text, '<script>alert(1)</script>');
    for (const block of blocks) assert.notEqual(block.type, 'html');
    assert.equal(core.safeUrl('data:text/html,<script>'), null); assert.equal(core.safeUrl('file:///C:/secret'), null);
});
test('Markdown 表格、標題、清單可在不注入 HTML 的情況下顯示', () => {
    const blocks = core.parseMarkdown('### 生產日\n| 工單 | 良品 |\n|---|---:|\n|145861|106250|\n\n- 已驗證\n- 依備份紀錄');
    assert.equal(blocks[0].type, 'heading'); assert.equal(blocks[1].type, 'table'); assert.equal(blocks[1].rows[0][1][0].text, '106250'); assert.equal(blocks[2].items.length, 2);
});
test('宿主登入僅讀取指定 project prefix，過期、未知帳號和缺 Token 均拒絕', () => {
    const values = {'X_BI_accountNo': ' adminv2 ', 'X_BI_TokenKey': 'test-token', 'X_BI_TokenExpiry': '2026-10-06T15:00:00Z', '_BI_accountNo': 'ADMINV2', '_BI_TokenKey': 'wrong-prefix-token'};
    const storage = {getItem: key => values[key] || null}; const now = Date.parse('2026-10-06T14:00:00Z');
    assert.equal(core.readSession(storage, 'X', now).tokenKey, 'test-token'); assert.equal(core.readSession(storage, '', now), null);
    assert.equal(core.readSession(storage, 'X', now + 3600000), null);
    values.X_BI_accountNo = 'OP01'; assert.equal(core.readSession(storage, 'X', now), null);
    values.X_BI_accountNo = 'ADMINV2'; delete values.X_BI_TokenKey; assert.equal(core.readSession(storage, 'X', now), null);
});
test('完成及資料不足可解除等待，submission_unknown 不得當完成', () => {
    assert.equal(core.isTerminal({execution_state: 'running', status: 'started'}), false);
    assert.equal(core.isTerminal({execution_state: 'submission_unknown'}), false);
    assert.equal(core.isTerminal({execution_state: 'completed', status: 'insufficient_data'}), true);
    assert.equal(core.isTerminal({execution_state: 'cancelled'}), true);
});
test('接續提問與重連快照保留先前回答，重複 done 不新增兩則回答', () => {
    let messages = [{role: 'user', content: '工單多少？', request_id: 'r1'}];
    messages = core.saveAssistantMessage(messages, {request_id: 'r1', answer: '106250 件', evidence: [{tool_name: 'get_work_order_summary'}]});
    messages.push({role: 'user', content: '不良品呢？', request_id: 'r2'});
    messages = core.saveAssistantMessage(messages, {request_id: 'r2', answer: '852 件'});
    messages = core.saveAssistantMessage(messages, {request_id: 'r2', answer: '852 件', status: 'succeeded'});
    assert.deepEqual(messages.map(message => message.content), ['工單多少？', '106250 件', '不良品呢？', '852 件']);
    assert.equal(messages[1].evidence[0].tool_name, 'get_work_order_summary');
    assert.equal(messages.filter(message => message.request_id === 'r2' && message.role === 'assistant').length, 1);
});
test('統計僅合計已取得 Token，完全未知與已知零用量不同', () => {
    assert.equal(core.reportedTokenTotal([{total_tokens: null}, {}]), null);
    assert.equal(core.reportedTokenTotal([{total_tokens: 0}]), 0);
    assert.equal(core.reportedTokenTotal([{total_tokens: 120}, {total_tokens: null}, {total_tokens: 30}]), 150);
});
test('遲來的 POST202 不會把已由 GET 恢復完成的回合重新標記等待', () => {
    let pending = {c1: {clientMessageId: 'nonce-1', question: '工單多少？', requestId: null}};
    let messages = [{role: 'user', content: '工單多少？', request_id: 'r1'}];
    // 收合、重開後 GET 依 nonce 找到已完成快照，保存答案並解除等待。
    messages = core.saveAssistantMessage(messages, {request_id: 'r1', answer: '106250 件', execution_state: 'completed', status: 'succeeded'});
    delete pending.c1;
    // 原來已送出的 POST202 此時才到，不能建立新的 pending 或改掉完成答案。
    pending = core.acceptPendingTurn(pending, 'c1', 'nonce-1', 'r1');
    assert.deepEqual(pending, {});
    assert.equal(messages[1].content, '106250 件');
    assert.equal(messages[1].execution_state, 'completed');
});
test('POST202 只補上原 nonce 的 Request ID，不覆蓋另一題的等待紀錄', () => {
    const pending = {c1: {clientMessageId: 'nonce-2', question: '不良品呢？', requestId: null}};
    assert.equal(core.acceptPendingTurn(pending, 'c1', 'nonce-1', 'r1'), pending);
    const accepted = core.acceptPendingTurn(pending, 'c1', 'nonce-2', 'r2');
    assert.equal(accepted.c1.requestId, 'r2'); assert.equal(accepted.c1.question, '不良品呢？');
    assert.equal(pending.c1.requestId, null);
});
