import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import type {ChatActions, ChatState} from '../src/chat/types';

// 使用產品的 JSX 設定及真正的呈現元件，驗證登入提示不再重複
const scoped = register({namespace: 'session-notice-presentation', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {MesUiProvider} = await scoped.import('../src/chat/mes-ui-context.tsx', import.meta.url) as typeof import('../src/chat/mes-ui-context');
const {MesAssistantProvider} = await scoped.import('../src/chat/assistant-runtime.tsx', import.meta.url) as typeof import('../src/chat/assistant-runtime');
const {ThreadListItems} = await scoped.import('../src/components/assistant-ui/elements/thread-list.aui.tsx', import.meta.url) as typeof import('../src/components/assistant-ui/elements/thread-list.aui');
const {ChatExecutionStatus} = await scoped.import('../src/features/common/ChatExecutionStatus.tsx', import.meta.url) as typeof import('../src/features/common/ChatExecutionStatus');

function state(overrides: Partial<ChatState> = {}): ChatState {
    return {enabled: true, opened: true, expanded: true, historyOpen: false, view: 'chat', runtime: {mode: 'API', continuous_context: false},
        conversationId: null, conversationTitle: '新聊天', conversation: null, conversations: [], historyCursor: null,
        historyLoading: false, historyLoaded: true, historyStatus: '', historyArchived: false, conversationSaving: [],
        messages: [], activeTurn: null, displayMessages: [], draft: '', submitting: false, cancelling: false,
        connectionStatus: '', sessionNotice: '', expired: false, readOnly: false, readOnlyNotice: '', hint: '',
        sendDisabled: true, inputDisabled: false, showStop: false, unknownSubmission: false, reconnectNeeded: false,
        reports: {}, exporting: [], feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null, ...overrides};
}

function render(current: ChatState) {
    const actions = {} as ChatActions;
    const children = createElement(MesAssistantProvider, {state: current, actions, children: [
        createElement(ThreadListItems, {key: 'history'}), createElement(ChatExecutionStatus, {key: 'progress'}),
    ]});
    return renderToStaticMarkup(createElement(MesUiProvider, {state: current, actions, children}));
}

for (const [name, overrides] of [
    ['未登入', {expired: true}],
    ['登入已過期', {expired: true, sessionNotice: '登入已逾時，請重新登入 MES 後再使用'}],
    ['沒有權限', {expired: false, sessionNotice: '登入已逾時或沒有權限，請重新登入 MES'}],
] as const) {
    test(`${name}時歷史清單與底部不重複顯示登入提示`, () => {
        const notice = '登入已逾時或沒有權限，請重新登入 MES';
        const current = state({historyStatus: notice, connectionStatus: notice, hint: '登入已逾時，請重新登入 MES', ...overrides});
        const before = structuredClone(current);
        const html = render(current);
        assert.equal(html.includes(notice), false);
        assert.equal(html.includes('data-slot="mes-chat-progress"'), false);
        assert.deepEqual(current, before);
    });
}

test('正常登入時保留歷史讀取故障及底部連線訊息', () => {
    const notice = '目前無法連線到生產情報服務，請稍後重新確認';
    const html = render(state({historyStatus: notice, connectionStatus: notice}));
    assert.equal(html.split(notice).length - 1, 2);
    assert.match(html, /data-slot="mes-chat-progress"/);
});

test('正常登入的真實分析狀態與轉圈仍可顯示', () => {
    const html = render(state({activeTurn: {execution_state: 'running'}, connectionStatus: '正在查詢工單報工紀錄'}));
    assert.match(html, /正在查詢工單報工紀錄/);
    assert.match(html, /data-slot="mes-chat-spinner"/);
});
