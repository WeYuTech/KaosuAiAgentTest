import test from 'node:test';
import assert from 'node:assert/strict';
import {createProviderHarness, deferred} from './helpers/provider-harness';
import {buildSettingsUpdate, settingsDraft, type ProviderDraft, type ProviderSettings} from '../src/chat/settings';

type Operations = {
    section: string | null; schedules: unknown[]; runs: unknown[] | null; runScope: string;
    sourceText: string; parsed: unknown; selectedRun: unknown; deleteTarget: unknown;
    open(value: string): void; showRuns(schedule?: unknown): Promise<void>; setSourceText(value: string): void;
    setSelectedRun(value: unknown): void; setDeleteTarget(value: unknown): void;
};
function operationsHarness() {
    const schedule = {schedule_id: 'scope-a-schedule', report_request: '範圍 A 的機台日報', revision: 1, status: 'active'};
    const report = {run_id: 'scope-a-report', status: 'completed', due_at: '2026-10-08T01:00:00Z'};
    let readsB = 0;
    const actionsA = {loadSchedules: async () => ({items: [schedule]}), loadScheduleRuns: async () => ({items: [report]})};
    const actionsB = {loadSchedules: async () => {readsB++; return {items: []};}, loadScheduleRuns: async () => ({items: []})};
    const env = {state: {expired: false, opened: false, submitting: false, activeTurn: null}, actions: actionsA};
    const harness = createProviderHarness<Operations>(new URL('../src/features/operations/operations.tsx', import.meta.url), 'OperationsProvider', {
        '@/chat/mes-ui-context': {useMesUi: () => env},
        '@/chat/operations': {budgetDraft: (value: unknown) => value, buildBudgetUpdate: () => ({}), operationErrorText: String, ScheduleCreationIdentity: class {forText() {return 'fixture-nonce';} confirmed() {}}},
        '@/chat/sidebar-budget': {SidebarBudgetRefresh: class {observe() {return false;} invalidate() {}}},
    });
    harness.render();
    return {harness, env, actionsA, actionsB, schedule, report, readsB: () => readsB};
}

test('控制器範圍變更後清除前一份報告、排程與表單，空清單不殘留其他範圍內容', async () => {
    const {harness, env, actionsB, schedule, report, readsB} = operationsHarness();
    try {
        harness.act(value => value.open('schedules')); await harness.settle();
        await harness.act(value => value.showRuns(schedule)); await harness.settle();
        harness.act(value => {value.setSourceText('尚未送出的日報'); value.setSelectedRun(report); value.setDeleteTarget(schedule);});
        assert.deepEqual(harness.current.runs, [report]); assert.equal(harness.current.schedules.length, 1);
        env.actions = actionsB; harness.render();
        assert.equal(harness.current.section, null);
        harness.act(value => value.open('schedules')); await harness.settle();
        assert.equal(readsB(), 1); assert.equal(harness.current.section, 'schedules');
        assert.deepEqual(harness.current.schedules, []); assert.equal(harness.current.runs, null); assert.equal(harness.current.runScope, '');
        assert.equal(harness.current.sourceText, ''); assert.equal(harness.current.selectedRun, null); assert.equal(harness.current.deleteTarget, null); assert.equal('managementToken' in harness.current, false);
    } finally {harness.unmount();}
});

test('前一個控制器的晚到報告不會覆蓋新範圍，既有聊天動作沒有被重新提交或取消', async () => {
    const {harness, env, actionsA, actionsB, schedule, report} = operationsHarness();
    const late = deferred<{items: typeof report[]}>(); actionsA.loadScheduleRuns = () => late.promise;
    try {
        harness.act(value => value.open('schedules')); await harness.settle();
        const pending = harness.act(value => value.showRuns(schedule));
        env.actions = actionsB; harness.render();
        late.resolve({items: [report]}); await pending; await harness.settle();
        assert.equal(harness.current.runs, null); assert.equal(harness.current.runScope, ''); assert.equal(harness.current.section, null);
    } finally {harness.unmount();}
});

type Settings = {
    section: string | null; settings: ProviderSettings | null; draft: ProviderDraft | null;
    loading: boolean; saving: boolean; error: string; notice: string;
    openSettings(section: string): void; setDraft(update: (value: ProviderDraft | null) => ProviderDraft | null): void; save(): Promise<void>;
};
function settingsSnapshot(model: string): ProviderSettings {
    const values = {mode: 'API' as const, api: {model, reasoning_effort: 'medium'}, agent: {id: 'agent_fixture', project_id: 'proj_fixture', model, reasoning_effort: 'medium'}};
    return {revision: model, effective: structuredClone(values), saved: structuredClone(values), api_key: {configured: false, saved_configured: false, source: 'local', editable: true},
        sources: {} as ProviderSettings['sources'], locked_fields: [], restart_required: false, apply: 'restart', management: {authorization: 'management_token'}, blocked_reason: null};
}
function settingsHarness(loadA: () => Promise<ProviderSettings>) {
    let writesB = 0;
    const env = {state: {expired: false}, actions: {loadProviderSettings: loadA, saveProviderSettings: async () => settingsSnapshot('A')}};
    const actionsB = {loadProviderSettings: async () => settingsSnapshot('B'), saveProviderSettings: async () => {writesB++; return settingsSnapshot('B');}};
    const harness = createProviderHarness<Settings>(new URL('../src/features/preferences/provider-settings.tsx', import.meta.url), 'ProviderSettingsProvider', {
        '@/chat/mes-ui-context': {useMesUi: () => env}, '@/chat/settings': {settingsDraft, buildSettingsUpdate},
    });
    harness.render(); return {harness, env, actionsB, writesB: () => writesB};
}

test('設定讀取中變更控制器，舊回應不再開啟或填入設定，控制器不保留憑證欄位', async () => {
    const late = deferred<ProviderSettings>(), {harness, env, actionsB, writesB} = settingsHarness(() => late.promise);
    try {
        harness.act(value => value.openSettings('api'));
        assert.equal(harness.current.loading, true); env.actions = actionsB; harness.render();
        assert.equal(harness.current.section, null); assert.equal('apiKey' in harness.current, false); assert.equal('managementToken' in harness.current, false);
        late.resolve(settingsSnapshot('A')); await harness.settle();
        assert.equal(harness.current.settings, null); assert.equal(harness.current.draft, null); assert.equal(harness.current.loading, false);
        await harness.act(value => value.save()); assert.equal(writesB(), 0);
    } finally {harness.unmount();}
});

test('已載入的設定與編輯草稿不跨控制器保留，新範圍需明確重新開啟讀取', async () => {
    const {harness, env, actionsB} = settingsHarness(async () => settingsSnapshot('A'));
    try {
        harness.act(value => value.openSettings('agent')); await harness.settle();
        harness.act(value => value.setDraft(previous => previous && {...previous, api: {...previous.api, model: '尚未保存的模型'}}));
        assert.equal(harness.current.draft?.api.model, '尚未保存的模型');
        assert.equal(harness.current.settings?.revision, 'A'); env.actions = actionsB; harness.render();
        assert.equal(harness.current.settings, null); assert.equal(harness.current.draft, null); assert.equal(harness.current.section, null);
        assert.equal('apiKey' in harness.current, false); assert.equal('managementToken' in harness.current, false);
        harness.act(value => value.openSettings('api')); await harness.settle();
        assert.equal(harness.current.settings?.revision, 'B');
    } finally {harness.unmount();}
});

type ConversationManagement = {
    dialog: null | {conversation: {conversation_id: string; title: string; metadata_version: number}};
    title: string; reloading: boolean; error: string; notice: string; dialogNotice: string;
    openDialog(kind: string, conversation: unknown, trigger: null): void; reloadDialog(): Promise<void>;
    confirm(): Promise<void>; update(conversation: unknown, patch: unknown): Promise<boolean>;
};
function conversationHarness() {
    const conversation = {conversation_id: 'fixture-scope-a', title: '範圍 A 聊天', metadata_version: 1};
    const late = deferred<typeof conversation>(); let writesB = 0;
    const actionsA = {loadConversationMetadata: () => late.promise, updateConversation: async () => {}};
    const actionsB = {loadConversationMetadata: async () => ({...conversation, conversation_id: 'fixture-scope-b'}), updateConversation: async () => {writesB++;}};
    const env = {state: {expired: false}, actions: actionsA};
    const harness = createProviderHarness<ConversationManagement>(new URL('../src/features/conversations/conversation-actions.tsx', import.meta.url), 'ConversationActionsProvider', {
        '@/chat/mes-ui-context': {useMesUi: () => env}, '@/features/common/UiContext': {usePortalContainer: () => null}, '@/features/common/restoreFocus': {restoreAvailableFocus() {}},
    });
    harness.render(); return {harness, env, actionsA, actionsB, conversation, late, writesB: () => writesB};
}

test('聊天室管理切換控制器清除確認目標，晚到 metadata 不能使新範圍操作前一聊天', async () => {
    const {harness, env, actionsB, conversation, late, writesB} = conversationHarness();
    try {
        harness.act(value => value.openDialog('rename', conversation, null)); const pending = harness.act(value => value.reloadDialog());
        assert.equal(harness.current.reloading, true); env.actions = actionsB; harness.render();
        late.resolve({...conversation, title: '舊範圍晚到名稱', metadata_version: 2}); await pending; await harness.settle();
        assert.equal(harness.current.dialog, null); assert.equal(harness.current.title, ''); assert.equal(harness.current.reloading, false); assert.equal(harness.current.dialogNotice, '');
        await harness.act(value => value.confirm()); assert.equal(writesB(), 0);
    } finally {harness.unmount();}
});

test('前一範圍的釘選錯誤晚到時，不把錯誤提示貼到新範圍', async () => {
    const {harness, env, actionsA, actionsB, conversation} = conversationHarness(), late = deferred<void>();
    actionsA.updateConversation = () => late.promise;
    try {
        const pending = harness.act(value => value.update(conversation, {is_pinned: true})); env.actions = actionsB; harness.render();
        late.reject({userMessage: '範圍 A 的版本衝突'}); assert.equal(await pending, false); await harness.settle();
        assert.equal(harness.current.notice, ''); assert.equal(harness.current.dialog, null);
    } finally {harness.unmount();}
});
