import test from 'node:test';
import assert from 'node:assert/strict';
import {decodeReport, decodeReportCard, ReportDecodeError} from '../src/chat/report-decoder';
import {chartSelection, findChartSelection, planSavedCharts} from '../src/chat/chart-planner';
import {savedSemanticMetricAvailable} from '../src/chat/semantic-availability';
import type {RawReportCard, SemanticReportColumn} from '../src/chat/types';

const group = 'mes-source-offline';
const dimension: SemanticReportColumn = {name: 'station', label: '保存機台', role: 'dimension', data_type: 'string', source_group: group};
const measure = (name: string): SemanticReportColumn => ({name, label: name, role: 'metric', data_type: 'number', unit: '公斤', source_group: group,
    interpretation: 'complete', completeness_required: true, required_missing_fields: ['missing'], availability_count_field: 'samples', comparison_group: 'saved_measure'});
const count: SemanticReportColumn = {name: 'samples', label: '樣本數', role: 'quality', data_type: 'number', source_group: group, interpretation: 'count', completeness_required: false, required_missing_fields: []};
const missing: SemanticReportColumn = {name: 'missing', label: '缺值數', role: 'quality', data_type: 'number', source_group: group, interpretation: 'quality', completeness_required: false, required_missing_fields: []};

function semantic(): RawReportCard {
    const columns = [dimension, measure('alpha'), measure('beta'), measure('gamma'), count, missing];
    const summary = {alpha: 3, beta: 17, gamma: 7, samples: 3, missing: 0};
    return {id: 'saved', kind: 'semantic_query', title: '保存報告', status: 'ok', source_call_id: 'source-a', semantic_metadata_version: 2,
        semantic_fingerprint: 'saved-fingerprint', semantic_columns: structuredClone(columns), chart_preference: {call_id: 'source-a', intent: 'relationship', metrics: ['gamma', 'alpha']},
        metrics: ['alpha', 'beta', 'gamma'].map(key => ({key, value: summary[key as 'alpha']})), summary,
        detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows: [
            {station: 'A', alpha: 0, beta: 8, gamma: 5, samples: 2, missing: 0},
            {station: 'B', alpha: 3, beta: 9, gamma: 2, samples: 1, missing: 0},
        ]}};
}
const envelope = (cards: unknown[], version: unknown = 'mes-report-v2') => ({report_version: version, request_id: 'request', answer: '原保存答案', cards});

test('呈現偏好解碼保留順序；偏好壞掉不丟失答案或其他卡片', () => {
    const preferences = {version: 'report-view-preferences-v1', revision: 2, selections: [{card_id: 'saved', mark: 'scatter', metrics: ['gamma', 'alpha']}]};
    const raw = {...envelope([semantic()]), view_preferences: preferences, view_preferences_editable: true};
    assert.deepEqual(decodeReport(raw).view_preferences, preferences);
    for (const invalid of [{...preferences, version: 'future'}, {...preferences, revision: -1}, {...preferences, selections: [...preferences.selections, ...preferences.selections]}, {...preferences, selections: [{...preferences.selections[0], mark: 'code'}]}]) {
        const result = decodeReport({...raw, view_preferences: invalid});
        assert.equal(result.cards[0].chart_contract, 'v2'); assert.equal(result.answer, raw.answer);
        assert.equal(result.view_preferences_editable, false); assert.ok(result.view_preferences_reason);
    }
});

test('保存偏好拒絕任意圖表規格、未知圖型、其他來源、transform、data.url與竄改數字', () => {
    const source = semantic(), valid = planSavedCharts(decodeReportCard(source, 2)).recommended[0];
    const selection = {card_id: source.id, ...chartSelection(valid)};
    const invalidSelections = [null, {mark: 'bar'}, valid, {...selection, mark: 'pie'}, {...selection, card_id: 'another-account'},
        {...selection, sourceRef: 'another-account'}, {...selection, encoding: {...valid.encoding, y: 'not_approved'}},
        {...selection, transform: [{calculate: '99'}]}, {...selection, data: {url: 'https://example.test/'}},
        {...selection, points: valid.points.map(point => ({...point, values: {...point.values, alpha: 999}}))}];
    for (const selection of invalidSelections) {
        const raw = {...envelope([source]), view_preferences_editable: true,
            view_preferences: {version: 'report-view-preferences-v1', revision: 1, selections: [selection]}};
        const before = structuredClone(raw), decoded = decodeReport(raw, 'request');
        assert.deepEqual(decoded.view_preferences?.selections, []);
        assert.equal(decoded.view_preferences_editable, false);
        assert.ok(decoded.view_preferences_reason);
        assert.equal(decoded.answer, raw.answer);
        assert.deepEqual(planSavedCharts(decoded.cards[0]).recommended[0], valid);
        assert.deepEqual(raw, before);
    }
});

test('保存選擇只從同卡合法候選取回原數字；未知欄位不改選其他指標', () => {
    const source = semantic(), plan = planSavedCharts(decodeReportCard(source, 2));
    for (const candidate of [...plan.recommended, ...plan.alternatives]) {
        const raw = {...envelope([source]), view_preferences_editable: true,
            view_preferences: {version: 'report-view-preferences-v1', revision: 1, selections: [{card_id: source.id, ...chartSelection(candidate)}]}};
        const decoded = decodeReport(raw, 'request'), current = planSavedCharts(decoded.cards[0]);
        const selected = findChartSelection([...current.recommended, ...current.alternatives], decoded.view_preferences!.selections[0]);
        assert.deepEqual(selected, candidate);
        assert.equal(selected!.sourceRef, source.id);
    }
    const decoded = decodeReport({...envelope([source]), view_preferences_editable: true,
        view_preferences: {version: 'report-view-preferences-v1', revision: 1, selections: [{card_id: source.id, mark: 'scatter', metrics: ['gamma', 'not_approved']}]}});
    const current = planSavedCharts(decoded.cards[0]);
    assert.equal(findChartSelection([...current.recommended, ...current.alternatives], decoded.view_preferences!.selections[0]), undefined);
    assert.deepEqual(decoded.cards[0].detail, source.detail);
});

test('主指標只接受保存來源內欄位，不讓壞卡影響其他卡', () => {
    const first = {...semantic(), primary_metrics: ['gamma', 'alpha']};
    assert.deepEqual(decodeReportCard(first, 2).primary_metrics, ['gamma', 'alpha']);
    assert.equal(decodeReportCard({...first, primary_metrics: ['foreign']}, 2).chart_contract, 'unavailable');
});

test('保存主指標可明確選筆數；非數值或未核准尺度仍不可畫圖', () => {
    const columns = [{name: 'subject', label: '對象', role: 'dimension', data_type: 'string'}, {name: 'samples', label: '筆數', role: 'quality', data_type: 'number', interpretation: 'count'}];
    const card = decodeReportCard({id: 'saved', kind: 'fixed', source_call_id: 'a', primary_metrics: ['samples'], chart_metadata: {version: 'mes-chart-metadata-v1', fingerprint: 'saved', columns}, detail: {columns: columns.map(column => ({key: column.name})), rows: [{subject: '甲', samples: 0}, {subject: '乙', samples: 2}]}}, 2);
    assert.deepEqual(planSavedCharts(card).recommended[0].encoding.series, ['samples']);
    assert.equal(card.chart_input?.columns.find(column => column.name === 'samples')?.role, 'metric');
});

test('v1與v2入口都輸出具契約型別卡片，不修改原始值或答案', () => {
    const source = semantic(), input = envelope([source]), before = structuredClone(input);
    const report = decodeReport(input, 'request');
    assert.equal(report.cards[0].chart_contract, 'v2');
    assert.equal(report.answer, input.answer);
    assert.deepEqual(report.cards[0].detail, source.detail);
    assert.deepEqual(input, before);
    const v1 = decodeReport(envelope([{...source, chart_preference: undefined}], 'mes-report-v1'));
    assert.equal(v1.cards[0].chart_contract, 'v2');
});

test('來源指定關係配對固定x/y，第三個指標與欄位重排不改配對', () => {
    const source = semantic();
    const first = planSavedCharts(decodeReportCard(source, 2)).recommended[0];
    assert.equal(first.mark, 'scatter');
    assert.deepEqual(first.encoding, {x: 'gamma', y: 'alpha', series: []});
    source.semantic_columns!.reverse(); source.detail!.columns!.reverse();
    const reordered = planSavedCharts(decodeReportCard(source, 2)).recommended[0];
    assert.deepEqual(reordered.encoding, first.encoding);
    assert.deepEqual(reordered.points.map(point => [point.values.gamma, point.values.alpha]), [[5, 0], [2, 3]]);
});

test('每張卡片保存自己的呈現目的與指標，不取其他來源的偏好', () => {
    const first = semantic(), second = semantic();
    second.id = 'second'; second.source_call_id = 'source-b';
    second.chart_preference = {call_id: 'source-b', intent: 'comparison', metrics: ['beta']};
    const report = decodeReport(envelope([first, second]));
    assert.equal(planSavedCharts(report.cards[0]).recommended[0].mark, 'scatter');
    assert.equal(planSavedCharts(report.cards[1]).recommended[0].mark, 'bar');
    assert.deepEqual(planSavedCharts(report.cards[1]).recommended[0].encoding.series, ['beta']);
});

test('指標改名後摘要與圖表使用同一份保存可用性關係，零值仍是有效值', () => {
    const source = semantic(); source.chart_preference = null;
    source.summary = {alpha: 0, beta: 17, gamma: 7, samples: 3, missing: 0}; source.metrics = [];
    const report = decodeReportCard(source, 2);
    assert.equal(report.display.highlights[0].value, '0');
    assert.equal(planSavedCharts(report).recommended[0].points[0].values.alpha, 0);
    (source.summary as Record<string, unknown>).missing = 1;
    source.detail!.rows![0].missing = 1;
    const incomplete = decodeReportCard(source, 2);
    assert.equal(incomplete.display.highlights[0].value, '未知');
    assert.equal(planSavedCharts(incomplete).recommended[0].points[0].values.alpha, null);
});

test('指定關係沒有足夠共同資料時顯示原因，不改選第三個指標', () => {
    const source = semantic(); source.detail!.rows![0].alpha = null;
    const plan = planSavedCharts(decodeReportCard(source, 2));
    assert.deepEqual(plan.recommended, []);
    assert.match(plan.reason || '', /指定指標/);
});

test('固定舊工具v2以保存的明細與標籤投影指定配對，不建立新語意版本', () => {
    const card = decodeReportCard({id: 'fixed', kind: 'machine_production', source_call_id: 'fixed-source',
        chart_preference: {call_id: 'fixed-source', intent: 'relationship', metrics: ['good_quantity', 'scrap_quantity']},
        detail: {columns: [{key: 'machine_id'}, {key: 'good_quantity', label: '保存良品'}, {key: 'scrap_quantity', label: '保存不良'}], rows: [
            {machine_id: 'A', good_quantity: 0, scrap_quantity: 2}, {machine_id: 'B', good_quantity: 7, scrap_quantity: 1},
        ]}}, 2);
    assert.equal(card.semantic_metadata_version, undefined);
    const graph = planSavedCharts(card).recommended[0];
    assert.deepEqual(graph.encoding, {x: 'good_quantity', y: 'scrap_quantity', series: []});
    assert.equal(graph.columns.find(column => column.name === 'good_quantity')!.label, '保存良品');
    assert.equal(graph.points[0].values.good_quantity, 0);
    assert.match(graph.points[0].label, /machine_id.*A/);
});

test('固定工具的明確偏好保留已知部分標記及原計數，缺量完整值不成關係圖', () => {
    const raw: RawReportCard = {id: 'fixed', kind: 'machine_production', source_call_id: 'fixed-source',
        chart_preference: {call_id: 'fixed-source', intent: 'relationship', metrics: ['known_good_quantity', 'known_scrap_quantity']},
        detail: {columns: ['machine_id', 'known_good_quantity', 'known_scrap_quantity'].map(key => ({key})), rows: [
            {machine_id: 'A', known_good_quantity: 0, known_scrap_quantity: 2, operation_count: 1},
            {machine_id: 'B', known_good_quantity: 7, known_scrap_quantity: 1, operation_count: 1},
        ]}};
    const plan = planSavedCharts(decodeReportCard(raw, 2));
    assert.equal(plan.recommended[0].mark, 'scatter');
    assert.ok(plan.recommended[0].notices.some(notice => notice.includes('已知部分')));
    assert.match(plan.recommended[0].columns.find(column => column.name === 'known_good_quantity')!.label, /已知部分/);
    raw.detail!.rows![0].operation_count = 0;
    assert.deepEqual(planSavedCharts(decodeReportCard(raw, 2)).recommended, []);
    raw.chart_preference = {call_id: 'fixed-source', intent: 'relationship', metrics: ['good_quantity', 'scrap_quantity']};
    raw.detail!.columns = ['machine_id', 'good_quantity', 'scrap_quantity'].map(key => ({key}));
    raw.detail!.rows = [{machine_id: 'A', good_quantity: 0, scrap_quantity: 2, quantity_complete: false}, {machine_id: 'B', good_quantity: 7, scrap_quantity: 1}];
    assert.deepEqual(planSavedCharts(decodeReportCard(raw, 2)).recommended, []);
});

test('v2預設null偏好與舊hist維持凍結adapter，不需要現行MDL', () => {
    const card = decodeReportCard({id: 'old', kind: 'machine_production', source_call_id: 'audit-1', chart_preference: null,
        detail: {rows: [{machine_id: 'A', produced_quantity: 12}]}}, 2);
    assert.equal(card.chart_contract, 'v2');
    assert.equal(card.chart_model, 'legacy');
    assert.equal(planSavedCharts(card).recommended[0].points[0].values.value, 12);
});

test('壞單卡保留原答案與其他卡片，非字串React文字不會送進呈現元件', () => {
    for (const broken of [null, {id: 'bad', kind: 'fixed', title: {}}, {id: 'bad', kind: 'fixed', detail: {columns: [null]}},
        {id: 'bad', kind: 'fixed', notes: [null]}, {id: 'bad', kind: 'fixed', evidence: [null]}, {...semantic(), id: 'bad', semantic_metadata_version: 99}]) {
        const report = decodeReport(envelope([semantic(), broken]));
        assert.equal(report.answer, '原保存答案');
        assert.equal(report.cards[0].chart_contract, 'v2');
        assert.equal(report.cards[1].chart_contract, 'unavailable');
        assert.ok(report.cards[1].chart_reason);
    }
});

test('未知report版本、非字串wire版本與不符request來源拒絕，不冒充已解析報告', () => {
    for (const version of ['mes-report-v99', ['mes-report-v2'], 2, null]) assert.throws(() => decodeReport(envelope([], version)), ReportDecodeError);
    assert.throws(() => decodeReport(envelope([]), 'foreign'), ReportDecodeError);
});

test('semantic版本使用原始number型別，布林與字串不升級舊快照', () => {
    for (const version of ['2', true, false, null, 2.5, 3]) {
        const source = semantic(); source.semantic_metadata_version = version;
        assert.equal(decodeReportCard(source, 2).chart_contract, 'unavailable');
    }
});

test('來源偏好必須引用本卡已保存numeric欄位並保留唯一配對', () => {
    for (const preference of [{call_id: 'foreign', intent: 'relationship', metrics: ['gamma', 'alpha']},
        {call_id: 'source-a', intent: 'relationship', metrics: ['alpha']}, {call_id: 'source-a', intent: 'relationship', metrics: ['alpha', 'alpha']},
        {call_id: 'source-a', intent: 'relationship', metrics: ['station', 'alpha']}, {call_id: 'source-a', intent: 'relationship', metrics: ['missing', 'alpha']}]) {
        const source = semantic(); source.chart_preference = preference;
        assert.equal(decodeReportCard(source, 2).chart_contract, 'unavailable');
    }
});

test('v2計數關系必须是同來源原始number质量字段，不接受自引或循环', () => {
    for (const change of [{source_group: 'another'}, {data_type: 'string'}, {role: 'dimension'}, {availability_count_field: 'alpha'}, {required_missing_fields: ['missing']}]) {
        const source = semantic(); Object.assign(source.semantic_columns!.find(column => column.name === 'samples')!, change);
        assert.equal(decodeReportCard(source, 2).chart_contract, 'unavailable');
    }
    const source = semantic(); source.semantic_columns![0].source_group = undefined;
    assert.equal(decodeReportCard(source, 2).chart_contract, 'unavailable');
});

test('v2完整量對等關系需存在、類型、單位與來源相同', () => {
    const source = semantic();
    source.semantic_columns!.push({...measure('known_alpha'), interpretation: 'known_partial', completeness_required: false, required_missing_fields: [], complete_counterpart: 'alpha'});
    source.detail!.columns!.push({key: 'known_alpha'});
    for (const invalid of ['unknown', 'known_alpha', 'station']) {
        source.semantic_columns!.at(-1)!.complete_counterpart = invalid;
        assert.equal(decodeReportCard(source, 2).chart_contract, 'unavailable');
    }
    source.semantic_columns!.at(-1)!.complete_counterpart = 'alpha';
    assert.equal(decodeReportCard(source, 2).chart_contract, 'v2');
    source.semantic_columns!.at(-1)!.unit = '秒';
    assert.equal(decodeReportCard(source, 2).chart_contract, 'unavailable');
});

test('無可用性計數的普通metric也按保存data_type核對原值', () => {
    const column = {name: 'measure', label: '保存數值', role: 'metric' as const, data_type: 'number' as const};
    for (const value of [true, false, '1', null, undefined, NaN, Infinity]) assert.equal(savedSemanticMetricAvailable(column, {measure: value}, [column]), false);
    for (const value of [0, -1, 1.5]) assert.equal(savedSemanticMetricAvailable(column, {measure: value}, [column]), true);
});


test('顯示投影保留保存指標說明，缺值理由優先，外來 display 不能覆寫保存數字', () => {
    const source = semantic();
    source.metrics![0].detail = '原保存指標說明';
    source.display = {answer: false, highlights: [{key: 'alpha', value: '99999'}], metrics: [], columns: []};
    const decoded = decodeReportCard(source, 2);
    assert.equal(decoded.display.answer, true);
    assert.equal(decoded.display.metrics[0].value, '3');
    assert.equal(decoded.display.metrics[0].unit, '公斤');
    assert.equal(decoded.display.metrics[0].detail, '原保存指標說明');
    assert.deepEqual(decoded.display.columns, source.detail!.columns);
    source.summary = {...source.summary as object, missing: 1};
    const missing = decodeReportCard(source, 2);
    assert.equal(missing.display.metrics[0].value, '未知');
    assert.equal(missing.display.metrics[0].unit, '');
    assert.equal(missing.display.metrics[0].detail, '資料未完整取得');
});
