import test from 'node:test';
import assert from 'node:assert/strict';
import {buildSettingsUpdate, settingsDraft, type ProviderSettings} from '../src/chat/settings';
import {ChatApi, ChatApiError} from '../src/chat/api';

function snapshot(): ProviderSettings {
    const saved = {mode: 'API' as const, api: {model: 'fixture-api', reasoning_effort: 'medium'},
        agent: {id: 'agent_fixture', project_id: 'proj_fixture', model: 'fixture-agent', reasoning_effort: 'medium'}};
    return {revision: 'fixture-v1', effective: structuredClone(saved), saved, api_key: {configured: true, saved_configured: true, source: 'local', editable: true},
        sources: {} as ProviderSettings['sources'], locked_fields: [], restart_required: false, apply: 'restart', management: {authorization: 'loopback'}, blocked_reason: null};
}

test('本地與雲端保留各自模型，切換只送來源且不夾帶金鑰', () => {
    const settings = snapshot(), draft = settingsDraft(settings);
    draft.api.provider = 'local';
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1', api: {provider: 'local'}});
    draft.local.model = '/models/測試模型.gguf';
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1', api: {provider: 'local'}, local: {model: '/models/測試模型.gguf'}});
    assert.equal(draft.api.model, settings.saved.api.model);
    assert.equal(settings.saved.api.provider, undefined);
});

test('本地來源及網址鎖定時不送覆寫，上下文非法值會顯示驗證錯誤', () => {
    const settings = snapshot();
    settings.effective.api.provider = 'local'; settings.effective.local = {base_url: 'http://127.0.0.1:1234/v1', model: 'fixture', context_tokens: 32768};
    settings.locked_fields = ['api.provider', 'local.base_url'];
    const draft = settingsDraft(settings);
    assert.equal(draft.api.provider, 'local'); assert.equal(draft.local.base_url, settings.effective.local.base_url);
    draft.api.provider = 'cloud'; draft.local.base_url = 'http://127.0.0.1:1/v1';
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1'});
    draft.local.context_tokens = NaN;
    assert.throws(() => buildSettingsUpdate(settings, draft), /上下文/);
});

test('設定只送出變更與原 revision，不重送無變更的欄位', () => {
    const settings = snapshot(), draft = settingsDraft(settings);
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1'});
    draft.agent.model = '  fixture-new  ';
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1', agent: {model: 'fixture-new'}});
    assert.equal(settings.saved.agent.model, 'fixture-agent');
});

test('環境變數欄位呈現有效值，修改草稿也不產生覆寫命令', () => {
    const settings = snapshot();
    settings.locked_fields = ['mode', 'api_key', 'api.model', 'agent.id'];
    settings.api_key.editable = false; settings.effective.mode = 'AGENT';
    settings.effective.api.model = 'env-api'; settings.effective.agent.id = 'agent_env';
    const draft = settingsDraft(settings);
    assert.equal(draft.mode, 'AGENT'); assert.equal(draft.api.model, 'env-api'); assert.equal(draft.agent.id, 'agent_env');
    draft.mode = 'API'; draft.api.model = 'other'; draft.agent.id = 'other';
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1'});
});

test('設定草稿混入金鑰也不傳送，後端設定快照保持原樣', () => {
    const settings = snapshot(), before = JSON.stringify(settings);
    const draft = {...settingsDraft(settings), api_key: 'fixture-secret'};
    assert.deepEqual(buildSettingsUpdate(settings, draft), {revision: 'fixture-v1'});
    assert.equal(JSON.stringify(settings), before);
    assert.equal(JSON.stringify(settings).includes('fixture-secret'), false);
});

function setup() {
    const entries = new Map<string, string>([['X_BI_accountNo', 'ADMINV2'], ['X_BI_TokenKey', 'fixture-session'], ['X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString()]]);
    const storage = {getItem(key: string) {return entries.get(key) ?? null;}} as Storage;
    return {storage, entries};
}

test('管理憑證 403 顯示設定錯誤，不將有效 MES 聊天登入標記逾時', async () => {
    const {storage} = setup(); let notices = 0;
    const api = new ChatApi({fetchImpl: async () => new Response(JSON.stringify({detail: '需要管理憑證'}), {status: 403})}, 'X', 'ADMINV2', storage, {notifySession() {notices++;}, rateLimited() {}});
    await assert.rejects(api.json('/api/chat/settings', {}, {notifySessionErrors: false}), (error: unknown) => error instanceof ChatApiError && error.userMessage === '需要管理憑證');
    assert.equal(notices, 0);
    await assert.rejects(api.json('/api/chat/conversations'));
    assert.equal(notices, 1);
});

test('本機 MES 憑證已過期時，設定請求仍通知登入失效且不發出網路請求', async () => {
    const {storage, entries} = setup(); entries.set('X_BI_TokenExpiry', '2000-01-01'); let requests = 0, notices = 0;
    const api = new ChatApi({fetchImpl: async () => {requests++; return new Response('{}');}}, 'X', 'ADMINV2', storage, {notifySession() {notices++;}, rateLimited() {}});
    await assert.rejects(api.json('/api/chat/settings', {}, {notifySessionErrors: false}));
    assert.equal(requests, 0); assert.equal(notices, 1);
});

test('設定端點回應 401 時仍使 MES 登入失效，管理 403 例外不能略過', async () => {
    const {storage} = setup(); let notices = 0;
    const api = new ChatApi({fetchImpl: async () => new Response(JSON.stringify({detail: '登入已逾時'}), {status: 401})}, 'X', 'ADMINV2', storage, {notifySession() {notices++;}, rateLimited() {}});
    await assert.rejects(api.json('/api/chat/settings', {}, {notifySessionErrors: false}));
    assert.equal(notices, 1);
    assert.equal(api.session(), null);
});

test('伺服器拒絕的憑證不再送出，宿主換新憑證後可重新使用且不修改宿主儲存', async () => {
    const {storage, entries} = setup(); let requests = 0;
    const api = new ChatApi({fetchImpl: async () => {requests++; return requests === 1 ? new Response('{}', {status: 401}) : new Response('{}');}}, 'X', 'ADMINV2', storage, {notifySession() {}, rateLimited() {}});
    await assert.rejects(api.json('/api/chat/settings', {}, {notifySessionErrors: false}));
    await assert.rejects(api.json('/api/chat/settings', {}, {notifySessionErrors: false}));
    assert.equal(requests, 1); assert.equal(entries.get('X_BI_TokenKey'), 'fixture-session');
    entries.set('X_BI_TokenKey', 'fixture-renewed');
    assert.equal(api.session()?.tokenKey, 'fixture-renewed');
    await api.json('/api/chat/settings'); assert.equal(requests, 2);
});

test('舊請求的遲來401不拒絕已更新的宿主憑證', async () => {
    const {storage, entries} = setup(); let notices = 0;
    let respond!: (value: Response) => void;
    const api = new ChatApi({fetchImpl: () => new Promise<Response>(resolve => {respond = resolve;})}, 'X', 'ADMINV2', storage, {notifySession() {notices++;}, rateLimited() {}});
    const pending = api.json('/api/chat/settings', {}, {notifySessionErrors: false});
    entries.set('X_BI_TokenKey', 'fixture-renewed'); respond(new Response('{}', {status: 401}));
    await assert.rejects(pending);
    assert.equal(api.session()?.tokenKey, 'fixture-renewed'); assert.equal(notices, 0);
});
