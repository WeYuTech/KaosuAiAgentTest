import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {register as registerLoader} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {saveAssistantMessage} from '../src/chat/core';
import {decodeReport} from '../src/chat/report-decoder';
import type {ChatActions, ChatState, ExecutionState, Message, Turn} from '../src/chat/types';

// 透過產品的 runtime 與 Message primitive 呈現真實擴充元件，不模擬元件內部 hook
registerLoader('data:text/javascript,' + encodeURIComponent('export async function load(url, context, nextLoad) { if (new URL(url).pathname.endsWith(".css")) return {format:"module", source:"export default {}", shortCircuit:true}; return nextLoad(url, context); }'), import.meta.url);
const scoped = register({namespace: 'message-audit-presentation', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {ThreadPrimitive, MessagePrimitive} = await scoped.import('@assistant-ui/react', import.meta.url) as typeof import('@assistant-ui/react');
const {MesAssistantProvider} = await scoped.import('../src/chat/assistant-runtime.tsx', import.meta.url) as typeof import('../src/chat/assistant-runtime');
const {MesUiProvider} = await scoped.import('../src/chat/mes-ui-context.tsx', import.meta.url) as typeof import('../src/chat/mes-ui-context');
const {MesMessageExtras} = await scoped.import('../src/features/mes/MesMessageExtras.tsx', import.meta.url) as typeof import('../src/features/mes/MesMessageExtras');
const {MesReportDetails} = await scoped.import('../src/features/mes/MesReportDialog.tsx', import.meta.url) as typeof import('../src/features/mes/MesReportDialog');
const {MesSourceAnswer} = await scoped.import('../src/features/mes/MesReportTable.tsx', import.meta.url) as typeof import('../src/features/mes/MesReportTable');
const {Thread} = await scoped.import('../src/components/assistant-ui/elements/thread.aui.tsx', import.meta.url) as typeof import('../src/components/assistant-ui/elements/thread.aui');
const {ChatExecutionStatus} = await scoped.import('../src/features/common/ChatExecutionStatus.tsx', import.meta.url) as typeof import('../src/features/common/ChatExecutionStatus');

const notice = '稽核紀錄暫時未能保存；已保存的聊天與查詢報告仍可讀取';
const actions = {} as ChatActions;

function presentationReport(mode: 'table' | 'chart', bindings = true) {
    return decodeReport({report_version: 'mes-report-v2', request_id: 'fixture-request', answer_presentation: {version: 'answer-presentation-v1', mode, preferred_chart_kind: mode === 'chart' ? 'bar' : null}, source_answer: '原回答含重要限制與 9999，不能用作數據',
        cards: [{id: 'saved', kind: 'work_order', title: '原回答資料', source_call_id: 'call', metrics: [{key: 'hidden', label: '不應自動顯示的隱藏總量', value: 98765}], detail: {columns: [{key: 'good', label: '良品量'}], rows: [{good: 99}]},
            ...(bindings ? {binding_table: {columns: [{key: 'subject', label: '對象'}, {key: 'metric', label: '指標'}, {key: 'value', label: '保存值'}], rows: [{subject: '全範圍摘要', metric: '原顯示量', value: '未知'}]}, binding_selection: {metrics: [], row_indices: [], cells: [], row_subjects: []}} : {})}], warnings: ['原始缺量限制']});
}

test('直接表格使用保存引用且保留原報表入口，不自動顯示全卡摘要或圖表', () => {
    const report = presentationReport('table');
    const html = render(message({execution_state: 'completed', status: 'succeeded', content: '已切換呈現', response_kind: 'rewrite', source_request_id: 'original'}), {reports: {'fixture-request': {state: 'ready', report, message: ''}}});
    assert.match(html, /data-slot="mes-binding-table"/);
    for (const text of ['對象', '指標', '保存值', '全範圍摘要', '原顯示量', '未知', '原回答與重要限制', '查看原始報表']) assert.ok(html.includes(text), text);
    for (const text of ['mes-report-overview', 'mes-report-chart', '不應自動顯示的隱藏總量', '98765', '9999']) assert.equal(html.includes(text), false, text);
});

test('摘要沒有明細圖型候選時明示圖表不可轉換，同時保留保存表格', () => {
    const report = presentationReport('chart');
    const html = render(message({execution_state: 'completed', status: 'succeeded', content: '已切換呈現'}), {reports: {'fixture-request': {state: 'ready', report, message: ''}}});
    assert.match(html, /無法直接轉換為圖表/);
    assert.match(html, /mes-binding-table/);
    assert.equal(html.includes('data-chart-kind='), false);
});

test('舊來源沒有bindings時說明不可直接轉換，保留原報表入口', () => {
    const report = presentationReport('table', false);
    const html = render(message({execution_state: 'completed', status: 'insufficient_data', content: '保存引用不足'}), {reports: {'fixture-request': {state: 'ready', report, message: ''}}});
    assert.match(html, /無法直接轉換為表格/);
    assert.match(html, /查看原始報表/);
    assert.equal(html.includes('不應自動顯示的隱藏總量'), false);
});

test('可展開原回答引用保留文字與重要限制，不執行HTML或由正文擷取數字', () => {
    const html = renderToStaticMarkup(createElement(MesSourceAnswer, {answer: '<script>原文 9999</script> ![圖](https://example.test/a.png)', warnings: ['原始缺量限制']}));
    assert.match(html, /原文 9999/);
    assert.match(html, /原始缺量限制/);
    assert.match(html, /&lt;script&gt;/);
    assert.equal(html.includes('<script>'), false);
    assert.equal(html.includes('<img'), false);
    assert.equal(html.includes('<table'), false);
});

test('完整 Thread 中的失敗訊息只出現一次，長原因不截斷', () => {
    const reason = '本地模型輸出達到上限，回答被截斷。未發布不完整答案，請縮小問題範圍或改用其他模型。';
    const saved = message({execution_state: 'failed', status: 'failed', error_message: reason, content: reason, audit_status: 'saved'});
    const props = {state: state(saved), actions};
    const html = renderToStaticMarkup(createElement(MesUiProvider, props,
        createElement(MesAssistantProvider, props, createElement(Thread))));
    assert.equal(html.split(reason).length - 1, 1);
    assert.match(html, /aui-message-error-message/);
    assert.equal(html.includes('line-clamp-2'), false);
});
function state(message: Message): ChatState {
    return {
        enabled: true, opened: true, expanded: false, historyOpen: false, view: 'chat',
        runtime: {mode: 'API', continuous_context: false}, conversationId: 'fixture-conversation', conversationTitle: '保存驗證', conversation: null, conversations: [],
        historyCursor: null, historyLoading: false, historyLoaded: true, historyStatus: '', historyArchived: false, conversationSaving: [],
        messages: [message], activeTurn: message, displayMessages: [message], draft: '', submitting: false, cancelling: false,
        connectionStatus: '', sessionNotice: '', expired: false, readOnly: false, readOnlyNotice: '', hint: '', sendDisabled: true, inputDisabled: false,
        showStop: message.execution_state === 'running', unknownSubmission: false, reconnectNeeded: false,
        reports: {}, exporting: [], feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null,
    };
}
function MessageExtras() {return createElement(MessagePrimitive.Root, null, createElement(MesMessageExtras));}
function render(message: Message, overrides: Partial<ChatState> = {}) {
    const props = {state: {...state(message), ...overrides}, actions};
    return renderToStaticMarkup(createElement(MesUiProvider, props,
        createElement(MesAssistantProvider, props,
            createElement(ThreadPrimitive.Root, null,
                createElement(ThreadPrimitive.Messages, {components: {Message: MessageExtras}}), createElement(ChatExecutionStatus)))));
}

test('真實訊息元件只對可重試的報告故障提供重新載入，404 與未知版本沒有循環入口', () => {
    const saved = message({execution_state: 'completed', status: 'succeeded', content: '保存答案', audit_status: 'saved'});
    for (const cacheState of ['retryable-error', 'loading', 'missing', 'unavailable'] as const) {
        const html = render(saved, {reports: {'fixture-request': {state: cacheState, report: null, message: '報告暫時無法讀取'}}});
        assert.equal(html.includes('重新載入'), cacheState === 'retryable-error');
        assert.ok(html.includes('保存答案') || html.includes('查詢資訊'));
    }
});
function message(overrides: Partial<Message> = {}): Message {
    return {role: 'assistant', request_id: 'fixture-request', conversation_id: 'fixture-conversation', content: '', execution_state: 'running', status: 'started', audit_status: 'unavailable', ...overrides};
}

test('生成中與送出待確認的 unavailable 不誤報保存失敗，仍呈現原執行狀態', () => {
    for (const execution_state of ['queued', 'submitting', 'running', 'submission_unknown'] as ExecutionState[]) {
        const html = render(message({execution_state}));
        assert.match(html, /data-slot="mes-message-extras"/);
        assert.match(html, /role="status"/);
        assert.equal(html.includes(notice), false, execution_state);
    }
});

test('已完成且明確 saved 不顯示保存失敗，未知保存狀態也不冒稱失敗', () => {
    for (const audit_status of ['saved', undefined]) {
        const html = render(message({execution_state: 'completed', status: 'succeeded', content: '已保存的測試答案', audit_status}));
        assert.equal(html.includes(notice), false);
        assert.match(html, /查詢資訊/);
    }
});

test('完成、失敗及取消後明確 unavailable 仍保留保存失敗提示', () => {
    for (const execution_state of ['completed', 'failed', 'cancelled'] as ExecutionState[]) {
        const html = render(message({execution_state, status: execution_state === 'completed' ? 'succeeded' : execution_state as 'failed' | 'cancelled', content: '需要自行保留的測試答案'}));
        assert.equal(html.includes(notice), true, execution_state);
    }
    assert.equal(render(message({execution_state: undefined, status: undefined, content: '既有歷史答案'})).includes(notice), true);
});

test('相同回合從串流 unavailable 更新為已保存終態，不殘留提示或新增助理答案', () => {
    let messages: Message[] = [];
    const frames: Turn[] = [
        {conversation_id: 'fixture-conversation', request_id: 'fixture-request', execution_state: 'running', status: 'started', answer: '部分回答', audit_status: 'unavailable'},
        {conversation_id: 'fixture-conversation', request_id: 'fixture-request', execution_state: 'completed', status: 'succeeded', answer: '完整回答', audit_status: 'saved'},
    ];
    for (const frame of frames) {
        messages = saveAssistantMessage(messages, frame);
        assert.equal(messages.length, 1);
        assert.equal(render(messages[0]!).includes(notice), false);
    }
    assert.equal(messages[0]!.audit_status, 'saved');
    assert.equal(messages[0]!.content, '完整回答');
    messages = saveAssistantMessage(messages, {...frames[1], audit_status: 'unavailable'});
    assert.equal(render(messages[0]!).includes(notice), true);
    messages = saveAssistantMessage(messages, frames[1]!);
    assert.equal(render(messages[0]!).includes(notice), false);
    assert.equal(messages.length, 1);
});

test('沿用條件只呈現已保存且明確 inherited 的摘要，舊回答與正文數字不推測條件', () => {
    const summary = '2026 年 8 月 · 機台 MC-03';
    const saved = message({execution_state: 'completed', status: 'succeeded', content: '已保存的回答 999 台', audit_status: 'saved', scope_inherited: true, query_scope_summary: summary, query_scope: {machine_id: 'MC-03'}});
    const html = render(saved);
    assert.match(html, /data-slot="mes-inherited-query-scope"/);
    assert.ok(html.includes('沿用查詢條件：' + summary));
    for (const variant of [{scope_inherited: false}, {scope_inherited: undefined}, {query_scope_summary: ''}, {query_scope_summary: '   '}, {query_scope_summary: undefined}]) assert.equal(render({...saved, ...variant}).includes('沿用查詢條件：'), false);
    assert.equal(render(message({content: '正文寫了 2026 年 8 月及機台 MC-03'})).includes('沿用查詢條件：'), false);
});

test('真實訊息元件區分澄清與資料不足，保存失敗仍獨立呈現', () => {
    const saved = message({execution_state: 'completed', status: 'insufficient_data', response_kind: 'clarification', content: '要查哪一年的七月？', audit_status: 'saved'});
    assert.equal(render(saved).includes('部分資料不足'), false);
    assert.equal(render({...saved, response_kind: undefined}).includes('部分資料不足'), true);
    assert.equal(render({...saved, evidence: [{tool_name: 'fixture', status: 'no_data'}]}).includes('部分資料不足'), true);
    assert.equal(render({...saved, audit_status: 'unavailable'}).includes(notice), true);
});

test('只有明確保存來源才呈現沒有重新查詢提示，不由正文推測', () => {
    const saved = message({execution_state: 'completed', status: 'succeeded', response_kind: 'rewrite', content: '主管摘要', audit_status: 'saved', source_request_id: 'source-fixture'});
    assert.match(render(saved), /data-slot="mes-saved-result-notice"/);
    assert.equal(render({...saved, source_request_id: undefined}).includes('沒有重新查詢 MES'), false);
});

test('核對失敗只呈現一次未完成標記，不冒稱資料不足或已完成整理', () => {
    const reason = '這次回答未通過核對，仍可查看保存的查詢結果。';
    const saved = message({execution_state: 'completed', status: 'insufficient_data', response_kind: 'insufficient_data', result_reasons: ['verification_failed'], content: reason, audit_status: 'saved', report_available: true});
    const props = {state: state(saved), actions};
    const html = renderToStaticMarkup(createElement(MesUiProvider, props,
        createElement(MesAssistantProvider, props, createElement(Thread))));
    assert.equal(html.split(reason).length - 1, 1);
    assert.equal(html.split('data-slot="mes-answer-incomplete"').length - 1, 1);
    assert.equal(html.includes('部分資料不足'), false);
    assert.equal(html.includes('mes-saved-result-notice'), false);
    assert.equal(render({...saved, source_request_id: '歷史不相容來源'}).includes('mes-saved-result-notice'), false);
});


function selectedReport() {
    const columns = [{name: 'subject', label: '保存對象', role: 'dimension', data_type: 'string'}, {name: 'reading', label: '保存數值', role: 'metric', data_type: 'number', unit: '公斤'}];
    return decodeReport({report_version: 'mes-report-v2', request_id: 'fixture-request', view_preferences_editable: true,
        view_preferences: {version: 'report-view-preferences-v1', revision: 2, selections: [{card_id: 'saved', mark: 'point', metrics: ['reading']}]},
        cards: [{id: 'saved', kind: '任意核准工具', title: '保存結果', source_call_id: 'call-a', status: 'ok',
            chart_metadata: {version: 'mes-chart-metadata-v1', fingerprint: 'saved-version', columns},
            chart_preference: {call_id: 'call-a', intent: 'comparison', metrics: ['reading']},
            detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows: [{subject: '甲', reading: 0}, {subject: '乙', reading: 30}]}}]});
}

test('主回答與明細使用同一卡片保存偏好，重建元件仍保持點圖及原值', () => {
    const report = selectedReport(), saved = message({execution_state: 'completed', status: 'succeeded', content: '原保存答案'});
    const props = {state: {...state(saved), reports: {[report.request_id]: {state: 'ready' as const, report, message: ''}}}, actions};
    const overview = render(saved, props.state);
    const details = () => renderToStaticMarkup(createElement(MesUiProvider, props, createElement(MesReportDetails, {card: report.cards[0], report})));
    for (const html of [overview, details(), details()]) {
        assert.match(html, /data-chart-kind="point"/);
        assert.doesNotMatch(html, /data-chart-kind="bar"/);
    }
    assert.match(details(), /保存數值/); assert.match(details(), /公斤/);
});

for (const reason of ['expired', 'archived', 'read-only', 'saving'] as const) test(`明細呈現選單沿共同保存狀態停用：${reason}`, () => {
    const report = selectedReport(), saved = message({execution_state: 'completed', status: 'succeeded'});
    if (reason === 'read-only') report.view_preferences_editable = false;
    const props = {state: {...state(saved), expired: reason === 'expired', conversation: reason === 'archived' ? {conversation_id: 'fixture-conversation', title: '保存聊天', is_archived: true} : null,
        presentationSaving: reason === 'saving' ? [report.request_id] : []}, actions};
    const html = renderToStaticMarkup(createElement(MesUiProvider, props, createElement(MesReportDetails, {card: report.cards[0], report})));
    assert.match(html, /<button[^>]*role="combobox"[^>]*\sdisabled=""/);
    assert.match(html, /data-chart-kind="point"/);
    assert.equal(html.includes('正在保存呈現方式'), reason === 'saving');
});


test('明細的偏好依報告與卡片配對，不套用另一來源或另一報告的點圖', () => {
    const first = selectedReport();
    const report = decodeReport({...first, cards: [...first.cards, {...first.cards[0], id: 'other', source_call_id: 'call-b', chart_preference: {call_id: 'call-b', intent: 'comparison', metrics: ['reading']}}]});
    const saved = message({execution_state: 'completed', status: 'succeeded'});
    const props = {state: {...state(saved), reports: {[first.request_id]: {state: 'ready' as const, report: first, message: ''}}}, actions};
    const html = renderToStaticMarkup(createElement(MesUiProvider, props, createElement(MesReportDetails, {card: report.cards[1], report})));
    assert.match(html, /data-chart-kind="bar"/); assert.doesNotMatch(html, /data-chart-kind="point"/);
    const otherReport = {...first, request_id: '另一報告', view_preferences: {version: 'report-view-preferences-v1' as const, revision: 0, selections: []}};
    const separate = renderToStaticMarkup(createElement(MesUiProvider, props, createElement(MesReportDetails, {card: otherReport.cards[0], report: otherReport})));
    assert.match(separate, /data-chart-kind="bar"/); assert.doesNotMatch(separate, /data-chart-kind="point"/);
});

test('直接呈現的明細圖表沿用已核對綁定，不重新以完整快照推導圖型', () => {
    const report = presentationReport('table'), saved = message({execution_state: 'completed', status: 'succeeded'});
    const html = renderToStaticMarkup(createElement(MesUiProvider, {state: state(saved), actions}, createElement(MesReportDetails, {card: report.cards[0], report})));
    assert.match(html, /data-slot="mes-binding-table"/);
    assert.match(html, /原顯示量/); assert.match(html, /未知/);
    assert.doesNotMatch(html, /data-chart-kind=/);
});
