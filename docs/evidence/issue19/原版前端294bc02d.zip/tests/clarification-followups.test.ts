import test from 'node:test';
import assert from 'node:assert/strict';
import {ChatController} from '../src/chat/controller';
import {createMesExternalStoreAdapter} from '../src/chat/assistant-runtime';
import {getMesFollowupSource, setMesFollowupDraft} from '../src/chat/follow-ups';
import type {ChatState, Mode, Turn} from '../src/chat/types';

class MemoryStorage implements Storage {
    private values = new Map<string, string>();
    get length() { return this.values.size; }
    key(index: number) { return [...this.values.keys()][index] || null; }
    getItem(key: string) { return this.values.get(key) || null; }
    setItem(key: string, value: string) { this.values.set(key, String(value)); }
    removeItem(key: string) { this.values.delete(key); }
    clear() { this.values.clear(); }
}

const choices = [
    {title: '使用已選期間', prompt: '查詢 2026 年 8 月的機台產量'},
    {title: '調整期間', prompt: '查詢 2026 年 7 月的機台產量'},
    {title: '指定機台', prompt: '查詢 2026 年 8 月機台 MC-03 的產量'},
];

function fixture(mode: Mode, transport: 'history' | 'snapshot' | 'stream') {
    const storage = new MemoryStorage();
    storage.setItem('X_BI_accountNo', 'ADMINV2');
    storage.setItem('X_BI_TokenKey', 'isolated-fixture-token');
    storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString());
    storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    storage.setItem('X_MES_AI_CHAT_ADMINV2_DRAFTS', JSON.stringify({c1: '未送出的中文草稿', c2: '另一個聊天的草稿'}));
    const requests: {path: string; method: string}[] = [];
    const completed: Turn = {
        conversation_id: 'c1', request_id: 'clarification-1', execution_state: 'completed',
        status: 'insufficient_data', audit_status: 'saved',
        answer: '請選擇查詢條件，確認後再送出', follow_up_suggestions: choices,
        tool_snapshots: [], evidence: [], usage_known: true,
        usage: {input_tokens: 0, output_tokens: 0, total_tokens: 0},
    };
    const running: Turn = {...completed, execution_state: 'running', status: 'started', audit_status: 'unavailable', answer: ''};
    const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url, 'http://fixture').pathname;
        const method = options.method || 'GET';
        requests.push({path, method});
        if (method !== 'GET') throw new Error('條件補選 fixture 不允許寫入或模型呼叫');
        if (path.endsWith('/runtime')) return json({mode, continuous_context: mode === 'AGENT'});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/c1')) return json({
            conversation_id: 'c1', title: '待補選查詢', mode,
            ...(transport === 'history'
                ? {messages: [{...completed, role: 'assistant', content: completed.answer}]}
                : {active_request_id: completed.request_id, messages: [{role: 'user', content: '查詢機台產量', request_id: completed.request_id}]}),
        });
        if (path.endsWith('/c2')) return json({conversation_id: 'c2', title: '另一個聊天', mode, messages: []});
        if (path.endsWith('/clarification-1')) return json(transport === 'stream' ? running : completed);
        if (path.endsWith('/stream')) return new Response([
            {name: 'snapshot', data: running},
            {name: 'answer_delta', data: {request_id: completed.request_id, delta: '請選擇查詢條件'}},
            {name: 'done', data: completed},
        ].map(({name, data}) => `event: ${name}\ndata: ${JSON.stringify(data)}\n\n`).join(''), {headers: {'Content-Type': 'text/event-stream'}});
        throw new Error('未預期 fixture 請求：' + path);
    };
    return {storage, requests, completed, controller: new ChatController({storage, fetchImpl}, 'X')};
}

for (const mode of ['API', 'AGENT'] as const) for (const transport of ['history', 'snapshot', 'stream'] as const) {
    test(`${mode} ${transport} 空工具澄清可補選條件，尺寸、重開與中文草稿隔離且零 POST`, async () => {
        const originalWindow = globalThis.window;
        globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
        const {controller, storage, requests, completed} = fixture(mode, transport);
        const unsubscribe = controller.subscribe(() => {
            const current = controller.getSnapshot();
            if (current.showStop) assert.equal(getMesFollowupSource(current), null);
        });
        try {
            await controller.actions.openChat();
            const current = controller.getSnapshot();
            const message = current.displayMessages.at(-1)!;
            assert.equal(message.status, 'insufficient_data');
            assert.equal(message.query_scope, undefined);
            assert.deepEqual(message.tool_snapshots, []);
            assert.deepEqual(message.evidence, []);
            assert.equal(current.draft, '未送出的中文草稿');
            const source = getMesFollowupSource(current)!;
            assert.deepEqual(source.suggestions, choices);
            assert.deepEqual(createMesExternalStoreAdapter({state: current, actions: controller.actions}).suggestions, choices);
            assert.equal(setMesFollowupDraft(current, controller.actions, source, source.suggestions[2]!), true);
            assert.equal(controller.getSnapshot().draft, choices[2]!.prompt);
            // 補選後由相同 controller 草稿接續中文編輯，不另存一份選項輸入。
            const chineseDraft = choices[2]!.prompt.replace('機台 MC-03', '機台 MC-03 與 MC-04') + '\n請列出已知數量';
            controller.actions.setDraft(chineseDraft);
            controller.actions.toggleExpanded();
            controller.actions.toggleExpanded();
            assert.equal(controller.getSnapshot().draft, chineseDraft);
            controller.actions.closeChat();
            assert.equal(getMesFollowupSource(controller.getSnapshot()), null);
            await controller.actions.openChat();
            assert.equal(controller.getSnapshot().draft, chineseDraft);
            assert.equal(controller.getSnapshot().messages.filter(item => item.role === 'assistant').length, 1);
            await controller.actions.selectConversation('c2');
            assert.equal(controller.getSnapshot().draft, '另一個聊天的草稿');
            assert.equal(setMesFollowupDraft(controller.getSnapshot(), controller.actions, source, source.suggestions[2]!), false);
            assert.equal(controller.getSnapshot().draft, '另一個聊天的草稿');
            await controller.actions.selectConversation('c1');
            assert.equal(controller.getSnapshot().draft, chineseDraft);
            assert.equal(JSON.parse(storage.getItem('X_MES_AI_CHAT_ADMINV2_DRAFTS')!).c1, chineseDraft);
            assert.deepEqual(controller.getSnapshot().displayMessages.at(-1)!.follow_up_suggestions, completed.follow_up_suggestions);
            assert.equal(requests.filter(item => item.method !== 'GET').length, 0);
        } finally {unsubscribe(); controller.dispose(); globalThis.window = originalWindow;}
    });
}

test('條件補選只用已保存選項，不從回答機台名稱、日期或其他欄位建立條件', async () => {
    const originalWindow = globalThis.window;
    globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    const {controller} = fixture('API', 'history');
    try {
        await controller.actions.openChat();
        const current = controller.getSnapshot();
        const saved = current.displayMessages.at(-1)!;
        const sourceWithoutChoices: ChatState = {...current, displayMessages: [{...saved, content: '現在是 2026 年，機台 MC-99，也許想查八月？', follow_up_suggestions: undefined}]};
        assert.equal(getMesFollowupSource(sourceWithoutChoices), null);
        assert.deepEqual(createMesExternalStoreAdapter({state: sourceWithoutChoices, actions: controller.actions}).suggestions, []);
        for (const blocked of [
            {...saved, audit_status: 'unavailable'},
            {...saved, execution_state: 'failed' as const, status: 'failed' as const},
            {...saved, status: 'rate_limited' as const},
            {...saved, conversation_id: 'different-chat'},
        ]) assert.equal(getMesFollowupSource({...current, displayMessages: [blocked]}), null);
        assert.equal(controller.getSnapshot().draft, '未送出的中文草稿');
    } finally {controller.dispose(); globalThis.window = originalWindow;}
});
