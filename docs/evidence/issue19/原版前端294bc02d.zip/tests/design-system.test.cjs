'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {auditCss, auditScript} = require('../scripts/check-design-system.cjs');
const tokens = new Set(['--mes-color-primary', '--mes-space-2', '--mes-font-size-sm', '--mes-radius-control']);
const inspect = css => auditCss(css, '頁面.css', tokens);

test('禁止頁面直接寫入色碼、色彩函式及具名顏色', () => {
    for (const value of ['#123456', 'rgb(1, 2, 3)', 'salmon']) assert.ok(inspect('.page { color: ' + value + '; }').length);
});
test('禁止頁面固定間距、字級、字重與圓角', () => {
    for (const rule of ['padding: 13px', 'padding: 10%', 'gap: 5%', 'margin: 1cm', 'gap: 1rem', 'font-size: 17px', 'line-height: 1.7', 'font-weight: 600', 'border-radius: 50%']) assert.ok(inspect('.page {' + rule + '}').length);
});
test('未知 token 與頁面自訂 fallback 會阻擋建置', () => {
    assert.ok(inspect('.page { color: var(--mes-unknown); }').length);
    assert.ok(inspect('.page { padding: var(--mes-space-2, 8px); }').length);
});
test('拒絕漸層與毛玻璃裝飾', () => {
    assert.ok(inspect('.page { background: linear-gradient(var(--mes-color-primary), var(--mes-color-primary)); }').length);
    assert.ok(inspect('.page { backdrop-filter: blur(var(--mes-space-2)); }').length);
});
test('合法 tokens、結構尺寸與網格比例可以通過', () => {
    assert.deepEqual(inspect('.page { color: var(--mes-color-primary); padding: 0 var(--mes-space-2); font-size: var(--mes-font-size-sm); border-radius: var(--mes-radius-control); width: 100vw; height: 100dvh; grid-template-columns: 1fr 1fr; border-collapse: collapse; }'), []);
});
test('任意視窗距離不能利用滿版例外繞過規範', () => {
    assert.ok(inspect('.page { padding: 100vh; width: 37vw; }').length);
});
test('頁面重複基礎元件與行內視覺樣式會失敗', () => {
    assert.ok(auditScript("const a = el('button'); input.style.padding = '13px';", 'chat.js').length);
    assert.ok(auditScript("const a = '<button>送出</button>';", 'chat.js').length);
    assert.ok(auditScript('const a = <button>送出</button>;', 'Chat.tsx').length);
    assert.ok(auditScript('const a = <Button className="p-[13px] bg-blue-500" />;', 'Chat.tsx').length);
    assert.ok(auditScript('const a = <div dangerouslySetInnerHTML={{__html: answer}} />;', 'Chat.tsx').length);
});
test('共用元件及依資料計算的進度與輸入高度可以通過', () => {
    assert.deepEqual(auditScript("const action = <Button variant='default'>送出</Button>; fill.style.width = percent + '%'; input.style.height = input.scrollHeight + 'px';", 'Chat.tsx'), []);
});
