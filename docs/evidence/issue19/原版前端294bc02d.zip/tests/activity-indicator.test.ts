import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

/** 與實際官方模板核對標記，避免測試只驗證一個模板不存在的 class */
test('活動摘要的指示器選擇器符合官方 data-slot，且不匹配回答正文', () => {
    const thread = readFileSync(new URL('../src/components/assistant-ui/elements/thread.aui.tsx', import.meta.url), 'utf8');
    const presentation = readFileSync(new URL('../src/features/mes/MesAnalysisMessage.tsx', import.meta.url), 'utf8');
    const marker = thread.match(/case "indicator":[\s\S]*?data-slot="([^"]+)"/)?.[1];
    assert.ok(marker, '官方模板必須保留可定位的指示器標記');
    const suffix = 'assistant-message-indicator';
    assert.equal(marker.endsWith(suffix), true);
    assert.ok(presentation.includes(`[&_[data-slot$=${suffix}]]:hidden`));
    assert.equal('aui_assistant-message-content'.endsWith(suffix), false);
    assert.equal('mes-answer-presentation'.endsWith(suffix), false);
    assert.equal(presentation.includes('[&_.aui-assistant-message-indicator]'), false);
});
