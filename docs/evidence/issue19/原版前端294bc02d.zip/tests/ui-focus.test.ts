import test from 'node:test';
import assert from 'node:assert/strict';
import {availableFocusTarget, restoreAvailableFocus} from '../src/features/common/restoreFocus';

function control(options: {connected?: boolean; visible?: boolean; disabled?: boolean; excluded?: boolean; tabIndex?: number; explicitTabIndex?: boolean} = {}) {
    let focused = 0;
    const element = {
        isConnected: options.connected ?? true,
        tabIndex: options.tabIndex ?? 0,
        getClientRects: () => options.visible === false ? [] : [{}],
        matches: () => options.disabled ?? false,
        closest: () => options.excluded ? {} : null,
        hasAttribute: () => options.explicitTabIndex ?? false,
        focus() {focused++;},
    } as unknown as HTMLElement;
    return {element, focused: () => focused};
}
function portal(...candidates: HTMLElement[]) {
    return {querySelectorAll: () => candidates} as unknown as HTMLElement;
}

test('選單項目已消失且主輸入區 inert 時，關閉 Dialog 將焦點還給可操作的歷史搜尋', () => {
    const menu = control({connected: false}), composer = control({excluded: true}), search = control();
    assert.equal(restoreAvailableFocus(menu.element, portal(composer.element, search.element)), true);
    assert.equal(menu.focused(), 0); assert.equal(composer.focused(), 0); assert.equal(search.focused(), 1);
});

test('停用或隱藏的原按鈕不攔截焦點，沒有可用目標時不改動宿主', () => {
    const disabled = control({disabled: true}), hidden = control({visible: false}), title = control({tabIndex: -1, explicitTabIndex: true});
    assert.equal(restoreAvailableFocus(disabled.element, portal(hidden.element, title.element)), true);
    assert.equal(disabled.focused(), 0); assert.equal(hidden.focused(), 0); assert.equal(title.focused(), 1);
    assert.equal(restoreAvailableFocus(hidden.element, null), false);
    assert.equal(restoreAvailableFocus(null, portal(disabled.element, hidden.element)), false);
});

test('編輯退出後保留仍可操作的目標；原訊息按鈕有效時優先還原且不跳至主輸入區', () => {
    const edit = control(), composer = control();
    assert.equal(restoreAvailableFocus(edit.element, portal(composer.element)), true);
    assert.equal(edit.focused(), 1); assert.equal(composer.focused(), 0);
    assert.equal(availableFocusTarget(control({tabIndex: -1}).element), false);
    assert.equal(availableFocusTarget(control({excluded: true}).element), false);
});
