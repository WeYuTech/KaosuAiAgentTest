import {decodeReportCard} from '../src/chat/report-decoder';
import test from 'node:test';
import assert from 'node:assert/strict';
import {planSavedCharts} from '../src/chat/chart-planner';
import type { RawReportCard as ReportCard, SemanticReportColumn } from '../src/chat/types';
const reportChartPanels = (card: ReportCard) => planSavedCharts(decodeReportCard(card)).recommended.map(chart => ({...chart, kind: chart.mark, points: chart.points.map(({label, values}) => ({label, values})),
    series: chart.encoding.series.map(key => ({key, label: chart.columns.find(column => column.name === key)!.label})),
}));
const reportChartData = (card: ReportCard) => {
    const chart = reportChartPanels(card)[0];
    if (!chart) return null;
    const key = chart.encoding.y;
    return {...chart, measure: chart.series[0].label, points: chart.points.filter(point => point.values[key] !== null).map(point => ({label: point.label, value: point.values[key]}))};
};
const semanticReportColumns = (card: ReportCard) => decodeReportCard(card).semantic_columns || [];

const columns: SemanticReportColumn[] = [
    {name: 'machine_id', label: '機台', role: 'dimension', data_type: 'string'},
    {name: 'personnel_group', label: '人員組合', role: 'dimension', data_type: 'string'},
    {name: 'production_date', label: '生產日', role: 'dimension', data_type: 'date'},
    {name: 'good_quantity', label: '良品量', role: 'metric', data_type: 'number', unit: null, completeness_required: true, required_missing_fields: ['missing_good_count']},
    {name: 'produced_quantity', label: '報工量', role: 'metric', data_type: 'number', unit: null, completeness_required: true, required_missing_fields: ['missing_good_count', 'missing_scrap_count']},
    {name: 'operation_count', label: '作業筆數', role: 'quality', data_type: 'number'},
];

function card(overrides: Partial<ReportCard> = {}): ReportCard {
    return {
        id: 'saved-semantic', kind: 'semantic_query', status: 'ok', semantic_fingerprint: 'fixture-mdl',
        semantic_columns: columns,
        metrics: [{key: 'good_quantity', value: 5000}],
        detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows: [
            {machine_id: 'SC01', personnel_group: 'A,B', production_date: '2026-07-01', good_quantity: 12, produced_quantity: 15, operation_count: 1, quantity_complete: true, missing_good_count: 0, missing_scrap_count: 0},
            {machine_id: 'SC02', personnel_group: 'A,C', production_date: '2026-07-02', good_quantity: 8, produced_quantity: 10, operation_count: 1, quantity_complete: true, missing_good_count: 0, missing_scrap_count: 0},
        ]}, ...overrides,
    };
}

test('多維圖表使用保存metadata首個核准指標與完整身分，摘要不替代本頁', () => {
    const saved = card(), before = JSON.stringify(saved), graph = reportChartData(saved)!;
    assert.equal(graph.measure, '良品量');
    assert.deepEqual(graph.points, [
        {label: 'SC01 · A,B · 2026-07-01', value: 12},
        {label: 'SC02 · A,C · 2026-07-02', value: 8},
    ]);
    assert.ok(graph.notices.some(notice => notice.includes('不拆分')));
    assert.equal(JSON.stringify(saved), before);
});

test('缺量完整指標不補零或借用已知部分；有效零保留', () => {
    const saved = card();
    saved.detail!.rows![0].quantity_complete = false;
    saved.detail!.rows![0].missing_good_count = 1;
    saved.detail!.rows![1].good_quantity = 0;
    const graph = reportChartData(saved)!;
    assert.deepEqual(graph.points, [{label: 'SC02 · A,C · 2026-07-02', value: 0}]);
    assert.match(graph.notices.join(' '), /未補零/);
});

test('不良缺值仍保留完整良品圖表，不誤標為已知部分', () => {
    const saved = card();
    saved.detail!.rows![0].quantity_complete = false;
    saved.detail!.rows![0].missing_scrap_count = 1;
    saved.detail!.rows![0].produced_quantity = null;
    const graph = reportChartData(saved)!;
    assert.equal(graph.points[0].value, 12);
    assert.doesNotMatch(graph.points[0].label, /已知部分/);
});

test('人員組合不拆分，已知分量與負數保留原義及原順序', () => {
    const known: SemanticReportColumn = {name: 'known_produced_quantity', label: '已知報工量', role: 'metric', data_type: 'number', interpretation: 'known_partial', completeness_required: false, required_missing_fields: []};
    const saved = card({semantic_columns: [...columns.filter(item => item.role === 'dimension'), known]});
    saved.detail!.columns!.push({key: known.name, label: known.label});
    saved.detail!.rows![0].known_produced_quantity = -2;
    saved.detail!.rows![1].known_produced_quantity = 5;
    const graph = reportChartData(saved)!;
    assert.deepEqual(graph.points.map(point => point.value), [-2, 5]);
    assert.match(graph.points[0].label, /A,B.*已知部分/);
    assert.match(graph.notices.join(' '), /負數/);
});

test('已知零數量必須來自有效作業，沒有作業的歷史零值不畫成產量', () => {
    const known: SemanticReportColumn = {name: 'known_produced_quantity', label: '已知報工量', role: 'metric', data_type: 'number', interpretation: 'known_partial', completeness_required: false, required_missing_fields: []};
    const saved = card({semantic_columns: [...columns.filter(item => item.role === 'dimension'), known]});
    saved.detail!.columns!.push({key: known.name, label: known.label});
    saved.detail!.rows![0].known_produced_quantity = 0;
    saved.detail!.rows![0].operation_count = 0;
    saved.detail!.rows![1].known_produced_quantity = 0;
    const before = JSON.stringify(saved);
    const graph = reportChartData(saved)!;
    assert.deepEqual(graph.points, [{label: 'SC02 · A,C · 2026-07-02（已知部分）', value: 0}]);
    assert.equal(JSON.stringify(saved), before);
});

test('欠缺維度不能以其他欄位或模型文字代替身分', () => {
    const saved = card({answer: 'SC01 產量一萬'});
    delete saved.detail!.rows![0].production_date;
    delete saved.detail!.rows![1].personnel_group;
    assert.equal(reportChartData(saved), null);
});

test('分頁保留結果順序、前八項與界線，不自行合併或加總', () => {
    const saved = card({pagination: {offset: 2, truncated: false}});
    const row = saved.detail!.rows![0];
    saved.detail!.rows = Array.from({length: 10}, (_, index) => ({...row, machine_id: `SC${index}`, good_quantity: index}));
    const graph = reportChartData(saved)!;
    assert.equal(graph.points.length, 8);
    assert.deepEqual(graph.points.map(point => point.value), [0, 1, 2, 3, 4, 5, 6, 7]);
    assert.match(graph.notices.join(' '), /分頁或截斷/);
});

test('未保存版本、欄位角色、重複欄位及未核准百分比都不猜圖表', () => {
    for (const saved of [
        card({semantic_fingerprint: undefined}),
        card({semantic_columns: [...columns, columns[0]]}),
        card({semantic_columns: [{name: 'completion_percent', label: '完成率', role: 'metric', data_type: 'number'}]}),
        card({semantic_columns: undefined}),
    ]) {
        assert.deepEqual(semanticReportColumns(saved), []);
        assert.equal(reportChartData(saved), null);
    }
});

test('只有品質計數或沒有維度時不自行選報工欄位', () => {
    assert.equal(reportChartData(card({semantic_columns: columns.filter(column => column.role !== 'metric')})), null);
    assert.equal(reportChartData(card({semantic_columns: columns.filter(column => column.role !== 'dimension')})), null);
});

test('只留查詢依據或無資料的結果不展開月份圖表', () => {
    assert.equal(reportChartData(card({presentation: 'evidence'})), null);
    assert.equal(reportChartData(card({status: 'no_data'})), null);
});

test('自動圖表涵蓋所有保存量，分組維持完整對象與每個指標的缺值', () => {
    const saved = card();
    saved.detail!.rows![0].missing_scrap_count = 1;
    const before = JSON.stringify(saved), panels = reportChartPanels(saved);
    assert.equal(panels.length, 1);
    assert.equal(panels[0].kind, 'bar');
    assert.deepEqual(panels[0].series.map(series => series.key), ['good_quantity', 'produced_quantity']);
    assert.deepEqual(panels[0].points, [
        {label: 'SC01 · A,B · 2026-07-01', values: {good_quantity: 12, produced_quantity: null}},
        {label: 'SC02 · A,C · 2026-07-02', values: {good_quantity: 8, produced_quantity: 10}},
    ]);
    assert.match(panels[0].notices.join(' '), /報工量有 1 筆/);
    assert.equal(JSON.stringify(saved), before);
});

test('完整量與已知量分組，品質計數不入圖，異單位及未知指標各自呈現', () => {
    const extra: SemanticReportColumn[] = [
        {name: 'known_good_quantity', label: '已知良品量', role: 'metric', data_type: 'number', interpretation: 'known_partial', completeness_required: false, required_missing_fields: []},
        {name: 'known_produced_quantity', label: '已知報工量', role: 'metric', data_type: 'number', interpretation: 'known_partial', completeness_required: false, required_missing_fields: []},
        {name: 'scrap_quantity', label: '不良重量', role: 'metric', data_type: 'number', unit: 'kg', completeness_required: true, required_missing_fields: ['missing_scrap_count']},
        {name: 'duration', label: '耗時', role: 'metric', data_type: 'number', unit: '秒'},
        {name: 'record_count', label: '紀錄數', role: 'metric', data_type: 'number'},
    ];
    const saved = card({semantic_columns: [...columns, ...extra]});
    saved.detail!.columns!.push(...extra.map(column => ({key: column.name, label: column.label})));
    for (const row of saved.detail!.rows!) Object.assign(row, {known_good_quantity: 5, known_produced_quantity: 7, scrap_quantity: 2, duration: 10, record_count: 1});
    const panels = reportChartPanels(saved);
    assert.deepEqual(panels.map(panel => panel.series.map(series => series.key)), [
        ['good_quantity', 'produced_quantity'], ['known_good_quantity', 'known_produced_quantity'], ['scrap_quantity'], ['duration'], ['record_count'],
    ]);
    assert.equal(panels[1].points[0].label, 'SC01 · A,B · 2026-07-01（已知部分）');
    assert.ok(panels[1].notices.some(notice => notice.includes('不能當成完整產量')));
});

function timeCard(values: unknown[], dimension: SemanticReportColumn = {name: 'production_date', label: '生產日', role: 'dimension', data_type: 'date'}): ReportCard {
    const savedColumns = [dimension, ...columns.filter(column => column.role !== 'dimension')];
    return card({semantic_columns: savedColumns, detail: {
        columns: savedColumns.map(column => ({key: column.name, label: column.label})),
        rows: values.map((value, index) => ({[dimension.name]: value, good_quantity: index + 2, produced_quantity: index + 3, operation_count: 1, missing_good_count: 0, missing_scrap_count: 0})),
    }});
}

test('唯一日期維度已升序才畫趨勢，各數列缺值保留同列斷點與真實零', () => {
    const saved = timeCard(['2026-07-01', '2026-07-02', '2026-07-03']);
    saved.detail!.rows![1].missing_scrap_count = 1;
    saved.detail!.rows![2].good_quantity = 0;
    const before = JSON.stringify(saved), panel = reportChartPanels(saved)[0];
    assert.equal(panel.kind, 'line');
    assert.deepEqual(panel.points.map(point => point.values), [
        {good_quantity: 2, produced_quantity: 3}, {good_quantity: 3, produced_quantity: null}, {good_quantity: 0, produced_quantity: 5},
    ]);
    assert.equal(JSON.stringify(saved), before);
});

test('日期亂序、重複、無效或缺少身分都不推測趨勢，也不重排資料', () => {
    for (const values of [
        ['2026-07-02', '2026-07-01'], ['2026-07-01', '2026-07-01'], ['2026-02-30', '2026-03-02'], ['2026-07-01', null], ['2026-07-01'],
    ]) {
        const saved = timeCard(values), before = JSON.stringify(saved);
        assert.equal(reportChartPanels(saved)[0].kind, 'bar');
        assert.equal(JSON.stringify(saved), before);
    }
    const saved = timeCard(['2026-07-01', '2026-07-02']);
    delete saved.detail!.rows![1].production_date;
    assert.equal(reportChartPanels(saved)[0].kind, 'bar');
    assert.equal(reportChartPanels(saved)[0].points.length, 1);
});

test('日期時間需明確時區並依實際時間核對順序，不使用執行環境時區', () => {
    const dimension: SemanticReportColumn = {name: 'reported_at', label: '報工時間', role: 'dimension', data_type: 'datetime'};
    for (const [values, expected] of [
        [['2026-07-01T08:00:00+08:00', '2026-07-01T01:00:00Z'], 'line'],
        [['2026-07-01T08:00:00', '2026-07-01T09:00:00'], 'bar'],
        [['2026-07-01T08:00:00+08:00', '2026-07-01T00:00:00Z'], 'bar'],
        [['2026-07-01T24:00:00Z', '2026-07-02T01:00:00Z'], 'bar'],
    ] as const) assert.equal(reportChartPanels(timeCard([...values], dimension))[0].kind, expected);
});

test('保存月份維度可畫趨勢，保留原順序前八項與逐欄限制', () => {
    const dimension: SemanticReportColumn = {name: 'production_month', label: '生產月', role: 'dimension', data_type: 'string'};
    const saved = timeCard(Array.from({length: 10}, (_, index) => `2026-${String(index + 1).padStart(2, '0')}`), dimension);
    saved.pagination = {has_more: true};
    saved.detail!.rows![0].missing_good_count = 1;
    saved.detail!.rows![0].missing_scrap_count = 1;
    const panel = reportChartPanels(saved)[0];
    assert.equal(panel.kind, 'line');
    assert.equal(panel.points.length, 8);
    assert.equal(panel.points[0].label, '2026-01');
    assert.deepEqual(panel.points[0].values, {good_quantity: null, produced_quantity: null});
    assert.ok(panel.notices.some(notice => notice.includes('共 10 項')));
    assert.ok(panel.notices.some(notice => notice.includes('分頁或截斷')));
});

test('無核准 metadata 或全部指標皆缺量時不自行生成圖表', () => {
    assert.deepEqual(reportChartPanels(card({semantic_fingerprint: undefined})), []);
    assert.deepEqual(reportChartPanels(card({presentation: 'evidence'})), []);
    assert.deepEqual(reportChartPanels(card({status: 'no_data'})), []);
    const saved = card();
    for (const row of saved.detail!.rows!) row.operation_count = 0;
    assert.deepEqual(reportChartPanels(saved), []);
});

test('首個指標全部缺值仍保留其他完整指標，不以首欄判斷整組是否可畫', () => {
    const saved = card();
    for (const row of saved.detail!.rows!) row.good_quantity = null;
    const panel = reportChartPanels(saved)[0];
    assert.deepEqual(panel.series.map(series => series.key), ['good_quantity', 'produced_quantity']);
    assert.deepEqual(panel.points.map(point => point.values), [
        {good_quantity: null, produced_quantity: 15}, {good_quantity: null, produced_quantity: 10},
    ]);
});

test('作業數與缺項契約不合法時不畫數量，不能用小數或未知缺項放行', () => {
    for (const operationCount of [0.5, -1, null, '1', true]) {
        const saved = card();
        for (const row of saved.detail!.rows!) row.operation_count = operationCount;
        assert.deepEqual(reportChartPanels(saved), []);
        assert.equal(reportChartData(saved), null);
    }
    for (const required of [undefined, [], ['missing_fake_count'], ['missing_good_count', 'missing_good_count']]) {
        const selected = {...columns[3], required_missing_fields: required};
        const saved = card({semantic_columns: [columns[0], selected]});
        for (const row of saved.detail!.rows!) row.missing_fake_count = 0;
        assert.deepEqual(reportChartPanels(saved), []);
        assert.equal(reportChartData(saved), null);
    }
    const saved = card({semantic_columns: [columns[0], {...columns[3], completeness_required: undefined}]});
    assert.deepEqual(reportChartPanels(saved), []);
});

test('可見前八項全未知就不畫空圖，不能把第九筆移到前面', () => {
    const saved = card();
    const row = saved.detail!.rows![0];
    saved.detail!.rows = Array.from({length: 9}, (_, index) => ({...row, machine_id: `SC${index}`, good_quantity: index === 8 ? 10 : null, produced_quantity: null}));
    const before = JSON.stringify(saved);
    assert.deepEqual(reportChartPanels(saved), []);
    assert.equal(JSON.stringify(saved), before);
    saved.detail!.rows![7].produced_quantity = 5;
    const panel = reportChartPanels(saved)[0];
    assert.equal(panel.points.length, 8);
    assert.equal(panel.points[7].values.produced_quantity, 5);
    assert.equal(panel.points.some(point => point.values.good_quantity !== null), false);
});

test('缺日與缺月保持長條，跨年及閏日連續資料才畫等距折線', () => {
    for (const dates of [['2026-07-01', '2026-07-04'], ['2026-07-01', '2026-07-03', '2026-07-05']]) {
        const saved = timeCard(dates), before = JSON.stringify(saved);
        assert.equal(reportChartPanels(saved)[0].kind, 'bar');
        assert.equal(JSON.stringify(saved), before);
    }
    for (const dates of [['2026-12-31', '2027-01-01'], ['2028-02-28', '2028-02-29', '2028-03-01']]) assert.equal(reportChartPanels(timeCard(dates))[0].kind, 'line');
    const month: SemanticReportColumn = {name: 'production_month', label: '生產月', role: 'dimension', data_type: 'string'};
    assert.equal(reportChartPanels(timeCard(['2026-07', '2026-09'], month))[0].kind, 'bar');
    assert.equal(reportChartPanels(timeCard(['2026-12', '2027-01', '2027-02'], month))[0].kind, 'line');
});

test('含時區時間按實際等間距判斷，不等間距不畫分類折線', () => {
    const dimension: SemanticReportColumn = {name: 'reported_at', label: '報工時間', role: 'dimension', data_type: 'datetime'};
    const irregular = timeCard(['2026-07-01T08:00:00+08:00', '2026-07-01T01:00:00Z', '2026-07-01T03:00:00Z'], dimension);
    assert.equal(reportChartPanels(irregular)[0].kind, 'bar');
    assert.equal(reportChartPanels(timeCard(['2026-07-01T08:00:00+08:00', '2026-07-01T01:00:00Z', '2026-07-01T02:00:00Z'], dimension))[0].kind, 'line');
});
