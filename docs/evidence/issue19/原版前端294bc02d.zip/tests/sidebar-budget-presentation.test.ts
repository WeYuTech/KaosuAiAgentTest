import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {sidebarBudgetSummary} from '../src/chat/sidebar-budget';
import type {BudgetSnapshot, BudgetUsage} from '../src/chat/operations';

// 呈現測試採產品的自動 JSX 設定，不為測試改寫產品或注入全域 React
const scoped = register({namespace: 'sidebar-budget-presentation', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {TooltipProvider} = await scoped.import('../src/components/ui/tooltip.tsx', import.meta.url) as typeof import('../src/components/ui/tooltip');
const {SidebarBudgetControl} = await scoped.import('../src/features/operations/SidebarBudget.tsx', import.meta.url) as typeof import('../src/features/operations/SidebarBudget');

function usage(scope: 'account' | 'system', limit: number | null): BudgetUsage {
    return {scope, ...(scope === 'account' ? {account_no: 'ADMINV2'} : {}), config: {monthly_token_limit: limit, warning_percent: 80, per_turn_reservation_tokens: 10000, revision: 0},
        confirmed_tokens: 72000, reserved_tokens: 10000, unknown_request_count: 0, active_request_count: 1, limit, reached: false, near_limit: false,
        remaining_tokens: limit === null ? null : limit - 82000, usage_status: 'known', committed_tokens: 82000, used_percent: limit === null ? null : 82};
}
function snapshot(accountLimit: number | null, systemLimit: number | null = null): BudgetSnapshot {
    return {period: '2026-10', timezone: 'Asia/Taipei', billing_note: '用量不是精確帳單', account: usage('account', accountLimit), system: usage('system', systemLimit), management: {write_allowed: false}};
}
type ControlProps = Parameters<typeof SidebarBudgetControl>[0];
function render(snapshotValue: BudgetSnapshot | null, options: Partial<ControlProps> = {}) {
    const summary = snapshotValue && sidebarBudgetSummary(snapshotValue);
    const limit = summary && snapshotValue?.[summary.scope].limit;
    const html = renderToStaticMarkup(createElement(TooltipProvider, null, createElement(SidebarBudgetControl, {
        summary, limitKind: limit === null ? 'unlimited' : limit === 0 ? 'zero' : 'configured', status: 'ready', expired: false, onOpen() {}, ...options,
    })));
    const button = html.match(/<button\b[\s\S]*?<\/button>/)![0];
    const visible = button.replace(/<svg\b[\s\S]*?<\/svg>/g, '').replace(/<[^>]+>/g, '').trim();
    return {html, button, visible};
}

test('額度摘要顯示名稱與百分比且不使用圖示，詳細範圍仍保留在輔助名稱', () => {
    const {html, button, visible} = render(snapshot(100000));
    assert.equal(visible, 'Token 用量82%'); assert.match(button, /aria-label="查看用量額度，目前帳號，2026-10，已確認 72,000 Token，預留 10,000 Token/);
    assert.match(button, /月上限 100,000/); assert.match(button, /不是精確帳單/); assert.match(html, /data-scope="account"/);
    assert.equal(html.includes('<svg'), false); assert.match(html, /data-slot="progress"/); assert.match(html, /h-1\.5/);
    assert.equal(button.includes('flex-col'), true); assert.equal(button.includes('bg-blue-'), false);
    assert.equal(render(snapshot(null, 100000)).visible, 'Token 用量82%'); assert.equal(render(snapshot(null, 100000)).html.includes('<svg'), false);
    assert.match(render(snapshot(null, 100000)).button, /aria-label="查看用量額度，整個系統/);
});

test('未設定上限明示未設上限並使用空中性軌，沒有假的零百分比', () => {
    const {html, button, visible} = render(snapshot(null));
    assert.equal(visible, 'Token 用量未設上限'); assert.equal(html.includes('<svg'), false); assert.match(button, /尚未設定月上限/);
    assert.equal(html.includes('aria-valuenow'), false); assert.match(html, /bg-muted/); assert.match(html, /progress-indicator[^\"]*\]?:hidden|progress-indicator\]\]:hidden/);
    assert.equal(button.match(/aria-label="([^"]*)"/)![1]!.includes('0%'), false);
});

test('零上限不是零使用率，讀取失敗／登入過期沒有舊數字，狀態可Tab查看Tooltip及原Dialog', () => {
    const zero = render(snapshot(0)); assert.equal(zero.visible, 'Token 用量額度為 0'); assert.equal(zero.html.includes('<svg'), false); assert.match(zero.button, /本月額度為 0/); assert.equal(zero.html.includes('aria-valuenow'), false);
    const failed = render(snapshot(100000), {status: 'unavailable'});
    assert.equal(failed.visible, 'Token 用量讀取失敗'); assert.equal(failed.html.includes('<svg'), false); assert.match(failed.button, /暫時無法讀取用量，不能當成零用量/); assert.equal(failed.html.includes('82%'), false);
    const expired = render(snapshot(100000), {expired: true});
    assert.equal(expired.visible, 'Token 用量登入逾時'); assert.equal(expired.html.includes('<svg'), false); assert.match(expired.button, /登入已逾時/);
    assert.equal(expired.button.includes('disabled='), false); assert.equal(expired.html.includes('82%'), false);
});

test('更新與未知用短文字說明，系統上限警告保留語意色與完整輔助名稱', () => {
    const loading = render(null, {status: 'loading'}); assert.equal(loading.visible, 'Token 用量更新中'); assert.equal(loading.html.includes('<svg'), false);
    assert.match(loading.button, /aria-busy="true"/); assert.match(loading.button, /正在讀取用量/);
    const data = snapshot(100000, 100000); data.account.usage_status = 'mixed'; data.account.unknown_request_count = 1;
    const unknown = render(data); assert.equal(unknown.visible, 'Token 用量82% · 待確認'); assert.equal(unknown.html.includes('<svg'), false); assert.match(unknown.button, /含 1 筆待確認用量/);
    data.system.reached = true;
    const reached = render(data); assert.equal(reached.visible, 'Token 用量82% · 待確認'); assert.match(reached.html, /text-destructive/); assert.match(reached.button, /系統額度已達上限/); assert.match(reached.button, /待確認用量/);
});
