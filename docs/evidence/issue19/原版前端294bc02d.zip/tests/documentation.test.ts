import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {DocumentMarkdown} from '../src/components/ui/document-markdown';
import {headingSlug} from '../src/lib/markdown-headings';
import {chooseDocument, documentHref, filterDocuments, parseDocumentCatalog, resolveDocumentLink, verifyDocumentBytes} from '../src/features/documentation/catalog';
import type {DocumentEntry} from '../src/features/documentation/catalog';

const sha256 = createHash('sha256').update('# 工程文件\n').digest('hex');
const example: DocumentEntry = {id: 'capabilities', title: '目前能力與接口', summary: '查詢工具與 API', source: 'docs/Emerald_目前能力與接口.md', asset: `capabilities-${sha256.slice(0, 12)}.md`, bytes: Buffer.byteLength('# 工程文件\n'), sha256};
const oee: DocumentEntry = {...example, id: 'oee', title: 'OEE 資料分析', source: 'docs/Emerald_OEE資料分析與接口.md', asset: `oee-${sha256.slice(0, 12)}.md`};
const entries = [example, oee];

test('文件頁只發布六份現行核心文件，歷史原稿與帳本不混入目錄', () => {
    const require = createRequire(import.meta.url);
    const {createCatalog} = require('../scripts/generate-documentation.cjs');
    const catalog: DocumentEntry[] = createCatalog();
    assert.deepEqual(catalog.map(document => document.id), ['capabilities', 'deployment', 'architecture', 'conversation', 'semantics', 'overview']);
    assert.equal(catalog[0].source, 'docs/Emerald_目前能力與接口.md');
    assert.ok(catalog.every(document => document.source.startsWith('docs/')));
    assert.ok(!catalog.some(document => /archive|outputs|帳本|appsettings|驗證報告|校對報告/.test(document.source)));
});

test('文件 query 僅選取索引，未知與 traversal 不退回其他內容', () => {
    assert.equal(chooseDocument(entries, null), example);
    assert.equal(chooseDocument(entries, 'oee'), oee);
    assert.equal(chooseDocument(entries, 'Emerald_OEE資料分析與接口.md'), oee);
    for (const value of ['../appsettings.local.json', 'https://example.com/secret.md', 'unknown']) assert.equal(chooseDocument(entries, value), undefined);
});
test('索引拒絕外部或路徑資產、重複 ID、超大資產與不符雜湊', () => {
    assert.deepEqual(parseDocumentCatalog({version: 1, documents: entries}).documents, entries);
    for (const changed of [{asset: '../secret.md'}, {asset: 'https://example.com/x.md'}, {source: 'docs/../appsettings.md'}, {bytes: 3 * 1024 * 1024}, {sha256: '0'.repeat(64)}]) {
        assert.throws(() => parseDocumentCatalog({version: 1, documents: [{...example, ...changed}]}));
    }
    assert.throws(() => parseDocumentCatalog({version: 1, documents: [example, example]}));
});
test('名稱搜尋不修改文件清單，深連結保留預覽網址參數', () => {
    assert.deepEqual(filterDocuments(entries, 'OEE'), [oee]);
    assert.deepEqual(filterDocuments(entries, '不存在'), []);
    assert.equal(documentHref('http://127.0.0.1:4173/docs?apiBaseUrl=x&file=old', 'oee'), '/docs?apiBaseUrl=x&file=oee');
});
test('相對 Markdown 連結切換已公開文件，工程來源連向既定 GitHub', () => {
    assert.deepEqual(resolveDocumentLink('Emerald_OEE資料分析與接口.md#公式', example.source, entries), {kind: 'document', id: 'oee', hash: '#%E5%85%AC%E5%BC%8F'});
    assert.deepEqual(resolveDocumentLink('#公式', example.source, entries), {kind: 'anchor', hash: '#公式'});
    const source = resolveDocumentLink('../app/main.py', example.source, entries);
    assert.equal(source.kind, 'external');
    assert.equal(source.kind === 'external' && source.href, 'https://github.com/WeYuTech/WeYu-MesAiAgent/blob/Emerald/app/main.py');
});
test('危險 URL、本機檔、憑證 URL 與未公開輸出不可點擊', () => {
    for (const url of ['javascript:alert(1)', 'data:text/html,test', 'file:///C:/secret', 'C:/secret', '//attacker.test/a', 'https://user:password@example.com', '../app/appsettings.local.json', '../outputs/private.md', '../../app/main.py', 'x%5csecret.md']) {
        assert.deepEqual(resolveDocumentLink(url, example.source, entries), {kind: 'blocked'});
    }
    assert.deepEqual(resolveDocumentLink('https://example.com/docs', example.source, entries), {kind: 'external', href: 'https://example.com/docs'});
});
test('共用文件 Markdown 保留 GFM 表格、程式碼與標題錨點，HTML 與遠端圖片不執行', () => {
    assert.equal(headingSlug('OEE 計算公式！'), 'oee-計算公式');
    const html = renderToStaticMarkup(createElement(DocumentMarkdown, {
        text: '# OEE 計算公式\n\n# OEE 計算公式\n\n| 指標 | 說明 |\n| --- | --- |\n| OEE | A × P × Q |\n\n```sql\nSELECT 1\n```\n\n<script>alert(1)</script>\n\n![外部圖片](https://example.com/track.png)',
        link: ({children}) => createElement('span', null, children),
    }));
    assert.ok(html.includes('id="oee-計算公式"'));
    assert.ok(html.includes('id="oee-計算公式-1"'));
    assert.ok(html.includes('data-slot="table"'));
    assert.ok(html.includes('SELECT 1'));
    assert.ok(!html.includes('<script'));
    assert.ok(!html.includes('<img'));
});
test('lazy 文件資產核對完整 SHA，SPA fallback 或舊快取不當成文件', async () => {
    const buffer = new TextEncoder().encode('# 工程文件\n').buffer;
    assert.equal(await verifyDocumentBytes(buffer, example), '# 工程文件\n');
    await assert.rejects(() => verifyDocumentBytes(new TextEncoder().encode('舊文件').buffer, example));
    await assert.rejects(() => verifyDocumentBytes(buffer, {...example, sha256: '0'.repeat(64)}));
});
