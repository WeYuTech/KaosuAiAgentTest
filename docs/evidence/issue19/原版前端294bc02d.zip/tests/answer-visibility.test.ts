import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {TRACE_VERSION} from '../src/chat/execution-trace';
import type {ChatActions, ChatState, Message, Mode} from '../src/chat/types';

const scoped = register({namespace: 'answer-visibility', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {ThreadPrimitive, MessagePrimitive, ErrorPrimitive} = await scoped.import('@assistant-ui/react', import.meta.url) as typeof import('@assistant-ui/react');
const {MesAssistantProvider} = await scoped.import('../src/chat/assistant-runtime.tsx', import.meta.url) as typeof import('../src/chat/assistant-runtime');
const {MesUiProvider} = await scoped.import('../src/chat/mes-ui-context.tsx', import.meta.url) as typeof import('../src/chat/mes-ui-context');
const {MesAnalysisMessage} = await scoped.import('../src/features/mes/MesAnalysisMessage.tsx', import.meta.url) as typeof import('../src/features/mes/MesAnalysisMessage');
const {MesMessageExtras} = await scoped.import('../src/features/mes/MesMessageExtras.tsx', import.meta.url) as typeof import('../src/features/mes/MesMessageExtras');
const {ChatExecutionStatus} = await scoped.import('../src/features/common/ChatExecutionStatus.tsx', import.meta.url) as typeof import('../src/features/common/ChatExecutionStatus');

function state(message: Message, mode: Mode): ChatState {
    return {
        enabled: true, opened: true, expanded: false, historyOpen: false, view: 'chat',
        runtime: {mode, continuous_context: mode === 'AGENT'}, conversationId: 'c1', conversationTitle: '可見性測試', conversation: null, conversations: [],
        historyCursor: null, historyLoading: false, historyLoaded: true, historyStatus: '', historyArchived: false, conversationSaving: [],
        messages: [message], activeTurn: message, displayMessages: [message], draft: '', submitting: false, cancelling: false,
        connectionStatus: '', sessionNotice: '', expired: false, readOnly: false, readOnlyNotice: '', hint: '', sendDisabled: true, inputDisabled: false,
        showStop: message.execution_state === 'running', unknownSubmission: false, reconnectNeeded: false,
        reports: {}, exporting: [], feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null,
    };
}
function MessageContent() {
    return createElement(MessagePrimitive.Root, null, createElement(MesAnalysisMessage, null,
        createElement('p', null, '已驗證答案必須立即可讀'), createElement(MesMessageExtras),
        createElement(MessagePrimitive.Error, null, createElement(ErrorPrimitive.Root, null, createElement(ErrorPrimitive.Message)))));
}
function render(message: Message, mode: Mode, overrides: Partial<ChatState> = {}) {
    const props = {state: {...state(message, mode), ...overrides}, actions: {} as ChatActions};
    return renderToStaticMarkup(createElement(MesUiProvider, props,
        createElement(MesAssistantProvider, props, createElement(ThreadPrimitive.Root, null,
            createElement(ThreadPrimitive.Messages, {components: {Message: MessageContent}}), createElement(ChatExecutionStatus)))));
}
function message(overrides: Partial<Message> = {}): Message {
    return {role: 'assistant', request_id: 'r1', conversation_id: 'c1', content: '已驗證答案', answer: '已驗證答案',
        execution_state: 'running', status: 'started', audit_status: 'unavailable',
        execution_trace_version: TRACE_VERSION, execution_trace: [{id: 'tool:one', stage: 'querying', source: 'tool_start', status: 'running',
            observed_at: '2026-10-12T00:00:00Z', tool_name: 'get_machine_production_summary'}], ...overrides};
}

test('服務狀態失敗原因顯示一次並提供重新連線，沒有假生成進度', () => {
    const reason = '服務狀態暫時不可讀，請重新連線';
    const html = render(message({execution_state: 'completed', status: 'succeeded'}), 'API', {runtime: null, connectionStatus: reason});
    assert.equal(html.split(reason).length - 1, 1);
    assert.match(html, /重新連線<\/button>/);
    assert.equal(html.includes('mes-chat-spinner'), false);
});

for (const mode of ['API', 'AGENT'] as const) {
    test(`${mode} 回合未結束時答案也可見，面板預設收合且不顯示第二個載入列`, () => {
        const html = render(message(), mode);
        assert.match(html, /已驗證答案必須立即可讀/);
        assert.match(html, /data-presentation="ready"/);
        assert.match(html, /aria-expanded="false"/);
        assert.equal(html.includes('mes-chat-spinner'), false);
        assert.equal(html.includes('未提供紀錄'), false);
    });
    test(`${mode} 最終資料不足與保存失敗不被精簡活動隱藏`, () => {
        const html = render(message({execution_state: 'completed', status: 'insufficient_data'}), mode);
        assert.match(html, /部分資料不足/);
        assert.match(html, /稽核紀錄暫時未能保存/);
    });
    test(`${mode} 取消、失敗、歷史與觀看中斷不隱藏答案或錯誤`, () => {
        for (const execution_state of ['cancelled', 'failed', 'completed'] as const) {
            const html = render(message({execution_state, error_message: '保留原始可公開錯誤'}), mode, {reconnectNeeded: true});
            assert.match(html, /已驗證答案必須立即可讀/);
            assert.match(html, /保留原始可公開錯誤/);
            assert.equal(html.includes('animate-spin'), false);
        }
    });
}
