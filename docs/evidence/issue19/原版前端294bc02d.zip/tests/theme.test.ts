import test from 'node:test';
import assert from 'node:assert/strict';
import { isChatTheme, persistTheme, readStoredTheme, themeStorageKey } from '../src/features/preferences/theme';
import type { ThemeStorage } from '../src/features/preferences/theme';

test('主題按專案與帳號隔離，分隔字元不造成儲存鍵碰撞', () => {
    assert.notEqual(themeStorageKey('Emerald', 'ADMINV2'), themeStorageKey('Kaosu', 'ADMINV2'));
    assert.notEqual(themeStorageKey('Emerald', 'ADMINV2'), themeStorageKey('Emerald', 'STAFF01'));
    assert.notEqual(themeStorageKey('A:B', 'C'), themeStorageKey('A', 'B:C'));
    assert.equal(themeStorageKey(' Emerald ', ' adminv2 '), themeStorageKey('Emerald', 'ADMINV2'));
});

test('主題僅接受明亮、黑暗、深藍；損毀或舊設定回到明亮', () => {
    for (const value of ['light', 'dark', 'navy']) {
        assert.equal(isChatTheme(value), true);
        assert.equal(readStoredTheme({ getItem: () => value, setItem() {} }, 'theme'), value);
    }
    for (const value of [null, '', 'system', 'LIGHT', '{"theme":"dark"}']) {
        assert.equal(isChatTheme(value), false);
        assert.equal(readStoredTheme({ getItem: () => value, setItem() {} }, 'theme'), 'light');
    }
});

test('localStorage 讀寫被拒時不拋錯，讀取預設明亮', () => {
    const blocked: ThemeStorage = { getItem() { throw new Error('儲存被拒'); }, setItem() { throw new Error('儲存被拒'); } };
    assert.equal(readStoredTheme(blocked, 'theme'), 'light');
    assert.equal(persistTheme(blocked, 'theme', 'navy'), false);
});

test('持久化只寫所屬專案帳號的主題值，不存其他資訊', () => {
    const writes: Array<[string, string]> = [];
    const storage: ThemeStorage = { getItem: () => null, setItem: (key, value) => { writes.push([key, value]); } };
    const key = themeStorageKey('Emerald', 'ADMINV2');
    assert.equal(persistTheme(storage, key, 'dark'), true);
    assert.deepEqual(writes, [[key, 'dark']]);
});

test('缺少專案或帳號時不讀寫共用匿名偏好', () => {
    let reads = 0, writes = 0;
    const storage: ThemeStorage = { getItem: () => { reads++; return 'dark'; }, setItem() { writes++; } };
    assert.equal(themeStorageKey('', 'ADMINV2'), null);
    assert.equal(themeStorageKey('Emerald', ''), null);
    assert.equal(readStoredTheme(storage, null), 'light');
    assert.equal(persistTheme(storage, null, 'navy'), false);
    assert.equal(reads, 0); assert.equal(writes, 0);
});
