import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {decodeReportCard} from '../src/chat/report-decoder';
import {planSavedCharts} from '../src/chat/chart-planner';

function card(rows: Record<string, unknown>[], columns: Record<string, unknown>[], intent = 'auto', metrics: string[] = []) {
    return decodeReportCard({id: 'saved', kind: '任意工具名稱', source_call_id: 'call-a', status: 'ok',
        chart_metadata: {version: 'mes-chart-metadata-v1', fingerprint: 'saved-version', columns},
        chart_preference: {call_id: 'call-a', intent, metrics}, detail: {columns: columns.map(column => ({key: column.name})), rows}}, 2);
}
const dimension = {name: 'subject', label: '保存對象', role: 'dimension', data_type: 'string'};
const metric = {name: 'reading', label: '保存數值', role: 'metric', data_type: 'number', unit: '公斤'};
const scoped = register({namespace: 'new-answer-chart', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {MesReportChart} = await scoped.import('../src/features/mes/MesReportChart.tsx', import.meta.url) as typeof import('../src/features/mes/MesReportChart');

test('新固定工具沒有模型選指標仍進入自動選型；單一值直接呈現數值', () => {
    const saved = card([{subject: '甲', reading: 0}], [dimension, metric]);
    assert.equal(saved.chart_model, 'semantic');
    assert.equal(planSavedCharts(saved).recommended[0].mark, 'value');
    assert.equal(planSavedCharts(saved).recommended[0].points[0].values.reading, 0);
});

test('單一對象的已保存目標關係選達成圖，超標不截成100%，改名及欄位順序不影響', () => {
    const columns = [dimension, {...metric, target_field: 'goal'}, {name: 'goal', label: '目標', role: 'quality', data_type: 'number', unit: '公斤'}];
    const saved = card([{subject: '甲', reading: 130990, goal: 130000}], columns);
    const plan = planSavedCharts(saved);
    assert.equal(plan.recommended[0].mark, 'bullet');
    assert.equal(plan.recommended[0].points[0].values.goal, 130000);
    const renamed = card([{subject: '甲', actual: 130990, expected: 130000}], [columns[2], columns[1], columns[0]].map(column =>
        column.name === 'goal' ? {...column, name: 'expected'} : column.name === 'reading' ? {...column, name: 'actual', target_field: 'expected'} : column));
    assert.equal(planSavedCharts(renamed).recommended[0].mark, 'bullet');
    assert.equal(planSavedCharts(renamed).recommended[0].points[0].values.actual, 130990);
});

test('時間連續選折線，分類比較選長條，關係配對遵照本來源偏好', () => {
    const rows = [{subject: '2026-06', reading: 1, other: 9}, {subject: '2026-07', reading: 2, other: 8}];
    assert.equal(planSavedCharts(card(rows, [{...dimension, temporal_grain: 'month'}, metric])).recommended[0].mark, 'line');
    assert.equal(planSavedCharts(card(rows, [dimension, metric])).recommended[0].mark, 'bar');
    const relation = card(rows, [dimension, metric, {...metric, name: 'other'}], 'relationship', ['other', 'reading']);
    assert.equal(planSavedCharts(relation).recommended[0].mark, 'scatter');
    assert.equal(planSavedCharts(relation).recommended[0].encoding.x, 'other');
});

test('目標缺值、非正值、單位不同與完整性不足均不能產生達成圖', () => {
    for (const goal of [null, 0, -1, '100', true]) {
        const plan = planSavedCharts(card([{subject: '甲', reading: 1, goal}], [dimension, {...metric, target_field: 'goal'}, {name: 'goal', label: '目標', role: 'quality', data_type: 'number', unit: '公斤'}]));
        assert.ok(![...plan.recommended, ...plan.alternatives].some(spec => spec.mark === 'bullet'));
    }
    const incomplete = card([{subject: '甲', reading: 8, goal: 10, complete: false}], [dimension,
        {...metric, target_field: 'goal', value_guards: [{field: 'complete', operator: 'eq', value: true}]},
        {name: 'goal', label: '目標', role: 'quality', data_type: 'number', unit: '公斤'}]);
    assert.equal(planSavedCharts(incomplete).recommended.length, 0);
    assert.equal(planSavedCharts(incomplete).fallback, 'table');
    const wrongUnits = card([{subject: '甲', reading: 8, goal: 10}], [dimension, {...metric, target_field: 'goal'}, {name: 'goal', label: '目標', role: 'quality', data_type: 'number', unit: '秒'}]);
    assert.equal(wrongUnits.chart_contract, 'unavailable');
});

test('未核准尺度與沒有可畫指標時提供保存表格，不硬畫長條', () => {
    const saved = card([{subject: '甲', reading: -1}], [dimension, {...metric, role: 'quality', interpretation: 'unverified_scale'}]);
    const plan = planSavedCharts(saved);
    assert.equal(plan.recommended.length, 0);
    assert.equal(plan.fallback, 'table');
});

test('未知版本或壞單卡不降級成舊長條圖', () => {
    const saved = decodeReportCard({id: 'bad', kind: 'work_order', source_call_id: 'a', chart_metadata: {version: 'v99', columns: []}}, 2);
    assert.equal(saved.chart_contract, 'unavailable');
});

test('預設不畫品質計數，問題明確選擇已核准計數時才呈現；原值尺度未核准仍保留表格', () => {
    const rows = [{subject: '甲', reading: 8, samples: 1}];
    const columns = [dimension, metric, {name: 'samples', label: '筆數', role: 'quality', data_type: 'number', interpretation: 'count'}];
    assert.deepEqual(planSavedCharts(card(rows, columns)).recommended[0].encoding.series, ['reading']);
    assert.deepEqual(planSavedCharts(card(rows, columns, 'auto', ['samples'])).recommended[0].encoding.series, ['samples']);
    const raw = card(rows, [dimension, {...metric, role: 'quality', interpretation: 'unverified_scale'}], 'auto', ['reading']);
    assert.equal(raw.chart_model, 'semantic');
    assert.equal(planSavedCharts(raw).fallback, 'table');
});

test('沒有保存新契約的歷史固定卡仍保持舊版口徑', () => {
    const saved = decodeReportCard({id: 'old', kind: 'machine_production', source_call_id: 'a', detail: {rows: [{machine_id: '甲', produced_quantity: 12}]}}, 2);
    assert.equal(saved.chart_model, 'legacy');
    assert.equal(planSavedCharts(saved).recommended[0].mark, 'bar');
});

test('實際元件分別呈現數值、目標達成及原值表格，缺值不補零', () => {
    const single = card([{subject: '甲', reading: 0}], [dimension, metric]);
    const valueHtml = renderToStaticMarkup(createElement(MesReportChart, {card: single}));
    assert.match(valueHtml, /data-chart-kind="value"/);
    assert.match(valueHtml, /data-slot="mes-report-values"/);
    assert.match(valueHtml, /0.*公斤/);
    const target = card([{subject: '甲', reading: 101, goal: 100}], [dimension, {...metric, target_field: 'goal'}, {name: 'goal', label: '目標', role: 'quality', data_type: 'number', unit: '公斤'}]);
    const targetHtml = renderToStaticMarkup(createElement(MesReportChart, {card: target}));
    assert.match(targetHtml, /data-chart-kind="bullet"/);
    assert.match(targetHtml, /101/);
    assert.match(targetHtml, /100/);
    const unknown = card([{subject: '甲', reading: null}], [dimension, {...metric, role: 'quality'}]);
    const tableHtml = renderToStaticMarkup(createElement(MesReportChart, {card: unknown}));
    assert.match(tableHtml, /data-slot="mes-report-auto-table"/);
    assert.match(tableHtml, /未知/);
    assert.doesNotMatch(tableHtml, /data-chart-kind="bar"/);
});

test('保存的呈現偏好在重建元件時恢復，表格與返回自動不改保存原值', () => {
    const saved = card([{subject: '甲', reading: 8}, {subject: '乙', reading: 0}], [dimension, metric]);
    const before = structuredClone(saved);
    const render = (selection: {mark: 'point' | 'table'; metrics: string[]} | null) => renderToStaticMarkup(createElement(MesReportChart, {card: saved, selection}));
    const point = {mark: 'point' as const, metrics: ['reading']};
    assert.match(render(point), /data-chart-kind="point"/);
    assert.match(render(JSON.parse(JSON.stringify(point))), /data-chart-kind="point"/);
    const tableHtml = render({mark: 'table', metrics: []});
    assert.match(tableHtml, /data-slot="mes-report-auto-table"/);
    assert.doesNotMatch(tableHtml, /data-chart-kind/);
    assert.match(tableHtml, />0</);
    assert.match(render(null), /data-chart-kind="bar"/);
    assert.deepEqual(saved, before);
});

test('已保存但不合法的圖型或欄位回到自動，不能以保存偏好繞過資料核對', () => {
    const saved = card([{subject: '甲', reading: 8}, {subject: '乙', reading: 0}], [dimension, metric]);
    for (const selection of [{mark: 'line' as const, metrics: ['reading']}, {mark: 'point' as const, metrics: ['unknown']}, {mark: 'table' as const, metrics: ['unknown']}]) {
        const html = renderToStaticMarkup(createElement(MesReportChart, {card: saved, selection}));
        assert.match(html, /已保存的呈現方式不適用/);
        assert.match(html, /data-chart-kind="bar"/);
    }
});

test('唯讀或保存中的受控切換不可再次送出，但不禁止舊元件的本地檢視', () => {
    const saved = card([{subject: '甲', reading: 8}], [dimension, metric]);
    for (const props of [{editable: false}, {saving: true}]) {
        const html = renderToStaticMarkup(createElement(MesReportChart, {card: saved, onSelectionChange: () => undefined, ...props}));
        assert.match(html, /role="combobox"[^>]* disabled=""/);
    }
    const local = renderToStaticMarkup(createElement(MesReportChart, {card: saved, editable: false}));
    assert.doesNotMatch(local, /role="combobox"[^>]* disabled=""/);
});

test('純呈現回合的圖型與表格切換只能使用原回答可見儲存格', () => {
    const saved = card([{subject: '甲', reading: 8, hidden: 98765}, {subject: '乙', reading: 0, hidden: 54321}, {subject: '丙', reading: 12345, hidden: 23456}], [dimension, metric, {...metric, name: 'hidden'}]);
    saved.binding_chart_input = saved.chart_input;
    saved.binding_table = {columns: [{key: 'subject', label: '對象'}, {key: 'metric', label: '指標'}, {key: 'value', label: '保存值'}], rows: [{subject: '甲', metric: '保存數值', value: '8'}, {subject: '乙', metric: '保存數值', value: '0'}]};
    saved.binding_selection = {metrics: ['reading'], row_indices: [0, 1], cells: [{row_index: 0, metric: 'reading'}, {row_index: 1, metric: 'reading'}], row_subjects: [{row_index: 0, label: '甲'}, {row_index: 1, label: '乙'}]};
    for (const mode of ['chart', 'table'] as const) {
        const presentation = {version: 'answer-presentation-v1' as const, mode, preferred_chart_kind: 'bar' as const};
        for (const selection of [{mark: 'point' as const, metrics: ['reading']}, {mark: 'table' as const, metrics: []}]) {
            const html = renderToStaticMarkup(createElement(MesReportChart, {card: saved, presentation, selection}));
            assert.doesNotMatch(html, /98765|54321|12345|23456/);
            assert.match(html, selection.mark === 'point' ? /data-chart-kind="point"/ : /data-slot="mes-report-auto-table"/);
        }
        const automatic = renderToStaticMarkup(createElement(MesReportChart, {card: saved, presentation}));
        assert.match(automatic, mode === 'chart' ? /data-chart-kind="bar"/ : /data-slot="mes-report-auto-table"/);
    }
});

test('保存值表格沿用數值可用性與完整性核對，不把缺值的已知部分冒充完整量', () => {
    const saved = card([{subject: '甲', reading: 98765, count: 1, missing: 1}, {subject: '乙', reading: 0, count: 1, missing: 0}], [dimension,
        {...metric, completeness_required: true, required_missing_fields: ['missing'], availability_count_field: 'count', interpretation: 'complete'},
        {name: 'count', label: '資料筆數', role: 'quality', data_type: 'number'}, {name: 'missing', label: '缺值數', role: 'quality', data_type: 'number'}]);
    const html = renderToStaticMarkup(createElement(MesReportChart, {card: saved, selection: {mark: 'table', metrics: []}}));
    assert.match(html, /未知/);
    assert.doesNotMatch(html, /98765/);
    assert.match(html, />0</);
    assert.equal(saved.detail!.rows![0].reading, 98765);
});

test('時間點圖元件使用時間軸，分類點圖仍用原分類軸', () => {
    const rows = [{subject: '2026-07-01', reading: 1}, {subject: '2026-07-08', reading: 2}, {subject: '2026-07-09', reading: 3}];
    const temporal = card(rows, [{...dimension, temporal_grain: 'day'}, metric]);
    const html = renderToStaticMarkup(createElement(MesReportChart, {card: temporal}));
    assert.match(html, /data-chart-kind="point"/);
    assert.match(html, /data-axis-kind="time"/);
    assert.match(html, /依保存時間位置/);
    const category = renderToStaticMarkup(createElement(MesReportChart, {card: card(rows, [dimension, metric]), selection: {mark: 'point', metrics: ['reading']}}));
    assert.match(category, /data-axis-kind="category"/);
});
