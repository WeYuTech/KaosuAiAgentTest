import test from 'node:test';
import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {Progress} from '../src/components/ui/progress';
import {ChatController} from '../src/chat/controller';
import {ChatApiError} from '../src/chat/api';
import {sidebarBudgetSummary, SidebarBudgetRefresh} from '../src/chat/sidebar-budget';
import type {BudgetSnapshot, BudgetUsage} from '../src/chat/operations';
import type {Turn} from '../src/chat/types';

function usage(scope: 'account' | 'system', limit: number | null = null): BudgetUsage {
    return {scope, ...(scope === 'account' ? {account_no: 'ADMINV2'} : {}), config: {monthly_token_limit: limit, warning_percent: 80, per_turn_reservation_tokens: 10000, revision: 0},
        confirmed_tokens: 72000, reserved_tokens: 10000, unknown_request_count: 0, active_request_count: 1, limit, reached: false, near_limit: true,
        remaining_tokens: limit === null ? null : limit - 82000, usage_status: 'known', committed_tokens: 82000, used_percent: limit === null ? null : 82};
}
function budget(accountLimit: number | null = null, systemLimit: number | null = null): BudgetSnapshot {
    return {period: '2026-10', timezone: 'Asia/Taipei', billing_note: '用量紀錄不是精確帳單', account: usage('account', accountLimit), system: usage('system', systemLimit), management: {write_allowed: false}};
}

test('側欄明確優先目前帳號，不拿系統更低的剩餘量混成帳號數字', () => {
    const snapshot = budget(100000, 50000); snapshot.system.confirmed_tokens = 10000; snapshot.system.reserved_tokens = 0;
    const view = sidebarBudgetSummary(snapshot);
    assert.equal(view.scope, 'account'); assert.equal(view.scopeLabel, '目前帳號');
    assert.equal(view.confirmedText, '72,000'); assert.equal(view.reservedText, '10,000'); assert.equal(view.percentage, 82);
    assert.match(view.accessibleText, /月上限 100,000/); assert.match(view.accessibleText, /不是精確帳單/);
});

test('帳號未設定上限才改用系統，明確標示整個系統而不相加', () => {
    const snapshot = budget(null, 200000); snapshot.system.confirmed_tokens = 150000; snapshot.system.reserved_tokens = 5000;
    const view = sidebarBudgetSummary(snapshot);
    assert.equal(view.scope, 'system'); assert.equal(view.scopeLabel, '整個系統'); assert.equal(view.percentage, 77.5);
    assert.equal(view.confirmedText, '150,000'); assert.equal(view.reservedText, '5,000');
    assert.equal(sidebarBudgetSummary(budget(0, 200000)).scope, 'account');
});

test('兩個上限皆未設定時保留已確認／預留及未知提醒，沒有假零百分比', () => {
    const snapshot = budget(); snapshot.account.usage_status = 'mixed'; snapshot.account.unknown_request_count = 2;
    const view = sidebarBudgetSummary(snapshot);
    assert.equal(view.scope, 'account'); assert.equal(view.percentage, null); assert.equal(view.percentageText, '');
    assert.equal(view.limitText, '尚未設定月上限'); assert.match(view.note, /含 2 筆待確認用量/);
    assert.equal(view.confirmedText, '72,000'); assert.equal(view.reservedText, '10,000'); assert.equal(view.accessibleText.includes('%'), false);
});

test('帳號比例獨立保留，系統上限另行提醒並併列未知用量，不誤認仍可提問', () => {
    const snapshot = budget(100000, 100000); snapshot.account.confirmed_tokens = 10000; snapshot.account.reserved_tokens = 10000;
    snapshot.account.near_limit = false; snapshot.account.usage_status = 'mixed'; snapshot.account.unknown_request_count = 1;
    snapshot.system.reached = true;
    const reached = sidebarBudgetSummary(snapshot);
    assert.equal(reached.scope, 'account'); assert.equal(reached.percentage, 20); assert.equal(reached.warning, true);
    assert.match(reached.note, /系統額度已達上限/); assert.match(reached.note, /待確認用量/); assert.equal(reached.reached, false);
    snapshot.system.reached = false; assert.match(sidebarBudgetSummary(snapshot).note, /系統額度接近上限/);
});

test('額度進度只算已確認加預留，不以used_percent或其他累計冒充，未知不當零', () => {
    const snapshot = budget(100000); snapshot.account.used_percent = 5; snapshot.account.committed_tokens = 5;
    snapshot.account.usage_status = 'unknown'; snapshot.account.unknown_request_count = 1;
    const view = sidebarBudgetSummary(snapshot);
    assert.equal(view.percentage, 82); assert.equal(view.percentageText, '82%'); assert.match(view.note, /待確認/);
    const invalid = structuredClone(snapshot); invalid.account.confirmed_tokens = null as unknown as number;
    assert.equal(sidebarBudgetSummary(invalid).percentage, null); assert.equal(sidebarBudgetSummary(invalid).confirmedText, '尚未取得');
});

test('零上限不除零，超額只限制視覺滿度，已知零與缺值不同', () => {
    const zero = sidebarBudgetSummary(budget(0)); assert.equal(zero.percentage, null); assert.equal(zero.limitText, '本月額度為 0'); assert.equal(zero.percentageText, '');
    const snapshot = budget(100000); snapshot.account.confirmed_tokens = 115000;
    assert.equal(sidebarBudgetSummary(snapshot).percentage, 100); assert.equal(sidebarBudgetSummary(snapshot).percentageText, '125%');
    snapshot.account.confirmed_tokens = 0; snapshot.account.reserved_tokens = 0;
    assert.equal(sidebarBudgetSummary(snapshot).percentage, 0); assert.equal(sidebarBudgetSummary(snapshot).percentageText, '0%');
});

const visible = {opened: true, expired: false, submitting: false, activeTurn: null as Turn | null, visible: true, editingBudget: false};
test('側欄第一次顯示讀一次，縮放尺寸不重讀，收合後重開才刷新', () => {
    const refresh = new SidebarBudgetRefresh();
    assert.equal(refresh.observe({...visible, visible: false}), false); assert.equal(refresh.observe(visible), true);
    for (let i = 0; i < 50; i++) assert.equal(refresh.observe(visible), false);
    assert.equal(refresh.observe({...visible, visible: false}), false); assert.equal(refresh.observe(visible), false);
    assert.equal(refresh.observe({...visible, opened: false}), false); assert.equal(refresh.observe(visible), true); assert.equal(refresh.observe(visible), false);
});

test('同回合串流片段不刷新，所有終態僅刷新一次，讀歷史不當新生成', () => {
    for (const phase of ['completed', 'failed', 'cancelled', 'submission_unknown'] as const) {
        const refresh = new SidebarBudgetRefresh(); assert.equal(refresh.observe(visible), true);
        assert.equal(refresh.observe({...visible, submitting: true}), false);
        for (const pending of ['queued', 'submitting', 'running', 'running'] as const) assert.equal(refresh.observe({...visible, activeTurn: {request_id: 'new-turn', execution_state: pending}}), false);
        const completed = {...visible, activeTurn: {request_id: 'new-turn', execution_state: phase}};
        assert.equal(refresh.observe(completed), true); assert.equal(refresh.observe(completed), false);
        assert.equal(refresh.observe({...visible, activeTurn: {request_id: 'old-history', execution_state: 'completed'}}), false);
    }
});

test('額度編輯中暫緩背景刷新，關閉後執行一次；失效登入不讀，新登入可再讀', () => {
    const refresh = new SidebarBudgetRefresh(); assert.equal(refresh.observe({...visible, editingBudget: true}), false);
    assert.equal(refresh.observe(visible), true); refresh.invalidate();
    assert.equal(refresh.observe({...visible, editingBudget: true}), false); assert.equal(refresh.observe(visible), true);
    assert.equal(refresh.observe({...visible, expired: true}), false); assert.equal(refresh.observe(visible), true); assert.equal(refresh.observe(visible), false);
    assert.equal(refresh.observe({...visible, submitting: true}), false); assert.equal(refresh.observe(visible), true);
});

test('分析中切換歷史使activeTurn消失，不假定遠端完成、不額外讀額度', () => {
    const refresh = new SidebarBudgetRefresh(); assert.equal(refresh.observe(visible), true);
    assert.equal(refresh.observe({...visible, submitting: true, activeTurn: {request_id: 'still-running', execution_state: 'queued'}}), false);
    assert.equal(refresh.observe({...visible, activeTurn: {request_id: 'still-running', execution_state: 'running'}}), false);
    assert.equal(refresh.observe({...visible, activeTurn: null}), false);
    assert.equal(refresh.observe({...visible, activeTurn: {request_id: 'old-history', execution_state: 'completed'}}), false);
    assert.equal(refresh.observe({...visible, activeTurn: {request_id: 'still-running', execution_state: 'completed'}}), true);
});

test('批次略過排隊／分析快照，送出中直接完成仍在送出結束刷新一次', () => {
    const refresh = new SidebarBudgetRefresh(); assert.equal(refresh.observe(visible), true);
    assert.equal(refresh.observe({...visible, submitting: true}), false);
    const completed = {...visible, activeTurn: {request_id: 'quick-turn', execution_state: 'completed' as const}};
    assert.equal(refresh.observe({...completed, submitting: true}), false);
    assert.equal(refresh.observe(completed), true); assert.equal(refresh.observe(completed), false);
});

test('新題剛送出時殘留上一題完成快照不冒充新回合，歷史切換不刷新', () => {
    const old = {...visible, activeTurn: {request_id: 'previous-turn', execution_state: 'completed' as const}};
    const refresh = new SidebarBudgetRefresh(); assert.equal(refresh.observe(old), true);
    assert.equal(refresh.observe({...old, submitting: true}), false);
    assert.equal(refresh.observe(old), false);
    assert.equal(refresh.observe({...visible, activeTurn: {request_id: 'other-history', execution_state: 'completed'}}), false);
});

test('共用 Progress 確實提供數值語意並支援減少動畫，未知值不宣稱0%', () => {
    const known = renderToStaticMarkup(createElement(Progress, {value: 82}));
    assert.match(known, /aria-valuenow="82"/); assert.match(known, /aria-valuemax="100"/); assert.match(known, /motion-reduce:transition-none/);
    const unknown = renderToStaticMarkup(createElement(Progress, {value: null})); assert.equal(unknown.includes('aria-valuenow'), false);
});

function environment() {
    const values = new Map<string, string>([['X_BI_accountNo', 'ADMINV2'], ['X_BI_TokenKey', 'fixture-session'], ['X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString()]]);
    const storage = {getItem(key: string) {return values.get(key) ?? null;}, setItem(key: string, value: string) {values.set(key, value);}} as Storage;
    const originalWindow = globalThis.window; globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    return {storage, values, restore() {globalThis.window = originalWindow;}};
}
function json(value: unknown, status = 200) {return new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});}

test('側欄與Dialog並行同權限GET只讀一次，後續明確刷新重新讀，不寫聊天或取消', async () => {
    const env = environment(), calls: RequestInit[] = []; let resolve!: (response: Response) => void;
    const firstResponse = new Promise<Response>(done => {resolve = done;});
    const controller = new ChatController({storage: env.storage, fetchImpl: async (url, options = {}) => {assert.equal(url, '/api/chat/budget'); calls.push(options); return calls.length === 1 ? firstResponse : json(budget());}}, 'X');
    try {
        controller.actions.setDraft('保留聊天草稿'); const before = controller.getSnapshot();
        const first = controller.actions.loadBudget(), concurrent = controller.actions.loadBudget('');
        assert.equal(calls.length, 1); resolve(json(budget(100000))); assert.equal((await first).account.limit, 100000); assert.equal((await concurrent).account.limit, 100000);
        await controller.actions.loadBudget(); assert.equal(calls.length, 2); assert.ok(calls.every(call => call.method === 'GET'));
        assert.equal(controller.getSnapshot(), before); assert.equal(controller.getSnapshot().draft, '保留聊天草稿');
    } finally {controller.dispose(); env.restore();}
});

test('唯讀與管理GET按憑證隔離，同管理憑證trim後合併，403失敗後不持續快取或重試', async () => {
    const env = environment(); let calls = 0;
    const controller = new ChatController({storage: env.storage, fetchImpl: async (_url, options) => {
        calls++; const token = new Headers(options?.headers).get('X-MES-Settings-Token');
        if (token === 'invalid') return json({detail: '管理憑證錯誤'}, 403);
        return json({...budget(), management: {write_allowed: token === 'fixture-manager'}});
    }}, 'X');
    try {
        const results = await Promise.all([controller.actions.loadBudget(), controller.actions.loadBudget(' fixture-manager '), controller.actions.loadBudget('fixture-manager')]);
        assert.equal(calls, 2); assert.equal(results[0]!.management.write_allowed, false); assert.equal(results[1]!.management.write_allowed, true);
        await assert.rejects(controller.actions.loadBudget('invalid')); await assert.rejects(controller.actions.loadBudget('invalid'));
        assert.equal(calls, 4); assert.equal(controller.getSnapshot().expired, false);
        assert.equal([...env.values.values()].some(value => value.includes('fixture-manager')), false);
    } finally {controller.dispose(); env.restore();}
});

test('MES token更新不得沿用舊GET，遲到舊回應拒絕但不使新登入失效', async () => {
    const env = environment(), resolvers: ((response: Response) => void)[] = []; let calls = 0;
    const controller = new ChatController({storage: env.storage, fetchImpl: async () => {calls++; return new Promise<Response>(done => {resolvers.push(done);});}}, 'X');
    try {
        const old = controller.actions.loadBudget(); const rejected = assert.rejects(old, (error: unknown) => error instanceof ChatApiError && error.status === 401);
        env.values.set('X_BI_TokenKey', 'new-fixture-session'); const fresh = controller.actions.loadBudget(); assert.equal(calls, 2);
        resolvers[0]!(json(budget(1))); resolvers[1]!(json(budget(100000))); await rejected; assert.equal((await fresh).account.limit, 100000);
        assert.equal(controller.getSnapshot().expired, false);
        env.values.set('X_BI_accountNo', 'OTHER'); await assert.rejects(controller.actions.loadBudget()); assert.equal(calls, 2);
    } finally {controller.dispose(); env.restore();}
});

test('保存額度後不合併保存前GET，401之後不發新的讀取或模型請求', async () => {
    const env = environment(), calls: RequestInit[] = []; let resolve!: (response: Response) => void;
    const initial = new Promise<Response>(done => {resolve = done;});
    const controller = new ChatController({storage: env.storage, fetchImpl: async (_url, options = {}) => {calls.push(options); return calls.length === 1 ? initial : json(budget(50000));}}, 'X');
    try {
        const old = controller.actions.loadBudget(); await controller.actions.saveBudget({scope: 'account', account_no: 'ADMINV2', revision: 0, monthly_token_limit: 50000});
        assert.equal((await controller.actions.loadBudget()).account.limit, 50000); assert.deepEqual(calls.map(call => call.method), ['GET', 'PATCH', 'GET']);
        resolve(json(budget())); await old;
    } finally {controller.dispose(); env.restore();}
    const expiredEnv = environment(); let reads = 0; const expired = new ChatController({storage: expiredEnv.storage, fetchImpl: async () => {reads++; return json({detail: '登入已逾時'}, 401);}}, 'X');
    try {await assert.rejects(expired.actions.loadBudget()); await assert.rejects(expired.actions.loadBudget()); assert.equal(reads, 1); assert.equal(expired.getSnapshot().expired, true);}
    finally {expired.dispose(); expiredEnv.restore();}
});
