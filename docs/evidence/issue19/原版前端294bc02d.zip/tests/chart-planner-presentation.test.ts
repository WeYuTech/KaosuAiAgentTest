import {decodeReportCard} from '../src/chat/report-decoder';
import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import type {RawReportCard as ReportCard, SemanticReportColumn} from '../src/chat/types';

const scoped = register({namespace: 'chart-planner-presentation', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {MesReportChart} = await scoped.import('../src/features/mes/MesReportChart.tsx', import.meta.url) as typeof import('../src/features/mes/MesReportChart');
function grid(rows: Record<string, unknown>[]): ReportCard {
    const columns: SemanticReportColumn[] = [
        {name: 'category_a', label: '機台', role: 'dimension', data_type: 'string'},
        {name: 'category_b', label: '班別', role: 'dimension', data_type: 'string'},
        {name: 'measure', label: '保存量測', role: 'metric', data_type: 'number', comparison_group: 'saved_measure', unit: '公斤'},
    ];
    return {id: 'grid', kind: 'semantic_query', title: '交叉比較', status: 'ok', chart_intent: 'auto', semantic_fingerprint: 'fixture', semantic_columns: columns,
        detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows}};
}
const render = (card: ReportCard) => renderToStaticMarkup(createElement(MesReportChart, {card: decodeReportCard(card)}));
const cellText = (html: string) => [...html.matchAll(/<td\b[^>]*>(.*?)<\/td>/g)].map(match => match[1]);

test('熱圖元件保留零、缺值與未顯示交叉列的不同意義', () => {
    const card = grid([{category_a: 'A', category_b: '早', measure: 0}, {category_a: 'B', category_b: '早', measure: null}, {category_a: 'A', category_b: '晚', measure: 8}]);
    const before = structuredClone(card), html = render(card);
    assert.match(html, /data-chart-kind="heatmap"/);
    assert.deepEqual(cellText(html), ['0', '未知', '8', '未顯示']);
    assert.match(html, /機台/);
    assert.match(html, /班別/);
    assert.match(html, /公斤/);
    assert.deepEqual(card, before);
});

test('熱圖完整呈現第九格，不因前八列截斷將已知值標成未顯示', () => {
    const rows = ['A', 'B', 'C'].flatMap((category_a, x) => ['早', '中', '晚'].map((category_b, y) => ({category_a, category_b, measure: x * 3 + y})));
    const html = render(grid(rows)), cells = cellText(html);
    assert.equal(cells.filter(value => value === '未知').length, 0);
    assert.equal(cells.filter(value => value === '未顯示').length, 0);
    assert.equal(cells.includes('8'), true);
    assert.match(html, /未含該交叉列/);
});

test('全部未知及無效metadata不產生空熱圖或假的色階範圍', () => {
    const card = grid([{category_a: 'A', category_b: '早', measure: null}, {category_a: 'B', category_b: '晚', measure: null}]);
    assert.equal(render(card), '');
    card.detail!.rows![0].measure = 1;
    card.semantic_columns![2].comparison_group = 'invalid group';
    assert.match(render(card), /保存欄位描述不符合圖表契約/);
    assert.doesNotMatch(render(card), /data-chart-kind/);
});
