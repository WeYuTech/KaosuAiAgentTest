import test from 'node:test';
import assert from 'node:assert/strict';
import {decodeReport, decodeReportCard, ReportDecodeError} from '../src/chat/report-decoder';
import {planBoundCharts, planSavedCharts} from '../src/chat/chart-planner';

const presentation = {version: 'answer-presentation-v1', mode: 'chart', preferred_chart_kind: 'bar'} as const;
const table = {columns: [{key: 'subject', label: '對象'}, {key: 'metric', label: '指標'}, {key: 'value', label: '保存值'}], rows: [{subject: '機台 A', metric: '良品量', value: '0'}, {subject: '機台 B', metric: '報廢量', value: '2'}]};
function source() {
    return {id: 'saved', kind: 'semantic_query', title: '保存資料', status: 'ok', source_call_id: 'call', semantic_fingerprint: 'saved', semantic_metadata_version: 1,
        semantic_columns: [{name: 'station', label: '機台', role: 'dimension', data_type: 'string'}, ...['good', 'scrap', 'hidden'].map(name => ({name, label: name, role: 'metric', data_type: 'number', unit: '公斤', comparison_group: 'quantity'}))],
        detail: {columns: ['station', 'good', 'scrap', 'hidden'].map(key => ({key, label: key})), rows: [{station: 'A', good: 0, scrap: 999, hidden: 98765}, {station: 'B', good: 888, scrap: 2, hidden: 54321}, {station: 'C', good: 555, scrap: 3, hidden: 12345}]},
        binding_table: structuredClone(table), binding_selection: {metrics: ['good', 'scrap'], row_indices: [0, 1], cells: [{row_index: 0, metric: 'good'}, {row_index: 1, metric: 'scrap'}], row_subjects: [{row_index: 0, label: '機台 A'}, {row_index: 1, label: '機台 B'}]}};
}

test('呈現 metadata 只接受封閉版本與模式，原回答視為不透明字串', () => {
    const report = decodeReport({report_version: 'mes-report-v2', request_id: 'r', answer_presentation: presentation, source_answer: '不把正文 9999 解析成資料', cards: [source()]});
    assert.deepEqual(report.answer_presentation, presentation);
    assert.equal(report.source_answer, '不把正文 9999 解析成資料');
    for (const invalid of [{...presentation, version: 'new'}, {...presentation, mode: 'scatter'}, {...presentation, preferred_chart_kind: 'pie'}, {...presentation, extra: true}]) {
        assert.throws(() => decodeReport({report_version: 'mes-report-v2', request_id: 'r', answer_presentation: invalid, cards: []}), ReportDecodeError);
    }
});

test('直接長條只顯示原回答引用的列與精確儲存格，不改零或補未顯示值', () => {
    const raw = source(), before = structuredClone(raw), card = decodeReportCard(raw, 2);
    const plan = planBoundCharts(card, presentation);
    assert.ok(plan.recommended.length);
    assert.ok(plan.recommended.every(chart => chart.mark === 'bar'));
    assert.ok(plan.alternatives.some(chart => chart.mark === 'point'));
    for (const chart of [...plan.recommended, ...plan.alternatives]) {
        assert.deepEqual(chart.points.map(point => point.rowIndex), [0, 1]);
        assert.deepEqual(chart.points.map(point => point.label), ['機台 A', '機台 B']);
        assert.deepEqual(chart.points.map(point => point.values), [{good: 0, scrap: null}, {good: null, scrap: 2}]);
        assert.equal(chart.columns.some(column => column.name === 'hidden'), false);
        assert.equal(JSON.stringify(chart).includes('98765'), false);
    }
    assert.deepEqual(raw, before);
    assert.equal(planSavedCharts(card).recommended[0].points.length, 3);
});

test('原保存索引與順序保留，沒有精確 cell 引用或只有摘要不能直接成圖', () => {
    const raw = source();
    raw.binding_selection.row_indices = [1];
    raw.binding_selection.cells = [{row_index: 1, metric: 'scrap'}];
    raw.binding_selection.metrics = ['scrap'];
    raw.binding_selection.row_subjects = [{row_index: 1, label: '機台 B'}];
    assert.equal(planBoundCharts(decodeReportCard(raw, 2), presentation).recommended[0].points[0].rowIndex, 1);
    for (const selection of [{metrics: ['good'], row_indices: [0]}, {metrics: [], row_indices: [], cells: [], row_subjects: []}]) {
        const card = decodeReportCard({...source(), binding_selection: selection}, 2);
        const plan = planBoundCharts(card, presentation);
        assert.equal(plan.recommended.length, 0);
        assert.match(plan.reason || '', /無法直接轉換.*圖表/);
        assert.deepEqual(card.binding_table, table);
    }
});

test('單卡損壞隔離，拒絕偽造儲存格、錯誤表頭及越界來源', () => {
    const invalids = [
        {...source(), binding_table: {...table, columns: [{key: 'value', label: '總量'}]}},
        {...source(), binding_selection: {...source().binding_selection, cells: [{row_index: 2, metric: 'good'}]}},
        {...source(), binding_selection: {...source().binding_selection, row_indices: [9]}},
        {...source(), binding_selection: {...source().binding_selection, row_subjects: [{row_index: 0, label: 'A'}]}},
    ];
    for (const invalid of invalids) {
        const report = decodeReport({report_version: 'mes-report-v2', request_id: 'r', cards: [invalid, {...source(), id: 'intact'}]});
        assert.equal(report.cards[0].chart_contract, 'unavailable');
        assert.notEqual(report.cards[1].chart_contract, 'unavailable');
    }
});

test('固定工具的直接圖標籤不用整列JSON，不把隱藏數字放進對象名稱', () => {
    const raw = source();
    const card = decodeReportCard({...raw, kind: 'work_order', semantic_columns: undefined, semantic_fingerprint: undefined, semantic_metadata_version: undefined}, 2);
    const plan = planBoundCharts(card, presentation);
    assert.ok(plan.recommended.length);
    assert.deepEqual(plan.recommended[0].points.map(point => point.label), ['機台 A', '機台 B']);
    assert.equal(JSON.stringify(plan).includes('98765'), false);
});

test('auto或缺少呈現metadata保持原來規劃，不擴充舊來源可畫內容', () => {
    const card = decodeReportCard(source(), 2);
    assert.deepEqual(planBoundCharts(card, {version: 'answer-presentation-v1', mode: 'auto', preferred_chart_kind: null}), planSavedCharts(card));
    assert.equal(planBoundCharts(decodeReportCard({...source(), binding_table: undefined}, 2), presentation).recommended.length, 0);
});

test('直接圖沿用原完整性與分頁限制，已引用的未核准完整量仍不能補零畫出', () => {
    const raw = source();
    const columns = [{name: 'station', label: '機台', role: 'dimension', data_type: 'string', source_group: 'saved'},
        {name: 'good', label: '良品量', role: 'metric', data_type: 'number', source_group: 'saved', unit: '公斤', interpretation: 'complete', completeness_required: true, required_missing_fields: ['missing'], availability_count_field: 'samples'},
        {name: 'missing', label: '缺值數', role: 'quality', data_type: 'number', source_group: 'saved', interpretation: 'quality', completeness_required: false, required_missing_fields: []},
        {name: 'samples', label: '樣本數', role: 'quality', data_type: 'number', source_group: 'saved', interpretation: 'count', completeness_required: false, required_missing_fields: []}];
    const selection = {metrics: ['good'], row_indices: [0, 1], cells: [{row_index: 0, metric: 'good'}, {row_index: 1, metric: 'good'}], row_subjects: [{row_index: 0, label: 'A'}, {row_index: 1, label: 'B'}]};
    const card = decodeReportCard({...raw, semantic_metadata_version: 2, semantic_columns: columns, pagination: {has_more: true}, binding_selection: selection,
        detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows: [{station: 'A', good: 0, missing: 0, samples: 1}, {station: 'B', good: 99, missing: 1, samples: 1}]}}, 2);
    const chart = planBoundCharts(card, presentation).recommended[0];
    assert.deepEqual(chart.points.map(point => point.values), [{good: 0}, {good: null}]);
    assert.equal(chart.scope.paginated, true);
    assert.equal(chart.columns.some(column => column.name === 'samples'), false);
    assert.match(chart.notices.join('；'), /未補零/);
    const noValues = decodeReportCard({...card, detail: {...card.detail, rows: [{station: 'A', good: 0, missing: 1, samples: 1}, {station: 'B', good: 99, missing: 1, samples: 1}]}}, 2);
    assert.equal(planBoundCharts(noValues, presentation).recommended.length, 0);
});
