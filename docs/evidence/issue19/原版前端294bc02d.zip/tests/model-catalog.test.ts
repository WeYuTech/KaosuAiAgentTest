import test from 'node:test';
import assert from 'node:assert/strict';
import {MODEL_OPTIONS, MODEL_PRICE_CHECKED_AT, MODEL_PRICING_URL, modelOption, modelPriceLabel} from '../src/features/preferences/model-catalog';

test('模型價格按官方標準輸入與輸出分開呈現，附查證日期與原始來源', () => {
    assert.equal(MODEL_PRICE_CHECKED_AT, '2026-10-11');
    assert.equal(MODEL_PRICING_URL, 'https://developers.openai.com/api/docs/pricing');
    assert.equal(modelPriceLabel('gpt-6-astra'), '輸入 $10.00 · 輸出 $50.00');
    assert.equal(modelPriceLabel('gpt-6-luna'), '輸入 $0.10 · 輸出 $0.50');
    assert.equal(new Set(MODEL_OPTIONS.map(model => model.id)).size, MODEL_OPTIONS.length);
});

test('自訂或未知模型不當零費用、不默默替換目前選項', () => {
    assert.equal(modelOption('customer-model'), undefined);
    assert.equal(modelPriceLabel('customer-model'), '尚未取得官方價格');
});
