import {decodeReportCard} from '../src/chat/report-decoder';
import test from 'node:test';
import assert from 'node:assert/strict';
import {metricsSummary, sourceText, sourceNoticeLabels} from '../src/chat/report';
import type { RawReportCard as ReportCard } from '../src/chat/types';
const cardPresentation = (card: ReportCard) => decodeReportCard(card).display;
const isAnswerReportCard = (card: ReportCard) => decodeReportCard(card).display.answer;

function card(produced: unknown, planned: unknown, completion: unknown): ReportCard {
    return {id: 'w1', kind: 'work_order', status: 'ok', provenance: 'backup', data_time: '2026-08-20', detail: {rows: [{work_order_no: '145861'}]}, metrics: [{key: 'completion_percent', value: completion, unit: '%'}, {key: 'produced_quantity', value: produced, unit: '件'}, {key: 'planned_quantity', value: planned, unit: '件'}], formula: {expression: '總報工量 ÷ 目標量 × 100%', substitution: '107,102 ÷ 130,000 × 100% = 82.39%'}};
}

test('盤點資料只在依據查看，原始 OEE 紀錄可在回答資料區查看', () => {
    const base = card(1, 2, 50);
    assert.equal(isAnswerReportCard({...base, kind: 'oee_readiness', presentation: 'evidence'}), false);
    assert.equal(isAnswerReportCard({...base, kind: 'work_order_oee', presentation: 'answer'}), true);
    assert.equal(isAnswerReportCard({...base, kind: 'reporting_coverage'}), false);
    assert.equal(isAnswerReportCard({...base, kind: 'reporting_coverage', presentation: 'answer'}), true);
});
test('工單明細直接顯示保存百分比、數量與既有公式，不產生額外計算', () => {
    const original = card(107102, 130000, 82.39), before = JSON.stringify(original), view = cardPresentation(original);
    assert.deepEqual(view.metrics.map(metric => [metric.key, metric.value, metric.unit]), [
        ['completion_percent', '82.39', '%'], ['produced_quantity', '107,102', '件'], ['planned_quantity', '130,000', '件'],
    ]);
    assert.equal(view.metrics[0].label, '報工完成率');
    assert.equal(original.formula?.substitution, '107,102 ÷ 130,000 × 100% = 82.39%');
    assert.equal(JSON.stringify(original), before);
});
test('正式資料來源使用原標記與日期，不以舊來源或現在時間取代', () => {
    const current = decodeReportCard({...card(107102, 130000, 82.39), provenance: 'mes_database', data_time: '2026-08-19'});
    assert.equal(sourceText(current), 'MES 資料庫'); assert.equal(current.data_time, '2026-08-19');
    assert.equal(sourceNoticeLabels.mes_database, '依資料庫實際紀錄時間，資料更新頻率尚未驗證');
    assert.equal(sourceText(decodeReportCard(card(107102, 130000, 82.39))), '備份資料');
});
test('超額報工保留保存百分比，不截成百分之百或新增推算餘量', () => {
    const view = cardPresentation(card(156000, 130000, 120));
    assert.equal(view.metrics[0].value, '120');
    assert.deepEqual(view.metrics.map(metric => metric.key), ['completion_percent', 'produced_quantity', 'planned_quantity']);
});
test('零目標、負報工及缺少完成率仍明示未知，不能把相容值當可用完成率', () => {
    for (const original of [card(107102, 0, 82.39), card(-1, 130000, 82.39), card(107102, 130000, null)]) {
        const view = cardPresentation(original); assert.equal(view.metrics[0].value, '未知'); assert.equal(view.metrics[0].unit, '');
        assert.equal(view.highlights[0].detail, '資料未完整取得');
    }
});
test('Cycle 未保存數值時不生成工單進度或推斷設備正常', () => {
    const view = cardPresentation({id: 'cycle1', kind: 'work_order_cycle', status: 'insufficient_data', metrics: [], provenance: 'backup'});
    assert.deepEqual(view.metrics, []); assert.deepEqual(view.highlights, []);
});
test('統計不把未知 Token 當零，已知零保留零並維持問題與負評合計', () => {
    assert.equal(metricsSummary([{date: 'd1', total_tokens: null}])[1].displayValue, '尚未取得');
    const result = metricsSummary([{date: 'd1', question_count: 2, negative_feedback_count: 1, total_tokens: 0}, {date: 'd2', question_count: 3, total_tokens: null}]);
    assert.deepEqual(result.map(item => item.value), [5, 0, 1]);
});
