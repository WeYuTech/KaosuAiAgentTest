import {strict as assert} from 'node:assert';
import {test} from 'node:test';
import {chatExecutionStatus} from '../src/chat/progress';
import type {ChatState, ExecutionState} from '../src/chat/types';

const view = (overrides: Partial<ChatState> = {}) => ({submitting: false, cancelling: false, expired: false, unknownSubmission: false, activeTurn: null, connectionStatus: '', hint: '', ...overrides});

test('已收到真正時間軸時，API 的 submitting 快照不覆蓋實際工具進度', () => {
    const activeTurn = {execution_state: 'submitting' as const, execution_trace_version: 'mes-execution-trace-v1', execution_trace: [{id: 'one', stage: 'querying' as const, status: 'running' as const, source: 'tool_start', observed_at: '2026-10-12T00:00:00Z'}]};
    assert.deepEqual(chatExecutionStatus(view({activeTurn, connectionStatus: '正在查詢工單摘要'})), {spinning: true, text: '正在查詢工單摘要'});
});

test('送出尚未取得回合識別碼時顯示轉圈與送出文字', () => {
    assert.deepEqual(chatExecutionStatus(view({submitting: true})), {spinning: true, text: '正在送出問題'});
});

test('queued／submitting／running 顯示狀態，終止與待確認回合不轉圈', () => {
    for (const phase of ['queued', 'submitting', 'running'] as ExecutionState[]) assert.equal(chatExecutionStatus(view({activeTurn: {execution_state: phase}})).spinning, true);
    for (const phase of ['completed', 'cancelled', 'failed', 'submission_unknown'] as ExecutionState[]) assert.equal(chatExecutionStatus(view({activeTurn: {execution_state: phase}})).spinning, false);
    for (const status of ['succeeded', 'failed', 'cancelled'] as const) assert.equal(chatExecutionStatus(view({activeTurn: {execution_state: 'running', status}})).spinning, false);
});

test('停止中、登入逾時與送出結果待確認不宣稱仍在生成', () => {
    const active = {execution_state: 'running' as const};
    assert.deepEqual(chatExecutionStatus(view({activeTurn: active, cancelling: true})), {spinning: false, text: '正在停止分析'});
    assert.equal(chatExecutionStatus(view({activeTurn: active, expired: true})).spinning, false);
    assert.equal(chatExecutionStatus(view({submitting: true, unknownSubmission: true})).spinning, false);
});

test('保存觀看故障停止圈圈但不改寫原 queued 狀態', () => {
    const state = view({watchUnavailable: true, submitting: true, activeTurn: {execution_state: 'queued'}, connectionStatus: '聊天狀態保存尚未確認，請明確停止原回合'});
    const before = structuredClone(state);
    assert.deepEqual(chatExecutionStatus(state), {spinning: false, text: state.connectionStatus});
    assert.deepEqual(state, before);
});

test('保留原進度訊息，沒有恢復已移除的追問快捷鍵提示或更改狀態', () => {
    const state = view({activeTurn: {execution_state: 'running'}, connectionStatus: '正在查詢 MES'}), before = structuredClone(state);
    assert.deepEqual(chatExecutionStatus(state), {spinning: true, text: '正在查詢 MES'});
    assert.deepEqual(state, before);
    assert.deepEqual(chatExecutionStatus(view({hint: '可接續追問 · Enter 送出 · Shift + Enter 換行'})), {spinning: false, text: ''});
});

test('提交 Promise 尚未返回也優先顯示已接受回合的真實工具階段', () => {
    assert.deepEqual(chatExecutionStatus(view({submitting: true, activeTurn: {execution_state: 'running'}, connectionStatus: '正在查詢工單報工紀錄'})), {spinning: true, text: '正在查詢工單報工紀錄'});
    assert.deepEqual(chatExecutionStatus(view({submitting: true, activeTurn: {execution_state: 'completed'}, connectionStatus: '已完成'})), {spinning: false, text: '已完成'});
});

test('已收到答案仍顯示生成狀態，整理與保存階段保留實際訊息', () => {
    const activeTurn = {execution_state: 'running' as const, answer: '工具已核對的回答前綴'};
    assert.deepEqual(chatExecutionStatus(view({activeTurn, connectionStatus: '正在查詢 MES'})), {spinning: true, text: '正在產生回答'});
    for (const text of ['正在整理已核對的答案', '正在保存回答與查詢依據']) assert.deepEqual(chatExecutionStatus(view({activeTurn, connectionStatus: text})), {spinning: true, text});
});
