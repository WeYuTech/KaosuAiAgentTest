import {decodeReportCard} from '../src/chat/report-decoder';
import test from 'node:test';
import assert from 'node:assert/strict';
import type { RawReportCard as ReportCard, SemanticReportColumn } from '../src/chat/types';
const reportHighlights = (card: ReportCard) => decodeReportCard(card).display.highlights;

const columns: SemanticReportColumn[] = [
    {name: 'machine_id', label: '機台', role: 'dimension', data_type: 'string'},
    {name: 'good_quantity', label: '良品量', role: 'metric', data_type: 'number', completeness_required: true, required_missing_fields: ['missing_good_count']},
    {name: 'scrap_quantity', label: '不良量', role: 'metric', data_type: 'number', completeness_required: true, required_missing_fields: ['missing_scrap_count']},
    {name: 'produced_quantity', label: '報工量', role: 'metric', data_type: 'number', completeness_required: true, required_missing_fields: ['missing_good_count', 'missing_scrap_count']},
    {name: 'known_produced_quantity', label: '已知報工量', role: 'metric', data_type: 'number', interpretation: 'known_partial', completeness_required: false, required_missing_fields: []},
    {name: 'operation_count', label: '有效作業筆數', role: 'metric', data_type: 'number', completeness_required: false, required_missing_fields: []},
    {name: 'missing_good_count', label: '缺良品量作業數', role: 'quality', data_type: 'number'},
    {name: 'missing_scrap_count', label: '缺不良量作業數', role: 'quality', data_type: 'number'},
];

function semantic(overrides: Partial<ReportCard> = {}): ReportCard {
    return {
        id: 'saved', kind: 'semantic_query', status: 'ok', semantic_fingerprint: 'saved-version', semantic_columns: columns,
        summary: {good_quantity: 1200, scrap_quantity: 20, produced_quantity: 1220, known_produced_quantity: 1220, operation_count: 10, missing_good_count: 0, missing_scrap_count: 0},
        metrics: [{key: 'good_quantity', value: 1200}, {key: 'unknown_quantity', value: 777}],
        detail: {columns: columns.map(column => ({key: column.name, label: column.label})), rows: [{machine_id: 'SC01', good_quantity: 5}]},
        ...overrides,
    };
}

function workOrder(overrides: Partial<ReportCard> = {}): ReportCard {
    return {
        id: 'order', kind: 'work_order', status: 'ok',
        metrics: [{key: 'completion_percent', label: '完成率', value: 80, unit: '%'}, {key: 'produced_quantity', label: '已報工產量', value: 80}, {key: 'planned_quantity', label: '目標產量', value: 100}],
        detail: {rows: [{work_order_no: 'W1'}]}, ...overrides,
    };
}

test('全部核准業務指標重用保存摘要，不截前三項、不加總本頁或呈現品質計數', () => {
    const saved = semantic({pagination: {truncated: true, offset: 20}});
    const before = JSON.stringify(saved);
    const highlights = reportHighlights(saved);
    assert.deepEqual(highlights.map(item => item.key), ['good_quantity', 'scrap_quantity', 'produced_quantity', 'known_produced_quantity', 'operation_count']);
    assert.deepEqual(highlights.map(item => item.value), ['1,200', '20', '1,220', '1,220', '10']);
    assert.equal(highlights[0].unit, '');
    assert.match(highlights[3].label, /已知部分/);
    assert.equal(JSON.stringify(saved), before);
});

test('缺不良量不遮蔽完整良品，總旗標與相同數值不能合併完整與已知指標', () => {
    const highlights = reportHighlights(semantic({quantity_complete: false, summary: {good_quantity: 1200, scrap_quantity: 0, produced_quantity: 1200, known_produced_quantity: 1200, operation_count: 10, missing_good_count: 0, missing_scrap_count: 2}}));
    assert.deepEqual(highlights.map(item => item.value), ['1,200', '未知', '未知', '1,200', '10']);
    assert.doesNotMatch(highlights[0].label, /已知部分/);
    assert.match(highlights[3].label, /已知部分/);
});

test('沒有作業、摘要缺項與無效作業數都不把相容數量零值當成有效產量', () => {
    for (const operationCount of [0, null, undefined, '2', true, -1, 1.5]) {
        const highlights = reportHighlights(semantic({metrics: [], summary: {good_quantity: 0, known_produced_quantity: 0, operation_count: operationCount, missing_good_count: 0, missing_scrap_count: 0}}));
        assert.equal(highlights[0].value, '未知');
        assert.equal(highlights[3].value, '未知');
    }
    assert.equal(reportHighlights(semantic({summary: {operation_count: 1}}))[0].value, '未知');
});

test('明確保存的未知摘要優先，不借用其他值，真實零與負數保持原值', () => {
    assert.equal(reportHighlights(semantic({summary: {good_quantity: null, operation_count: 2, missing_good_count: 0}}))[0].value, '未知');
    const highlights = reportHighlights(semantic({metrics: [{key: 'good_quantity', value: 0}], summary: {good_quantity: 0, scrap_quantity: -2, operation_count: 2, missing_good_count: 0, missing_scrap_count: 0}}));
    assert.equal(highlights[0].value, '0');
    assert.equal(highlights[1].value, '-2');
});

test('只准用保存 metadata 的標籤與單位，沒有 metadata 不讀答案猜測', () => {
    const changed = columns.map(column => column.name === 'good_quantity' ? {...column, label: '保存良品量', unit: '公斤'} : column);
    const highlights = reportHighlights(semantic({semantic_columns: changed}));
    assert.equal(highlights[0].label, '保存良品量');
    assert.equal(highlights[0].unit, '公斤');
    assert.deepEqual(reportHighlights(semantic({semantic_fingerprint: undefined, answer: '良品量 99999'})), []);
    assert.deepEqual(reportHighlights(semantic({semantic_columns: columns.filter(column => column.role === 'quality')})), []);
});

test('完整指標的缺項契約不完整時維持未知', () => {
    for (const required of [undefined, [], ['missing_unknown_count'], ['missing_good_count', 'missing_good_count']]) {
        const changed = columns.map(column => column.name === 'good_quantity' ? {...column, required_missing_fields: required} : column);
        assert.equal(reportHighlights(semantic({semantic_columns: changed}))[0].value, '未知');
    }
});

test('摘要與指標副本矛盾時明示未知，不能默選其中一個保存值', () => {
    for (const value of [77, null, '1200', undefined]) {
        const saved = semantic({metrics: [{key: 'good_quantity', value}]});
        const before = structuredClone(saved), highlight = reportHighlights(saved)[0];
        assert.equal(highlight.value, '未知');
        assert.equal(highlight.unit, '');
        assert.equal(highlight.detail, '保存摘要數值不一致');
        assert.deepEqual(saved, before);
    }
    assert.equal(reportHighlights(semantic({metrics: []}))[0].value, '1,200');
    assert.equal(reportHighlights(semantic())[0].value, '1,200');
    const saved = semantic({summary: {good_quantity: null, operation_count: 2, missing_good_count: 0}});
    assert.equal(reportHighlights(saved)[0].detail, '保存摘要數值不一致');
});

test('已知部分的保存完整性定義缺漏或矛盾時維持未知', () => {
    for (const definition of [
        {completeness_required: undefined},
        {required_missing_fields: ['missing_good_count']},
        {required_missing_fields: ['missing_unknown_count']},
    ]) {
        const saved = semantic({semantic_columns: columns.map(column => column.name === 'known_produced_quantity' ? {...column, ...definition} : column)});
        assert.equal(reportHighlights(saved)[3].value, '未知');
    }
});

test('工單使用既有完成率呈現，保留超額原值與未驗證單位', () => {
    const saved = workOrder();
    saved.metrics![0].value = 120;
    saved.metrics![1].value = 120;
    const highlights = reportHighlights(saved);
    assert.equal(highlights[0].value, '120');
    assert.equal(highlights[0].unit, '%');
    assert.equal(highlights[1].unit, '');
});

test('缺量工單與無效目標不得顯示相容零完成率或假的百分比', () => {
    for (const saved of [workOrder({quantity_complete: false}), workOrder({detail: {rows: [{quantity_complete: false}]}}), workOrder({status: 'insufficient_data'})]) {
        saved.metrics![0].value = 0;
        const highlights = reportHighlights(saved);
        assert.equal(highlights[0].value, '未知');
        assert.equal(highlights[0].unit, '');
    }
    const saved = workOrder();
    saved.metrics![1].value = -1;
    assert.equal(reportHighlights(saved)[0].value, '未知');
    saved.metrics![1].value = 1;
    saved.metrics![2].value = 0;
    assert.equal(reportHighlights(saved)[0].value, '未知');
});

test('部分量必須明示且不同業務摘要不能固定只留下前三項', () => {
    const saved = workOrder({quantity_complete: false});
    saved.metrics!.push({key: 'good_quantity', label: '已知良品量', value: 79}, {key: 'scrap_quantity', label: '已知不良量', value: 1});
    const highlights = reportHighlights(saved);
    assert.equal(highlights.length, 5);
    assert.match(highlights[1].label, /已知部分/);
    assert.match(highlights[3].label, /已知部分/);
});

test('固定工具保留已保存完整與已知摘要，不從明細補值', () => {
    const saved: ReportCard = {id: 'machine', kind: 'machine_production', status: 'insufficient_data', quantity_complete: false, metrics: [
        {key: 'produced_quantity', label: '報工量', value: null}, {key: 'good_quantity', label: '良品量', value: null}, {key: 'scrap_quantity', label: '不良量', value: null},
        {key: 'known_good_quantity', label: '已知良品量', value: 0}, {key: 'known_scrap_quantity', label: '已知不良量', value: 3}, {key: 'operation_count', value: 5},
    ], detail: {rows: [{produced_quantity: 99999}]}};
    assert.deepEqual(reportHighlights(saved).map(item => item.value), ['未知', '未知', '未知', '0', '3']);
});

test('Cycle 樣本不足保留未知且不加入內部樣本數，充分樣本才呈現秒數', () => {
    const saved: ReportCard = {id: 'cycle', kind: 'machine_cycle', status: 'ok', metrics: [
        {key: 'average_cycle_seconds', label: '平均 Cycle', value: 6, unit: '秒'},
        {key: 'minimum_cycle_seconds', label: '最小 Cycle', value: 5, unit: '秒'},
        {key: 'maximum_cycle_seconds', label: '最大 Cycle', value: 7, unit: '秒'},
        {key: 'interval_sample_count', value: 1}, {key: 'anomaly_count', value: 0},
    ]};
    assert.deepEqual(reportHighlights(saved).map(item => item.value), ['未知', '未知', '未知']);
    saved.metrics![3].value = 2;
    assert.deepEqual(reportHighlights(saved).map(item => item.value), ['6', '5', '7']);
    assert.equal(reportHighlights(saved)[0].unit, '秒');
});

test('失敗、無資料與依據報告不展開重點，未知工具與答案文字不能補造', () => {
    for (const overrides of [{status: 'no_data'}, {status: 'failed'}, {presentation: 'evidence'}, {kind: 'unknown'}]) {
        assert.deepEqual(reportHighlights(workOrder(overrides)), []);
    }
    assert.deepEqual(reportHighlights(workOrder({metrics: [], answer: '完成率 80%'})), []);
    assert.equal(reportHighlights({id: 'oee', kind: 'machine_oee', metrics: [{key: 'operation_count', label: '作業紀錄數', value: 20, unit: '筆'}]})[0].value, '20');
});

test('字串、布林與非有限數字保持未知，不補零或移除其他需求指標', () => {
    for (const value of ['0', false, null, undefined, NaN, Infinity]) {
        const saved = workOrder();
        saved.metrics![1].value = value;
        const highlights = reportHighlights(saved);
        assert.equal(highlights[1].value, '未知');
        assert.equal(highlights[0].value, '未知');
        assert.equal(highlights.length, 3);
    }
});
