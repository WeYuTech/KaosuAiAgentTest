import test from 'node:test';
import assert from 'node:assert/strict';
import {observeAnalysis, toggleAnalysis} from '../src/chat/analysis-presentation';

test('新回合預設收合，不建立等待答案的呈現階段', () => {
    assert.deepEqual(observeAnalysis(null, 'c1:r1'), {identity: 'c1:r1', open: false});
});

test('手動展開後，進度與完成更新不強制收合', () => {
    const opened = toggleAnalysis(observeAnalysis(null, 'c1:r1'), true);
    assert.equal(observeAnalysis(opened, 'c1:r1'), opened);
    assert.equal(opened.open, true);
});

test('手動收合保持選擇，重複操作不建立新狀態', () => {
    const closed = observeAnalysis(null, 'c1:r1');
    assert.equal(toggleAnalysis(closed, false), closed);
    assert.equal(observeAnalysis(closed, 'c1:r1'), closed);
});

test('切換回合、歷史及重連重新掛載時預設收合', () => {
    const opened = toggleAnalysis(observeAnalysis(null, 'c1:r1'), true);
    assert.deepEqual(observeAnalysis(opened, 'c2:r2'), {identity: 'c2:r2', open: false});
    assert.deepEqual(observeAnalysis(null, 'c1:r1'), {identity: 'c1:r1', open: false});
});
