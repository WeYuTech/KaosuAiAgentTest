import test from 'node:test';
import assert from 'node:assert/strict';
import { ChatController } from '../src/chat/controller';
import type { Conversation, Report, Turn } from '../src/chat/types';
import {getMesFollowupSource} from '../src/chat/follow-ups';
import type {ProviderSettings} from '../src/chat/settings';

class MemoryStorage implements Storage {
    private values = new Map<string, string>();
    get length() { return this.values.size; }
    key(index: number) { return [...this.values.keys()][index] || null; }
    getItem(key: string) { return this.values.get(key) || null; }
    setItem(key: string, value: string) { this.values.set(key, String(value)); }
    removeItem(key: string) { this.values.delete(key); }
    clear() { this.values.clear(); }
}
function setup() {
    const storage = new MemoryStorage();
    storage.setItem('X_BI_accountNo', 'ADMINV2'); storage.setItem('X_BI_TokenKey', 'local-fixture-token'); storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString());
    const originalWindow = globalThis.window;
    globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    return {storage, restore() { globalThis.window = originalWindow; }};
}
function json(value: unknown, status = 200): Response { return new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}}); }
function pathname(input: RequestInfo | URL): string { return new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url, 'http://fixture').pathname; }
function doneTurn(): Turn { return {conversation_id: 'c1', request_id: 'r1', execution_state: 'completed', status: 'succeeded', answer: '已保存的驗證答案'}; }

test('新聊天狀態讀取失敗保留原因且不重複 toast，重新連線只讀取狀態', async () => {
    const environment = setup(); let reads = 0, posts = 0;
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        if (options.method === 'POST') {posts++; throw new Error('重新連線不可重送問題');}
        assert.ok(pathname(input).endsWith('/runtime'));
        reads++;
        return reads === 2 ? json({detail: '服務狀態暫時不可讀，請重新連線'}, 503) : json({mode: 'API', api_provider: 'local', continuous_context: false});
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.newChat();
        await until(() => controller.getSnapshot().runtime === null);
        assert.equal(controller.getSnapshot().connectionStatus, '服務狀態暫時不可讀，請重新連線');
        assert.equal(controller.getSnapshot().toast, null);
        controller.actions.setDraft('尚未送出的問題');
        await controller.actions.reconnect();
        assert.equal(controller.getSnapshot().runtime?.api_provider, 'local');
        assert.equal(controller.getSnapshot().draft, '尚未送出的問題');
        assert.equal(controller.getSnapshot().connectionStatus, '');
        assert.equal(reads, 3); assert.equal(posts, 0);
    } finally {controller.dispose(); environment.restore();}
});

function savedReport(requestId = 'r1') {return {report_version: 'mes-report-v2', request_id: requestId, cards: [{id: 'saved', kind: 'machine_production', source_call_id: 'completed-source', chart_preference: null, metrics: [{key: 'produced_quantity', value: 0}], detail: {rows: [{machine_id: 'A', produced_quantity: 0}]}}]};}

function editableReport(revision = 0, mark = 'point') {return {...savedReport(), view_preferences_editable: true, view_preferences: {version: 'report-view-preferences-v1', revision, selections: revision ? [{card_id: 'saved', mark, metrics: ['produced_quantity']}] : []}};}

test('遲到呈現PUT不覆蓋較新保存快照', async () => {
    const environment = setup(), pending = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'PUT') return pending.promise;
        if (path.endsWith('/report')) return json(editableReport());
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', active_request_id: 'r1', messages: []});
        if (path.endsWith('/r1')) return json({...doneTurn(), event_sequence: 7, report: editableReport(2, 'bar')});
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.loadReport('r1');
        const save = controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']});
        await controller.actions.openChat();
        assert.equal(controller.getSnapshot().reports.r1.report?.view_preferences?.revision, 2);
        pending.resolve(json(editableReport(1))); assert.equal(await save, false);
        assert.equal(controller.getSnapshot().reports.r1.report?.view_preferences?.selections[0].mark, 'bar');
        assert.ok(controller.getSnapshot().presentationErrors?.r1);
    } finally {pending.resolve(json(editableReport(1))); controller.dispose(); environment.restore();}
});

test('封存聊天即使殘留可編輯報告快取也不發送偏好；回自動的冪等版本可接受', async () => {
    const environment = setup(); let writes = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'PUT') {writes++; return json(editableReport());}
        if (path.endsWith('/report')) return json(editableReport());
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', is_archived: true, read_only: true, messages: [{...doneTurn(), role: 'assistant', content: '保存答案'}]});
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.loadReport('r1'); assert.equal(await controller.actions.savePresentation('r1', 'saved', null), true);
        await controller.actions.openChat(); assert.equal(await controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']}), false);
        assert.equal(writes, 1);
    } finally {controller.dispose(); environment.restore();}
});

test('切換呈現保存薄偏好，重建控制器還原；重複點擊不重送或呼叫模型', async () => {
    const environment = setup(), pending = deferred<Response>(); let writes = 0, persisted = editableReport();
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        if (pathname(input).endsWith('/presentation')) {
            writes++; assert.equal(options.method, 'PUT');
            assert.deepEqual(JSON.parse(String(options.body)), {expected_revision: 0, card_id: 'saved', selection: {mark: 'point', metrics: ['produced_quantity']}});
            return pending.promise;
        }
        assert.ok(pathname(input).endsWith('/report')); return json(persisted);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    let reopened: ChatController | undefined;
    try {
        await controller.actions.openReport('r1', 'saved', 'detail');
        const saving = controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']});
        assert.deepEqual(controller.getSnapshot().presentationSaving, ['r1']);
        assert.equal(await controller.actions.savePresentation('r1', 'saved', null), false);
        assert.equal(controller.getSnapshot().reports.r1.report?.view_preferences?.revision, 0);
        persisted = editableReport(1); pending.resolve(json(persisted)); assert.equal(await saving, true);
        assert.equal(controller.getSnapshot().reportDialog?.report.view_preferences?.revision, 1);
        controller.dispose(); reopened = new ChatController({storage: environment.storage, fetchImpl}, 'X');
        const result = await reopened.actions.loadReport('r1');
        assert.equal(result.report?.view_preferences?.selections[0].mark, 'point'); assert.equal(writes, 1);
    } finally {pending.resolve(json(editableReport(1))); reopened?.dispose(); controller.dispose(); environment.restore();}
});

for (const status of [409, 503]) test(`呈現保存 ${status} 保留可讀答案並提供明確重載，不自動重送`, async () => {
    const environment = setup(); let reads = 0, writes = 0;
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        if (options.method === 'PUT') {writes++; return json({detail: '測試保存失敗'}, status);}
        assert.ok(pathname(input).endsWith('/report')); reads++; return json(editableReport(reads > 1 ? 1 : 0));
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.loadReport('r1');
        assert.equal(await controller.actions.savePresentation('r1', 'saved', null), false);
        assert.equal(controller.getSnapshot().reports.r1.state, 'ready');
        assert.ok(controller.getSnapshot().presentationErrors?.r1);
        assert.equal(reads, status === 409 ? 2 : 1);
        await controller.actions.retryReport('r1');
        assert.equal(controller.getSnapshot().presentationErrors?.r1, undefined); assert.equal(writes, 1);
    } finally {controller.dispose(); environment.restore();}
});

for (const invalidation of ['delete', 'edit', 'account', 'dispose']) test(`呈現保存晚到後 ${invalidation} 不恢復不可見報告`, async () => {
    const environment = setup(), pending = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', supports_message_edit: true, continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (options.method === 'DELETE') return json({deleted: true});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', messages: [{role: 'user', content: '原問題', request_id: 'r1'}, {...doneTurn(), role: 'assistant', content: '保存答案', report_available: true}]});
        if (path.endsWith('/presentation')) return pending.promise;
        if (path.endsWith('/report')) return json(editableReport());
        if (path.endsWith('/messages')) return json({...doneTurn(), request_id: 'new'}, 202);
        if (path.endsWith('/new')) return json({...doneTurn(), request_id: 'new'});
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); await controller.actions.loadReport('r1');
        const save = controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']});
        if (invalidation === 'delete') await controller.actions.deleteConversation('c1');
        else if (invalidation === 'edit') await controller.actions.resubmitQuestion('r1', '更正問題');
        else if (invalidation === 'account') environment.storage.setItem('X_BI_TokenKey', '更新憑證');
        else controller.dispose();
        pending.resolve(json(editableReport(1))); assert.equal(await save, false);
        assert.notEqual(controller.getSnapshot().reports.r1?.report?.view_preferences?.revision, 1);
        if (invalidation === 'delete' || invalidation === 'edit') assert.equal(controller.getSnapshot().reports.r1, undefined);
    } finally {pending.resolve(json(editableReport(1))); controller.dispose(); environment.restore();}
});

test('大量歷史只保存可用旗標，不載入所有報告；可見訊息入口使用 v2 且共享同一請求', async () => {
    const environment = setup(); let reports = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const messages = Array.from({length: 1000}, (_, index) => ({...doneTurn(), request_id: `r${index}`, report_available: true, role: 'assistant', content: '歷史保存答案'}));
    const fetchImpl: typeof fetch = async input => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '長聊天', messages});
        if (path.endsWith('/report')) {reports++; assert.equal(new URL(String(input), 'http://fixture').search, '?version=2'); return json(savedReport('r50'));}
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); assert.equal(reports, 0); assert.equal(controller.getSnapshot().messages.length, 1000);
        const [first, second] = await Promise.all([controller.actions.loadReport('r50'), controller.actions.loadReport('r50')]);
        assert.equal(reports, 1); assert.equal(first.state, 'ready'); assert.equal(first.report, second.report);
    } finally {controller.dispose(); environment.restore();}
});

for (const transport of ['snapshot', 'done']) test(`${transport} 完整答案與 inline 報告同一次更新，Audit 故障不阻擋保存資料`, async () => {
    const environment = setup(); let reportReads = 0, posts = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const completed = {...doneTurn(), event_sequence: 7, audit_status: 'unavailable', report_available: true, report: savedReport()};
    const queued = {...doneTurn(), answer: '', execution_state: 'running', status: 'started', event_sequence: 2};
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input); if (options.method === 'POST') {posts++; throw new Error('不應重送模型');}
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '保存回合', active_request_id: 'r1', messages: []});
        if (path.endsWith('/r1')) return json(transport === 'snapshot' ? completed : queued);
        if (path.endsWith('/stream')) return new Response(`id: 7\nevent: done\ndata: ${JSON.stringify(completed)}\n\n`, {headers: {'Content-Type': 'text/event-stream'}});
        if (path.endsWith('/report')) {reportReads++; throw new Error('完整報告不得再 GET');}
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    const unsubscribe = controller.subscribe(() => {
        const snapshot = controller.getSnapshot();
        if (snapshot.activeTurn?.execution_state === 'completed') {assert.equal(snapshot.reports.r1?.state, 'ready'); assert.equal(snapshot.displayMessages.at(-1)?.content, completed.answer);}
    });
    try {
        await controller.actions.openChat(); const entry = await controller.actions.loadReport('r1');
        assert.equal(entry.state, 'ready'); assert.equal(entry.report?.cards[0]?.chart_contract, 'v2');
        assert.equal(controller.getSnapshot().messages[0]?.report, undefined); assert.equal(reportReads, 0); assert.equal(posts, 0);
    } finally {unsubscribe(); controller.dispose(); environment.restore();}
});

for (const failure of ['503', 'timeout', 'network']) test(`${failure} 報告讀取可人工重載；並行重試去重且不送模型`, async () => {
    const environment = setup(); const recovery = deferred<Response>(); let reads = 0;
    const fetchImpl: typeof fetch = async (_input, options = {}) => {
        assert.notEqual(options.method, 'POST'); reads++;
        if (reads === 1) {if (failure === '503') return json({}, 503); throw failure === 'timeout' ? new DOMException('逾時', 'AbortError') : new Error('離線');}
        return recovery.promise;
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        assert.equal((await controller.actions.loadReport('r1')).state, 'retryable-error');
        assert.equal((await controller.actions.loadReport('r1')).state, 'retryable-error'); assert.equal(reads, 1);
        const first = controller.actions.retryReport('r1'), second = controller.actions.retryReport('r1');
        assert.equal(controller.getSnapshot().reports.r1?.state, 'loading'); assert.equal(reads, 2);
        recovery.resolve(json(savedReport())); const entries = await Promise.all([first, second]);
        assert.equal(entries[0].report, entries[1].report); assert.equal(entries[0].state, 'ready');
    } finally {recovery.resolve(json(savedReport())); controller.dispose(); environment.restore();}
});

test('404 是不存在而非可重試故障，未知格式保留不可用原因且不循環重試', async () => {
    const environment = setup(); let reads = 0;
    const fetchImpl: typeof fetch = async input => {reads++; return pathname(input).includes('/missing/') ? json({}, 404) : json({...savedReport('bad'), report_version: 'future-report'});};
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        assert.equal((await controller.actions.loadReport('missing')).state, 'missing');
        assert.equal((await controller.actions.retryReport('missing')).state, 'missing');
        const bad = await controller.actions.loadReport('bad'); assert.equal(bad.state, 'unavailable'); assert.match(bad.message, /版本或來源/);
        await controller.actions.retryReport('bad'); assert.equal(reads, 2);
    } finally {controller.dispose(); environment.restore();}
});

for (const invalidation of ['delete', 'sidebar-delete', 'edit', 'new-chat', 'dispose', 'close-dialog']) test(`${invalidation} 關閉明細並丟棄晚到報告，不恢復刪除或取代的資料`, async () => {
    const environment = setup(); const late = deferred<Response>(); let reads = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const row: Conversation = {conversation_id: 'c1', title: '原聊天', metadata_version: 1, messages: [{role: 'user', content: '原問題', request_id: 'r1'}, {...doneTurn(), role: 'assistant', content: '保存答案', report_available: true}]};
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', supports_message_edit: true, continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (options.method === 'DELETE') return json({deleted: true});
        if (path.endsWith('/c1')) return json(row);
        if (path.endsWith('/c2')) return json({conversation_id: 'c2', title: '另一聊天', messages: []});
        if (path.endsWith('/report')) {reads++; return late.promise;}
        if (path.endsWith('/messages') && options.method === 'POST') return json({...doneTurn(), request_id: 'new', report_available: false}, 202);
        if (path.endsWith('/new')) return json({...doneTurn(), request_id: 'new', report_available: false});
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat();
        if (invalidation === 'sidebar-delete') await controller.actions.selectConversation('c2');
        const opening = controller.actions.openReport('r1', null, 'detail');
        assert.equal(reads, 1);
        if (invalidation === 'delete' || invalidation === 'sidebar-delete') await controller.actions.deleteConversation('c1', 1);
        else if (invalidation === 'edit') await controller.actions.resubmitQuestion('r1', '修改原問題');
        else if (invalidation === 'new-chat') controller.actions.newChat();
        else if (invalidation === 'dispose') controller.dispose();
        else controller.actions.closeReport();
        late.resolve(json(savedReport())); await opening;
        assert.equal(controller.getSnapshot().reportDialog, null);
        if (invalidation !== 'close-dialog') assert.equal(controller.getSnapshot().reports.r1, undefined);
        if (['delete', 'sidebar-delete', 'edit'].includes(invalidation)) {assert.equal((await controller.actions.loadReport('r1')).state, 'missing'); assert.equal(reads, 1);}
    } finally {late.resolve(json(savedReport())); controller.dispose(); environment.restore();}
});

test('刪除已載入報告的聊天，關閉真正開啟的明細並清除 ready 快取與匯出入口', async () => {
    const environment = setup(); let reportReads = 0, exports = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (options.method === 'DELETE') return json({deleted: true});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '保存聊天', messages: [{...doneTurn(), role: 'assistant', content: '保存答案'}]});
        if (path.endsWith('/report')) {reportReads++; return json(savedReport());}
        if (path.endsWith('/export.xlsx')) {exports++; throw new Error('已刪除資料不可匯出');}
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); await controller.actions.openReport('r1', 'saved', 'detail');
        assert.equal(controller.getSnapshot().reportDialog?.requestId, 'r1'); assert.equal(controller.getSnapshot().reports.r1?.state, 'ready');
        await controller.actions.deleteConversation('c1');
        assert.equal(controller.getSnapshot().reportDialog, null); assert.equal(controller.getSnapshot().reports.r1, undefined);
        assert.equal((await controller.actions.retryReport('r1')).state, 'missing'); await controller.actions.downloadReport('r1');
        assert.equal(reportReads, 1); assert.equal(exports, 0);
    } finally {controller.dispose(); environment.restore();}
});

for (const newerFinishesFirst of [false, true]) test(`登入憑證更新後丟棄舊報告，不留下永久 loading 或覆蓋新資料（新回應先完成=${newerFinishesFirst}）`, async () => {
    const environment = setup(), oldResponse = deferred<Response>(), newResponse = deferred<Response>();
    const tokens: string[] = [];
    const fetchImpl: typeof fetch = async (_input, options = {}) => {
        assert.notEqual(options.method, 'POST');
        const token = new Headers(options.headers).get('TokenKey')!; tokens.push(token);
        return token === 'new-token' ? newResponse.promise : oldResponse.promise;
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        const oldRead = controller.actions.loadReport('r1'); assert.equal(controller.getSnapshot().reports.r1?.state, 'loading');
        environment.storage.setItem('X_BI_TokenKey', 'new-token');
        let newRead: ReturnType<typeof controller.actions.loadReport>;
        if (newerFinishesFirst) {
            newRead = controller.actions.loadReport('r1'); newResponse.resolve(json({...savedReport(), answer: '新憑證的保存資料'})); await newRead;
            oldResponse.resolve(json({...savedReport(), answer: '舊憑證的回應'})); await oldRead;
        } else {
            oldResponse.resolve(json({...savedReport(), answer: '舊憑證的回應'})); assert.equal((await oldRead).report, null);
            assert.equal(controller.getSnapshot().reports.r1, undefined, '舊請求須清除自己的 loading，讓可見訊息能用新憑證讀取');
            newRead = controller.actions.loadReport('r1'); newResponse.resolve(json({...savedReport(), answer: '新憑證的保存資料'})); await newRead;
        }
        assert.deepEqual(tokens, ['local-fixture-token', 'new-token']);
        assert.equal(controller.getSnapshot().reports.r1?.state, 'ready'); assert.equal(controller.getSnapshot().reports.r1?.report?.answer, '新憑證的保存資料');
    } finally {oldResponse.resolve(json(savedReport())); newResponse.resolve(json(savedReport())); controller.dispose(); environment.restore();}
});

for (const malformed of ['source', 'warnings']) test(`回答依據 fallback 也經統一 decoder，${malformed} 損壞時保留答案並提示原因`, async () => {
    const environment = setup(); let reads = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async input => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '保存回答', messages: [{...doneTurn(), role: 'assistant', content: '原保存答案'}]});
        reads++; throw new Error('fallback 不應讀其他資料');
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat();
        const fallback = {report_version: 'mes-report-v1', request_id: malformed === 'source' ? 'other' : 'r1', cards: [], ...(malformed === 'warnings' ? {warnings: [{unknown: true}]} : {})};
        await controller.actions.openReport('r1', null, 'evidence', fallback as unknown as Report);
        assert.equal(controller.getSnapshot().reportDialog, null); assert.ok(controller.getSnapshot().toast);
        assert.equal(controller.getSnapshot().messages[0]?.content, '原保存答案'); assert.equal(reads, 0);
    } finally {controller.dispose(); environment.restore();}
});

for (const version of ['mes-report-v1', 'mes-report-v2']) test(`控制器報告入口解析 ${version}，壞單卡保留其他保存資料`, async () => {
    const environment = setup(); let requests = 0;
    const fetchImpl: typeof fetch = async input => {
        requests++; assert.ok(pathname(input).endsWith('/r1/report'));
        assert.equal(new URL(String(input), 'http://fixture').search, '?version=2');
        return json({report_version: version, request_id: 'r1', answer: '原保存答案', cards: [
            {id: 'fixed', kind: 'machine_production', source_call_id: 'saved-source', chart_preference: null, detail: {rows: [{machine_id: 'A', produced_quantity: 0}]}},
            {id: 'bad', kind: 'semantic_query', detail: {columns: [null]}},
        ]});
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        const [first, second] = await Promise.all([controller.actions.loadReport('r1'), controller.actions.loadReport('r1')]);
        assert.equal(requests, 1); assert.equal(first.report, second.report);
        assert.equal(first.state, 'ready'); assert.equal(first.report?.answer, '原保存答案');
        assert.notEqual(first.report?.cards[0].chart_contract, 'unavailable');
        assert.equal(first.report?.cards[1].chart_contract, 'unavailable');
        assert.ok(first.report?.cards[1].chart_reason);
    } finally {controller.dispose(); environment.restore();}
});

for (const metadataFails of [false, true]) test(`設定立即生效後刷新模型與舊聊天鎖定，開新聊天不重送問題（metadata 失敗=${metadataFails}）`, async () => {
    const environment = setup();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    let applied = false, patches = 0, posts = 0;
    const profile = {mode: 'API' as const, api: {model: 'gpt-6.1-sol', reasoning_effort: 'medium'}, agent: {id: 'agent_fixture', project_id: 'proj_fixture', model: 'gpt-6-astra', reasoning_effort: 'medium'}};
    const settings: ProviderSettings = {revision: 'new', effective: profile, saved: profile, api_key: {configured: true, saved_configured: true, source: 'local', editable: true}, sources: {} as ProviderSettings['sources'], locked_fields: [], restart_required: false, apply: 'immediate', updated: true, management: {authorization: 'loopback'}, blocked_reason: null};
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'POST') {posts++; throw new Error('設定切換不能送出問題');}
        if (path.endsWith('/settings')) {assert.equal(options.method, 'PATCH'); patches++; applied = true; return json(settings);}
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false, model_name: applied ? profile.api.model : 'old-model'});
        if (path.endsWith('/c1')) return applied && metadataFails ? json({message: 'metadata 暫時不可讀'}, 503) : json({conversation_id: 'c1', title: '原聊天', messages: [], read_only: applied, read_only_reason: applied ? 'configuration_changed' : null});
        if (path.endsWith('/conversations')) return json({items: []});
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('原聊天草稿');
        const result = await controller.actions.saveProviderSettings({revision: 'old', api: {model: profile.api.model}});
        assert.equal(result.apply, 'immediate'); assert.equal(patches, 1); assert.equal(posts, 0);
        assert.equal(controller.getSnapshot().runtime?.model_name, profile.api.model);
        assert.equal(controller.getSnapshot().readOnly, true);
        assert.equal(controller.getSnapshot().inputDisabled, true);
        assert.equal(controller.getSnapshot().draft, '原聊天草稿');
        controller.actions.newChat(); await until(() => controller.getSnapshot().runtime?.model_name === profile.api.model);
        assert.equal(controller.getSnapshot().conversationId, null); assert.equal(controller.getSnapshot().readOnly, false); assert.equal(posts, 0);
    } finally {controller.dispose(); environment.restore();}
});
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(accept => {resolve = accept;}); return {promise, resolve}; }
async function until(predicate: () => boolean): Promise<void> { const deadline = Date.now() + 2000; while (!predicate() && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 0)); assert.ok(predicate(), '隔離流程應在期限內進入預期狀態'); }

for (const newerDraft of ['', '觀看故障前另寫的草稿']) test(newerDraft ? '保存觀看故障保留較新草稿，不輪詢或重送，明確停止後解除阻擋' : '保存觀看故障還原原題草稿，不偽造終態且不輪詢或重送', async () => {
    const environment = setup(); const streamResponse = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    let messagePosts = 0, snapshotReads = 0, streams = 0, cancellations = 0;
    const question = '隔離保存租約問題';
    const queued: Turn = {conversation_id: 'c1', request_id: 'r1', question, execution_state: 'queued', status: 'started', answer: '', audit_status: 'unavailable', usage_known: false, usage: null};
    const failureMessage = '聊天狀態保存尚未確認，已停止觀看，本次不會自動重送；請明確停止原回合';
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '隔離聊天', messages: []});
        if (path.endsWith('/messages') && options.method === 'POST') {messagePosts++; return json(queued, 202);}
        if (path.endsWith('/r1')) {snapshotReads++; return json(queued);}
        if (path.endsWith('/stream')) {streams++; return streamResponse.promise;}
        if (path.endsWith('/cancel') && options.method === 'POST') {cancellations++; return json({...queued, execution_state: 'cancelled', status: 'cancelled', error_message: '使用者已停止分析'});}
        if (path.endsWith('/report')) return json({}, 404);
        throw new Error('未預期隔離請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl, pollIntervalMs: 1}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft(question);
        const submitting = controller.actions.submitQuestion(); await until(() => streams === 1);
        if (newerDraft) controller.actions.setDraft(newerDraft);
        const body = [{name: 'snapshot', data: queued}, {name: 'error', data: {conversation_id: 'c2', request_id: 'r1', code: 'runtime_store_unavailable', requires_confirmation: true, message: '其他聊天的故障不可污染目前聊天'}}, {name: 'error', data: {conversation_id: 'c1', request_id: 'r1', code: 'runtime_store_unavailable', requires_confirmation: true, persisted: false, retryable: false, message: failureMessage}}].map(event => `event: ${event.name}\ndata: ${JSON.stringify(event.data)}\n\n`).join('');
        streamResponse.resolve(new Response(body, {headers: {'Content-Type': 'text/event-stream'}})); await submitting;
        const current = controller.getSnapshot();
        assert.equal(current.watchUnavailable, true); assert.equal(current.showStop, true); assert.equal(current.sendDisabled, true);
        assert.equal(current.activeTurn?.execution_state, 'queued'); assert.equal(current.unknownSubmission, false);
        assert.equal(current.draft, newerDraft || question); assert.equal(current.connectionStatus, failureMessage);
        assert.equal(current.displayMessages.at(-1)?.watch_unavailable, true);
        const savedPending = JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!);
        assert.equal(savedPending.c1.requestId, 'r1'); assert.equal(savedPending.c1.question, question);
        assert.equal(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_DRAFTS')!).c1, newerDraft || question);
        const readsAfterFailure = snapshotReads;
        await new Promise(resolve => setTimeout(resolve, 1100));
        await controller.actions.submitQuestion();
        assert.equal(snapshotReads, readsAfterFailure); assert.equal(streams, 1); assert.equal(messagePosts, 1);
        await controller.actions.cancelTurn();
        assert.equal(cancellations, 1); assert.equal(messagePosts, 1);
        const stopped = controller.getSnapshot();
        assert.equal(stopped.activeTurn?.execution_state, 'cancelled'); assert.equal(stopped.watchUnavailable, false); assert.equal(stopped.showStop, false);
        assert.equal(stopped.draft, newerDraft || question); assert.equal(stopped.sendDisabled, false);
        assert.deepEqual(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!), {});
    } finally {streamResponse.resolve(new Response('', {headers: {'Content-Type': 'text/event-stream'}})); controller.dispose(); environment.restore();}
});

for (const boundary of ['snapshot', 'stream-http', 'poll']) test(`${boundary} 儲存 HTTP503 沿用觀看故障保護，不持續輪詢或重送`, async () => {
    const environment = setup(); environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    let posts = 0, reads = 0, streams = 0;
    const question = 'HTTP 儲存故障原題';
    const queued: Turn = {conversation_id: 'c1', request_id: 'r1', question, execution_state: 'queued', status: 'started', answer: '', usage_known: false};
    const unavailable = () => json({code: 'runtime_store_unavailable', message: '聊天儲存不可用'}, 503);
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '隔離聊天', messages: []});
        if (path.endsWith('/messages') && options.method === 'POST') {posts++; return json(queued, 202);}
        if (path.endsWith('/r1')) {reads++; return boundary === 'snapshot' || boundary === 'poll' && reads > 1 ? unavailable() : json(queued);}
        if (path.endsWith('/stream')) {streams++; return boundary === 'stream-http' ? unavailable() : new Response('', {headers: {'Content-Type': 'text/event-stream'}});}
        throw new Error('未預期隔離請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl, pollIntervalMs: 1}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft(question); await controller.actions.submitQuestion();
        await until(() => controller.getSnapshot().watchUnavailable === true);
        const current = controller.getSnapshot();
        assert.equal(current.activeTurn?.execution_state, 'queued'); assert.equal(current.showStop, true);
        assert.equal(current.draft, question); assert.equal(current.sendDisabled, true); assert.equal(current.reconnectNeeded, true);
        assert.equal(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!).c1.requestId, 'r1');
        const stoppedReads = reads, stoppedStreams = streams;
        await new Promise(resolve => setTimeout(resolve, 1100)); await controller.actions.submitQuestion();
        assert.equal(posts, 1); assert.equal(reads, stoppedReads); assert.equal(streams, stoppedStreams);
    } finally {controller.dispose(); environment.restore();}
});

for (const transport of ['history', 'snapshot', 'stream']) test(`保存查詢條件與追問透過 ${transport} 完整保留，沒有新增 POST 或解析回答`, async () => {
    const environment = setup(); let posts = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const metadata = {query_scope: {date_start: '2026-08-01', date_end: '2026-08-31', machine_id: 'MC-03', work_order: 'WO-88'}, query_scope_summary: '2026 年 8 月 · 機台 MC-03 · 工單 WO-88', scope_inherited: true, follow_up_suggestions: [{title: '查看明細', prompt: '依相同條件列出工單明細'}]};
    const completed = {...doneTurn(), ...metadata, audit_status: 'saved'};
    const running = {...completed, execution_state: 'running' as const, status: 'started' as const, answer: ''};
    const frames: Turn[] = [];
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'POST') {posts++; throw new Error('保存資料驗證只讀取既有回合');}
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '查詢條件驗證', ...(transport === 'history' ? {messages: [{...completed, role: 'assistant', content: completed.answer}]} : {active_request_id: 'r1', messages: [{role: 'user', content: '保存的查詢', request_id: 'r1'}]})});
        if (path.endsWith('/r1')) return json(transport === 'stream' ? running : completed);
        if (path.endsWith('/stream')) {
            const body = [{name: 'snapshot', data: running}, {name: 'answer_delta', data: {request_id: 'r1', delta: '來源正文包含 999，不用來猜條件'}}, {name: 'done', data: completed}].map(event => `event: ${event.name}\ndata: ${JSON.stringify(event.data)}\n\n`).join('');
            return new Response(body, {headers: {'Content-Type': 'text/event-stream'}});
        }
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    const unsubscribe = controller.subscribe(() => {
        const current = controller.getSnapshot();
        if (current.activeTurn) frames.push({...current.activeTurn});
        if (current.showStop) assert.equal(getMesFollowupSource(current), null);
    });
    try {
        await controller.actions.openChat();
        const current = controller.getSnapshot();
        const message = current.displayMessages.at(-1)!;
        for (const key of ['query_scope', 'query_scope_summary', 'scope_inherited', 'follow_up_suggestions'] as const) assert.deepEqual(message[key], metadata[key]);
        assert.deepEqual(getMesFollowupSource(current)?.suggestions, metadata.follow_up_suggestions);
        assert.equal(current.displayMessages.filter(message => message.role === 'assistant').length, 1);
        if (transport === 'stream') {
            const delta = frames.find(frame => frame.answer === '來源正文包含 999，不用來猜條件');
            assert.ok(delta);
            assert.deepEqual(delta.query_scope, metadata.query_scope);
            assert.deepEqual(delta.follow_up_suggestions, metadata.follow_up_suggestions);
        }
        assert.equal(posts, 0);
    } finally {unsubscribe(); controller.dispose(); environment.restore();}
});

test('聊天切換讀取中鎖定送出，完成後還原各聊天草稿及輸入', async () => {
    const environment = setup(); const reading = deferred<Response>(); let posts = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2_DRAFTS', JSON.stringify({c1: '原聊天草稿', c2: '目標聊天草稿'}));
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '原聊天', messages: []});
        if (path.endsWith('/c2')) return reading.promise;
        if (path.endsWith('/messages') && opts.method === 'POST') {posts++; return json(doneTurn(), 202);}
        if (path.includes('/turns/')) return json(doneTurn());
        if (path.endsWith('/report')) return json({}, 404);
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat();
        const selection = controller.actions.selectConversation('c2');
        await controller.actions.submitQuestion(); assert.equal(posts, 0);
        assert.equal(controller.getSnapshot().inputDisabled, true);
        assert.equal(controller.getSnapshot().sendDisabled, true);
        reading.resolve(json({conversation_id: 'c2', title: '目標聊天', messages: []})); await selection;
        assert.equal(controller.getSnapshot().conversationId, 'c2');
        assert.equal(controller.getSnapshot().draft, '目標聊天草稿');
        assert.equal(controller.getSnapshot().inputDisabled, false);
        assert.equal(controller.getSnapshot().sendDisabled, false);
        await controller.actions.selectConversation('c1'); assert.equal(controller.getSnapshot().draft, '原聊天草稿');
    } finally {reading.resolve(json({conversation_id: 'c2', title: '目標聊天', messages: []})); controller.dispose(); environment.restore();}
});

for (const newerDraft of ['', '拒絕回應前新輸入的草稿']) test(newerDraft ? '問題確定遭拒時保留較新的草稿，不留下未保存問題或自動重送' : '問題確定遭拒時還原原草稿，重開仍保留且不自動重送', async () => {
    const environment = setup(); const rejection = deferred<Response>(); let posts = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '新聊天', messages: []});
        if (path.endsWith('/messages') && opts.method === 'POST') {posts++; return rejection.promise;}
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('  額度不足的原問題\n  ');
        const submitting = controller.actions.submitQuestion(); await until(() => posts === 1);
        if (newerDraft) controller.actions.setDraft(newerDraft);
        rejection.resolve(json({code: 'quota_exceeded', detail: '本月 Token 額度不足'}, 429)); await submitting;
        const expectedDraft = newerDraft || '  額度不足的原問題\n  ';
        assert.equal(controller.getSnapshot().draft, expectedDraft);
        assert.deepEqual(controller.getSnapshot().messages, []);
        assert.equal(controller.getSnapshot().conversationTitle, '新聊天');
        assert.equal(controller.getSnapshot().unknownSubmission, false);
        assert.deepEqual(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!), {});
        controller.actions.closeChat(); await controller.actions.openChat();
        assert.equal(controller.getSnapshot().draft, expectedDraft); assert.equal(posts, 1);
    } finally {rejection.resolve(json({}, 429)); controller.dispose(); environment.restore();}
});

test('聊天讀取失敗後解除輸入鎖定並保留原聊天草稿', async () => {
    const environment = setup(); const reading = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async input => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '原聊天', messages: []});
        if (path.endsWith('/c2')) return reading.promise;
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('保留原草稿');
        const selection = controller.actions.selectConversation('c2');
        assert.equal(controller.getSnapshot().inputDisabled, true);
        reading.resolve(json({detail: '暫時無法讀取'}, 503)); await selection;
        assert.equal(controller.getSnapshot().conversationId, 'c1');
        assert.equal(controller.getSnapshot().draft, '保留原草稿');
        assert.equal(controller.getSnapshot().inputDisabled, false);
        assert.equal(controller.getSnapshot().sendDisabled, false);
    } finally {reading.resolve(json({}, 503)); controller.dispose(); environment.restore();}
});

for (const status of [503, 404]) test(status === 503 ? '活動聊天切換讀取失敗後提供重新連線，僅GET恢復原回合' : '切換到不存在聊天時清除原活動回合，不殘留停止按鈕或舊答案', async () => {
    const environment = setup(); let streamOpened = false, completed = false, posts = 0;
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (opts.method === 'POST') posts++;
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '活動聊天', active_request_id: 'r1', messages: [{role: 'user', content: '原問題', request_id: 'r1'}]});
        if (path.endsWith('/c2')) return json({detail: '目標聊天讀取失敗'}, status);
        if (path.endsWith('/r1')) return json(completed ? doneTurn() : {...doneTurn(), execution_state: 'running', status: 'started', answer: '目前答案'});
        if (path.endsWith('/stream')) return new Response(new ReadableStream<Uint8Array>({start(stream) {
            streamOpened = true; opts.signal?.addEventListener('abort', () => stream.error(new DOMException('已停止觀看', 'AbortError')));
        }}), {headers: {'Content-Type': 'text/event-stream'}});
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        const opening = controller.actions.openChat(); await until(() => streamOpened);
        await controller.actions.selectConversation('c2'); await opening;
        if (status === 503) {
            assert.equal(controller.getSnapshot().conversationId, 'c1');
            assert.equal(controller.getSnapshot().reconnectNeeded, true);
            assert.equal(controller.getSnapshot().sendDisabled, true);
            completed = true; await controller.actions.reconnect();
            assert.equal(controller.getSnapshot().activeTurn?.execution_state, 'completed');
            assert.equal(controller.getSnapshot().reconnectNeeded, false);
            assert.deepEqual(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!), {});
        } else {
            assert.equal(controller.getSnapshot().conversationId, null);
            assert.equal(controller.getSnapshot().activeTurn, null);
            assert.deepEqual(controller.getSnapshot().displayMessages, []);
            assert.equal(controller.getSnapshot().showStop, false);
            assert.equal(controller.getSnapshot().reconnectNeeded, false);
        }
        assert.equal(posts, 0);
    } finally {controller.dispose(); environment.restore();}
});

for (const checkIsolation of [false, true]) test(checkIsolation ? '前一回合停止尚未返回時，後續回合可停止且同回合不重送' : '遲來停止回應不覆蓋後續回合或清除其 pending', async () => {
    const environment = setup(); const cancelFirst = deferred<Response>(), cancelSecond = deferred<Response>();
    const streams = new Map<string, ReadableStreamDefaultController<Uint8Array>>(); let secondPosts = 0, secondCancels = 0;
    const first: Turn = {...doneTurn(), execution_state: 'running', status: 'started', answer: ''};
    const second: Turn = {...first, request_id: 'r2'};
    const row: Conversation = {conversation_id: 'c1', title: '原聊天', active_request_id: 'r1', messages: [{role: 'user', content: '第一題', request_id: 'r1'}]};
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: [row]});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/c1')) return json(row);
        if (path.endsWith('/r1/cancel')) return cancelFirst.promise;
        if (path.endsWith('/r2/cancel')) {secondCancels++; return cancelSecond.promise;}
        if (path.endsWith('/messages') && opts.method === 'POST') {secondPosts++; return json(second, 202);}
        if (path.endsWith('/stream')) {
            const requestId = path.includes('/r1/') ? 'r1' : 'r2';
            return new Response(new ReadableStream<Uint8Array>({start(stream) {
                streams.set(requestId, stream);
                opts.signal?.addEventListener('abort', () => {try {stream.error(new DOMException('已停止觀看', 'AbortError'));} catch {/* 已結束的串流不再變更 */}});
            }}), {headers: {'Content-Type': 'text/event-stream'}});
        }
        if (path.endsWith('/r1')) return json(first);
        if (path.endsWith('/r2')) return json(second);
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        const opening = controller.actions.openChat(); await until(() => streams.has('r1'));
        const firstCancellation = controller.actions.cancelTurn();
        streams.get('r1')!.enqueue(new TextEncoder().encode('event: done\ndata: ' + JSON.stringify(doneTurn()) + '\n\n'));
        streams.get('r1')!.close(); await opening;
        controller.actions.setDraft('第二題'); const submitting = controller.actions.submitQuestion(); await until(() => streams.has('r2'));
        assert.equal(secondPosts, 1);
        let secondCancellation: Promise<void> | undefined;
        if (checkIsolation) {
            assert.equal(controller.getSnapshot().cancelling, false);
            secondCancellation = controller.actions.cancelTurn(); await controller.actions.cancelTurn();
            assert.equal(secondCancels, 1); assert.equal(controller.getSnapshot().cancelling, true);
        }
        cancelFirst.resolve(json({...first, execution_state: 'cancelled', status: 'cancelled'})); await firstCancellation;
        assert.equal(controller.getSnapshot().activeTurn?.request_id, 'r2');
        assert.equal(controller.getSnapshot().activeTurn?.execution_state, 'running');
        assert.equal(controller.getSnapshot().cancelling, checkIsolation);
        assert.equal(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!).c1.requestId, 'r2');
        if (!secondCancellation) secondCancellation = controller.actions.cancelTurn();
        cancelSecond.resolve(json({...second, execution_state: 'cancelled', status: 'cancelled'})); await secondCancellation; await submitting;
        assert.equal(controller.getSnapshot().activeTurn?.request_id, 'r2');
        assert.equal(controller.getSnapshot().activeTurn?.execution_state, 'cancelled');
        assert.equal(controller.getSnapshot().cancelling, false);
        assert.deepEqual(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!), {});
    } finally {cancelFirst.resolve(json(doneTurn())); cancelSecond.resolve(json({...second, execution_state: 'cancelled'})); controller.dispose(); environment.restore();}
});

test('同題並行只提交一次，收合重開僅讀歷史並保留草稿及唯一答案', async () => {
    const environment = setup(); let posts = 0, cancels = 0; const row: Conversation = {conversation_id: 'c1', title: '新聊天', messages: []}; let turn = doneTurn();
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) return json({detail: '沒有報告'}, 404);
        if (path.endsWith('/cancel')) { cancels++; return json(turn); }
        if (path.endsWith('/conversations') && opts.method === 'POST') return json(row, 201);
        if (path.endsWith('/conversations')) return json({items: [row], next_before_id: null});
        if (path.endsWith('/messages') && opts.method === 'POST') {
            posts++; const body = JSON.parse(String(opts.body)); turn = {...doneTurn(), client_message_id: body.client_message_id};
            row.messages = [{role: 'user', content: body.question, client_message_id: body.client_message_id, request_id: 'r1'}, {...turn, role: 'assistant', content: turn.answer!}]; return json(turn, 202);
        }
        if (path.includes('/turns/')) return json(turn);
        if (path.endsWith('/c1')) return json(row);
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('工單產量多少？');
        await Promise.all([controller.actions.submitQuestion(), controller.actions.submitQuestion()]);
        assert.equal(posts, 1); assert.equal(controller.getSnapshot().messages.filter(message => message.role === 'assistant').length, 1);
        controller.actions.setDraft('尚未送出的草稿'); controller.actions.closeChat(); await controller.actions.openChat();
        assert.equal(posts, 1); assert.equal(cancels, 0); assert.equal(controller.getSnapshot().draft, '尚未送出的草稿'); assert.equal(controller.getSnapshot().messages.filter(message => message.role === 'assistant').length, 1);
    } finally { controller.dispose(); environment.restore(); }
});

test('遺失 POST202 後保存 nonce，重建控制器不自動重送，僅 GET 恢復原回合', async () => {
    const environment = setup(); let posts = 0, found = false, clientId = '';
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/conversations') && opts.method === 'POST') return json({conversation_id: 'c1', title: '新聊天'}, 201);
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/messages') && opts.method === 'POST') { posts++; clientId = JSON.parse(String(opts.body)).client_message_id; throw new TypeError('模擬已送達但回應遺失'); }
        if (path.includes('/turns/')) return json(doneTurn());
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '工單產量多少？', messages: found ? [{role: 'user', content: '工單產量多少？', client_message_id: clientId, request_id: 'r1'}] : []});
        throw new Error('未預期請求：' + path);
    };
    const first = new ChatController({storage: environment.storage, fetchImpl}, 'X'); let restored: ChatController | null = null;
    try {
        await first.actions.openChat(); first.actions.setDraft('工單產量多少？'); await first.actions.submitQuestion();
        assert.equal(first.getSnapshot().unknownSubmission, true); assert.equal(first.getSnapshot().sendDisabled, true);
        assert.equal(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!).c1.clientMessageId, clientId);
        first.actions.closeChat(); first.dispose(); restored = new ChatController({storage: environment.storage, fetchImpl}, 'X');
        await restored.actions.openChat(); assert.equal(restored.getSnapshot().unknownSubmission, true); await restored.actions.submitQuestion(); assert.equal(posts, 1);
        found = true; await restored.actions.reconnect(); assert.equal(posts, 1); assert.equal(restored.getSnapshot().activeTurn?.execution_state, 'completed'); assert.deepEqual(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!), {});
    } finally { first.dispose(); restored?.dispose(); environment.restore(); }
});

test('重開 GET 先恢復完成，遲來的 POST202 不覆蓋完成答案或重建 pending', async () => {
    const environment = setup(); let posts = 0, clientId = ''; let accept!: (response: Response) => void;
    const deferred = new Promise<Response>(resolve => { accept = resolve; });
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/conversations') && opts.method === 'POST') return json({conversation_id: 'c1', title: '新聊天'}, 201);
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/messages') && opts.method === 'POST') { posts++; clientId = JSON.parse(String(opts.body)).client_message_id; return deferred; }
        if (path.includes('/turns/')) return json(doneTurn());
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '工單產量多少？', messages: [{role: 'user', content: '工單產量多少？', client_message_id: clientId, request_id: 'r1'}]});
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('工單產量多少？'); const submission = controller.actions.submitQuestion();
        const deadline = Date.now() + 2000; while (posts === 0 && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 0)); assert.equal(posts, 1);
        controller.actions.closeChat(); await controller.actions.openChat(); assert.equal(controller.getSnapshot().messages.filter(message => message.role === 'assistant').length, 1);
        accept(json({...doneTurn(), execution_state: 'running', status: 'started'}, 202)); await submission;
        assert.equal(posts, 1); assert.deepEqual(JSON.parse(environment.storage.getItem('X_MES_AI_CHAT_ADMINV2_TURNS')!), {}); assert.equal(controller.getSnapshot().messages.filter(message => message.role === 'assistant').length, 1); assert.equal(controller.getSnapshot().activeTurn?.execution_state, 'completed');
    } finally { controller.dispose(); environment.restore(); }
});


for (const mode of ['API', 'AGENT']) test(`${mode} 編輯從原位置重新生成、不保留舊問答並避免並行重送`, async () => {
    const environment = setup();
    const row: Conversation = {conversation_id: 'c1', title: '原聊天', messages: [
        {role: 'user', content: '原問題', request_id: 'old', client_message_id: 'old-client'},
        {role: 'assistant', content: '原答案', request_id: 'old', execution_state: 'completed', status: 'succeeded'},
    ]};
    const posts: {question: string; client_message_id: string; edit_source_request_id: string}[] = [];
    const turn = {...doneTurn(), request_id: 'new', answer: '新結果'};
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, opts = {}) => {
        const path = pathname(input);
        if (path.endsWith('/runtime')) return json({mode, continuous_context: mode === 'AGENT', supports_message_edit: true});
        if (path.endsWith('/conversations')) return json({items: [row]});
        if (path.endsWith('/report')) return json({}, 404);
        if (path.endsWith('/c1')) return json(row);
        if (path.endsWith('/messages') && opts.method === 'POST') {
            const body = JSON.parse(String(opts.body)); posts.push(body);
            row.messages = [];
            row.messages!.push({role: 'user', content: body.question, client_message_id: body.client_message_id, request_id: 'new'}, {...turn, role: 'assistant', content: '新結果'});
            return json(turn, 202);
        }
        if (path.includes('/turns/')) return json(turn);
        throw new Error('未預期請求：' + path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); controller.actions.setDraft('另一個尚未送出的草稿');
        await controller.actions.resubmitQuestion('不存在的來源', '不要送出');
        await controller.actions.resubmitQuestion('old', '   ');
        assert.equal(posts.length, 0);
        await Promise.all([controller.actions.resubmitQuestion('old', '修改後的問題'), controller.actions.resubmitQuestion('old', '修改後的問題')]);
        assert.equal(posts.length, 1);
        assert.deepEqual(Object.keys(posts[0]).sort(), ['client_message_id', 'edit_source_request_id', 'question']);
        assert.equal(posts[0].edit_source_request_id, 'old');
        assert.equal(posts[0].question, '修改後的問題');
        assert.notEqual(posts[0].client_message_id, 'old-client');
        assert.equal(controller.getSnapshot().draft, '另一個尚未送出的草稿');
        assert.deepEqual(controller.getSnapshot().messages.map(m => m.content), ['修改後的問題', '新結果']);
        controller.actions.closeChat(); await controller.actions.openChat();
        assert.equal(posts.length, 1);
        assert.equal(controller.getSnapshot().messages.length, 2);
        assert.equal(controller.getSnapshot().draft, '另一個尚未送出的草稿');
    } finally {controller.dispose(); environment.restore();}
});


for (const leave of ['switch', 'close'] as const) test(`離開聊天後丟棄遲到呈現保存：${leave}`, async () => {
    const environment = setup(), pending = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'PUT') return pending.promise;
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) return json(editableReport());
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', messages: [{...doneTurn(), role: 'assistant', content: '保存答案'}]});
        if (path.endsWith('/c2')) return json({conversation_id: 'c2', messages: []});
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); await controller.actions.loadReport('r1');
        const saving = controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']});
        if (leave === 'switch') await controller.actions.selectConversation('c2');
        else controller.actions.closeChat();
        pending.resolve(json(editableReport(1)));
        assert.equal(await saving, false);
        assert.deepEqual(controller.getSnapshot().presentationSaving, []);
        assert.notEqual(controller.getSnapshot().reports.r1?.report?.view_preferences?.revision, 1);
    } finally {pending.resolve(json(editableReport(1))); controller.dispose(); environment.restore();}
});


for (const exit of ['stay', 'switch', 'delete'] as const) test(`報告 GET、呈現 PUT 與分析交錯：${exit} 保留同一保存來源與版本`, async () => {
    const environment = setup(), oldReport = deferred<Response>(), mainTurn = deferred<Response>(), write = deferred<Response>(), analysis = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    let turnReads = 0, reportReads = 0, writes = 0, analysisReads = 0, posts = 0;
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'POST') {posts++; throw new Error('保存結果不得重新生成');}
        if (options.method === 'DELETE') return json({deleted: true});
        if (path.endsWith('/presentation')) {writes++; return write.promise;}
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: []});
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', title: '原聊天', active_request_id: 'r1', messages: []});
        if (path.endsWith('/c2')) return json({conversation_id: 'c2', title: '另一聊天', messages: []});
        if (path.endsWith('/r1')) {turnReads++; return mainTurn.promise;}
        if (path.endsWith('/a1')) {analysisReads++; return analysis.promise;}
        if (path.endsWith('/report')) {reportReads++; return oldReport.promise;}
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl, pollIntervalMs: 10}, 'X');
    let stopAnalysis = () => {};
    try {
        const opening = controller.actions.openChat(); await until(() => turnReads === 1);
        const reading = controller.actions.loadReport('r1');
        mainTurn.resolve(json({...doneTurn(), event_sequence: 7, report: editableReport(), supplementary_analysis: {request_id: 'a1', state: 'pending', findings: []}})); await opening;
        controller.actions.setDraft('八月也要看');
        stopAnalysis = controller.actions.observeSupplementaryAnalysis('r1');
        const saving = controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']});
        assert.equal(analysisReads, 1); assert.equal(writes, 1);
        if (exit === 'switch') await controller.actions.selectConversation('c2');
        else if (exit === 'delete') await controller.actions.deleteConversation('c1');
        write.resolve(json(editableReport(1))); assert.equal(await saving, exit === 'stay');
        oldReport.resolve(json(editableReport())); await reading;
        analysis.resolve(json({conversation_id: 'c1', request_id: 'a1', event_sequence: 2, supplementary_analysis: {request_id: 'a1', state: 'no_signal', findings: []}}));
        if (exit === 'stay') {
            await until(() => controller.getSnapshot().messages.some(message => message.supplementary_analysis?.state === 'no_signal'));
            assert.equal(controller.getSnapshot().reports.r1.report?.view_preferences?.revision, 1);
            assert.equal(controller.getSnapshot().messages[0].content, doneTurn().answer);
            assert.equal(controller.getSnapshot().draft, '八月也要看'); assert.equal(controller.getSnapshot().sendDisabled, false);
        } else {
            await new Promise(resolve => setTimeout(resolve, 20));
            assert.equal(controller.getSnapshot().messages.some(message => message.request_id === 'r1'), false);
            assert.notEqual(controller.getSnapshot().reports.r1?.report?.view_preferences?.revision, 1);
            if (exit === 'delete') {
                assert.equal(controller.getSnapshot().reports.r1, undefined);
                assert.equal((await controller.actions.loadReport('r1')).state, 'missing');
            }
        }
        assert.deepEqual(controller.getSnapshot().presentationSaving, []);
        assert.equal(posts, 0); assert.equal(reportReads, 1); assert.equal(writes, 1); assert.equal(analysisReads, 1);
    } finally {
        stopAnalysis(); oldReport.resolve(json(editableReport())); mainTurn.resolve(json(doneTurn())); write.resolve(json(editableReport(1))); analysis.resolve(json({})); controller.dispose(); environment.restore();
    }
});


for (const exit of ['switch', 'close'] as const) test(`未確認的呈現 PUT 在 ${exit} 後重開，以 GET 確認伺服器版本且不重送`, async () => {
    const environment = setup(), pending = deferred<Response>();
    environment.storage.setItem('X_MES_AI_CHAT_ADMINV2', JSON.stringify('c1'));
    let persisted = editableReport(), reads = 0, writes = 0;
    const fetchImpl: typeof fetch = async (input, options = {}) => {
        const path = pathname(input);
        if (options.method === 'PUT') {writes++; persisted = editableReport(1); return pending.promise;}
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/report')) {reads++; return json(persisted);}
        if (path.endsWith('/c1')) return json({conversation_id: 'c1', messages: [{...doneTurn(), role: 'assistant', content: '保存答案', report_available: true}]});
        if (path.endsWith('/c2')) return json({conversation_id: 'c2', messages: []});
        throw new Error(path);
    };
    const controller = new ChatController({storage: environment.storage, fetchImpl}, 'X');
    try {
        await controller.actions.openChat(); await controller.actions.loadReport('r1');
        const saving = controller.actions.savePresentation('r1', 'saved', {mark: 'point', metrics: ['produced_quantity']});
        if (exit === 'switch') await controller.actions.selectConversation('c2');
        else controller.actions.closeChat();
        pending.resolve(json(persisted)); assert.equal(await saving, false);
        if (exit === 'switch') await controller.actions.selectConversation('c1');
        else await controller.actions.openChat();
        const restored = await controller.actions.loadReport('r1');
        assert.equal(restored.report?.view_preferences?.revision, 1);
        assert.equal(restored.report?.view_preferences?.selections[0].mark, 'point');
        assert.equal(reads, 2); assert.equal(writes, 1);
    } finally {pending.resolve(json(persisted)); controller.dispose(); environment.restore();}
});
