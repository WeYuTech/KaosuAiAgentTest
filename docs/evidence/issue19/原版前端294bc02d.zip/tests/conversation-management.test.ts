import test from 'node:test';
import assert from 'node:assert/strict';
import {ChatController} from '../src/chat/controller';
import {groupConversations} from '../src/chat/core';
import type {Conversation} from '../src/chat/types';

class MemoryStorage implements Storage {
    values = new Map<string, string>();
    get length() { return this.values.size; }
    key(i: number) { return [...this.values.keys()][i] || null; }
    getItem(key: string) { return this.values.get(key) || null; }
    setItem(key: string, value: string) { this.values.set(key, value); }
    removeItem(key: string) { this.values.delete(key); }
    clear() { this.values.clear(); }
}
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {status, headers: {'Content-Type': 'application/json'}});
function setup(customFetch?: typeof fetch) {
    const storage = new MemoryStorage();
    storage.setItem('X_BI_accountNo', 'ADMINV2'); storage.setItem('X_BI_TokenKey', 'fixture'); storage.setItem('X_BI_TokenExpiry', new Date(Date.now() + 3600000).toISOString());
    const oldWindow = globalThis.window; globalThis.window = {addEventListener() {}, removeEventListener() {}} as unknown as Window & typeof globalThis;
    const rows: Conversation[] = [
        {conversation_id: 'c1', title: '生產進度', metadata_version: 0, messages: [{role: 'assistant', content: '保存答案'}]},
        {conversation_id: 'c2', title: '班別產量', metadata_version: 0, messages: []},
        {conversation_id: 'legacy-old', title: '舊版紀錄', metadata_version: 0, read_only: true, read_only_reason: 'legacy_history', legacy: true, messages: []},
    ];
    let busy = false; let historyFailed = false;
    const calls: {url: URL; method: string}[] = [];
    const fetchImpl: typeof fetch = customFetch || (async (input, options = {}) => {
        const url = new URL(String(input), 'http://fixture'); const method = options.method || 'GET'; const body = options.body ? JSON.parse(String(options.body)) : {};
        calls.push({url, method});
        if (url.pathname.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (url.pathname.endsWith('/conversations')) return historyFailed ? json({detail: '歷史服務暫時中斷'}, 503) : json({items: rows.filter(row => !row.deleted && !!row.is_archived === (url.searchParams.get('archived') === 'true')).sort((a, b) => Number(!!b.is_pinned) - Number(!!a.is_pinned)), next_before_id: null});
        const row = rows.find(item => url.pathname.endsWith('/' + item.conversation_id));
        if (!row || row.deleted) return json({detail: '找不到聊天'}, 404);
        if (method === 'PATCH' || method === 'DELETE') {
            const version = method === 'PATCH' ? body.metadata_version : Number(url.searchParams.get('metadata_version'));
            if (version !== row.metadata_version) return json({detail: '聊天已更新，請重新讀取。'}, 409);
            if (busy && (method === 'DELETE' || body.is_archived === true)) return json({detail: '這份聊天仍在分析或等待確認。'}, 409);
            const next = row.metadata_version! + 1;
            if (method === 'DELETE') { row.deleted = true; row.metadata_version = next; return json({conversation_id: row.conversation_id, deleted: true, metadata_version: next}); }
            Object.assign(row, body, {metadata_version: next});
            row.read_only = !!row.is_archived || !!row.legacy; row.read_only_reason = row.is_archived ? 'archived' : row.legacy ? 'legacy_history' : null;
        }
        return json(row);
    });
    const controller = new ChatController({storage, fetchImpl}, 'X');
    return {controller, storage, rows, calls, setBusy(value: boolean) { busy = value; }, setHistoryFailed(value: boolean) {historyFailed = value;}, dispose() { controller.dispose(); globalThis.window = oldWindow; }};
}

test('重新命名與釘選保存版本，保留訊息及草稿，不送出問題或取消請求', async () => {
    const f = setup(); const a = f.controller.actions;
    try {
        await a.openChat(); await a.loadHistory(); await a.selectConversation('c1'); a.setDraft('未送出草稿');
        assert.equal((await a.updateConversation('c1', {title: '重新命名'}, 0)).metadata_version, 1);
        await a.updateConversation('c1', {is_pinned: true}, 1);
        const state = f.controller.getSnapshot();
        assert.equal(state.conversationTitle, '重新命名'); assert.equal(state.draft, '未送出草稿'); assert.equal(state.messages[0].content, '保存答案');
        assert.equal(state.conversations[0].is_pinned, true); assert.deepEqual(state.conversationSaving, []);
        assert.equal(f.calls.filter(call => call.method === 'POST').length, 0);
    } finally { f.dispose(); }
});
test('封存回看與還原、舊版管理、刪除後僅清除目標聊天草稿', async () => {
    const f = setup(); const a = f.controller.actions;
    try {
        await a.openChat(); await a.loadHistory(); await a.selectConversation('c2'); a.setDraft('別的草稿');
        await a.selectConversation('c1'); a.setDraft('目標草稿'); await a.updateConversation('c1', {is_archived: true}, 0);
        assert.equal(f.controller.getSnapshot().conversationId, null);
        await a.showArchivedConversations(true); assert.deepEqual(f.controller.getSnapshot().conversations.map(row => row.conversation_id), ['c1']);
        await a.selectConversation('c1'); assert.equal(f.controller.getSnapshot().readOnly, true); assert.match(f.controller.getSnapshot().readOnlyNotice, /封存/);
        await a.updateConversation('c1', {is_archived: false}, 1); assert.equal(f.controller.getSnapshot().readOnly, false);
        await a.showArchivedConversations(false); await a.updateConversation('legacy-old', {is_pinned: true}, 0); assert.equal(f.controller.getSnapshot().conversations[0].legacy, true);
        await a.deleteConversation('c1', 2); assert.equal(f.controller.getSnapshot().conversationId, null);
        const drafts = JSON.parse(f.storage.getItem('X_MES_AI_CHAT_ADMINV2_DRAFTS')!);
        assert.equal(drafts.c1, undefined); assert.equal(drafts.c2, '別的草稿'); assert.equal(f.storage.getItem('X_MES_AI_CHAT_ADMINV2'), 'null');
        assert.equal(f.calls.filter(call => call.method === 'POST').length, 0);
    } finally { f.dispose(); }
});
test('活動封存與刪除409保留目前聊天、草稿及答案，改名仍可執行', async () => {
    const f = setup(); const a = f.controller.actions;
    try {
        await a.openChat(); await a.loadHistory(); await a.selectConversation('c1'); a.setDraft('持續保留'); f.setBusy(true);
        await assert.rejects(a.updateConversation('c1', {is_archived: true}, 0), error => (error as {status?: number}).status === 409);
        await assert.rejects(a.deleteConversation('c1', 0), error => (error as {status?: number}).status === 409);
        const state = f.controller.getSnapshot(); assert.equal(state.conversationId, 'c1'); assert.equal(state.draft, '持續保留'); assert.equal(state.messages[0].content, '保存答案');
        await a.updateConversation('c1', {title: '仍可命名'}, 0); assert.equal(f.calls.filter(call => call.method === 'POST').length, 0);
    } finally { f.dispose(); }
});
test('歷史視圖切換拒絕遲來舊頁，opaque游標原樣傳送且不重複項目', async () => {
    let resolveOld!: (response: Response) => void; let first = true; let cursorSent = '';
    const f = setup(async input => {
        const url = new URL(String(input), 'http://fixture');
        if (first) { first = false; return new Promise<Response>(resolve => { resolveOld = resolve; }); }
        cursorSent = url.searchParams.get('before_id') || '';
        return json({items: [{conversation_id: 'archived', title: '封存', is_archived: true}], next_before_id: cursorSent ? null : 'opaque+/=游標'});
    });
    try {
        const old = f.controller.actions.loadHistory(); await f.controller.actions.showArchivedConversations(true);
        resolveOld(json({items: [{conversation_id: 'old', title: '遲來舊頁'}]})); await old;
        assert.equal(f.controller.getSnapshot().historyArchived, true); assert.equal(f.controller.getSnapshot().conversations[0].conversation_id, 'archived');
        await f.controller.actions.loadHistory(false); assert.equal(cursorSent, 'opaque+/=游標'); assert.equal(f.controller.getSnapshot().conversations.length, 1);
    } finally { f.dispose(); }
});
test('釘選跨日期置頂且不修改來源排序或日期', () => {
    const rows = [{title: '今日', updated_at: '2026-10-07T12:00:00+08:00'}, {title: '舊釘選', updated_at: '2026-08-20T12:00:00+08:00', is_pinned: true}];
    const before = JSON.stringify(rows); const groups = groupConversations(rows, '2026-10-07T15:00:00+08:00');
    assert.equal(groups[0].label, '已釘選'); assert.equal(groups[0].items[0].title, '舊釘選'); assert.equal(JSON.stringify(rows), before);
});

test('版本衝突後明確重新讀取不換聊天或清除草稿，重複操作不並行提交', async () => {
    const f = setup(); const a = f.controller.actions;
    try {
        await a.openChat(); await a.loadHistory(); await a.selectConversation('c1'); a.setDraft('聊天草稿');
        f.rows[0].metadata_version = 1; f.rows[0].title = '另一個視窗更新';
        await assert.rejects(a.updateConversation('c1', {title: '我的名稱'}, 0), error => (error as {status?: number}).status === 409);
        const metadata = await a.loadConversationMetadata('c1'); assert.equal(metadata.metadata_version, 1);
        assert.equal(f.controller.getSnapshot().conversationId, 'c1'); assert.equal(f.controller.getSnapshot().draft, '聊天草稿'); assert.equal(f.controller.getSnapshot().messages[0].content, '保存答案');
        const results = await Promise.allSettled([a.updateConversation('c1', {title: '我的名稱'}, 1), a.deleteConversation('c1', 1)]);
        assert.equal(results[0].status, 'fulfilled'); assert.equal(results[1].status, 'rejected');
        assert.equal(f.calls.filter(call => call.method === 'DELETE').length, 0); assert.equal(f.calls.filter(call => call.method === 'POST').length, 0);
    } finally { f.dispose(); }
});

test('串流中改名釘選及讀取metadata沿用原SSE，不取消或重送問題', async () => {
    const row: Conversation = {conversation_id: 'c1', title: '生成中', metadata_version: 0, active_request_id: 'r1', messages: []};
    let stream!: ReadableStreamDefaultController<Uint8Array>; let opened = false; let aborts = 0; let posts = 0; let streams = 0;
    const f = setup(async (input, options = {}) => {
        const url = new URL(String(input), 'http://fixture'); const path = url.pathname;
        if (options.method === 'POST') posts++;
        if (path.endsWith('/runtime')) return json({mode: 'API', continuous_context: false});
        if (path.endsWith('/conversations')) return json({items: [row]});
        if (path.endsWith('/stream')) {
            streams++; opened = true;
            options.signal?.addEventListener('abort', () => {aborts++;});
            return new Response(new ReadableStream({start(controller) {stream = controller;}}), {headers: {'Content-Type': 'text/event-stream'}});
        }
        if (path.includes('/turns/')) return json({conversation_id: 'c1', request_id: 'r1', execution_state: 'running', status: 'started', answer: '目前回答'});
        if (path.endsWith('/report')) return json({}, 404);
        if (options.method === 'PATCH') Object.assign(row, JSON.parse(String(options.body)), {metadata_version: row.metadata_version! + 1});
        return json(row);
    });
    let selection: Promise<void> | null = null;
    try {
        await f.controller.actions.openChat(); selection = f.controller.actions.selectConversation('c1');
        const deadline = Date.now() + 2000; while (!opened && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 0)); assert.ok(opened);
        f.controller.actions.setDraft('下一題草稿');
        await f.controller.actions.updateConversation('c1', {title: '新名稱'}, 0);
        await f.controller.actions.updateConversation('c1', {is_pinned: true}, 1);
        await f.controller.actions.loadConversationMetadata('c1');
        assert.equal(f.controller.getSnapshot().activeTurn?.answer, '目前回答'); assert.equal(f.controller.getSnapshot().draft, '下一題草稿');
        assert.equal(streams, 1); assert.equal(aborts, 0); assert.equal(posts, 0);
        stream.enqueue(new TextEncoder().encode('event: done\ndata: ' + JSON.stringify({conversation_id: 'c1', request_id: 'r1', execution_state: 'completed', status: 'succeeded', answer: '完整回答'}) + '\n\n'));
        stream.close(); await selection; assert.equal(f.controller.getSnapshot().messages[0].content, '完整回答');
    } finally { f.dispose(); }
});

test('封存已成功但歷史刷新503時，目標仍移出正常清單且其他聊天保留', async () => {
    const f = setup(); const a = f.controller.actions;
    try {
        await a.openChat(); await a.loadHistory(); f.setHistoryFailed(true);
        await a.updateConversation('c1', {is_archived: true}, 0);
        assert.ok(!f.controller.getSnapshot().conversations.some(row => row.conversation_id === 'c1'));
        assert.ok(f.controller.getSnapshot().conversations.some(row => row.conversation_id === 'c2'));
        assert.match(f.controller.getSnapshot().historyStatus, /歷史服務/);
    } finally {f.dispose();}
});
