import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import type {Message} from '../src/chat/types';

const scoped = register({namespace: 'visible-report', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {messageHasReport, observeVisibleReport} = await scoped.import('../src/features/mes/useVisibleReport.ts', import.meta.url) as typeof import('../src/features/mes/useVisibleReport');

test('只在訊息進入可見範圍載入一次；cleanup 丟棄已排程的遲到通知', () => {
    const original = globalThis.IntersectionObserver;
    let callback!: IntersectionObserverCallback, observations = 0, disconnected = 0, loads = 0;
    class Observer {
        constructor(value: IntersectionObserverCallback) {callback = value;}
        observe() {observations++;}
        disconnect() {disconnected++;}
    }
    globalThis.IntersectionObserver = Observer as unknown as typeof IntersectionObserver;
    try {
        const stop = observeVisibleReport({} as Element, () => {loads++;});
        assert.equal(observations, 1); assert.equal(loads, 0);
        callback([{isIntersecting: false}] as IntersectionObserverEntry[], {} as IntersectionObserver); assert.equal(loads, 0);
        callback([{isIntersecting: true}] as IntersectionObserverEntry[], {} as IntersectionObserver); assert.equal(loads, 1);
        callback([{isIntersecting: true}] as IntersectionObserverEntry[], {} as IntersectionObserver); assert.equal(loads, 1); stop();
        const hidden = observeVisibleReport({} as Element, () => {loads++;}); hidden();
        callback([{isIntersecting: true}] as IntersectionObserverEntry[], {} as IntersectionObserver); assert.equal(loads, 1); assert.ok(disconnected >= 3);
    } finally {globalThis.IntersectionObserver = original;}
});

test('保存報告不由 Audit 狀態阻擋；沒有可用旗標或非完成訊息保留相容邊界', () => {
    const completed: Message = {role: 'assistant', content: '保存回答', request_id: 'saved', execution_state: 'completed', status: 'succeeded', report_available: true, audit_status: 'unavailable'};
    assert.equal(messageHasReport(completed), true);
    assert.equal(messageHasReport({...completed, report_available: false}), false);
    assert.equal(messageHasReport({...completed, execution_state: 'running', status: 'started'}), false);
    assert.equal(messageHasReport({...completed, role: 'user'}), false);
    assert.equal(messageHasReport({...completed, request_id: undefined}), false);
    assert.equal(messageHasReport({role: 'assistant', request_id: 'legacy', content: '舊保存答案'}), true);
    assert.equal(messageHasReport({...completed, execution_state: 'failed', status: 'failed', report_available: undefined}), false);
});
