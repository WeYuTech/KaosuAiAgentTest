import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import {register as registerLoader} from 'node:module';
import {fileURLToPath} from 'node:url';
import {register} from 'tsx/esm/api';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import type {ChatActions, ChatState} from '../src/chat/types';

// SSR 只核對真實按鈕與 runtime 能力；CSS 已由正式 build 獨立驗證。
registerLoader('data:text/javascript,' + encodeURIComponent('export async function load(url, context, nextLoad) { if (new URL(url).pathname.endsWith(".css")) return {format:"module", source:"export default {}", shortCircuit:true}; return nextLoad(url, context); }'), import.meta.url);
const scoped = register({namespace: 'composer-store-failure', tsconfig: fileURLToPath(new URL('../tsconfig.app.json', import.meta.url))});
after(() => scoped.unregister());
const {ComposerPrimitive, ThreadPrimitive} = await scoped.import('@assistant-ui/react', import.meta.url) as typeof import('@assistant-ui/react');
const {MesAssistantProvider} = await scoped.import('../src/chat/assistant-runtime.tsx', import.meta.url) as typeof import('../src/chat/assistant-runtime');
const {MesUiProvider} = await scoped.import('../src/chat/mes-ui-context.tsx', import.meta.url) as typeof import('../src/chat/mes-ui-context');
const {ComposerAction} = await scoped.import('../src/components/assistant-ui/elements/thread.aui.tsx', import.meta.url) as typeof import('../src/components/assistant-ui/elements/thread.aui');
const {Button} = await scoped.import('../src/components/ui/button.tsx', import.meta.url) as typeof import('../src/components/ui/button');

function state(overrides: Partial<ChatState> = {}): ChatState {
    return {enabled: true, opened: true, expanded: false, historyOpen: false, view: 'chat', runtime: {mode: 'API', continuous_context: false}, conversationId: 'isolated-conversation', conversationTitle: '隔離保存故障', conversation: null, conversations: [], historyCursor: null, historyLoading: false, historyLoaded: true, historyStatus: '', historyArchived: false, conversationSaving: [], messages: [], activeTurn: {conversation_id: 'isolated-conversation', request_id: 'isolated-request', execution_state: 'queued'}, displayMessages: [], draft: '保留的原題', submitting: false, cancelling: false, connectionStatus: '保存尚未確認', sessionNotice: '', expired: false, readOnly: false, readOnlyNotice: '', hint: '', sendDisabled: true, inputDisabled: false, showStop: true, unknownSubmission: false, reconnectNeeded: true, watchUnavailable: true, reports: {}, exporting: [], feedbackSaving: [], reportDialog: null, metrics: [], metricsStatus: '', toast: null, ...overrides};
}

function render(overrides: Partial<ChatState> = {}) {
    const props = {state: state(overrides), actions: {cancelTurn: async () => {}} as ChatActions};
    return renderToStaticMarkup(createElement(MesUiProvider, props,
        createElement(MesAssistantProvider, props, createElement(ThreadPrimitive.Root, null,
            createElement(ComposerPrimitive.Root, null,
                createElement(ComposerPrimitive.Cancel, {asChild: true}, createElement(Button, {'aria-label': '官方取消能力驗證'})),
                createElement(ComposerAction))))));
}

test('真實 primitive 無生成能力時不能取消，但保存故障的唯一停止按鈕仍可使用', () => {
    const html = render();
    const primitive = html.match(/<button[^>]*aria-label="官方取消能力驗證"[^>]*>/)![0];
    const actual = html.match(/<button[^>]*aria-label="停止分析"[^>]*>/)![0];
    assert.match(primitive, /disabled=""/);
    assert.doesNotMatch(actual, /disabled=""/);
    assert.match(actual, /type="button"/);
    assert.equal((html.match(/aria-label="停止分析"/g) || []).length, 1);
});

test('保存故障停止要求仍遵守登入與取消中阻擋，不恢復轉圈能力', () => {
    for (const overrides of [{expired: true}, {cancelling: true}, {showStop: false, submitting: true}]) {
        const html = render(overrides);
        assert.match(html.match(/<button[^>]*aria-label="停止分析"[^>]*>/)![0], /disabled=""/);
    }
});
