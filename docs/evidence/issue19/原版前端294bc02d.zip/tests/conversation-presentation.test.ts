import test from 'node:test';
import assert from 'node:assert/strict';
import {hasDataLimitation} from '../src/chat/conversation-presentation';
import {statusText} from '../src/chat/report';
import {saveAssistantMessage} from '../src/chat/core';
import type {Turn} from '../src/chat/types';

const clarification: Turn = {request_id: 'r1', conversation_id: 'c1', execution_state: 'completed', status: 'insufficient_data', response_kind: 'clarification', answer: '要查哪一年？'};

test('澄清是等待條件而不是 MES 缺資料，舊回答仍保留原警告', () => {
    assert.equal(hasDataLimitation(clarification), false);
    assert.equal(statusText(clarification), '等待補充條件');
    assert.equal(hasDataLimitation({...clarification, response_kind: undefined}), true);
    assert.equal(hasDataLimitation({...clarification, response_kind: 'insufficient_data'}), true);
    assert.equal(statusText({...clarification, execution_state: 'failed'}), '分析失敗');
    assert.equal(hasDataLimitation(null), false);
});

test('實際工具資料不足不能被 clarification 或 rewrite 標記掩蓋', () => {
    const evidence = [{tool_name: 'example', status: 'no_data'}];
    assert.equal(hasDataLimitation({...clarification, evidence}), true);
    assert.equal(hasDataLimitation({...clarification, response_kind: 'rewrite'}), true);
});

test('新回應種類與保存來源經原訊息合併保留，不重複建立訊息', () => {
    let messages = saveAssistantMessage([], clarification);
    const rewritten: Turn = {...clarification, response_kind: 'rewrite', source_request_id: 'original', answer: '短版', status: 'succeeded'};
    messages = saveAssistantMessage(messages, rewritten);
    assert.equal(messages.length, 1);
    assert.equal(messages[0]?.source_request_id, 'original');
    assert.equal(messages[0]?.response_kind, 'rewrite');
    assert.equal(messages[0]?.content, '短版');
});

test('回答核對或任務失敗明確標成未完成，實際資料缺項仍保留', () => {
    for (const reason of ['verification_failed', 'task_incomplete'] as const) {
        const failed: Turn = {...clarification, response_kind: 'insufficient_data', result_reasons: [reason]};
        assert.equal(hasDataLimitation(failed), false);
        assert.equal(statusText(failed), '回答未完成');
        assert.equal(hasDataLimitation({...failed, evidence: [{tool_name: 'fixture', status: 'no_data'}]}), true);
        assert.equal(saveAssistantMessage([], failed)[0]?.result_reasons?.[0], reason);
    }
    assert.equal(hasDataLimitation({...clarification, response_kind: 'insufficient_data', result_reasons: ['unsupported_capability']}), false);
    assert.equal(hasDataLimitation({...clarification, response_kind: 'insufficient_data', result_reasons: ['data_unavailable']}), true);
});

test('明確未支援的要求顯示部分未支援，不能以完成標籤冒稱已成功轉換', () => {
    const unsupported: Turn = {...clarification, response_kind: 'insufficient_data', result_reasons: ['unsupported_capability']};
    assert.equal(statusText(unsupported), '部分要求未支援');
    assert.equal(hasDataLimitation(unsupported), false);
    assert.equal(statusText({...unsupported, result_reasons: ['unsupported_capability', 'verification_failed']}), '回答未完成');
    assert.equal(statusText({...unsupported, result_reasons: ['unsupported_capability', 'data_unavailable']}), '部分要求未支援');
    assert.equal(hasDataLimitation({...unsupported, result_reasons: ['unsupported_capability', 'data_unavailable']}), true);
    assert.equal(statusText({...unsupported, status: 'succeeded', result_reasons: null}), '已完成');
});
